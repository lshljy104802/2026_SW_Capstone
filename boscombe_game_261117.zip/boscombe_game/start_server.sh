#!/bin/sh
# 보스콤 밸리 게임 서버 실행 (배포자 PC)
cd "$(dirname "$0")" && python3 server/server.py --model qwen2.5:7b "$@"
