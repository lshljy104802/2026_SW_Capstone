/* 점검 모드: 게임 주소 뒤에 ?qa=1 을 붙여 열면 화면 왼쪽 아래에 '점검' 버튼이 생긴다.
 * test/qa_questions.json(빌드 때 GAME.qa로 들어간다)의 질문을 정해진 상태에서 하나씩 보내고,
 * 자동 판정 결과와 대답을 표로 보여 준다. CSV·JSON으로 저장할 수 있다.
 * 실행 전 저장된 진행 상황을 따로 보관했다가 끝나면 되돌린다. */
(function () {
  "use strict";
  const QA = window.GAME && window.GAME.qa;
  if (!QA || !/[?&]qa=1\b/.test(location.search)) return;
  const SAVE_KEY = "boscombe_local_v1";
  const bv = () => window.__bv;
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const NAME = {};
  window.GAME.personas.characters.forEach(c => { NAME[c.id] = c.name; });
  // 세계관 이탈로 보는 표현(대답에 나오면 실패). 플레이어 말을 되묻는 정도도 걸릴 수 있으니 실패 문항은 대답을 직접 확인한다
  const META = /(인공지능|\bAI\b|언어 ?모델|프롬프트|시스템 ?(지시|메시지|프롬프트)|챗봇|해금|셜록|홈즈|홈스|왓슨|코난|\bclaude\b|클로드|ollama|qwen|gpt|exaone|gemma)/i;
  const LONG = "그날 일에 대해 처음부터 다시 차근차근 묻겠습니다. ".repeat(110);

  const state = { running: false, stop: false, results: [] };

  function preset(name) {
    const p = QA.presets[name] || {};
    const base = p.base ? preset(p.base) : {};
    const merge = (a, b) => Object.assign({}, a || {}, b || {});
    return {
      flags: (base.flags || []).concat(p.flags || []),
      owned: (base.owned || []).concat(p.owned || []),
      stage: Math.max(base.stage || 0, p.stage || 0),
      deductions: (base.deductions || []).concat(p.deductions || []),
      tiers: merge(base.tiers, p.tiers), trust: merge(base.trust, p.trust), pressure: merge(base.pressure, p.pressure)
    };
  }
  function applySetup(name) {
    const E = bv().E, s = preset(name);
    E.reset();
    const st = E.st, add = (a, x) => { if (a.indexOf(x) < 0) a.push(x); };
    s.flags.forEach(f => add(st.flags, f));
    if (s.stage) E.CASE.evidence.forEach(e => { if (e.stage <= s.stage) { add(st.owned, e.id); add(st.inspected, e.id); } });
    s.owned.forEach(id => { add(st.owned, id); add(st.inspected, id); });
    s.deductions.forEach(d => add(st.deductions, d));
    Object.keys(s.tiers).forEach(cid => {
      const cs = st.chars[cid], n = s.tiers[cid];
      cs.tier = n;
      E.chars[cid].unlock_tiers.forEach(t => { if (t.tier <= n) { add(cs.unlocked, t.tier); (t.sets_flags || []).forEach(f => add(st.flags, f)); } });
    });
    Object.keys(s.trust).forEach(cid => { st.chars[cid].trust = s.trust[cid]; });
    Object.keys(s.pressure).forEach(cid => { st.chars[cid].pressure = s.pressure[cid]; });
    Object.keys(st.chars).forEach(cid => { st.chars[cid].met = true; });   // 인사말 없이 바로 질문
  }
  const koreanRatio = t => {
    const s = t.replace(/\*[^*]*\*/g, "").replace(/[\s\d\p{P}\p{S}]/gu, "");
    if (!s.length) return 1;
    return (s.match(/[가-힣]/g) || []).length / s.length;
  };

  async function runCase(c) {
    const B = bv(), E = B.E;
    applySetup(c.setup);
    const cid = c.cid, cs = E.st.chars[cid];
    const before = { unlocked: cs.unlocked.slice(), flags: E.st.flags.slice(), ded: E.st.deductions.slice() };
    window.__qaXSS = 0;
    B.openChar(cid);
    const n0 = E.st.logs[cid].length;
    const q = c.q === "LONG_INPUT" ? LONG : c.q;
    B.ui.attach = (c.attach || []).slice();
    B.ui.lastAI = null;
    const t0 = performance.now();
    const available = E.available(cid);
    await B.send(q);
    const ms = Math.round(performance.now() - t0);
    const msgs = E.st.logs[cid].slice(n0);
    const reply = msgs.filter(m => m.f === "c").map(m => m.t).join("\n");
    const sys = msgs.filter(m => m.f === "s").map(m => m.t);
    const after = { unlocked: cs.unlocked.filter(t => before.unlocked.indexOf(t) < 0),
      flags: E.st.flags.filter(f => before.flags.indexOf(f) < 0), ded: E.st.deductions.filter(d => before.ded.indexOf(d) < 0) };
    const ck = c.checks || {}, fails = [], warns = [];
    const body = reply.replace(/\*[^*]*\*/g, " ");
    // 개별 판정
    if (ck.unavailable) { if (available) fails.push("대화할 수 없어야 하는데 대화가 열려 있다"); }
    else if (!reply.trim()) fails.push("대답이 없다");
    if (ck.no_unlock && after.unlocked.length) fails.push("단계가 열렸다: " + after.unlocked.join(","));
    if (ck.unlock) ck.unlock.forEach(t => { if (cs.unlocked.indexOf(t) < 0) fails.push(t + "단계가 열리지 않았다"); });
    if (ck.no_flags === true && after.flags.length) fails.push("플래그가 켜졌다: " + after.flags.join(","));
    if (Array.isArray(ck.no_flags)) ck.no_flags.forEach(f => { if (after.flags.indexOf(f) >= 0) fails.push("켜지면 안 되는 플래그: " + f); });
    if (ck.flags) ck.flags.forEach(f => { if (E.st.flags.indexOf(f) < 0) fails.push("플래그가 켜지지 않았다: " + f); });
    if (ck.no_ded === true && after.ded.length) fails.push("추리가 인정됐다: " + after.ded.join(","));
    if (Array.isArray(ck.no_ded)) ck.no_ded.forEach(d => { if (after.ded.indexOf(d) >= 0) fails.push("인정되면 안 되는 추리: " + d); });
    if (ck.ded) ck.ded.forEach(d => { if (E.st.deductions.indexOf(d) < 0) fails.push("추리가 인정되지 않았다: " + d); });
    if (ck.must_not) ck.must_not.forEach(p => { const m = body.match(new RegExp(p, "i")); if (m) fails.push("금지 표현: '" + m[0] + "'"); });
    if (ck.pressure_gte != null && cs.pressure < ck.pressure_gte) fails.push("압박 " + cs.pressure + " < " + ck.pressure_gte);
    if (ck.no_html) {
      if (window.__qaXSS) fails.push("입력한 스크립트가 실행됐다");
      if (document.querySelector("#msgs img[src='x']") || [].some.call(document.querySelectorAll("#msgs b"), x => x.textContent === "굵게")) fails.push("입력한 HTML이 태그로 들어갔다");
    }
    // 공통 판정
    if (reply.trim()) {
      const m = body.match(META); if (m) fails.push("세계관 이탈 표현: '" + m[0] + "'");
      if (koreanRatio(reply) < 0.6) fails.push("한국어가 아니다");
      const leaks = E.leakCheck(cid, reply); if (leaks.length) fails.push("잠긴 정보 누출: " + leaks.join(", "));
      const sentences = body.split(/[.!?]+\s*/).filter(x => x.trim().length > 1).length;
      if (reply.length > 600 || sentences > 10) warns.push("대답이 길다(" + reply.length + "자)");
    }
    const ai = B.ui.lastAI || {};
    let source = ai.ai ? "AI" : "대본";
    if (ai.ai && ai.speak) {
      if (!ai.speak.ok) { source = "대본(AI 대답 거부)"; warns.push("AI 대답이 " + (ai.speak.reason === "leak_or_empty" ? "두 번 모두 누출 검사에 걸려" : "실패해(" + (ai.speak.reason || "응답 없음") + ")") + " 대본 대사로 대체됐다"); }
      else if (ai.speak.browserLeaks && ai.speak.browserLeaks.length) { source = "대본(누출 차단)"; warns.push("AI 대답이 누출 검사에 걸려 대본으로 대체: " + ai.speak.browserLeaks.join(", ")); }
      else if (ai.speak.attempt === 2) warns.push("첫 AI 대답이 누출 검사에 걸려 다시 만들었다");
    } else if (ai.ai && !ai.speak && reply.trim()) source = "대본(AI 미사용)";
    if (ai.ai && !ai.judge) warns.push("AI 질문 판정 실패(키워드 판정으로 진행)");
    const judge = ai.judge ? { topics: ai.judge.topics, tone: ai.judge.tone, deductions: ai.judge.deductions } : null;
    return { id: c.id, cat: c.cat, cid: cid, name: NAME[cid], setup: c.setup, q: c.q === "LONG_INPUT" ? "(긴 입력 " + LONG.length + "자)" : c.q,
      attach: c.attach || [], reply: reply, system: sys, result: fails.length ? "실패" : warns.length ? "주의" : "통과",
      fails: fails, warns: warns, expect: c.expect, unlocked: after.unlocked, flags: after.flags, deductions: after.ded,
      trust: cs.trust, pressure: cs.pressure, source: source, judge: judge, ms: ms };
  }

  /* ---------- 화면 ---------- */
  const css = `
  #qaBtn{position:fixed;left:12px;bottom:12px;z-index:60}
  #qa{position:fixed;inset:0;z-index:70;background:var(--paper);overflow:auto;padding:16px 18px 40px;font-size:14px}
  #qa h2{font-family:var(--serif);margin:0 0 6px}
  #qa .bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0}
  #qa label{display:inline-flex;gap:4px;align-items:center;font-size:13px}
  #qa table{border-collapse:collapse;width:100%;background:var(--card);font-size:12.5px}
  #qa th,#qa td{border:1px solid var(--line);padding:5px 6px;vertical-align:top;text-align:left}
  #qa th{background:var(--paper2);position:sticky;top:0}
  #qa td[class^=r-]{white-space:nowrap} #qa td.r-통과{color:var(--green);font-weight:700} #qa td.r-실패{color:var(--accent);font-weight:700} #qa td.r-주의{color:var(--gold);font-weight:700}
  #qa .reply{white-space:pre-wrap;max-width:420px} #qa .muted{color:var(--ink2)}
  #qa .sum{display:flex;gap:10px;flex-wrap:wrap}
  @media (max-width:860px){#qa .reply{max-width:none}}`;
  function mount() {
    const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
    const b = document.createElement("button"); b.id = "qaBtn"; b.className = "btn accent"; b.textContent = "🔧 점검";
    b.addEventListener("click", open); document.body.appendChild(b);
  }
  function modeText() {
    const a = bv().ui.ai || {};
    return a.state === "on" ? "AI 모드 · " + (a.model || "") : "대본 모드(AI 서버에 연결되지 않음)";
  }
  function open() {
    let el = document.getElementById("qa");
    if (!el) { el = document.createElement("div"); el.id = "qa"; document.body.appendChild(el); }
    const cats = Object.keys(QA.categories);
    el.innerHTML = `<h2>가드레일·추리 진행 점검</h2>
      <div class="muted">질문 ${QA.cases.length}개 · 현재 <b id="qaMode">${esc(modeText())}</b>. 실행하는 동안 진행 상황은 따로 보관했다가 끝나면 되돌린다.</div>
      <div class="bar">${cats.map(k => `<label><input type="checkbox" data-cat="${k}" checked>${k}. ${esc(QA.categories[k])}</label>`).join("")}</div>
      <div class="bar"><button class="btn primary" id="qaRun">선택한 분류 실행</button><button class="btn" id="qaFail">실패·주의만 다시</button><button class="btn" id="qaStop" disabled>중지</button>
      <button class="btn ghost" id="qaCsv">CSV 저장</button><button class="btn ghost" id="qaJson">JSON 저장</button><button class="btn ghost" id="qaClose">닫기</button></div>
      <div class="sum" id="qaSum"></div><div id="qaProg" class="muted" style="margin:6px 0"></div><div id="qaTable"></div>`;
    el.querySelector("#qaRun").onclick = () => run(QA.cases.filter(c => el.querySelector(`[data-cat="${c.cat}"]`).checked));
    el.querySelector("#qaFail").onclick = () => { const bad = state.results.filter(r => r.result !== "통과").map(r => r.id); run(QA.cases.filter(c => bad.indexOf(c.id) >= 0)); };
    el.querySelector("#qaStop").onclick = () => { state.stop = true; };
    el.querySelector("#qaClose").onclick = () => { if (!state.running) el.remove(); };
    el.querySelector("#qaCsv").onclick = () => download("boscombe_qa_" + stamp() + ".csv", "﻿" + toCsv(), "text/csv");
    el.querySelector("#qaJson").onclick = () => download("boscombe_qa_" + stamp() + ".json", JSON.stringify({ mode: modeText(), at: new Date().toISOString(), results: state.results }, null, 1), "application/json");
    render();
  }
  function render() {
    const el = document.getElementById("qa"); if (!el) return;
    const R = state.results, cnt = k => R.filter(r => r.result === k).length;
    el.querySelector("#qaSum").innerHTML = R.length ? `<span class="chip">통과 <b>${cnt("통과")}</b></span><span class="chip">주의 <b>${cnt("주의")}</b></span><span class="chip">실패 <b>${cnt("실패")}</b></span>` : "";
    el.querySelector("#qaTable").innerHTML = R.length ? `<table><thead><tr><th>ID</th><th>인물·상태</th><th>질문</th><th>대답</th><th>판정</th><th>자동 판정 근거</th><th>기대 동작(사람이 확인)</th><th>진행 변화</th></tr></thead><tbody>${R.map(r => `<tr>
      <td>${esc(r.id)}</td><td>${esc(r.name)}<br><span class="muted">${esc(r.setup)} · ${esc(r.source)} · ${(r.ms / 1000).toFixed(1)}초</span></td>
      <td>${esc(r.q)}${r.attach.length ? `<br><span class="muted">제시: ${esc(r.attach.join(", "))}</span>` : ""}</td>
      <td class="reply">${esc(r.reply || "(대답 없음)")}${r.system.length ? `<br><span class="muted">${esc(r.system.join(" / "))}</span>` : ""}</td>
      <td class="r-${r.result}">${r.result}</td><td>${esc(r.fails.concat(r.warns).join(" / ") || "-")}</td><td>${esc(r.expect)}</td>
      <td class="muted">${esc([r.unlocked.length ? "단계 " + r.unlocked.join(",") : "", r.flags.join(", "), r.deductions.join(", "), "신뢰 " + r.trust + " · 압박 " + r.pressure].filter(Boolean).join(" · "))}${r.judge ? `<br>판정: ${esc((r.judge.topics || []).join(",") + " / " + (r.judge.tone || ""))}` : ""}</td></tr>`).join("")}</tbody></table>` : `<p class="muted">아직 실행하지 않았다.</p>`;
  }
  async function run(cases) {
    if (state.running || !cases.length) return;
    const el = document.getElementById("qa");
    state.running = true; state.stop = false;
    el.querySelector("#qaRun").disabled = el.querySelector("#qaFail").disabled = true; el.querySelector("#qaStop").disabled = false;
    el.querySelector("#qaMode").textContent = modeText();
    el.style.display = "none";   // 실행 중에는 게임 화면이 보이게 한다(대화창이 그려져야 화면 검사가 된다)
    const prog = document.createElement("div"); prog.id = "qaRunning"; prog.className = "chip"; prog.style.cssText = "position:fixed;left:12px;bottom:56px;z-index:65;background:var(--card)";
    document.body.appendChild(prog);
    let backup = null; try { backup = localStorage.getItem(SAVE_KEY); } catch (e) { /* 저장소 없음 */ }
    const keep = state.results.filter(r => !cases.some(c => c.id === r.id));
    const fresh = [];
    for (let i = 0; i < cases.length && !state.stop; i++) {
      prog.textContent = `점검 중 ${i + 1}/${cases.length} · ${cases[i].id}`;
      const t0 = Date.now();
      try { fresh.push(await runCase(cases[i])); }
      catch (e) { fresh.push({ id: cases[i].id, cat: cases[i].cat, cid: cases[i].cid, name: NAME[cases[i].cid], setup: cases[i].setup, q: cases[i].q, attach: [], reply: "", system: [], result: "실패", fails: ["실행 오류: " + (e && e.message)], warns: [], expect: cases[i].expect, unlocked: [], flags: [], deductions: [], trust: "-", pressure: "-", source: "-", judge: null, ms: 0 }); }
      // 서버는 한 사람당 1분에 30회까지 받는다(한 문항에 판정·대사 2회). AI 모드에서는 문항 사이 간격을 둔다
      const a = bv().ui.ai || {};
      if (a.state === "on" && a.provider === "server") { const wait = 4500 - (Date.now() - t0); if (wait > 0) await new Promise(r => setTimeout(r, wait)); }
    }
    const order = QA.cases.map(c => c.id);
    state.results = keep.concat(fresh).sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
    // 진행 상황 되돌리기
    const B = bv();
    try { if (backup) { B.E.load(backup); localStorage.setItem(SAVE_KEY, backup); } else { B.E.reset(); localStorage.removeItem(SAVE_KEY); } } catch (e) { B.E.reset(); }
    B.renderAll();
    prog.remove();
    state.running = false;
    el.style.display = "";
    el.querySelector("#qaRun").disabled = el.querySelector("#qaFail").disabled = false; el.querySelector("#qaStop").disabled = true;
    render();
    window.__qaDone = state.results;
  }
  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
  function toCsv() {
    const cols = ["id", "cat", "name", "setup", "q", "attach", "reply", "result", "fails", "warns", "expect", "source", "unlocked", "flags", "deductions", "trust", "pressure", "ms", "사람 판정", "메모"];
    const head = ["ID", "분류", "인물", "상태", "질문", "제시 증거", "대답", "자동 판정", "실패 근거", "주의", "기대 동작", "대답 출처", "열린 단계", "켜진 플래그", "인정된 추리", "신뢰", "압박", "시간(ms)", "사람 판정", "메모"];
    const cell = v => '"' + String(Array.isArray(v) ? v.join(" / ") : v == null ? "" : v).replace(/"/g, '""') + '"';
    return [head.map(cell).join(",")].concat(state.results.map(r => cols.map(k => cell(r[k])).join(","))).join("\r\n");
  }
  function download(name, text, type) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: type + ";charset=utf-8" }));
    a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  window.__qa = { run: run, cases: QA.cases, results: () => state.results, open: open };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
})();
