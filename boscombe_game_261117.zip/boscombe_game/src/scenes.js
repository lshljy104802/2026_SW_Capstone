/* 보스콤 밸리 — 장소별 현장 그림. 증거는 실제 물건 모양으로 그려져 있고 눌러서 조사한다.
 * 그림은 SVG 일러스트이며(사진 아님), 외부 이미지 없이 이 파일만으로 그린다.
 */
(function (root) {
  "use strict";
  const W = 1000, H = 560;

  /* ---------- 공통 그리기 도구 ---------- */
  function rng(seed) { let s = seed; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
  const defs = `<defs>
    <linearGradient id="scSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b9c9cf"/><stop offset="1" stop-color="#e6e2cf"/></linearGradient>
    <linearGradient id="scGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fa264"/><stop offset="1" stop-color="#5f7a3f"/></linearGradient>
    <linearGradient id="scWater" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8aa9ad"/><stop offset="1" stop-color="#4a7078"/></linearGradient>
    <linearGradient id="scWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a6f55"/><stop offset="1" stop-color="#6d5641"/></linearGradient>
    <linearGradient id="scStone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7d7a73"/><stop offset="1" stop-color="#5a5752"/></linearGradient>
    <linearGradient id="scWood" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7b5233"/><stop offset="1" stop-color="#5b3a22"/></linearGradient>
    <radialGradient id="scLight" cx=".5" cy=".3" r=".7"><stop offset="0" stop-color="#fff6d8" stop-opacity=".55"/><stop offset="1" stop-color="#fff6d8" stop-opacity="0"/></radialGradient>
    <filter id="scGrain"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="5"/><feColorMatrix values="0 0 0 0 .3  0 0 0 0 .25  0 0 0 0 .2  0 0 0 .12 0"/><feComposite in2="SourceGraphic" operator="in"/></filter>
    <filter id="scSoft"><feGaussianBlur stdDeviation="2.2"/></filter>
    <filter id="scShadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#1d160f" flood-opacity=".35"/></filter>
  </defs>`;

  function tree(x, y, r, c) {
    c = c || ["#4f6b3a", "#62804a"];
    return `<g><rect x="${x - r * .12}" y="${y}" width="${r * .24}" height="${r * 1.1}" fill="#4a3826"/><circle cx="${x}" cy="${y}" r="${r}" fill="${c[0]}"/><circle cx="${x - r * .35}" cy="${y - r * .25}" r="${r * .55}" fill="${c[1]}" opacity=".8"/><circle cx="${x + r * .4}" cy="${y + r * .1}" r="${r * .5}" fill="${c[0]}" opacity=".9"/></g>`;
  }
  function treeLine(seed, y0, y1, n, c) {
    const r = rng(seed); let s = "";
    for (let i = 0; i < n; i++) { const x = r() * W, y = y0 + r() * (y1 - y0); s += tree(x, y, 30 + r() * 30, c); }
    return s;
  }
  function grassTufts(seed, y0, y1, n, color) {
    const r = rng(seed); let s = "";
    for (let i = 0; i < n; i++) { const x = r() * W, y = y0 + r() * (y1 - y0); s += `<path d="M${x.toFixed(0)} ${y.toFixed(0)} l-3 -9 M${x.toFixed(0)} ${y.toFixed(0)} l1 -11 M${x.toFixed(0)} ${y.toFixed(0)} l4 -8" stroke="${color || "#4c6634"}" stroke-width="1.4" opacity=".7"/>`; }
    return s;
  }
  function figure(x, y, coat, hat) {
    return `<g transform="translate(${x} ${y})"><ellipse cx="0" cy="92" rx="26" ry="6" fill="#1d160f" opacity=".25"/><path d="M-22 90 L-18 30 Q0 18 18 30 L22 90 Z" fill="${coat}"/><rect x="-14" y="86" width="10" height="8" fill="#2b2620"/><rect x="4" y="86" width="10" height="8" fill="#2b2620"/><circle cx="0" cy="12" r="13" fill="#e2b996"/>${hat === "cap" ? `<path d="M-14 6 Q0 -10 14 6 L20 9 Q0 4 -14 6 Z" fill="#4e4536"/>` : hat === "bonnet" ? `<path d="M-15 16 Q-17 -6 0 -5 Q17 -6 15 16" fill="none" stroke="#e9dcc2" stroke-width="6"/>` : `<path d="M-13 6 Q0 -8 13 6" fill="#5a4632"/>`}<path d="M-18 34 L-26 64 M18 34 L26 64" stroke="${coat}" stroke-width="8" stroke-linecap="round"/></g>`;
  }

  /* ---------- 증거 물건 그림(물건 중심이 0,0) ---------- */
  const OBJ = {
    newsStack: `<g filter="url(#scShadow)"><rect x="-58" y="-26" width="116" height="52" rx="3" fill="#e9dfc6" transform="rotate(-4)"/><rect x="-56" y="-30" width="112" height="52" rx="3" fill="#f3ead2" transform="rotate(3)"/><rect x="-54" y="-30" width="108" height="56" rx="2" fill="#f7f0dc" stroke="#8c7a5a"/><text x="0" y="-12" font-family="serif" font-size="11" font-weight="700" text-anchor="middle" fill="#2b2620">HEREFORDSHIRE</text><path d="M-46 -4 h92 M-46 4 h40 M-46 12 h40 M-46 20 h40 M4 4 h42 M4 12 h42 M4 20 h42" stroke="#8c7a5a" stroke-width="2"/><path d="M-50 -24 h100" stroke="#2b2620" stroke-width="1"/></g>`,
    newsPage: `<g filter="url(#scShadow)"><path d="M-40 -32 h80 v64 h-80 z" fill="#f6eedb" stroke="#8c7a5a"/><path d="M-40 -32 l14 10 v64 l-14 -10 z" fill="#e6dbc0"/><rect x="-22" y="-24" width="54" height="9" fill="#5c4a33"/><path d="M-22 -8 h54 M-22 0 h54 M-22 8 h54 M-22 16 h36" stroke="#8c7a5a" stroke-width="2"/></g>`,
    newsCut: `<g filter="url(#scShadow)"><path d="M-36 -30 l72 -4 l4 64 l-74 2 z" fill="#f4ecd6" stroke="#8c7a5a"/><path d="M-26 -18 h50 M-26 -10 h50 M-26 -2 h50 M-26 6 h38 M-26 14 h46" stroke="#8c7a5a" stroke-width="2"/><circle cx="24" cy="18" r="7" fill="none" stroke="#a2463d" stroke-width="2"/></g>`,
    sealedDoc: `<g filter="url(#scShadow)"><rect x="-38" y="-46" width="76" height="92" rx="2" fill="#fbf5e3" stroke="#8c7a5a"/><text x="0" y="-28" font-family="serif" font-size="10" font-weight="700" text-anchor="middle" fill="#2b2620">INQUEST</text><path d="M-28 -16 h56 M-28 -8 h56 M-28 0 h56 M-28 8 h56 M-28 16 h40" stroke="#8c7a5a" stroke-width="2"/><circle cx="20" cy="32" r="9" fill="#8b2a22"/><path d="M14 40 l-4 10 M24 40 l4 10" stroke="#8b2a22" stroke-width="3"/></g>`,
    folder: `<g filter="url(#scShadow)"><path d="M-50 -30 h30 l8 -8 h28 l6 8 h28 v62 h-100 z" fill="#c7a564" stroke="#7f6334"/><rect x="-50" y="-24" width="100" height="56" fill="#d8b874" stroke="#7f6334"/><text x="0" y="6" font-family="serif" font-size="10" font-weight="700" text-anchor="middle" fill="#4a3826">POLICE</text><path d="M0 -24 v56" stroke="#7a2e2a" stroke-width="2"/></g>`,
    weekly: `<g filter="url(#scShadow)"><rect x="-46" y="-34" width="92" height="68" fill="#efe5cc" stroke="#8c7a5a" transform="rotate(-6)"/><g transform="rotate(-6)"><text x="0" y="-18" font-family="serif" font-size="9" font-weight="700" text-anchor="middle" fill="#2b2620">WEEKLY · INQUEST IN FULL</text><path d="M-38 -10 h76 M-38 -2 h76 M-38 6 h76 M-38 14 h76 M-38 22 h50" stroke="#8c7a5a" stroke-width="2"/></g></g>`,
    telegram: `<g filter="url(#scShadow)"><path d="M-50 -18 l18 -22 l70 6 l12 26 z" fill="#efe1bd" stroke="#6b5a3e"/><path d="M-30 -36 l12 12 M-6 -36 l4 14 M18 -34 l-4 12" stroke="#6b5a3e" stroke-width="1.2"/><text x="6" y="-22" font-family="serif" font-size="8" font-weight="700" text-anchor="middle" fill="#7a2e2a">BALLARAT</text><rect x="-56" y="-18" width="112" height="44" rx="2" fill="#e9dcc0" stroke="#6b5a3e"/><path d="M-56 -18 l56 26 l56 -26" fill="none" stroke="#6b5a3e"/><text x="0" y="22" font-family="serif" font-size="8" text-anchor="middle" fill="#4a3826">TELEGRAM · BRISTOL</text></g>`,
    boots: `<g filter="url(#scShadow)"><path d="M-46 -34 h22 v38 h22 a6 6 0 0 1 6 6 v8 h-50 z" fill="#3e2d1f"/><path d="M-46 14 h50" stroke="#1f160e" stroke-width="3"/><path d="M8 -30 h22 v38 h24 a6 6 0 0 1 6 6 v6 h-52 z" fill="#5a4129"/><path d="M8 16 h52" stroke="#1f160e" stroke-width="3"/><path d="M-42 -26 h14 M12 -22 h14" stroke="#7b5d3e" stroke-width="2"/></g>`,
    lease: `<g filter="url(#scShadow)"><rect x="-40" y="-30" width="80" height="60" fill="#f6efdc" stroke="#8c7a5a" transform="rotate(5)"/><rect x="-44" y="-28" width="80" height="60" fill="#fbf6e6" stroke="#8c7a5a"/><text x="-4" y="-12" font-family="serif" font-size="9" font-weight="700" text-anchor="middle" fill="#2b2620">LEASE · HATHERLEY</text><path d="M-34 -2 h60 M-34 6 h60 M-34 14 h44" stroke="#8c7a5a" stroke-width="2"/><path d="M14 22 q8 -6 16 0" stroke="#2b2620" stroke-width="1.5" fill="none"/></g>`,
    trampled: `<g><ellipse cx="0" cy="0" rx="92" ry="30" fill="#7f8f55"/><ellipse cx="0" cy="2" rx="70" ry="20" fill="#9aa66a"/>${[-60, -44, -28, -12, 4, 20, 36, 52].map(x => `<path d="M${x} 10 l18 -6 M${x + 4} -6 l16 4" stroke="#5f6e3a" stroke-width="2"/>`).join("")}<ellipse cx="-30" cy="18" rx="6" ry="10" fill="#4a3826" opacity=".7" transform="rotate(-20 -30 18)"/><ellipse cx="-8" cy="22" rx="6" ry="10" fill="#4a3826" opacity=".7" transform="rotate(-20 -8 22)"/><ellipse cx="40" cy="-14" rx="6" ry="10" fill="#4a3826" opacity=".7" transform="rotate(30 40 -14)"/><ellipse cx="60" cy="-6" rx="6" ry="10" fill="#4a3826" opacity=".7" transform="rotate(30 60 -6)"/></g>`,
    squarePrints: `<g>${[[-70, 20, 1], [-36, 4, .45], [-2, -12, 1], [32, -28, .45], [66, -44, 1]].map(([x, y, o]) => `<g transform="translate(${x} ${y}) rotate(-25)"><rect x="-7" y="-14" width="14" height="22" rx="2" fill="#3a2c1d" opacity="${o}"/><rect x="-6" y="-12" width="12" height="5" fill="#2a1f14" opacity="${o}"/></g>`).join("")}</g>`,
    cigar: `<g><ellipse cx="0" cy="8" rx="46" ry="14" fill="#7a5a33" opacity=".55"/>${[-34, -20, -6, 10, 26].map((x, i) => `<path d="M${x} ${6 + (i % 2) * 6} q8 -8 16 0 q-8 6 -16 0z" fill="${["#b8742f", "#9b5d25", "#c48a3c", "#8a4f1f", "#ad6a2c"][i]}"/>`).join("")}<ellipse cx="6" cy="0" rx="16" ry="6" fill="#bdb4a6"/><rect x="-4" y="-8" width="30" height="8" rx="4" fill="#6b3f22" transform="rotate(-12 10 -4)"/><rect x="22" y="-14" width="6" height="8" fill="#cfc6b6" transform="rotate(-12 10 -4)"/></g>`,
    stone: `<g><ellipse cx="0" cy="12" rx="54" ry="16" fill="#5f7d3e"/>${[-40, -24, -8, 18, 34].map((x, i) => `<circle cx="${x}" cy="${8 + (i % 2) * 6}" r="${7 + i % 3 * 2}" fill="#6f8f45"/>`).join("")}<path d="M-26 8 L-10 -26 L14 -16 L28 6 L6 14 Z" fill="url(#scStone)" stroke="#3e3c38" stroke-width="1.5"/><path d="M-10 -26 L-2 -2 L14 -16" fill="none" stroke="#9c9a93" stroke-width="1.2"/></g>`,
    ledger: `<g filter="url(#scShadow)"><path d="M-50 -24 q25 -10 50 0 q25 -10 50 0 v48 q-25 -10 -50 0 q-25 -10 -50 0 z" fill="#f4ecd6" stroke="#6e2f2a" stroke-width="2"/><path d="M0 -24 v48" stroke="#6e2f2a" stroke-width="2"/><path d="M-42 -12 h34 M-42 -4 h34 M-42 4 h34 M8 -12 h34 M8 -4 h34 M8 4 h26" stroke="#8c7a5a" stroke-width="1.8"/><rect x="-54" y="22" width="108" height="6" fill="#6e2f2a"/></g>`,
    letter: `<g filter="url(#scShadow)"><rect x="-34" y="-22" width="68" height="44" fill="#f8f0db" stroke="#6b5a3e"/><path d="M-34 -22 l34 26 l34 -26" fill="none" stroke="#6b5a3e"/><circle cx="0" cy="6" r="7" fill="#8b2a22"/><text x="0" y="36" font-family="serif" font-size="9" text-anchor="middle" fill="#2b2620">to J. Turner</text></g>`
  };

  /* ---------- 장소별 장면 ---------- */
  const SCENES = {
    ross_hotel: {
      name: "로스의 호텔(헤리퍼드 암스)",
      bg: () => `<rect width="${W}" height="${H}" fill="#7d4f3f"/>${Array.from({ length: 26 }, (_, i) => `<rect x="${i * 40}" y="0" width="20" height="330" fill="#86584a"/>`).join("")}<rect y="300" width="${W}" height="40" fill="#5b3a2a"/><rect y="330" width="${W}" height="230" fill="url(#scWood)"/>${Array.from({ length: 10 }, (_, i) => `<path d="M0 ${350 + i * 22} H${W}" stroke="#4a2f1c" stroke-width="1" opacity=".5"/>`).join("")}
        <rect x="640" y="50" width="220" height="200" fill="#c5d3d6" stroke="#4a2f1c" stroke-width="10"/><path d="M750 50 V250 M640 150 H860" stroke="#4a2f1c" stroke-width="6"/><path d="M620 40 Q660 140 630 270 L600 270 L600 40 Z M880 40 Q840 140 870 270 L900 270 L900 40 Z" fill="#7a2e2a"/>${tree(700, 210, 40)}${tree(820, 220, 34)}
        <rect x="60" y="80" width="140" height="100" fill="#d9c9a5" stroke="#5c4a33" stroke-width="6"/><path d="M78 160 l30 -40 l26 26 l18 -14 l30 28" stroke="#6b7a4a" stroke-width="4" fill="none"/>
        <ellipse cx="420" cy="430" rx="330" ry="70" fill="#3a2414" opacity=".35"/><path d="M110 360 L730 360 L770 430 L70 430 Z" fill="#6e4a2c"/><path d="M70 430 H770 V446 H70 Z" fill="#553820"/><rect x="100" y="446" width="18" height="100" fill="#553820"/><rect x="722" y="446" width="18" height="100" fill="#553820"/>
        <path d="M120 360 L720 360 L740 400 L100 400 Z" fill="#2f5a3f" opacity=".85"/>`,
      objects: [
        { ev: "EV_NEWS_REPORT", x: 175, y: 378, draw: "newsStack", hit: [62, 36] },
        { ev: "EV_GROOM_APPOINTMENT", x: 300, y: 350, draw: "newsPage", hit: [44, 36], labelAbove: true },
        { ev: "EV_PATIENCE_DEPOSITION", x: 420, y: 380, draw: "newsCut", hit: [42, 34] },
        { ev: "EV_INQUEST_RECORD", x: 540, y: 344, draw: "sealedDoc", hit: [42, 50], labelAbove: true },
        { ev: "EV_ARREST_REMARK", x: 665, y: 380, draw: "folder", hit: [54, 38] },
        { ev: "EV_SURGEON_REPORT", x: 470, y: 488, draw: "weekly", hit: [50, 38] }
      ],
      chars: [{ cid: "inspector_lestrade", x: 900, y: 360 }, { cid: "alice_turner", x: 820, y: 430 }, { cid: "john_turner", x: 560, y: 470, onlyIfAvailable: true }]
    },
    ross_telegraph: {
      name: "로스 전신국",
      bg: () => `<rect width="${W}" height="${H}" fill="#c9bfa6"/><rect y="0" width="${W}" height="60" fill="#b3a88c"/>${Array.from({ length: 6 }, (_, r) => Array.from({ length: 8 }, (_, c) => `<rect x="${560 + c * 46}" y="${80 + r * 40}" width="40" height="34" fill="#8a6b48" stroke="#5c4a33"/><rect x="${566 + c * 46}" y="${96 + r * 40}" width="28" height="14" fill="#efe1bd" opacity="${(r + c) % 3 ? .9 : 0}"/>`).join("")).join("")}
        <circle cx="300" cy="120" r="54" fill="#f4ecd8" stroke="#5c4a33" stroke-width="8"/><path d="M300 120 V84 M300 120 L326 132" stroke="#2b2620" stroke-width="5" stroke-linecap="round"/>
        <rect y="330" width="${W}" height="230" fill="url(#scWood)"/><rect y="320" width="${W}" height="24" fill="#8a5c36"/>
        <g transform="translate(200 300)"><rect x="-60" y="0" width="120" height="20" fill="#3a2a1c"/><rect x="-40" y="-40" width="26" height="40" fill="#b78a3c"/><rect x="-6" y="-30" width="40" height="12" fill="#7a5a33"/><circle cx="40" cy="-24" r="8" fill="#2b2620"/><path d="M-60 6 C-120 0 -160 -40 -200 -120" stroke="#2b2620" stroke-width="3" fill="none"/></g>`,
      objects: [{ ev: "EV_VICTORIA_MAP", x: 520, y: 360, draw: "telegram", hit: [62, 46] }],
      chars: []
    },
    hereford_gaol: {
      name: "헤리퍼드 감옥",
      bg: () => { let b = `<rect width="${W}" height="${H}" fill="url(#scStone)"/>`; for (let r = 0; r < 14; r++) for (let c = 0; c < 12; c++) b += `<rect x="${c * 90 + (r % 2) * 45 - 45}" y="${r * 40}" width="86" height="36" fill="#6f6c66" stroke="#4a4844" opacity=".7"/>`;
        b += `<rect x="420" y="70" width="160" height="110" fill="#d8e2e4"/>${[0, 1, 2, 3].map(i => `<rect x="${440 + i * 36}" y="70" width="8" height="110" fill="#2f2c28"/>`).join("")}<path d="M420 180 L300 560 L760 560 L580 180 Z" fill="url(#scLight)"/><rect y="460" width="${W}" height="100" fill="#4d4a45"/>`;
        b += `${Array.from({ length: 12 }, (_, i) => `<rect x="${40 + i * 82}" y="0" width="12" height="${H}" fill="#2b2824"/>`).join("")}<rect y="20" width="${W}" height="14" fill="#2b2824"/><rect y="500" width="${W}" height="14" fill="#2b2824"/>`; return b; },
      objects: [],
      chars: [{ cid: "james_mccarthy", x: 500, y: 360 }]
    },
    hatherley_farm: {
      name: "해덜리 농장",
      bg: () => `<rect width="${W}" height="${H}" fill="url(#scSky)"/><path d="M0 260 Q200 200 420 240 T1000 220 V320 H0 Z" fill="#9cb07a"/>${treeLine(3, 220, 260, 14, ["#5f7a45", "#7a9457"])}<rect y="300" width="${W}" height="260" fill="url(#scGrass)"/>
        <g><rect x="120" y="170" width="380" height="200" fill="#e3d6b6" stroke="#5c4a33" stroke-width="4"/><path d="M100 176 L310 70 L520 176 Z" fill="#7a3b2b" stroke="#5c4a33" stroke-width="4"/><rect x="420" y="80" width="30" height="60" fill="#7b5d3e"/>
        ${[0, 1].map(i => `<rect x="${160 + i * 220}" y="210" width="70" height="66" fill="#9fb3b8" stroke="#5c4a33" stroke-width="5"/><path d="M${195 + i * 220} 210 V276 M${160 + i * 220} 243 H${230 + i * 220}" stroke="#5c4a33" stroke-width="3"/>`).join("")}
        <rect x="280" y="250" width="60" height="120" fill="#5c4a33"/><rect x="250" y="364" width="120" height="16" fill="#8a7a5a"/><rect x="236" y="378" width="148" height="16" fill="#7a6a4a"/></g>
        <rect x="560" y="210" width="190" height="160" fill="#a5774d" stroke="#5c4a33" stroke-width="4"/><path d="M546 214 L655 140 L764 214 Z" fill="#6b5a3e" stroke="#5c4a33" stroke-width="4"/>
        <path d="M600 560 C680 470 820 420 1000 400" stroke="#d8c79e" stroke-width="46" fill="none"/>${[0, 1, 2, 3, 4, 5, 6].map(i => `<rect x="${780 + i * 32}" y="${360 - i * 2}" width="6" height="56" fill="#7b5d3e"/>`).join("")}<path d="M776 372 H1000 M776 392 H1000" stroke="#7b5d3e" stroke-width="5"/>${grassTufts(9, 420, 560, 70)}`,
      objects: [
        { ev: "EV_BOOTS_HATHERLEY", x: 300, y: 404, draw: "boots", hit: [64, 40] },
        { ev: "EV_RENT_RECORD", x: 195, y: 243, draw: "lease", hit: [50, 38] }
      ],
      chars: [{ cid: "william_crowder", x: 880, y: 320 }]
    },
    boscombe_pool: {
      name: "보스콤 연못",
      bg: () => `<rect width="${W}" height="${H}" fill="url(#scSky)"/>${treeLine(11, 140, 230, 30)}<rect y="230" width="${W}" height="330" fill="url(#scGrass)"/>${treeLine(17, 210, 290, 10, ["#46613a", "#5a7842"])}
        <path d="M150 330 C180 270 420 250 600 262 C760 272 860 300 840 350 C820 400 600 410 420 404 C250 398 120 380 150 330 Z" fill="url(#scWater)" stroke="#466b70" stroke-width="3"/><path d="M260 320 q60 -12 120 -4 M480 340 q80 -10 160 0 M330 370 q60 6 130 -2" stroke="#b6cdcf" stroke-width="2.5" fill="none" opacity=".7"/>
        ${(() => { const r = rng(21); let s = ""; for (let i = 0; i < 70; i++) { const a = r() * Math.PI * 2, x = 495 + Math.cos(a) * (360 + r() * 30), y = 335 + Math.sin(a) * (80 + r() * 18); if (y > 250) s += `<path d="M${x.toFixed(0)} ${y.toFixed(0)} l-3 -16 M${x.toFixed(0)} ${y.toFixed(0)} l2 -19 M${x.toFixed(0)} ${y.toFixed(0)} l5 -14" stroke="#55703b" stroke-width="1.8"/>`; } return s; })()}
        <path d="M0 440 Q300 410 560 450 T1000 430 V560 H0 Z" fill="#7f8f55" opacity=".6"/>${grassTufts(23, 420, 560, 90)}`,
      objects: [
        { ev: "EV_POOL_LAYOUT", x: 495, y: 330, draw: null, hit: [330, 70], outline: true },
        { ev: "EV_TRACKS_POOL", x: 300, y: 470, draw: "trampled", hit: [96, 36] },
        { ev: "EV_TIPTOE_TRACKS", x: 770, y: 470, draw: "squarePrints", hit: [96, 50] }
      ],
      chars: []
    },
    great_beech: {
      name: "큰 너도밤나무와 숲길",
      bg: () => `<rect width="${W}" height="${H}" fill="#9fb08a"/>${treeLine(31, 40, 200, 34, ["#3f5a30", "#557344"])}<rect y="250" width="${W}" height="310" fill="#6f8048"/>${treeLine(37, 180, 300, 14, ["#46613a", "#5a7842"])}
        <path d="M640 560 C700 470 760 380 860 300 C900 270 960 250 1000 240 V300 C960 310 920 330 880 360 C800 420 760 490 740 560 Z" fill="#c9b787"/>
        <g><path d="M300 560 C320 440 330 330 310 220 L380 220 C370 330 380 440 410 560 Z" fill="#7a6a5a"/><path d="M310 230 C250 260 220 300 200 330 M370 240 C430 270 470 300 490 340" stroke="#7a6a5a" stroke-width="22" fill="none" stroke-linecap="round"/>
        <circle cx="340" cy="140" r="150" fill="#8a5a33"/><circle cx="250" cy="110" r="90" fill="#a8743f" opacity=".9"/><circle cx="440" cy="120" r="90" fill="#6f4627" opacity=".9"/><circle cx="350" cy="40" r="80" fill="#b5813f" opacity=".8"/></g>
        ${(() => { const r = rng(41); let s = ""; for (let i = 0; i < 80; i++) { const x = 120 + r() * 520, y = 470 + r() * 80; s += `<path d="M${x.toFixed(0)} ${y.toFixed(0)} q6 -6 12 0 q-6 5 -12 0z" fill="${["#b8742f", "#9b5d25", "#c48a3c"][i % 3]}" opacity=".8"/>`; } return s; })()}`,
      objects: [
        { ev: "EV_BEECH_CIGAR", x: 470, y: 486, draw: "cigar", hit: [52, 26] },
        { ev: "EV_STONE_WEAPON", x: 170, y: 470, draw: "stone", hit: [56, 34] },
        { ev: "EV_WOOD_PATH", x: 830, y: 360, draw: "squarePrints", hit: [96, 50], scale: .8 }
      ],
      chars: []
    },
    moran_lodge: {
      name: "숲지기 모런의 집",
      bg: () => `<rect width="${W}" height="${H}" fill="url(#scSky)"/>${treeLine(51, 150, 260, 26)}<rect y="300" width="${W}" height="260" fill="url(#scGrass)"/>
        <g><rect x="330" y="180" width="320" height="190" fill="#e3d6b6" stroke="#5c4a33" stroke-width="4"/><path d="M310 186 L490 90 L670 186 Z" fill="#8a7a5a" stroke="#5c4a33" stroke-width="4"/><rect x="580" y="96" width="30" height="64" fill="#6b5a3e"/><path d="M596 90 q-16 -30 6 -50 q18 -18 0 -40" stroke="#cfc8bd" stroke-width="10" fill="none" opacity=".7"/>
        <rect x="380" y="220" width="64" height="60" fill="#9fb3b8" stroke="#5c4a33" stroke-width="4"/><rect x="460" y="250" width="56" height="120" fill="#5c4a33"/></g>
        <rect x="560" y="320" width="150" height="14" fill="#7b5d3e"/><rect x="570" y="334" width="10" height="40" fill="#7b5d3e"/><rect x="690" y="334" width="10" height="40" fill="#7b5d3e"/>
        <ellipse cx="200" cy="420" rx="46" ry="16" fill="#6b5a3e"/><rect x="160" y="380" width="80" height="40" fill="#7b5d3e"/><ellipse cx="200" cy="380" rx="40" ry="12" fill="#a68a64"/>
        ${[0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => `<rect x="${30 + i * 34}" y="440" width="6" height="50" fill="#7b5d3e"/>`).join("")}<path d="M26 452 H330 M26 472 H330" stroke="#7b5d3e" stroke-width="5"/>${grassTufts(57, 400, 560, 60)}`,
      objects: [
        { ev: "EV_TURNER_GAIT", x: 800, y: 280, draw: "moran", hit: [40, 90] },
        { ev: "EV_STAFF_REGISTER", x: 636, y: 304, draw: "ledger", hit: [60, 32] },
        { act: "ACT_SEND_NOTE", x: 200, y: 360, draw: "letter", hit: [44, 32] }
      ],
      chars: [{ cid: "patience_moran", x: 900, y: 400 }]
    },
    turner_hall: {
      name: "터너 저택",
      bg: () => `<rect width="${W}" height="${H}" fill="url(#scSky)"/>${treeLine(61, 160, 250, 20)}<rect y="300" width="${W}" height="260" fill="url(#scGrass)"/>
        <g><rect x="180" y="130" width="640" height="250" fill="#d9ccb0" stroke="#4d3f2c" stroke-width="5"/><path d="M160 136 L500 40 L840 136 Z" fill="#5d5448" stroke="#4d3f2c" stroke-width="5"/>
        ${[0, 1, 2, 3, 4, 5].map(i => `<rect x="${215 + i * 100}" y="170" width="54" height="74" fill="#9fb3b8" stroke="#4d3f2c" stroke-width="4"/><path d="M${215 + i * 100} 170 q27 30 54 0" fill="#7a2e2a" opacity=".8"/>`).join("")}
        ${[0, 1, 2, 3].map(i => `<rect x="${410 + i * 56}" y="250" width="16" height="130" fill="#ece2c9" stroke="#4d3f2c"/>`).join("")}<rect x="470" y="290" width="60" height="90" fill="#4d3f2c"/></g>
        <path d="M500 380 C480 440 420 500 300 560 L700 560 C580 500 520 440 500 380 Z" fill="#d8c79e"/>${grassTufts(67, 400, 560, 50)}`,
      objects: [],
      chars: [{ cid: "john_turner", x: 270, y: 210, onlyIfUnavailable: true }]
    }
  };
  // 숲지기 모런: 물건이 아니라 사람에게 듣는 증거
  OBJ.moran = figure(0, -60, "#5a6b44", "cap");

  const LOC_SCENE = { hatherley_path: "hatherley_farm", pool_woods: "boscombe_pool", wood_path: "great_beech" };
  function sceneOf(loc) { return LOC_SCENE[loc] || loc; }

  /* status(id) → owned|open|locked|done ; label(id) → 이름 ; chars: {cid:{available, unread}} */
  function sceneSVG(key, status, label, chars, portrait) {
    const sc = SCENES[key];
    let s = `<svg class="scene-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="${sc.name} 현장">${defs}${sc.bg()}`;
    sc.objects.forEach(o => {
      const id = o.ev || o.act, st = status(id), attr = o.ev ? `data-ev="${o.ev}"` : `data-act="${o.act}"`;
      const sx = o.scale || 1;
      s += `<g class="sobj sobj-${st}" ${attr} transform="translate(${o.x} ${o.y})" tabindex="0" role="button" aria-label="${label(id)}"><title>${label(id)}</title>`;
      if (o.outline) s += `<ellipse rx="${o.hit[0]}" ry="${o.hit[1]}" class="sobj-ring"/>`;
      else if (st === "open") s += `<ellipse rx="${o.hit[0] + 8}" ry="${o.hit[1] + 8}" class="sobj-pulse"/>`;
      if (o.draw) s += `<g class="sobj-art" transform="scale(${sx})">${OBJ[o.draw]}</g>`;
      s += `<ellipse rx="${o.hit[0]}" ry="${o.hit[1]}" class="sobj-hit"/>`;
      const bx = o.outline ? o.hit[0] * .7 : o.hit[0] * .9, by = -o.hit[1] * (o.outline ? .9 : 1.05);
      if (st === "locked") s += `<g transform="translate(${bx} ${by})"><circle r="13" fill="#2b2620"/><rect x="-6" y="-2" width="12" height="9" rx="1.5" fill="#f3ecdc"/><path d="M-4 -2 v-3.5 a4 4 0 0 1 8 0 v3.5" stroke="#f3ecdc" stroke-width="2" fill="none"/></g>`;
      if (st === "owned" || st === "done") s += `<g transform="translate(${bx} ${by})"><circle r="13" fill="#3f6b3a"/><path d="M-6 0 l4 4.5 l8 -9" stroke="#fff" stroke-width="2.6" fill="none"/></g>`;
      if (st === "open") s += `<g transform="translate(${bx} ${by})"><circle r="13" fill="#7a2e2a"/><text y="5" text-anchor="middle" font-size="16" font-weight="700" fill="#fff">?</text></g>`;
      s += `<text class="sobj-label" y="${o.labelAbove ? -o.hit[1] - 12 : o.hit[1] + 22}" text-anchor="middle">${label(id)}</text></g>`;
    });
    sc.chars.forEach(c => {
      const info = chars[c.cid] || {};
      if (c.onlyIfAvailable && !info.available) return;
      if (c.onlyIfUnavailable && info.available) return;
      s += `<g class="spin ${info.available ? "" : "spin-off"}" data-char="${c.cid}" transform="translate(${c.x - 34} ${c.y - 34})" tabindex="0" role="button"><circle cx="34" cy="34" r="37" fill="#f3ecdc" stroke="#2b2620" stroke-width="3"/>${portrait(c.cid, { size: 68 })}${info.unread ? `<circle cx="64" cy="6" r="10" fill="#d93b30"/>` : ""}<text x="34" y="94" text-anchor="middle" class="spin-label">${info.name || ""}${info.available ? " · 대화" : ""}</text></g>`;
    });
    s += `<rect width="${W}" height="${H}" filter="url(#scGrain)" pointer-events="none"/></svg>`;
    return s;
  }

  /* 장소 버튼에 쓰는 작은 그림 */
  const THUMB = {
    overview: `<rect width="48" height="36" rx="3" fill="#b9c48c"/><path d="M6 26 C14 18 24 24 30 16 S42 10 44 8" stroke="#d8c79e" stroke-width="3" fill="none"/><ellipse cx="26" cy="20" rx="8" ry="5" fill="#6f939a"/><circle cx="12" cy="10" r="4" fill="#4f6b3a"/><circle cx="38" cy="26" r="4" fill="#4f6b3a"/>`,
    ross_hotel: `<rect x="6" y="12" width="36" height="22" fill="#ece2c9" stroke="#4d3f2c"/><path d="M3 13 L24 3 L45 13 Z" fill="#6e2f2a"/><rect x="21" y="24" width="6" height="10" fill="#4d3f2c"/>`,
    ross_telegraph: `<rect x="8" y="14" width="26" height="20" fill="#ece2c9" stroke="#4d3f2c"/><path d="M6 15 L21 6 L36 15 Z" fill="#5d5448"/><path d="M41 4 V34 M37 8 H45" stroke="#4d3f2c" stroke-width="2"/>`,
    hereford_gaol: `<rect x="5" y="8" width="38" height="26" fill="#b9b0a0" stroke="#4d3f2c"/>${[0, 1, 2, 3].map(i => `<rect x="${10 + i * 8}" y="14" width="4" height="8" fill="#3d3530"/>`).join("")}<rect x="20" y="24" width="8" height="10" fill="#3d3530"/>`,
    hatherley_farm: `<rect x="5" y="16" width="22" height="18" fill="#e3d6b6" stroke="#5c4a33"/><path d="M3 17 L16 7 L29 17 Z" fill="#7a3b2b"/><rect x="30" y="20" width="14" height="14" fill="#a5774d" stroke="#5c4a33"/>`,
    boscombe_pool: `<rect width="48" height="36" rx="3" fill="#8fa264"/><ellipse cx="24" cy="20" rx="17" ry="9" fill="#6f939a"/><path d="M14 20 q5 -3 10 0 M26 23 q5 -3 10 0" stroke="#cfe0e2" stroke-width="1.5" fill="none"/>`,
    great_beech: `<rect x="21" y="18" width="6" height="16" fill="#7a6a5a"/><circle cx="24" cy="14" r="12" fill="#8a5a33"/><circle cx="18" cy="11" r="6" fill="#a8743f"/>`,
    moran_lodge: `<rect x="8" y="16" width="30" height="18" fill="#e3d6b6" stroke="#5c4a33"/><path d="M5 17 L23 6 L41 17 Z" fill="#8a7a5a"/><rect x="32" y="6" width="4" height="8" fill="#6b5a3e"/>`,
    turner_hall: `<rect x="4" y="14" width="40" height="20" fill="#d9ccb0" stroke="#4d3f2c"/><path d="M2 15 L24 4 L46 15 Z" fill="#5d5448"/>${[0, 1, 2].map(i => `<rect x="${17 + i * 6}" y="22" width="2" height="12" fill="#ece2c9"/>`).join("")}`
  };
  function thumb(key) { return `<svg viewBox="0 0 48 36" width="48" height="36" aria-hidden="true">${THUMB[key] || THUMB.overview}</svg>`; }

  root.BVScenes = { sceneSVG: sceneSVG, sceneOf: sceneOf, thumb: thumb, SCENES: SCENES,
    ORDER: ["overview", "ross_hotel", "ross_telegraph", "hereford_gaol", "hatherley_farm", "boscombe_pool", "great_beech", "moran_lodge", "turner_hall"] };
})(typeof window !== "undefined" ? window : globalThis);
