/* 보스콤 밸리 로컬 게임 — 화면 */
(function () {
  "use strict";
  const G = window.GAME, S = window.SCRIPT, Art = window.BVArt;
  const E = new window.BoscombeEngine(G.personas, G.case, S);
  const SAVE_KEY = "boscombe_local_v1", SET_KEY = "boscombe_local_settings";
  const NAMES = {}; G.personas.characters.forEach(c => { NAMES[c.id] = c.name; });
  const CHAR_ORDER = ["inspector_lestrade", "alice_turner", "patience_moran", "william_crowder", "james_mccarthy", "john_turner"];
  const SHORT = { inspector_lestrade: "경감", alice_turner: "앨리스", patience_moran: "페이션스", william_crowder: "크라우더", james_mccarthy: "제임스", john_turner: "터너" };
  const LOCNAME = {}; G.case.locations.forEach(l => { LOCNAME[l.id] = l.name; });
  const LOCDESC = {
    ross_hotel: "탐정이 묵는 로스의 여관. 사건 기사와 검시 기록이 실린 지역 신문, 경찰 기록을 여기서 읽을 수 있다.",
    ross_telegraph: "로스의 전신국. 브리스톨로 전보를 쳐서 자료를 받아 볼 수 있다.",
    hereford_gaol: "제임스 매카시가 갇혀 있는 감옥. 면회 허가가 있어야 들어갈 수 있다.",
    hatherley_farm: "매카시 부자가 살던 농장. 터너 소유의 땅이다.",
    hatherley_path: "농장에서 보스콤 연못으로 이어지는 길. 사냥터지기 크라우더가 부자를 본 길이다.",
    boscombe_pool: "해덜리 농장과 터너 영지 사이의 작은 연못. 둘레가 질척한 풀밭이다.",
    pool_woods: "연못을 둘러싼 숲.",
    great_beech: "숲 가장자리에 선 큰 너도밤나무.",
    wood_path: "숲을 지나 큰길로 이어지는 길.",
    moran_lodge: "터너 영지의 숲지기 모런 가족이 사는 집. 사건 직후 제임스가 도움을 청하러 달려온 곳이다.",
    turner_hall: "이 지역 최대 지주 존 터너의 저택. 터너는 몸져누워 있어 의사가 면회를 막고 있다."
  };
  const CHAR_LOC = { inspector_lestrade: "ross_hotel", alice_turner: "ross_hotel", james_mccarthy: "hereford_gaol", patience_moran: "moran_lodge", william_crowder: "hatherley_path", john_turner: "turner_hall" };
  const FLAG_MSG = {
    prison_visit_granted: "레스트레이드 경감이 면회 허가증을 내주었다. 이제 감옥의 제임스와 이야기할 수 있다.",
    scene_access_granted: "경감이 현장으로 안내했다. 지도의 연못·농장·숲을 조사할 수 있다.",
    victoria_known: "터너와 매카시가 빅토리아 금광에서 알게 되었다는 것을 알았다. 로스 전신국에서 지도를 요청할 수 있다.",
    alice_message_available: "앨리스의 전언을 받았다. 제임스에게 전할 수 있다.",
    james_quarrel_reason_known: "제임스가 말다툼의 이유를 털어놓았다.",
    james_bristol_secret_known: "제임스가 브리스톨의 비밀을 털어놓았다.",
    patience_opened_up: "페이션스가 마음을 열었다.",
    crowder_testimony_weakened: "크라우더가 '따라갔다'는 말이 짐작이었다고 인정했다.",
    turner_rent_free_known: "터너가 매카시에게 땅을 공짜로 빌려주었다는 소문을 들었다.",
    turner_blackmail_admitted: "터너가 매카시에게 협박당해 왔다고 인정했다.",
    turner_confessed_murder: "터너가 연못에서의 일을 자백했다.",
    turner_full_confession: "터너가 모든 것을 털어놓고 자백서 서명에 동의했다.",
    turner_summoned: "레스트레이드 경감이 숲지기 모런 편에 터너에게 쪽지를 보냈다. 이제 터너와 대화할 수 있다."
  };
  const FLAG_HINT = { scene_access_granted: "레스트레이드 경감에게 현장 안내를 부탁해야 한다.", victoria_known: "터너와 매카시가 호주 어디에서 알게 되었는지 알아야 전보를 칠 수 있다." };
  const UNAVAIL_HINT = { james_mccarthy: () => "레스트레이드 경감에게 면회를 부탁해 보자.", john_turner: () => noteHint() };
  /* 터너를 만나는 길: 레스트레이드에게 근거 있는 추리를 보고하면(ACT_SEND_NOTE 조건) 경감이 기별을 넣는다.
   * 무엇이 몇 개 필요한지는 직접 알려 주지 않는다 */
  function noteHint() {
    if (E.actionStatus("ACT_SEND_NOTE").state === "open") return "터너는 앓아누워 손님을 받지 않는다. 레스트레이드 경감에게 지금까지의 추리를 보고하면 자리를 마련해 줄지도 모른다.";
    return "터너는 앓아누워 손님을 받지 않는다. 경감이 자리를 마련해 줄 만큼 근거 있는 추리를 보고해야 한다. 막히면 위의 힌트 버튼을 눌러 보자.";
  }

  let settings = { hints: true, ai: { enabled: true, server: "" } };
  let ui = { tab: "map", loc: "ross_hotel", evFilter: 0, attach: [], busy: false, picked: { culprit: null, motive: "", ev: [] }, evpop: false, grading: false,
    ai: { state: "checking", model: "", reason: "" }, aiWarned: false };

  /* ---------- 저장 ---------- */
  function trySet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* 저장소를 쓸 수 없는 환경 */ } }
  function tryGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function save() { trySet(SAVE_KEY, E.save()); }
  (function load() {
    const raw = tryGet(SAVE_KEY);
    if (raw) { try { E.load(raw); } catch (e) { E.reset(); } }
    const st = tryGet(SET_KEY);
    if (st) { try { const o = JSON.parse(st); settings.hints = o.hints !== false; if (o.ai) settings.ai = Object.assign(settings.ai, o.ai); } catch (e) { /* 무시 */ } }
  })();

  /* ---------- 도우미 ---------- */
  const $ = s => document.querySelector(s);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = t => esc(t).replace(/\*([^*]+)\*/g, '<em class="act">$1</em>');
  const now = () => { const d = new Date(); return (d.getHours() < 12 ? "오전 " : "오후 ") + ((d.getHours() % 12) || 12) + ":" + String(d.getMinutes()).padStart(2, "0"); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const evTitle = id => (E.ev[id] ? E.ev[id].title : id);
  function toast(msg) {
    const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }
  function log(cid, m) { m.ts = m.ts || now(); E.st.logs[cid].push(m); }
  function sysAll(text, kind) { log(E.st.current, { f: "s", t: text, k: kind || "flag" }); }

  function evStatus(id) { const s = E.evidenceStatus(id); return s.state; }
  function lockReason(id) {
    const s = E.evidenceStatus(id);
    if (s.state !== "locked") return "";
    if (s.flags.length) return FLAG_HINT[s.flags[0]] || "아직 조사할 수 없다.";
    return "먼저 '" + s.requires.map(evTitle).join("', '") + "'을(를) 조사해야 한다.";
  }

  /* ---------- 머리글 ---------- */
  function renderTop() {
    const nEv = E.st.owned.length, nRec = E.st.records.length + E.st.deductions.length;
    $("#counters").innerHTML = `<span class="chip">증거 <b>${nEv}</b>/${E.CASE.evidence.length}</span><button class="chip hintbtn" id="btnHint" title="지금 해 볼 만한 행동이나 질문을 하나 알려 준다">💡 힌트</button><span class="chip">수사 기록 <b>${nRec}</b></span>${aiPill()}`;
  }

  /* ---------- 탭 ---------- */
  const TABS = [["map", "지도"], ["evidence", "증거"], ["records", "수사 기록"], ["conclude", "결론"]];
  function renderTabs() {
    if (!TABS.some(t => t[0] === ui.tab)) ui.tab = "map";
    const n = { evidence: E.st.owned.length, records: E.st.records.length + E.st.deductions.length };
    $("#tabs").innerHTML = TABS.map(([k, l]) => `<button role="tab" aria-selected="${ui.tab === k}" data-tab="${k}">${l}${n[k] !== undefined ? `<span class="n">${n[k]}</span>` : ""}</button>`).join("");
  }

  function renderMain() {
    renderTabs();
    const v = $("#view");
    if (ui.tab === "map") v.innerHTML = viewMap();
    else if (ui.tab === "evidence") v.innerHTML = viewEvidence();
    else if (ui.tab === "records") v.innerHTML = viewRecords();
    else v.innerHTML = viewConclude();
  }

  /* ---------- 지도 ---------- */
  function charPinInfo() {
    const o = {};
    CHAR_ORDER.forEach(c => { o[c] = { available: E.available(c), unread: E.st.chars[c].unread, hidden: c === "john_turner" && E.available(c) }; });
    return o;
  }
  const Sc = window.BVScenes;
  const SCENE_DESC = Object.assign({}, LOCDESC, {
    overview: "보스콤 밸리 전체 지도. 지도 위 장소나 아래 장소 카드를 누르면 그 장소로 간다.",
    great_beech: "연못 숲 가장자리에 선 큰 너도밤나무. 나무 뒤로 큰길까지 이어지는 숲길이 있다.",
    moran_lodge: LOCDESC.moran_lodge
  });
  const GATE_NOTE = {
    hatherley_farm: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    boscombe_pool: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    great_beech: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    ross_telegraph: ["victoria_known", "전보를 칠 근거가 아직 없다. 터너와 매카시가 호주 어디에서 알게 되었는지 알아내자."],
    hereford_gaol: ["prison_visit_granted", "면회 허가가 있어야 들어갈 수 있다. 레스트레이드 경감에게 면회를 부탁하자."]
  };
  function sceneEvidence(key) { return E.CASE.evidence.filter(e => Sc.sceneOf(e.location) === key); }
  function viewMap() {
    const key = ui.loc || "ross_hotel";
    // 숲지기 집의 쪽지는 경감이 보낸 뒤에야 '완료'로 보인다(플레이어가 직접 보내지 않음)
    const status = id => (E.ev[id] ? evStatus(id) : E.actionStatus(id).state === "done" ? "done" : "locked");
    const label = id => (E.ev[id] ? E.ev[id].object : "터너에게 쪽지 보내기");
    const chars = {};
    CHAR_ORDER.forEach(c => { chars[c] = { available: E.available(c), unread: E.st.chars[c].unread, name: SHORT[c] }; });
    // 전체 지도(1000×640)를 다른 장소 장면과 같은 비율(1000×560)로 잘라 보여 준다. 위아래의 빈 들판만 잘린다
    const art = key === "overview" ? Art.mapSVG(status, charPinInfo(), null).replace('viewBox="0 0 1000 640"', 'viewBox="0 64 1000 560"') : Sc.sceneSVG(key, status, label, chars, Art.portrait);
    const gate = GATE_NOTE[key] && E.st.flags.indexOf(GATE_NOTE[key][0]) < 0 ? `<div class="scene-gate">${esc(GATE_NOTE[key][1])}</div>` : "";
    const name = key === "overview" ? "전체 지도" : Sc.SCENES[key].name;
    // 장소 카드: 누르면 그 장소, 선택된 카드를 한 번 더 누르면 전체 지도
    const cards = Sc.ORDER.filter(k => k !== "overview").map(k => {
      const evs = k === "overview" ? [] : sceneEvidence(k);
      const own = evs.filter(e => E.st.owned.indexOf(e.id) >= 0).length;
      const open = evs.filter(e => evStatus(e.id) === "open").length;
      const faces = k === "overview" ? "" : CHAR_ORDER.filter(c => Sc.sceneOf(charLoc(c)) === k).map(c => Art.portrait(c, { size: 22 })).join("");
      const meta = k === "overview" ? "한눈에 보기" : evs.length ? `증거 ${own}/${evs.length}` : "증거 없음";
      return `<button class="loccard" data-scene="${k}" aria-pressed="${key === k}" title="${key === k ? "한 번 더 누르면 전체 지도" : "이 장소로 가기"}">${Sc.thumb(k)}<span class="lc-body"><span class="lc-name">${esc(k === "overview" ? "전체 지도" : Sc.SCENES[k].name)}</span><span class="lc-meta">${meta}${open ? ` · <b>새로 조사 ${open}</b>` : ""}</span>${key === k ? `<span class="lc-back">↩ 다시 누르면 전체 지도</span>` : ""}${faces ? `<span class="lc-faces">${faces}</span>` : ""}</span></button>`;
    }).join("");
    return `<section class="sceneframe"><div class="scene-cap"><b>${esc(name)}</b><span>${esc(SCENE_DESC[key] || "")}</span></div><div class="scenescroll">${art}</div>${gate}
      <div class="maplegend"><span class="lg-open">? 조사할 수 있는 물건</span><span class="lg-locked">아직 조사할 수 없음</span><span class="lg-owned">조사 완료</span><span>인물 얼굴을 누르면 대화</span></div></section>
      <h3 class="sect-title">장소 <span class="note" style="font-weight:500">${key === "overview" ? "· 지금 전체 지도" : "· 선택한 장소를 다시 누르면 전체 지도"}</span></h3><div class="locgrid">${cards}</div>`;
  }
  function charLoc(c) { return c === "john_turner" && E.available(c) ? "ross_hotel" : CHAR_LOC[c]; }

  /* ---------- 증거 ---------- */
  function evCard(e, opts) {
    const st = { 1: "사건 기록", 2: "현장 조사", 3: "추가 조사" }[e.stage];
    const icon = (Art.OBJECTS.find(o => o.ev === e.id) || {}).icon || Art.OFFMAP_ICONS[e.id] || "paper";
    return `<article class="evcard"><div class="ev-head">${Art.icon(icon, 30)}<div><h4>${esc(e.title)}</h4><div class="meta">${esc(LOCNAME[e.location])} · ${esc(e.object)}</div></div></div>
      <div><span class="badge s${e.stage}">${st}</span></div><p class="txt">${esc(e.text)}</p>
      ${opts && opts.noActs ? "" : `<div class="acts"><button class="btn sm" data-present="${e.id}">${esc(SHORT[E.st.current])}에게 제시</button></div>`}</article>`;
  }
  function viewEvidence() {
    const list = E.CASE.evidence.filter(e => !ui.evFilter || e.stage === ui.evFilter);
    const owned = list.filter(e => E.st.owned.indexOf(e.id) >= 0);
    const missing = list.length - owned.length;
    const f = [[0, "전체"], [1, "사건 기록"], [2, "현장 조사"], [3, "추가 조사"]].map(([k, l]) => `<button data-evf="${k}" aria-pressed="${ui.evFilter === k}">${l}</button>`).join("");
    return `<div class="filters">${f}</div>${owned.length ? `<div class="evgrid">${owned.map(e => evCard(e)).join("")}${missing ? `<div class="evcard ghost">아직 찾지 못한 증거 ${missing}개</div>` : ""}</div>` : `<div class="empty">아직 모은 증거가 없다. 지도에서 장소와 조사 대상을 눌러 증거를 모으자.</div>`}`;
  }

  /* ---------- 수사 기록 ---------- */
  function viewRecords() {
    const deds = E.st.deductions;
    const dedHtml = deds.length ? `<section class="recgroup ded-rec"><header><span class="dedmark">추</span>탐정의 추리<span class="note" style="margin-left:auto;font-weight:500">${deds.length}건</span></header><ol>${deds.map(id => `<li><b>${esc(E.dedClaim(id))}</b>${E.st.dedSaid[id] ? `<span class="said">내가 한 말: “${esc(E.st.dedSaid[id])}”</span>` : ""}</li>`).join("")}</ol></section>` : "";
    if (!E.st.records.length && !deds.length) return `<div class="empty">대화로 알아낸 내용과 탐정이 세운 추리가 여기에 정리된다.<br>인물에게 질문하고 증거를 제시해 보자. 증거가 가리키는 결론이 떠오르면 레스트레이드 경감에게 보고해 보자.</div>`;
    const by = {};
    E.st.records.forEach(r => { (by[r.c] = by[r.c] || []).push(r); });
    return `<div class="records">${dedHtml}${CHAR_ORDER.filter(c => by[c]).map(c => `<section class="recgroup"><header>${Art.portrait(c, { size: 30 })}${esc(NAMES[c])}<span class="note" style="margin-left:auto;font-weight:500">${by[c].length}건</span></header><ol>${by[c].map(r => `<li>${esc(E.kText[r.k])}${E.lineTier(r.k) > 0 ? `<span class="tag">새로 털어놓음</span>` : ""}</li>`).join("")}</ol></section>`).join("")}</div>`;
  }

  /* ---------- 결론 ---------- */
  function viewConclude() {
    const sus = ["james_mccarthy", "john_turner", "william_crowder", "patience_moran", "alice_turner", "inspector_lestrade"];
    const owned = E.CASE.evidence.filter(e => E.st.owned.indexOf(e.id) >= 0);
    const last = E.st.ending ? S.endings[E.st.ending.id] : null;
    return `<div class="concl"><form class="cform" id="cform">
      <h3>1. 범인은 누구인가</h3><div class="suspects">${sus.map(c => `<button type="button" class="suspect" data-sus="${c}" aria-pressed="${ui.picked.culprit === c}">${Art.portrait(c, { size: 46 })}${esc(NAMES[c])}</button>`).join("")}</div>
      <h3>2. 범인은 왜 그랬는가</h3>
      <textarea id="motiveText" class="motive" rows="5" maxlength="1000" placeholder="범인의 동기를 내 말로 적어 보자. 무엇이 범인을 몰아붙였는지, 범인이 무엇을 지키거나 끝내려 했는지 근거와 함께 쓰면 좋다.">${esc(ui.picked.motive)}</textarea>
      <p class="note" style="margin:4px 0 0">${aiOn() ? "제출하면 AI 채점관이 진상과 대조해 채점한다." : "AI에 연결되지 않아 핵심 표현으로 채점한다."} 범인으로 터너를 지목하면 터너가 직접 반응한다. 여기 쓴 추리도 수사 기록에 반영된다.</p>
      <h3>3. 결정적인 증거 (여러 개 고르기)</h3>${owned.length ? `<div class="evpick">${owned.map(e => `<label><input type="checkbox" name="kev" value="${e.id}" ${ui.picked.ev.indexOf(e.id) >= 0 ? "checked" : ""}> ${esc(e.title)}</label>`).join("")}</div>` : `<p class="note">아직 모은 증거가 없다.</p>`}
      <div style="margin-top:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button class="btn accent" type="submit" ${ui.grading ? "disabled" : ""}>${ui.grading ? "채점 중…" : "결론 제출"}</button><span class="note">제출 뒤에도 수사를 이어갈 수 있다.</span></div></form>
      <aside class="status"><h3>수사 현황</h3><ul>
        <li><span>모은 증거</span><b>${E.st.owned.length}/${E.CASE.evidence.length}</b></li>
        <li><span>세운 추리</span><b>${E.st.deductions.length}</b></li>
        <li><span>털어놓은 진술</span><b>${E.st.records.filter(r => E.lineTier(r.k) > 0).length}</b></li>
        <li><span>힌트 사용</span><b>${E.st.hintsUsed}</b></li>
      </ul>${last ? `<p class="note" style="margin-top:10px">지난 결론: <b>${esc(last.title)}</b></p>` : ""}</aside></div>`;
  }

  /* ---------- 대화 ---------- */
  function renderStrip() {
    $("#cstrip").innerHTML = CHAR_ORDER.map(c => {
      const av = E.available(c), cs = E.st.chars[c];
      return `<button class="cbtn ${av ? "" : "off"}" data-char="${c}" aria-pressed="${E.st.current === c}" title="${esc(NAMES[c])}"><span class="ring">${Art.portrait(c, { size: 46 })}</span>${av ? "" : `<span class="lock">🔒</span>`}${cs.unread ? `<span class="dot">${cs.unread}</span>` : ""}<span class="nm">${esc(SHORT[c])}</span></button>`;
    }).join("");
  }
  function renderHead() {
    const c = E.st.current, p = E.chars[c], cs = E.st.chars[c];
    const loc = LOCNAME[charLoc(c)] || p.location;
    $("#chead").innerHTML = `<button class="btn sm ghost back" data-close-chat>←</button>${Art.portrait(c, { size: 40 })}<div class="who"><b>${esc(p.name)}</b><div>${esc(p.role)} · ${esc(loc)}</div></div>
      <div class="meters" title="신뢰가 높으면 민감한 이야기를 털어놓고, 긴장이 너무 높으면 입을 닫는 인물도 있다"><div class="meter">신뢰<i><b style="width:${cs.trust}%"></b></i></div><div class="meter p">긴장<i><b style="width:${cs.pressure}%"></b></i></div></div>`;
  }
  function renderMsgs(typing) {
    const c = E.st.current, logs = E.st.logs[c];
    let html = "", prev = null;
    if (!E.available(c) && !logs.length) {
      html += `<div class="sys">${esc(E.chars[c].availability.unavailable_message)}</div>`;
      if (UNAVAIL_HINT[c]) html += `<div class="sys" style="background:rgba(43,38,32,.35)">${esc(UNAVAIL_HINT[c]())}</div>`;
    }
    logs.forEach(m => {
      if (m.f === "s") { html += `<div class="sys ${m.k || ""}">${esc(m.t)}</div>`; prev = null; return; }
      const me = m.f === "p", cont = prev === m.f;
      const att = (m.ev || []).map(id => `<div class="evatt">${Art.icon((Art.OBJECTS.find(o => o.ev === id) || {}).icon || Art.OFFMAP_ICONS[id] || "paper", 20)} 증거 제시: ${esc(evTitle(id))}</div>`).join("");
      html += `<div class="row ${me ? "me" : ""} ${cont ? "cont" : ""}">${me ? `<span class="tm">${m.ts}</span>` : `<div class="av">${Art.portrait(c, { size: 38, square: true })}</div>`}<div class="col">${me ? "" : `<div class="name">${esc(E.chars[c].name)}</div>`}<div class="bub">${m.t ? fmt(m.t) : ""}${att}</div></div>${me ? "" : `<span class="tm">${m.ts}</span>`}</div>`;
      prev = m.f;
    });
    if (typing) html += `<div class="row ${prev === "c" ? "cont" : ""}"><div class="av">${Art.portrait(c, { size: 38, square: true })}</div><div class="col"><div class="name">${esc(E.chars[c].name)}</div><div class="bub typing"><span></span><span></span><span></span></div></div></div>`;
    const box = $("#msgs"); box.innerHTML = html; box.scrollTop = box.scrollHeight;
  }
  /* 예시 질문은 입력창 안내문에 하나만 보인다(누를 수 있는 질문 목록은 두지 않음) */
  function exampleQuestion(c) {
    const cs = E.st.chars[c], sc = S.characters[c];
    const left = sc.suggest.filter(([t]) => t.indexOf("T_") !== 0 || cs.probed.indexOf(t) < 0)
      .filter(([t]) => !S.topicRequiresFlag[t] || E.st.flags.indexOf(S.topicRequiresFlag[t]) >= 0);
    return (left[0] || sc.suggest[0])[1];
  }
  function renderComposer() {
    const c = E.st.current, av = E.available(c);
    $("#attached").innerHTML = ui.attach.map(id => `<span class="chip">📎 ${esc(evTitle(id))}<button data-unattach="${id}" aria-label="빼기">✕</button></span>`).join("");
    $("#input").disabled = !av || ui.busy;
    $("#input").placeholder = !av ? "아직 대화할 수 없습니다" : settings.hints ? `자유롭게 질문하세요 — 예: ${exampleQuestion(c)}` : `${SHORT[c]}에게 자유롭게 질문하세요`;
    $("#send").disabled = !av || ui.busy;
    $("#btnEv").disabled = !av || ui.busy || !E.st.owned.length;
    const pop = $("#evpop");
    pop.hidden = !ui.evpop;
    if (ui.evpop) pop.innerHTML = E.CASE.evidence.filter(e => E.st.owned.indexOf(e.id) >= 0).map(e => `<button data-attach="${e.id}">${Art.icon((Art.OBJECTS.find(o => o.ev === e.id) || {}).icon || Art.OFFMAP_ICONS[e.id] || "paper", 22)}${esc(e.title)}</button>`).join("");
  }
  function renderChat(typing) { renderStrip(); renderHead(); renderMsgs(typing); renderComposer(); }
  function renderAll() { renderTop(); renderMain(); renderChat(); }

  function openChar(c) {
    E.st.current = c;
    const cs = E.st.chars[c];
    cs.unread = 0;
    if (E.available(c) && !cs.met) { cs.met = true; log(c, { f: "c", t: S.characters[c].greet }); }
    ui.attach = []; ui.evpop = false;
    save();
    document.body.classList.add("chat-open");
    renderAll();
    setTimeout(() => { const i = $("#input"); if (i && !i.disabled && window.innerWidth > 860) i.focus(); }, 30);
  }

  /* ---------- AI 서버(배포자 PC의 Ollama) ---------- */
  function aiBase() {
    if (settings.ai.server) return settings.ai.server.replace(/\/$/, "");
    return /^https?:/.test(location.protocol) ? location.origin : "";
  }
  function aiOn() { return settings.ai.enabled && ui.ai.state === "on"; }
  function aiPill() {
    const st = !settings.ai.enabled ? ["off", "대본 모드"] : ui.ai.state === "on" ? ["on", "AI 대화 · " + ui.ai.model] : ui.ai.state === "checking" ? ["", "AI 서버 확인 중…"] : ["off", "대본 모드"];
    return `<button class="chip aipill ${st[0]}" id="btnAiPill" title="${esc(ui.ai.reason || "")}">${esc(st[1])}</button>`;
  }
  async function api(path, body, ms) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), ms || 60000);
    try {
      const r = await fetch(aiBase() + path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal } : { signal: ctrl.signal });
      return await r.json();
    } finally { clearTimeout(timer); }
  }
  const PR = new window.BVPrompts(G.personas, G.case);
  const CLAUDE_OPTS = { model: "claude-haiku-5-5", modelTier: "quick", cache: false };
  let sampleFn = null;
  async function checkServer() {
    if (!settings.ai.enabled) { ui.ai = { state: "off", model: "", reason: "설정에서 꺼 두었다" }; renderTop(); return; }
    ui.ai.state = "checking"; renderTop();
    // claude.ai 아티팩트 안에서 열면: 보는 사람의 Claude 계정으로 연결(배포판의 Ollama 자리를 임시로 대신함)
    if (window.claude && typeof window.claude.use === "function") {
      try { sampleFn = await window.claude.use("sample"); } catch (e) { sampleFn = null; }
      if (sampleFn) {
        ui.ai = { state: "on", provider: "claude", model: "Claude Haiku 5.5", reason: "보는 사람의 Claude 계정으로 Claude Haiku 5.5가 대사를 만든다. 배포판에서는 이 자리를 배포자 PC의 Ollama가 맡는다." };
        renderTop(); renderComposer(); return;
      }
    }
    if (!aiBase()) { ui.ai = { state: "off", model: "", reason: "파일로 열었기 때문에 대본 모드로 동작한다. 게임 서버 주소로 접속하면 AI 대화를 쓸 수 있다." }; renderTop(); return; }
    try {
      const st = await api("/api/status", null, 6000);
      ui.ai = st.ok ? { state: "on", provider: "server", model: st.model, reason: "배포자 PC의 Ollama로 인물이 자유롭게 대답한다" } : { state: "off", model: "", reason: st.reason || "AI 서버를 쓸 수 없다" };
    } catch (e) { ui.ai = { state: "off", model: "", reason: "AI 서버에 연결하지 못했다" }; }
    renderTop(); renderComposer();
  }
  async function aiJudge(c, text) {
    if (ui.ai.provider === "claude") return PR.cleanJudge(await sampleFn.json(PR.judgeInput(c, text, E.st.owned), CLAUDE_OPTS), E.st.owned);
    return api("/api/judge", { cid: c, text: text, owned: E.st.owned }, 45000);
  }
  async function aiSpeak(o) {
    if (ui.ai.provider === "claude") {
      for (const strict of [false, true]) {
        const r = await sampleFn(PR.speakInput(Object.assign({}, o, { strict: strict })), CLAUDE_OPTS);
        if (!r.modelApplied && r.modelTierApplied) { ui.ai.model = "Claude(" + r.modelTierApplied + ")"; }
        const t = PR.cleanReply(r.text);
        if (t && !E.leakCheck(o.cid, t).length) return { ok: true, text: t };
      }
      return { ok: false };
    }
    return api("/api/speak", o, 150000);
  }
  async function aiGrade(cid, text) {
    if (ui.ai.provider === "claude") return PR.cleanGrade(await sampleFn.json(PR.gradeInput(NAMES[cid], text, S.motiveRubric), CLAUDE_OPTS), S.motiveRubric.length);
    const r = await api("/api/grade", { cid: cid, text: text }, 90000);
    if (!r || !r.ok) throw new Error("grade failed");
    return r;
  }
  function aiError(e) {
    const code = e && e.code;
    if (ui.ai.provider === "claude") {
      if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].indexOf(code) >= 0) {
        ui.ai = { state: "off", model: "", reason: "Claude 사용이 허용되지 않아 대본 모드로 진행한다" };
        toast("Claude 사용을 허용하지 않아 대본 대사로 진행합니다."); renderTop(); return;
      }
      if (code === "rate_limited") { toast("Claude 사용량 한도에 걸려 이번 대답은 대본 대사로 했습니다. 잠시 뒤 다시 시도하세요."); return; }
      if (code === "session_expired") { toast("Claude에 다시 로그인해야 합니다. 이번 대답은 대본 대사로 했습니다."); return; }
      if (code === "cancelled") return;
      toast("Claude 응답에 문제가 있어 이번 대답은 대본 대사로 했습니다."); return;
    }
    aiFail();
  }
  function aiFail(msg) {
    ui.ai = { state: "off", model: "", reason: msg || "AI 서버 응답이 없다" };
    if (!ui.aiWarned) { toast("AI 서버 연결이 끊겨 대본 모드로 진행합니다. 잠시 뒤 다시 연결을 시도합니다."); ui.aiWarned = true; }
    setTimeout(() => { ui.aiWarned = false; checkServer(); }, 30000);
  }
  function splitBubbles(t) {
    const parts = t.split(/\n\s*\n+/).map(x => x.trim()).filter(Boolean);
    if (parts.length <= 3) return parts.length ? parts : [t];
    return [parts[0], parts[1], parts.slice(2).join(" ")];
  }

  async function send(text) {
    const c = E.st.current;
    text = (text || "").trim();
    if (ui.busy || (!text && !ui.attach.length) || !E.available(c)) return;
    const ev = ui.attach.slice();
    log(c, { f: "p", t: text, ev: ev });
    ui.attach = []; ui.evpop = false; ui.busy = true;
    $("#input").value = "";
    renderChat(true);
    let ext = null;
    ui.lastAI = { ai: aiOn(), judge: null, speak: null };   // 점검 모드(?qa=1)가 읽는 기록
    if (aiOn()) {
      try { ext = await aiJudge(c, text); if (!ext || !ext.ok) ext = null; }
      catch (e) { ext = null; aiError(e); }
      ui.lastAI.judge = ext;
    }
    const r = E.respond(c, text, ev, ext);
    let bubbles = r.bubbles.map(b => b.text);
    if (aiOn() && bubbles.length) {
      const cs = E.st.chars[c];
      const history = E.st.logs[c].filter(m => m.f !== "s").slice(-9, -1).map(m => ({ role: m.f === "p" ? "user" : "assistant",
        content: (m.t || "") + (m.ev && m.ev.length ? " [증거 제시: " + m.ev.map(evTitle).join(", ") + "]" : "") }));
      try {
        const sp = await aiSpeak({ cid: c, text: text, unlocked: cs.unlocked, trust: cs.trust, pressure: cs.pressure, heard: cs.heard,
          presented: r.judge.presented, ctx: r.ctx, draft: bubbles.join(" "), history: history });
        const lk = sp.ok ? E.leakCheck(c, sp.text) : [];
        ui.lastAI.speak = { ok: !!sp.ok, attempt: sp.attempt || null, reason: sp.reason || null, browserLeaks: lk };
        if (sp.ok && !lk.length) bubbles = splitBubbles(sp.text);
      } catch (e) { ui.lastAI.speak = { ok: false, reason: "error" }; aiError(e); }
    } else await sleep(450 + Math.min(900, text.length * 12));
    for (let i = 0; i < bubbles.length; i++) {
      log(c, { f: "c", t: bubbles[i] });
      renderMsgs(i < bubbles.length - 1);
      if (i < bubbles.length - 1) await sleep(520);
    }
    r.system.forEach(t => log(c, { f: "s", t: t }));
    (r.newDeductions || []).forEach(id => log(c, { f: "s", t: "탐정의 추리를 수사 기록에 적었다: " + E.dedClaim(id), k: "ded" }));
    if ((r.newFlags || []).indexOf("turner_summoned") >= 0) E.st.chars.john_turner.unread += 1;
    if (r.unlocked.length) log(c, { f: "s", t: `${E.chars[c].name}이(가) 새로운 이야기를 털어놓았다 — 수사 기록에 추가됨`, k: "unlock" });
    (r.newFlags || []).forEach(f => { if (FLAG_MSG[f]) log(c, { f: "s", t: FLAG_MSG[f], k: "flag" }); });
    if ((r.newFlags || []).indexOf("prison_visit_granted") >= 0) E.st.chars.james_mccarthy.unread += 1;
    ui.busy = false;
    save();
    renderAll();
    const i = $("#input"); if (i && window.innerWidth > 860) i.focus();
  }

  /* ---------- 창 ---------- */
  function modal(title, body, buttons) {
    closeModal();
    const back = document.createElement("div"); back.className = "modal-back"; back.id = "modal";
    back.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h2>${esc(title)}</h2><button class="btn sm ghost" data-modal-close aria-label="닫기">✕</button></header><div class="body">${body}</div>${buttons ? `<footer>${buttons}</footer>` : ""}</div>`;
    document.body.appendChild(back);
    back.addEventListener("click", e => { if (e.target === back) closeModal(); });
    const b = back.querySelector("footer .btn, [data-modal-close]"); if (b) b.focus();
  }
  function closeModal() { const m = $("#modal"); if (m) m.remove(); }

  function inspect(id) {
    const st = E.evidenceStatus(id);
    if (st.state === "locked") { toast(lockReason(id)); return; }
    const r = E.inspect(id);
    save(); renderAll();
    const e = r.evidence;
    modal(r.isNew ? "새 증거를 찾았다" : e.title, `${r.isNew ? `<p class="note">${esc(LOCNAME[e.location])} — ${esc(e.object)}</p>` : ""}<div class="doc"><b>${esc(e.title)}</b><br>${esc(e.text)}</div>`,
      `<button class="btn" data-present="${e.id}">${esc(SHORT[E.st.current])}에게 제시</button><button class="btn primary" data-modal-close>확인</button>`);
  }

  function doAction(aid) {
    if (E.actionStatus(aid).state === "done") { toast("레스트레이드 경감이 숲지기 모런 편에 터너에게 보낸 쪽지다. 터너와 대화할 수 있다."); return; }
    toast(noteHint());
  }

  function showBriefing(first) {
    const b = G.personas.scenario.public_briefing.map(x => `<li>${esc(x)}</li>`).join("");
    modal("사건 개요", `<div class="doc"><ul class="brief" style="margin:0;padding-left:18px">${b}</ul></div>
      <div class="how"><div><b>1. 조사</b>지도의 장소와 물건을 눌러 증거를 모은다.</div><div><b>2. 대화</b>인물에게 자유롭게 묻고, 증거를 제시한다.</div><div><b>3. 추리</b>증거가 가리키는 결론은 레스트레이드 경감에게 보고한다. 범인과 마주했을 때 들이밀거나 결론에 적어도 된다. 세운 추리는 수사 기록에 남는다.</div><div><b>4. 결론</b>범인을 고르고 동기를 내 말로 적어 제출한다.</div></div>
      <p class="note">막히면 머리글의 💡 힌트 버튼으로 다음에 해 볼 행동을 하나씩 볼 수 있다. 인물은 근거 없는 추궁에는 입을 닫고, 증거를 들이밀면 조금씩 털어놓는다. 행동 횟수 제한은 없다. 게임 서버로 접속하면 인물이 자유로운 질문에도 대답하고, 서버 없이 파일로 열면 대본 대사로 대답한다.</p>`,
      `<button class="btn primary" data-modal-close>${first ? "수사 시작" : "닫기"}</button>`);
  }

  function showSettings() {
    modal("설정", `<label class="toggle"><input type="checkbox" id="setHints" ${settings.hints ? "checked" : ""}> 입력창에 예시 질문 보이기</label>
      <hr style="border:0;border-top:1px solid var(--line);margin:12px 0">
      <label class="toggle"><input type="checkbox" id="setAi" ${settings.ai.enabled ? "checked" : ""}> AI 대화 쓰기(게임 서버에 접속한 경우)</label>
      <p class="note">게임 서버로 접속하면 배포자 PC의 Ollama가 질문을 이해하고 인물의 대답을 만든다. 무엇을 털어놓을지는 게임 규칙이 정하고, 잠긴 정보가 섞인 대답은 내보내지 않는다. 서버에 연결되지 않으면 대본 모드로 동작한다.</p>
      <div class="field"><span>게임 서버 주소 (비워 두면 지금 접속한 주소)</span><input type="text" id="setServer" placeholder="예: http://192.168.0.10:8000" value="${esc(settings.ai.server)}"></div>
      <div id="aiTest" class="note">현재 상태: ${esc(ui.ai.state === "on" ? "AI 대화 연결됨 (" + ui.ai.model + ") — " + ui.ai.reason : ui.ai.reason || "확인 중")}</div>`,
      `<button class="btn" id="btnTest">연결 시험</button><button class="btn primary" id="btnSaveSet">저장</button>`);
  }

  function showEnding(end, reaction) {
    const en = S.endings[end.id], r = end.report, g = r.grade;
    const row = (k, v, ok) => `<tr><td>${k}</td><td class="${ok === undefined ? "" : ok ? "ok" : "no"}">${v}</td></tr>`;
    const truth = G.personas.gm_truth;
    const by = g.by === "keyword" ? "핵심 표현 채점" : g.by;
    const motiveRow = r.culprit ? `${g.score}/${g.max} · ${esc(g.verdict)} <span class="note">(${esc(by)})</span>` : "범인을 잘못 지목해 채점하지 않음";
    modal(en.title, `<div class="doc">${esc(en.text)}</div>
      ${reaction ? `<div class="reaction">${Art.portrait("john_turner", { size: 44, square: true })}<div><b>${esc(NAMES.john_turner)}</b><p>${fmt(reaction)}</p></div></div>` : ""}
      <table class="report">
        ${row("범인", r.culprit ? "맞음" : "틀림", r.culprit)}
        ${row("동기", motiveRow, r.culprit ? r.motive : undefined)}
        ${r.culprit && g.feedback ? `<tr><td></td><td class="fb">${esc(g.feedback)}</td></tr>` : ""}
        ${row("결정적 증거(정답 세트의 최소 해결 증거와 일치)", `${r.keyEvidence}/${r.keyChosen}개 선택`, r.keyEvidence >= 3)}
        ${row("범인 특징·흐름 추리", `${r.deductions}/${r.deductionsTotal}`, r.deductions >= 4)}
        ${row("다른 후보 배제", `${r.exclusions}/3`, r.exclusions === 3)}
        ${row("범인의 자백", r.fullConfession ? "전부 털어놓음" : r.confessed ? "자백" : "없음", r.confessed)}
        ${row("모은 증거", `${r.evidenceOwned}/${r.evidenceTotal}`)}
        ${row("힌트 사용", `${r.hintsUsed || 0}회`)}
      </table>
      <details><summary style="cursor:pointer;font-weight:600">진상 보기 (스포일러)</summary><p style="margin-top:8px">${esc(truth.motive)}</p>${r.culprit ? `<p class="note">채점 요소: ${S.motiveRubric.map((m, i) => (g.points[i] ? "✓ " : "· ") + esc(m.label)).join(" / ")}</p>` : ""}<p>${esc(truth.method)}</p><ol class="timeline">${truth.timeline.map(t => `<li><b>${esc(t.t)}</b> ${esc(t.event)}</li>`).join("")}</ol></details>`,
      `<button class="btn" data-modal-close>계속 수사하기</button><button class="btn accent" data-reset>처음부터 다시</button>`);
  }

  /* ---------- 힌트 ---------- */
  function showHint(level) {
    const h = E.hint();
    if (level === undefined) level = Math.max(0, h.level);
    E.useHint(h.id, level);
    save(); renderTop();
    const more = level < 1 ? `<button class="btn" data-hint-more>더 구체적으로</button>` : "";
    modal("힌트", `<div class="hint"><span class="hint-ico">💡</span><p>${esc(h.text[0])}</p></div>${level >= 1 ? `<div class="hint more"><span class="hint-ico">🔎</span><p>${esc(h.text[1])}</p></div>` : ""}
      <p class="note">힌트는 지금 해 볼 만한 것을 하나만 알려 준다. 사용 횟수는 결과에 기록된다(지금 ${E.st.hintsUsed}회).</p>`,
      `${more}<button class="btn primary" data-modal-close>닫기</button>`);
  }

  /* ---------- 결론 제출 ---------- */
  async function submitConclusion() {
    const cid = ui.picked.culprit, text = ui.picked.motive.trim();
    if (!cid) { toast("범인을 고르자."); return; }
    if (text.length < 8) { toast("범인이 왜 그랬는지 한 문장 이상 적어 보자."); return; }
    E.creditDeductions(text);
    ui.grading = true; renderMain();
    modal("결론 검토 중", `<p>${aiOn() ? "채점관이 결론을 진상과 대조하고 있다…" : "결론을 정리하고 있다…"}</p>`);
    let grade = null;
    if (cid === E.CASE.answer.culprit && aiOn()) {
      try { const a = await aiGrade(cid, text); grade = E.makeGrade(a.points, a.feedback, ui.ai.model + " 채점"); }
      catch (e) { aiError(e); }
    }
    if (!grade) grade = E.gradeMotive(text);
    const end = E.accuse(cid, { text: text, grade: grade }, ui.picked.ev);
    let reaction = null;
    if (cid === "john_turner" && E.available("john_turner")) {
      const confessed = end.report.confessed, tv = S.turnerVerdict;
      reaction = !confessed ? tv.denied : grade.score >= 2 ? tv.confessedGood : tv.confessedPart;
      if (aiOn()) {
        const cs = E.st.chars.john_turner;
        try {
          const sp = await aiSpeak({ cid: "john_turner", text: "범인은 당신입니다. " + text, unlocked: cs.unlocked, trust: cs.trust, pressure: cs.pressure, heard: cs.heard,
            presented: [], ctx: { newly: [], deflect: [], verdict: { score: grade.score, max: grade.max, confessed: confessed } }, draft: reaction, history: [] });
          if (sp.ok && !E.leakCheck("john_turner", sp.text).length) reaction = sp.text;
        } catch (e) { aiError(e); }
      }
      if (E.leakCheck("john_turner", reaction).length) reaction = tv.denied;
      log("john_turner", { f: "p", t: "범인은 당신입니다. " + text });
      log("john_turner", { f: "c", t: reaction });
    }
    ui.grading = false;
    save(); renderAll(); showEnding(end, reaction);
  }

  /* ---------- 이벤트 ---------- */
  document.addEventListener("click", async e => {
    const t = e.target.closest("button, [data-ev], [data-act], [data-char], [data-loc], [data-scene], g.hot, g.pin, g.maploc, g.sobj, g.spin");
    if (!t) return;
    const d = t.dataset;
    if (d.modalClose !== undefined) { closeModal(); return; }
    if (d.tab) { ui.tab = d.tab; renderMain(); return; }
    if (d.closeChat !== undefined) { document.body.classList.remove("chat-open"); return; }
    if (d.present) { if (!E.available(E.st.current)) { toast("지금 대화 상대에게는 제시할 수 없다."); return; } if (ui.attach.indexOf(d.present) < 0) ui.attach.push(d.present); closeModal(); document.body.classList.add("chat-open"); renderComposer(); toast("증거를 첨부했다. 질문과 함께 보내자."); $("#input").focus(); return; }
    if (d.attach) { if (ui.attach.indexOf(d.attach) < 0) ui.attach.push(d.attach); ui.evpop = false; renderComposer(); $("#input").focus(); return; }
    if (d.unattach) { ui.attach = ui.attach.filter(x => x !== d.unattach); renderComposer(); return; }
    if (d.q) { send(d.q); return; }
    if (d.evf !== undefined) { ui.evFilter = +d.evf; renderMain(); return; }
    if (d.sus) { ui.picked.culprit = d.sus; renderMain(); return; }
    if (d.reset !== undefined || t.id === "btnReset") { modal("처음부터 다시", `<p>지금까지 모은 증거, 대화, 추리를 모두 지우고 처음부터 시작한다.</p>`, `<button class="btn" data-modal-close>취소</button><button class="btn accent" data-reset-yes>지우고 새로 시작</button>`); return; }
    if (d.resetYes !== undefined) { E.reset(); save(); ui.picked = { culprit: null, motive: "", ev: [] }; ui.tab = "map"; ui.loc = "ross_hotel"; closeModal(); const c0 = E.st.current; E.st.chars[c0].met = true; log(c0, { f: "c", t: S.characters[c0].greet }); save(); renderAll(); showBriefing(true); return; }
    if (d.scene) { ui.loc = ui.loc === d.scene ? "overview" : d.scene; renderMain(); return; }
    if (t.matches && t.matches("g.hot, g.maploc")) { ui.loc = Sc.sceneOf(d.loc); renderMain(); return; }
    if (d.ev) { inspect(d.ev); return; }
    if (d.act) { doAction(d.act); return; }
    if (d.char) { closeModal(); openChar(d.char); return; }
    if (d.loc) { ui.loc = Sc.sceneOf(d.loc); renderMain(); return; }
    if (t.id === "btnBrief") { showBriefing(false); return; }
    if (t.id === "btnHint") { showHint(); return; }
    if (d.hintMore !== undefined) { showHint(1); return; }
    if (t.id === "btnSettings") { showSettings(); return; }
    if (t.id === "btnEv") { ui.evpop = !ui.evpop; renderComposer(); return; }
    if (t.id === "send") { send($("#input").value); return; }
    if (t.id === "toChat") { openChar(E.st.current); return; }
    if (t.id === "toMain") { document.body.classList.remove("chat-open"); return; }
    if (t.id === "btnAiPill") { showSettings(); return; }
    if (t.id === "btnSaveSet") {
      settings.hints = $("#setHints").checked;
      settings.ai = { enabled: $("#setAi").checked, server: $("#setServer").value.trim() };
      trySet(SET_KEY, JSON.stringify(settings)); closeModal(); renderChat(); toast("설정을 저장했다."); checkServer(); return;
    }
    if (t.id === "btnTest") {
      const out = $("#aiTest"); out.textContent = "시험 중…";
      const keep = settings.ai.server; settings.ai.server = $("#setServer").value.trim();
      try {
        const st = await api("/api/status", null, 6000);
        out.innerHTML = st.ok ? `<b class="ok">연결됨</b> — 모델 ${esc(st.model)}` : `<b class="no">서버는 켜져 있지만 AI를 쓸 수 없다.</b> ${esc(st.reason || "")}`;
      } catch (err) { out.innerHTML = `<b class="no">게임 서버에 연결하지 못했다.</b> 주소와 서버 실행 여부를 확인하자.`; }
      settings.ai.server = keep;
      return;
    }
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { closeModal(); ui.evpop = false; renderComposer(); }
    if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("g.hot, g.pin, g.sobj, g.spin")) { e.preventDefault(); e.target.dispatchEvent(new MouseEvent("click", { bubbles: true })); }
  });
  document.addEventListener("submit", e => {
    e.preventDefault();
    const f = e.target;
    if (f.id === "cform") {
      ui.picked.motive = ($("#motiveText") || {}).value || "";
      ui.picked.ev = Array.from(f.querySelectorAll("input[name=kev]:checked")).map(x => x.value);
      if (!ui.grading) submitConclusion();
    }
  });
  document.addEventListener("change", e => {
    if (e.target.name === "kev") ui.picked.ev = Array.from(document.querySelectorAll("input[name=kev]:checked")).map(x => x.value);
  });
  const input = $("#input");
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(input.value); }
  });
  document.addEventListener("input", e => { if (e.target.id === "motiveText") ui.picked.motive = e.target.value; });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(120, input.scrollHeight) + "px"; });

  (function greetCurrent() {
    const c0 = E.st.current;
    if (E.available(c0) && !E.st.chars[c0].met) { E.st.chars[c0].met = true; log(c0, { f: "c", t: S.characters[c0].greet }); }
  })();
  renderAll();
  checkServer();
  if (!tryGet(SAVE_KEY) || E.st.turn === 0 && !E.st.owned.length) showBriefing(true);
  window.__bv = { E: E, send: send, openChar: openChar, inspect: inspect, ui: ui, renderAll: renderAll, showHint: showHint, submitConclusion: submitConclusion };
})();
