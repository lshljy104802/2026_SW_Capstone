/* 보스콤 밸리 로컬 게임 — 그림(인물 초상, 사건 지도). 외부 이미지 없이 SVG로 그린다. */
(function (root) {
  "use strict";

  /* ---------------- 인물 초상 ---------------- */
  const P = {
    james_mccarthy: { bg: "#c9b79c", coat: "#2f3a4a", skin: "#efd2b6", hair: "#3b2a1e", style: "short", collar: "#f3efe6", brow: "worried" },
    john_turner: { bg: "#b7a78c", coat: "#3b3330", skin: "#ddd2c6", hair: "#cfcac1", style: "wild", beard: "full", collar: "#e9e4da", brow: "heavy", lines: true, lips: "#8f8aa0" },
    alice_turner: { bg: "#d9c4d0", coat: "#5b3f78", skin: "#f3d9c6", hair: "#8a3b22", style: "long", eyes: "#6a4c9c", cheeks: true, collar: "#efe6f0" },
    patience_moran: { bg: "#cdd7bd", coat: "#7d8f6a", skin: "#f2d6bd", hair: "#9a6b3e", style: "bonnet", small: true, collar: "#efe9da", brow: "scared" },
    william_crowder: { bg: "#beb299", coat: "#6b5a3e", skin: "#e2b996", hair: "#5a4632", style: "cap", mustache: "thick", collar: "#d8cdb6", ruddy: true },
    inspector_lestrade: { bg: "#c4c0b1", coat: "#a88f6a", skin: "#ead0b8", hair: "#2e261f", style: "slick", mustache: "thin", collar: "#f1ece2", thin: true }
  };

  function portrait(cid, opts) {
    const o = P[cid], id = "pc_" + cid + "_" + Math.random().toString(36).slice(2, 7);
    const rx = o.thin ? 14.5 : o.small ? 15 : 16.5, ry = o.thin ? 20.5 : o.small ? 18 : 19.5;
    const hx = 50, hy = o.small ? 49 : 46;
    let g = "";
    g += `<rect width="100" height="100" fill="${o.bg}"/>`;
    g += `<path d="M8 100 C12 80 30 71 50 71 C70 71 88 80 92 100 Z" fill="${o.coat}"/>`;
    if (cid === "inspector_lestrade") g += `<path d="M30 76 L44 100 L36 100 Z M70 76 L56 100 L64 100 Z" fill="#8e7754"/>`;
    g += `<path d="M42 70 L50 82 L58 70 Z" fill="${o.collar}"/>`;
    if (cid === "james_mccarthy" || cid === "john_turner") g += `<path d="M47 72 L50 80 L53 72 Z" fill="#5a2a2a"/>`;
    if (cid === "alice_turner") g += `<circle cx="50" cy="76" r="2.4" fill="#e9d48a"/>`;
    g += `<rect x="${hx - 6}" y="${hy + 14}" width="12" height="11" rx="4" fill="${o.skin}"/>`;
    // 뒷머리
    if (o.style === "long") g += `<path d="M30 44 C28 24 72 24 70 44 C72 60 74 74 66 80 L60 64 C60 70 40 70 40 64 L34 80 C26 74 28 60 30 44 Z" fill="${o.hair}"/>`;
    if (o.style === "bonnet") g += `<path d="M28 50 C26 22 74 22 72 50 C72 58 68 62 66 62 L34 62 C32 62 28 58 28 50 Z" fill="#e9dcc2" stroke="#cbb88f" stroke-width="1.2"/>`;
    // 귀, 얼굴
    g += `<ellipse cx="${hx - rx + 0.5}" cy="${hy + 2}" rx="3" ry="4.5" fill="${o.skin}"/><ellipse cx="${hx + rx - 0.5}" cy="${hy + 2}" rx="3" ry="4.5" fill="${o.skin}"/>`;
    g += `<ellipse cx="${hx}" cy="${hy}" rx="${rx}" ry="${ry}" fill="${o.skin}"/>`;
    if (o.ruddy) g += `<ellipse cx="${hx - 9}" cy="${hy + 6}" rx="4" ry="2.6" fill="#d98c6c" opacity=".45"/><ellipse cx="${hx + 9}" cy="${hy + 6}" rx="4" ry="2.6" fill="#d98c6c" opacity=".45"/>`;
    if (o.cheeks) g += `<ellipse cx="${hx - 9}" cy="${hy + 7}" rx="3.6" ry="2.2" fill="#e88b8b" opacity=".45"/><ellipse cx="${hx + 9}" cy="${hy + 7}" rx="3.6" ry="2.2" fill="#e88b8b" opacity=".45"/>`;
    // 눈, 눈썹
    const ey = hy + 1, eyeC = o.eyes || "#2a211b";
    g += `<ellipse cx="${hx - 6.5}" cy="${ey}" rx="1.9" ry="${o.small ? 2.3 : 1.9}" fill="${eyeC}"/><ellipse cx="${hx + 6.5}" cy="${ey}" rx="1.9" ry="${o.small ? 2.3 : 1.9}" fill="${eyeC}"/>`;
    const bc = o.style === "wild" ? "#9e988d" : o.hair;
    const bw = o.brow === "heavy" ? 2.6 : 1.5;
    if (o.brow === "worried" || o.brow === "scared") g += `<path d="M${hx - 10} ${ey - 4} L${hx - 3} ${ey - 6}" stroke="${bc}" stroke-width="${bw}" stroke-linecap="round"/><path d="M${hx + 10} ${ey - 4} L${hx + 3} ${ey - 6}" stroke="${bc}" stroke-width="${bw}" stroke-linecap="round"/>`;
    else g += `<path d="M${hx - 10} ${ey - 5} Q${hx - 6.5} ${ey - 7.5} ${hx - 3} ${ey - 5.5}" stroke="${bc}" stroke-width="${bw}" fill="none" stroke-linecap="round"/><path d="M${hx + 10} ${ey - 5} Q${hx + 6.5} ${ey - 7.5} ${hx + 3} ${ey - 5.5}" stroke="${bc}" stroke-width="${bw}" fill="none" stroke-linecap="round"/>`;
    // 코
    g += `<path d="M${hx} ${ey + 2} L${hx - 2} ${ey + 8} L${hx + 1.5} ${ey + 8.5}" stroke="#b58f73" stroke-width="1.1" fill="none" stroke-linecap="round"/>`;
    if (o.lines) g += `<path d="M${hx - 12} ${ey - 9} Q${hx} ${ey - 12} ${hx + 12} ${ey - 9}" stroke="#b9a999" stroke-width=".9" fill="none"/><path d="M${hx - 13} ${ey + 3} Q${hx - 12} ${ey + 8} ${hx - 9} ${ey + 11}" stroke="#b9a999" stroke-width=".9" fill="none"/><path d="M${hx + 13} ${ey + 3} Q${hx + 12} ${ey + 8} ${hx + 9} ${ey + 11}" stroke="#b9a999" stroke-width=".9" fill="none"/>`;
    // 입
    const my = hy + 13;
    if (!o.beard) g += `<path d="M${hx - 4} ${my} Q${hx} ${my + (o.brow === "worried" || o.brow === "scared" ? -1 : 1.6)} ${hx + 4} ${my}" stroke="${o.lips || "#9c5b4f"}" stroke-width="1.4" fill="none" stroke-linecap="round"/>`;
    // 수염
    if (o.mustache === "thick") g += `<path d="M${hx - 8} ${my - 1} Q${hx} ${my - 6} ${hx + 8} ${my - 1} Q${hx} ${my - 2.5} ${hx - 8} ${my - 1} Z" fill="${o.hair}"/>`;
    if (o.mustache === "thin") g += `<path d="M${hx - 6} ${my - 1.5} Q${hx} ${my - 4.5} ${hx + 6} ${my - 1.5}" stroke="${o.hair}" stroke-width="1.6" fill="none" stroke-linecap="round"/>`;
    if (o.beard === "full") g += `<path d="M${hx - 15} ${hy + 2} C${hx - 16} ${hy + 22} ${hx - 6} ${hy + 30} ${hx} ${hy + 31} C${hx + 6} ${hy + 30} ${hx + 16} ${hy + 22} ${hx + 15} ${hy + 2} C${hx + 12} ${hy + 12} ${hx + 6} ${hy + 10} ${hx} ${hy + 11} C${hx - 6} ${hy + 10} ${hx - 12} ${hy + 12} ${hx - 15} ${hy + 2} Z" fill="${o.hair}"/><path d="M${hx - 4} ${my + 1} Q${hx} ${my + 2.5} ${hx + 4} ${my + 1}" stroke="${o.lips}" stroke-width="1.4" fill="none"/>`;
    // 앞머리·모자
    if (o.style === "short") g += `<path d="M${hx - rx - 1} ${hy - 2} C${hx - rx - 2} ${hy - 20} ${hx - 6} ${hy - 25} ${hx + 2} ${hy - 23} C${hx + 12} ${hy - 22} ${hx + rx + 2} ${hy - 15} ${hx + rx} ${hy - 1} C${hx + 12} ${hy - 12} ${hx + 2} ${hy - 13} ${hx - 6} ${hy - 11} C${hx - 11} ${hy - 9} ${hx - 14} ${hy - 6} ${hx - rx - 1} ${hy - 2} Z" fill="${o.hair}"/>`;
    if (o.style === "wild") g += `<path d="M${hx - rx - 3} ${hy} C${hx - rx - 6} ${hy - 18} ${hx - 10} ${hy - 28} ${hx} ${hy - 25} C${hx + 12} ${hy - 29} ${hx + rx + 6} ${hy - 16} ${hx + rx + 3} ${hy} C${hx + 12} ${hy - 13} ${hx + 4} ${hy - 15} ${hx} ${hy - 13} C${hx - 6} ${hy - 15} ${hx - 13} ${hy - 12} ${hx - rx - 3} ${hy} Z" fill="${o.hair}"/><path d="M${hx - rx - 4} ${hy - 6} l-3 -3 M${hx + rx + 4} ${hy - 6} l3 -3 M${hx - 6} ${hy - 25} l-2 -4 M${hx + 6} ${hy - 26} l2 -4" stroke="${o.hair}" stroke-width="2" stroke-linecap="round"/>`;
    if (o.style === "long") g += `<path d="M${hx - rx - 1} ${hy + 4} C${hx - rx - 3} ${hy - 18} ${hx - 4} ${hy - 26} ${hx + 3} ${hy - 23} C${hx + 14} ${hy - 21} ${hx + rx + 3} ${hy - 12} ${hx + rx + 1} ${hy + 4} C${hx + 12} ${hy - 9} ${hx + 6} ${hy - 13} ${hx} ${hy - 14} C${hx - 8} ${hy - 12} ${hx - 13} ${hy - 6} ${hx - rx - 1} ${hy + 4} Z" fill="${o.hair}"/><path d="M${hx + 9} ${hy - 19} q4 -4 8 0 q-4 4 -8 0" fill="#e2c35a"/>`;
    if (o.style === "bonnet") g += `<path d="M${hx - rx - 2} ${hy} C${hx - rx - 2} ${hy - 16} ${hx - 6} ${hy - 22} ${hx} ${hy - 21} C${hx + 6} ${hy - 22} ${hx + rx + 2} ${hy - 16} ${hx + rx + 2} ${hy} C${hx + 10} ${hy - 10} ${hx - 10} ${hy - 10} ${hx - rx - 2} ${hy} Z" fill="${o.hair}"/><path d="M${hx - rx - 4} ${hy + 6} C${hx - rx - 8} ${hy - 22} ${hx + rx + 8} ${hy - 22} ${hx + rx + 4} ${hy + 6}" fill="none" stroke="#e9dcc2" stroke-width="7"/><path d="M${hx - 6} ${hy + 19} l-3 9 M${hx + 6} ${hy + 19} l3 9" stroke="#c9a76b" stroke-width="2"/>`;
    if (o.style === "cap") g += `<path d="M${hx - rx - 3} ${hy - 6} C${hx - rx - 2} ${hy - 22} ${hx + rx + 2} ${hy - 24} ${hx + rx + 3} ${hy - 8} L${hx + rx + 9} ${hy - 4} C${hx + 10} ${hy - 6} ${hx - 10} ${hy - 7} ${hx - rx - 3} ${hy - 6} Z" fill="#4e4536"/><path d="M${hx - rx} ${hy - 9} L${hx + rx + 2} ${hy - 11}" stroke="#3c3529" stroke-width="1.2"/>`;
    if (o.style === "slick") g += `<path d="M${hx - rx - 1} ${hy - 4} C${hx - rx - 1} ${hy - 22} ${hx + rx + 1} ${hy - 25} ${hx + rx + 1} ${hy - 5} C${hx + 8} ${hy - 15} ${hx - 4} ${hy - 17} ${hx - rx - 1} ${hy - 4} Z" fill="${o.hair}"/><path d="M${hx - 2} ${hy - 20} Q${hx + 6} ${hy - 16} ${hx + 12} ${hy - 12}" stroke="#4a3f33" stroke-width="1" fill="none"/>`;
    const size = (opts && opts.size) || 44;
    return `<svg class="portrait" width="${size}" height="${size}" viewBox="0 0 100 100" role="img" aria-label="초상"><defs><clipPath id="${id}"><rect width="100" height="100" rx="${(opts && opts.square) ? 22 : 50}"/></clipPath></defs><g clip-path="url(#${id})">${g}</g></svg>`;
  }

  /* ---------------- 지도 아이콘 ---------------- */
  const ICON = {
    boots: `<path d="M-5 -7 h5 v8 h5 a2 2 0 0 1 2 2 v2 h-12 z" fill="#4a3a2a"/>`,
    paper: `<path d="M-5 -7 h7 l3 3 v11 h-10 z" fill="#f4ecd8" stroke="#6b5a3e" stroke-width=".8"/><path d="M-3 -2 h6 M-3 1 h6 M-3 4 h4" stroke="#6b5a3e" stroke-width=".7"/>`,
    news: `<rect x="-6" y="-6" width="12" height="12" fill="#f4ecd8" stroke="#6b5a3e" stroke-width=".8"/><rect x="-4.5" y="-4.5" width="5" height="4" fill="#6b5a3e"/><path d="M1.5 -4 h3 M1.5 -2 h3 M-4.5 1 h9 M-4.5 3 h9" stroke="#6b5a3e" stroke-width=".7"/>`,
    feet: `<ellipse cx="-2.5" cy="-2" rx="2" ry="3.2" fill="#3d3122"/><ellipse cx="2.8" cy="3" rx="2" ry="3.2" fill="#3d3122"/>`,
    feetSq: `<rect x="-4.6" y="-5.5" width="3.6" height="6" rx=".6" fill="#3d3122"/><rect x="1" y="0" width="3.6" height="6" rx=".6" fill="#3d3122" opacity=".55"/>`,
    cigar: `<rect x="-6" y="-1.5" width="10" height="3" rx="1.4" fill="#7a4b2a"/><rect x="3.5" y="-1.5" width="2.5" height="3" fill="#bdb4a6"/><path d="M6 -2 q2 -3 0 -5" stroke="#9b958c" stroke-width=".8" fill="none"/>`,
    stone: `<path d="M-6 3 L-3 -5 L3 -4 L6 2 L1 5 Z" fill="#8c8a83" stroke="#5e5c56" stroke-width=".8"/>`,
    eye: `<path d="M-7 0 Q0 -6 7 0 Q0 6 -7 0 Z" fill="#f4ecd8" stroke="#3d3122" stroke-width=".9"/><circle r="2.3" fill="#3d3122"/>`,
    book: `<rect x="-5.5" y="-6" width="11" height="12" rx="1" fill="#6e2f2a"/><path d="M-3.5 -6 v12" stroke="#d9c7a0" stroke-width=".8"/>`,
    person: `<circle cy="-3" r="3" fill="#3d3122"/><path d="M-5 6 q5 -9 10 0 z" fill="#3d3122"/>`,
    letter: `<rect x="-6" y="-4" width="12" height="8" fill="#f4ecd8" stroke="#6b5a3e" stroke-width=".8"/><path d="M-6 -4 l6 5 l6 -5" stroke="#6b5a3e" stroke-width=".8" fill="none"/><circle cy="1.5" r="1.4" fill="#8b2a22"/>`,
    map: `<path d="M-6 -5 l4 -1 l4 1 l4 -1 v11 l-4 1 l-4 -1 l-4 1 z" fill="#efe1bd" stroke="#6b5a3e" stroke-width=".8"/><path d="M-2 -6 v11 M2 -5 v11" stroke="#6b5a3e" stroke-width=".6"/>`,
    grass: `<path d="M-6 4 q2 -6 3 -1 q1 -7 3 0 q2 -6 3 1 q1 -5 3 0" stroke="#3f5a2a" stroke-width="1.3" fill="none"/><path d="M-6 5 h12" stroke="#6b4f2a" stroke-width="1"/>`
  };

  const OBJECTS = [
    { ev: "EV_RENT_RECORD", loc: "hatherley_farm", x: 132, y: 302, icon: "paper" },
    { ev: "EV_BOOTS_HATHERLEY", loc: "hatherley_farm", x: 196, y: 352, icon: "boots" },
    { ev: "EV_POOL_LAYOUT", loc: "boscombe_pool", x: 560, y: 318, icon: "eye" },
    { ev: "EV_TRACKS_POOL", loc: "boscombe_pool", x: 512, y: 404, icon: "grass" },
    { ev: "EV_TIPTOE_TRACKS", loc: "boscombe_pool", x: 650, y: 360, icon: "feetSq" },
    { ev: "EV_STONE_WEAPON", loc: "great_beech", x: 676, y: 296, icon: "stone" },
    { ev: "EV_BEECH_CIGAR", loc: "great_beech", x: 734, y: 236, icon: "cigar" },
    { ev: "EV_WOOD_PATH", loc: "wood_path", x: 800, y: 150, icon: "feet" },
    { ev: "EV_TURNER_GAIT", loc: "moran_lodge", x: 734, y: 578, icon: "person" },
    { ev: "EV_STAFF_REGISTER", loc: "moran_lodge", x: 826, y: 552, icon: "book" },
    { act: "ACT_SEND_NOTE", loc: "moran_lodge", x: 704, y: 506, icon: "letter" }
  ];
  const OFFMAP_ICONS = { EV_NEWS_REPORT: "news", EV_GROOM_APPOINTMENT: "news", EV_PATIENCE_DEPOSITION: "news", EV_INQUEST_RECORD: "paper", EV_ARREST_REMARK: "paper", EV_SURGEON_REPORT: "news", EV_VICTORIA_MAP: "map" };

  const LOCS = {
    hatherley_farm: { x: 165, y: 330, label: "해덜리 농장", lx: 165, ly: 404 },
    hatherley_path: { x: 340, y: 360, label: "농장에서 연못 가는 길", lx: 340, ly: 338 },
    boscombe_pool: { x: 570, y: 350, label: "보스콤 연못", lx: 570, ly: 448 },
    pool_woods: { x: 560, y: 190, label: "연못 주변 숲", lx: 560, ly: 168 },
    great_beech: { x: 706, y: 262, label: "큰 너도밤나무", lx: 706, ly: 210 },
    wood_path: { x: 820, y: 130, label: "숲길(큰길까지)", lx: 846, ly: 112 },
    moran_lodge: { x: 770, y: 525, label: "숲지기 집", lx: 800, ly: 620 },
    turner_hall: { x: 920, y: 330, label: "터너 저택", lx: 920, ly: 392 }
  };
  const PINS = { patience_moran: { x: 666, y: 570 }, william_crowder: { x: 332, y: 470 }, john_turner: { x: 952, y: 300 } };

  // 결정론적 난수(지도가 매번 같게)
  function rng(seed) { let s = seed; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }

  function trees(r, n, box, avoid) {
    let out = "";
    for (let i = 0; i < n; i++) {
      const x = box[0] + r() * (box[2] - box[0]), y = box[1] + r() * (box[3] - box[1]);
      if (avoid && avoid(x, y)) continue;
      const s = 9 + r() * 9, c = ["#4f6b3a", "#5a7842", "#46613a", "#62804a"][Math.floor(r() * 4)];
      out += `<circle cx="${(x + 2).toFixed(1)}" cy="${(y + 3).toFixed(1)}" r="${s.toFixed(1)}" fill="#2f3f24" opacity=".35"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${s.toFixed(1)}" fill="${c}"/><circle cx="${(x - s / 3).toFixed(1)}" cy="${(y - s / 3).toFixed(1)}" r="${(s / 2.6).toFixed(1)}" fill="#7f9b5e" opacity=".55"/>`;
    }
    return out;
  }

  function baseMap() {
    if (root._bvBase) return root._bvBase;
    const r = rng(7);
    const nearPool = (x, y) => ((x - 570) ** 2) / (150 ** 2) + ((y - 345) ** 2) / (105 ** 2) < 1;
    let s = "";
    s += `<defs>
      <linearGradient id="bvWater" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7fa3a8"/><stop offset="1" stop-color="#4f7a83"/></linearGradient>
      <radialGradient id="bvMarsh" cx=".5" cy=".5" r=".5"><stop offset=".65" stop-color="#9fb07a"/><stop offset="1" stop-color="#9fb07a" stop-opacity="0"/></radialGradient>
      <pattern id="bvField" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(20)"><rect width="14" height="14" fill="#c4c98d"/><path d="M0 7 h14" stroke="#b3b97c" stroke-width="2"/></pattern>
      <pattern id="bvField2" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(-35)"><rect width="12" height="12" fill="#b8c486"/><path d="M0 6 h12" stroke="#a9b676" stroke-width="2"/></pattern>
      <filter id="bvPaper"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="3"/><feColorMatrix values="0 0 0 0 .45  0 0 0 0 .40  0 0 0 0 .30  0 0 0 .09 0"/><feComposite in2="SourceGraphic" operator="in"/></filter>
    </defs>`;
    s += `<rect width="1000" height="640" fill="#b9c48c"/>`;
    // 들판과 산울타리
    s += `<path d="M0 90 L300 70 L330 250 L0 280 Z" fill="url(#bvField)"/><path d="M0 420 L260 400 L300 640 L0 640 Z" fill="url(#bvField2)"/><path d="M300 470 L470 450 L520 640 L320 640 Z" fill="url(#bvField)"/><path d="M880 420 L1000 410 L1000 640 L860 640 Z" fill="url(#bvField2)"/>`;
    s += `<path d="M0 280 L330 250 L300 70 M0 420 L260 400 L300 640 M300 470 L470 450 L520 640 M860 640 L880 420 L1000 410" stroke="#5f7444" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>`;
    // 큰길
    s += `<path d="M-10 52 C200 40 420 66 640 50 S900 40 1010 62" stroke="#d8c79e" stroke-width="18" fill="none"/><path d="M-10 52 C200 40 420 66 640 50 S900 40 1010 62" stroke="#c4b182" stroke-width="18" fill="none" stroke-dasharray="1 9" opacity=".6"/>`;
    s += `<text x="60" y="34" class="mapsmall">큰길 — 로스 방면</text>`;
    // 숲(연못 북쪽·동쪽)
    s += `<path d="M410 110 C520 80 760 90 880 130 C900 220 880 430 850 480 C800 470 740 440 700 420 C700 300 640 250 560 245 C480 245 430 240 410 110 Z" fill="#6f8a52" opacity=".55"/>`;
    s += trees(r, 230, [400, 95, 880, 270], nearPool);
    s += trees(r, 120, [700, 260, 870, 470], (x, y) => nearPool(x, y) || ((x - 770) ** 2 + (y - 525) ** 2) < 70 ** 2);
    s += trees(r, 40, [20, 110, 120, 250]);
    s += trees(r, 26, [860, 120, 1000, 260]);
    // 늪지와 연못
    s += `<ellipse cx="570" cy="350" rx="165" ry="112" fill="url(#bvMarsh)"/>`;
    s += `<path d="M470 330 C470 280 560 262 632 276 C690 290 702 344 676 384 C648 424 560 432 512 410 C478 394 470 362 470 330 Z" fill="url(#bvWater)" stroke="#466b70" stroke-width="2"/>`;
    s += `<path d="M500 318 q40 -14 80 -6 M530 360 q50 -10 100 2 M520 392 q40 6 90 -4" stroke="#a9c3c5" stroke-width="1.6" fill="none" opacity=".7"/>`;
    for (let i = 0; i < 46; i++) { const a = r() * Math.PI * 2, rr = 1.02 + r() * .1; const x = 573 + Math.cos(a) * 106 * rr, y = 345 + Math.sin(a) * 78 * rr; s += `<path d="M${x.toFixed(1)} ${y.toFixed(1)} l-2 -9 M${x.toFixed(1)} ${y.toFixed(1)} l1 -11 M${x.toFixed(1)} ${y.toFixed(1)} l3 -8" stroke="#55703b" stroke-width="1.1"/>`; }
    // 농장 길, 숲길, 저택 진입로
    s += `<path d="M215 352 C290 366 380 352 470 356" stroke="#d8c79e" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M215 352 C290 366 380 352 470 356" stroke="#b8a372" stroke-width="7" fill="none" stroke-dasharray="2 10" stroke-linecap="round"/>`;
    s += `<path d="M712 252 C740 210 770 190 790 160 C808 130 840 100 880 60" stroke="#c9b787" stroke-width="5" fill="none" stroke-dasharray="7 6" stroke-linecap="round"/>`;
    s += `<path d="M920 360 C930 420 940 470 960 640 M680 400 C720 460 740 500 760 512" stroke="#d8c79e" stroke-width="6" fill="none" stroke-linecap="round"/>`;
    s += `<path d="M150 300 C150 200 140 120 160 60" stroke="#d8c79e" stroke-width="6" fill="none" stroke-linecap="round"/>`;
    // 큰 너도밤나무
    s += `<circle cx="712" cy="268" r="33" fill="#2f3f24" opacity=".35"/><circle cx="706" cy="262" r="33" fill="#8a5a33"/><circle cx="694" cy="250" r="16" fill="#a8743f" opacity=".75"/><circle cx="720" cy="270" r="14" fill="#6f4627" opacity=".7"/>`;
    // 해덜리 농장
    s += `<rect x="96" y="286" width="150" height="96" rx="6" fill="#cdbb8f" stroke="#9a8659" stroke-width="2" stroke-dasharray="4 3"/>`;
    s += `<rect x="112" y="300" width="66" height="44" fill="#e8dcc0" stroke="#5c4a33" stroke-width="1.6"/><path d="M106 302 L145 276 L184 302 Z" fill="#7a3b2b" stroke="#5c4a33" stroke-width="1.6"/><rect x="138" y="322" width="12" height="22" fill="#5c4a33"/><rect x="118" y="310" width="10" height="9" fill="#9fb3b8" stroke="#5c4a33"/><rect x="160" y="310" width="10" height="9" fill="#9fb3b8" stroke="#5c4a33"/>`;
    s += `<rect x="190" y="306" width="44" height="34" fill="#a5774d" stroke="#5c4a33" stroke-width="1.4"/><path d="M186 308 L212 290 L238 308 Z" fill="#6b5a3e" stroke="#5c4a33" stroke-width="1.4"/>`;
    // 숲지기 집
    s += `<rect x="738" y="508" width="64" height="40" fill="#e3d6b6" stroke="#5c4a33" stroke-width="1.6"/><path d="M732 510 L770 484 L808 510 Z" fill="#8a7a5a" stroke="#5c4a33" stroke-width="1.6"/><rect x="786" y="482" width="8" height="16" fill="#6b5a3e"/><rect x="764" y="526" width="11" height="22" fill="#5c4a33"/>`;
    // 터너 저택
    s += `<rect x="868" y="290" width="104" height="80" rx="4" fill="#a7b97a" opacity=".6"/><rect x="880" y="306" width="80" height="52" fill="#d9ccb0" stroke="#4d3f2c" stroke-width="1.8"/><path d="M874 308 L920 282 L966 308 Z" fill="#5d5448" stroke="#4d3f2c" stroke-width="1.8"/><rect x="912" y="334" width="14" height="24" fill="#4d3f2c"/>`;
    for (let i = 0; i < 3; i++) s += `<rect x="${888 + i * 24}" y="316" width="9" height="11" fill="#9fb3b8" stroke="#4d3f2c"/>`;
    s += `<rect width="1000" height="640" filter="url(#bvPaper)" opacity=".9"/>`;
    // 장소 이름
    Object.keys(LOCS).forEach(k => { const L = LOCS[k]; s += `<g class="maploc" data-loc="${k}"><text x="${L.lx}" y="${L.ly}" class="maplabel" text-anchor="middle">${L.label}</text></g>`; });
    s += `<g transform="translate(950 590)"><circle r="20" fill="#f3ecdc" opacity=".8"/><path d="M0 -15 L5 0 L0 -3 L-5 0 Z" fill="#7a2e2a"/><path d="M0 15 L5 0 L0 3 L-5 0 Z" fill="#5c4a33"/><text y="-22" text-anchor="middle" class="mapsmall">N</text></g>`;
    root._bvBase = s;
    return s;
  }

  /* status(ev|act) → "owned" | "open" | "locked" | "done"; pins: {cid: {available, unread}} */
  function mapSVG(status, pins, selectedLoc) {
    let s = `<svg class="map-svg" viewBox="0 0 1000 640" role="img" aria-label="보스콤 밸리 사건 지도">` + baseMap();
    if (selectedLoc && LOCS[selectedLoc]) { const L = LOCS[selectedLoc]; s += `<circle cx="${L.x}" cy="${L.y}" r="78" fill="none" stroke="#7a2e2a" stroke-width="2.5" stroke-dasharray="6 6" opacity=".8"/>`; }
    OBJECTS.forEach(o => {
      const id = o.ev || o.act, st = status(id);
      const cls = "hot hot-" + st;
      const attrs = o.ev ? `data-ev="${o.ev}"` : `data-act="${o.act}"`;
      s += `<g class="${cls}" ${attrs} data-loc="${o.loc}" transform="translate(${o.x} ${o.y})" tabindex="0" role="button">`;
      if (st === "open") s += `<circle r="27" class="pulse"/>`;
      s += `<circle r="20" class="hot-bg"/><g transform="scale(1.65)">${ICON[o.icon]}</g>`;
      if (st === "locked") s += `<g transform="translate(14 -14)"><circle r="7" fill="#5c4a33"/><rect x="-3" y="-1" width="6" height="5" rx="1" fill="#f3ecdc"/><path d="M-2 -1 v-2 a2 2 0 0 1 4 0 v2" stroke="#f3ecdc" stroke-width="1.2" fill="none"/></g>`;
      if (st === "owned" || st === "done") s += `<g transform="translate(14 -14)"><circle r="7" fill="#3f6b3a"/><path d="M-3 0 l2 2.5 l4 -4.5" stroke="#fff" stroke-width="1.6" fill="none"/></g>`;
      s += `</g>`;
    });
    Object.keys(PINS).forEach(cid => {
      const p = PINS[cid], info = pins[cid] || {};
      if (info.hidden) return;
      s += `<g class="pin ${info.available ? "" : "pin-off"}" data-char="${cid}" transform="translate(${p.x - 18} ${p.y - 18})" tabindex="0" role="button"><circle cx="18" cy="18" r="20" fill="#f3ecdc" stroke="#2b2620" stroke-width="2"/>${portrait(cid, { size: 36 }).replace("<svg ", "<svg x=\"0\" y=\"0\" ")}${info.unread ? `<circle cx="34" cy="3" r="6" fill="#d93b30"/>` : ""}</g>`;
    });
    s += `</svg>`;
    return s;
  }

  function icon(name, size) {
    return `<svg width="${size || 28}" height="${size || 28}" viewBox="-10 -10 20 20" aria-hidden="true">${ICON[name] || ICON.paper}</svg>`;
  }

  /* 지도 밖 장소 그림 */
  function building(kind) {
    const base = `<svg viewBox="0 0 120 70" class="bld" aria-hidden="true"><rect width="120" height="70" fill="#d9ccae"/>`;
    if (kind === "hotel") return base + `<rect x="18" y="20" width="84" height="44" fill="#ece2c9" stroke="#4d3f2c" stroke-width="1.5"/><path d="M12 22 L60 6 L108 22 Z" fill="#6e2f2a" stroke="#4d3f2c" stroke-width="1.5"/>${[0, 1, 2, 3].map(i => `<rect x="${26 + i * 20}" y="28" width="9" height="11" fill="#9fb3b8" stroke="#4d3f2c"/>`).join("")}<rect x="54" y="46" width="12" height="18" fill="#4d3f2c"/><rect x="40" y="40" width="40" height="6" fill="#2b2620"/><text x="60" y="44.6" font-size="4.2" fill="#e9d48a" text-anchor="middle">HEREFORD ARMS</text></svg>`;
    if (kind === "telegraph") return base + `<rect x="30" y="24" width="60" height="40" fill="#ece2c9" stroke="#4d3f2c" stroke-width="1.5"/><path d="M26 26 L60 12 L94 26 Z" fill="#5d5448" stroke="#4d3f2c" stroke-width="1.5"/><rect x="54" y="44" width="12" height="20" fill="#4d3f2c"/><path d="M100 8 V64 M94 14 H106 M95 20 H105" stroke="#4d3f2c" stroke-width="1.6"/><path d="M100 14 C80 10 60 8 0 12" stroke="#4d3f2c" stroke-width=".8" fill="none"/></svg>`;
    return base + `<rect x="14" y="16" width="92" height="48" fill="#b9b0a0" stroke="#4d3f2c" stroke-width="1.5"/>${[0, 1, 2, 3, 4].map(i => `<rect x="${22 + i * 17}" y="26" width="8" height="12" fill="#3d3530"/><path d="M${24 + i * 17} 26 v12 M${26 + i * 17} 26 v12 M${28 + i * 17} 26 v12" stroke="#b9b0a0" stroke-width=".9"/>`).join("")}<rect x="50" y="44" width="20" height="20" fill="#3d3530"/><path d="M14 16 h92" stroke="#4d3f2c" stroke-width="4"/></svg>`;
  }

  root.BVArt = { portrait: portrait, mapSVG: mapSVG, icon: icon, building: building, OBJECTS: OBJECTS, OFFMAP_ICONS: OFFMAP_ICONS, LOCS: LOCS };
})(typeof window !== "undefined" ? window : globalThis);
