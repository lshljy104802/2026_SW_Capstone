@echo off
chcp 65001 >nul
REM 보스콤 밸리 게임 서버 실행 (배포자 PC). 모델을 바꾸려면 아래 qwen2.5:7b 를 고친다.
cd /d "%~dp0"
set "PY="
py -3 --version >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python --version >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo.
  echo [오류] Python을 찾지 못했습니다.
  echo  1. python.org/downloads 에서 Python을 설치합니다.
  echo     설치 첫 화면 아래의 "Add python.exe to PATH"를 꼭 체크합니다.
  echo  2. 이미 설치했는데도 이 메시지가 나오면:
  echo     Windows 설정 - 앱 - 고급 앱 설정 - 앱 실행 별칭에서
  echo     python.exe, python3.exe 항목을 끈 뒤 다시 실행합니다.
  echo.
  pause
  exit /b 1
)
%PY% server\server.py --model qwen2.5:7b %*
pause
