"""src/ 와 data/ 를 합쳐 파일 하나짜리 게임(dist/boscombe_valley_local.html)을 만든다.

python build.py
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent
SRC, DATA, DIST = ROOT / "src", ROOT / "data", ROOT / "dist"


def localize(obj, loc=None):
    """data/localization_ko.json의 표대로 문자열을 바꾼다(원본 파일은 그대로 둔다)."""
    if loc is None:
        loc = json.loads((DATA / "localization_ko.json").read_text(encoding="utf-8"))
    def tr(s):
        for a, b in loc["replace"]:
            s = s.replace(a, b)
        return s
    if isinstance(obj, dict):
        return {k: localize(v, loc) for k, v in obj.items()}
    if isinstance(obj, list):
        out = []
        for v in obj:
            out.append(localize(v, loc))
            if isinstance(v, str) and v in loc.get("keep_both_in_lists", []) and tr(v) != v:
                out.append(v)          # 옛 표기도 누출 검사에 남긴다
        return out
    return tr(obj) if isinstance(obj, str) else obj


def main():
    personas = localize(json.loads((DATA / "boscombe_personas.json").read_text(encoding="utf-8")))
    case = json.loads((DATA / "boscombe_case.json").read_text(encoding="utf-8"))
    case.pop("answer_notes", None)
    qa = json.loads((ROOT / "test" / "qa_questions.json").read_text(encoding="utf-8"))
    data = json.dumps({"personas": personas, "case": case, "qa": qa}, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = (SRC / "index.template.html").read_text(encoding="utf-8")
    parts = {"/*__CSS__*/": "style.css", "/*__SCRIPT__*/": "script.js", "/*__ENGINE__*/": "engine.js", "/*__PROMPTS__*/": "prompts.js", "/*__ART__*/": "art.js", "/*__SCENES__*/": "scenes.js", "/*__UI__*/": "ui.js", "/*__QA__*/": "qa.js"}
    for mark, name in parts.items():
        html = html.replace(mark, (SRC / name).read_text(encoding="utf-8").replace("</script", "<\\/script"))
    html = html.replace("/*__DATA__*/", data)
    DIST.mkdir(exist_ok=True)
    # 시험(test/)과 팀원 확인용: 현지화를 적용한 페르소나 데이터
    (DIST / "boscombe_personas_ko.json").write_text(json.dumps(personas, ensure_ascii=False, indent=1), encoding="utf-8")
    out = DIST / "boscombe_valley_local.html"
    out.write_text(html, encoding="utf-8")
    print(f"{out} ({len(html.encode('utf-8')) // 1024} KB)")
    # claude.ai 아티팩트용: 문서 뼈대(doctype/html/head/body)는 게시할 때 붙으므로 뺀다
    frag = html
    for a, b in [("<!doctype html>\n<html lang=\"ko\">\n<head>\n", ""), ('<meta charset="utf-8">\n', ""),
                 ('<meta name="viewport" content="width=device-width,initial-scale=1">\n', ""), ("</head>\n<body>\n", ""), ("</body>\n</html>\n", "")]:
        assert a in frag, a
        frag = frag.replace(a, b, 1)
    art = DIST / "boscombe_valley_artifact.html"
    art.write_text(frag.replace("<title>보스콤 밸리 사건 — 로컬판</title>", "<title>보스콤 밸리 사건</title>"), encoding="utf-8")
    print(f"{art} (아티팩트용)")


if __name__ == "__main__":
    main()
