const { chromium } = require('playwright'); const path = require('path');
(async () => { const out = process.argv[2]; const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1280, height: 860 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html')); await p.waitForTimeout(400); await p.click('[data-modal-close]');
  // 일부 진행 상태: 현장 출입 + 일부 증거
  await p.evaluate(() => { const E = window.__bv.E; E.st.flags.push('scene_access_granted'); ['EV_NEWS_REPORT','EV_INQUEST_RECORD','EV_BOOTS_HATHERLEY'].forEach(id => E.st.owned.push(id)); window.__bv.renderAll(); });
  for (const k of ["ross_hotel", "ross_telegraph", "hereford_gaol", "hatherley_farm", "boscombe_pool", "great_beech", "moran_lodge", "turner_hall", "overview"]) {
    await p.click(`[data-scene="${k}"]`); await p.waitForTimeout(150);
    const el = await p.$('.sceneframe'); await el.screenshot({ path: `${out}/sc_${k}.png` });
  }
  await p.click('[data-scene="boscombe_pool"]'); await p.screenshot({ path: `${out}/sc_full.png` });
  await p.click('g.sobj[data-ev="EV_TRACKS_POOL"]', { force: true }); await p.waitForTimeout(200); await p.screenshot({ path: `${out}/sc_modal.png` });
  const m = await b.newPage({ viewport: { width: 390, height: 844 } }); await m.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html')); await m.waitForTimeout(400); await m.click('[data-modal-close]');
  await m.screenshot({ path: `${out}/sc_mobile.png`, fullPage: true }); console.log('mobile sw', await m.evaluate(() => document.documentElement.scrollWidth));
  console.log('errors', JSON.stringify(errs)); await b.close(); })();
