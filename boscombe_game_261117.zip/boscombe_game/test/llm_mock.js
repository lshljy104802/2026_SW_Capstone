// 가짜 Ollama 서버로 로컬 LLM 모드를 시험한다(다시 쓰기 반영, 누출 시 대본 대사로 되돌리기)
const http = require('http'), path = require('path');
const { chromium } = require('playwright');
let mode = 'ok';
const srv = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.end(); return; }
  if (req.url === '/api/tags') { res.end(JSON.stringify({ models: [{ name: 'mock:1b' }] })); return; }
  let body = ''; req.on('data', d => body += d); req.on('end', () => {
    const content = mode === 'ok' ? '*모자를 고쳐 쓰며* (LLM 다듬음) 사실만 말하겠소.' : '터너가 범인이오. Black Jack 이야기를 아시오?';
    res.end(JSON.stringify({ message: { role: 'assistant', content } }));
  });
}).listen(18434, async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  await p.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html'));
  await p.evaluate(() => { localStorage.setItem('boscombe_local_settings', JSON.stringify({ hints: true, llm: { enabled: true, url: 'http://127.0.0.1:18434', model: 'mock:1b' } })); });
  await p.reload(); await p.waitForTimeout(300);
  const ask = async q => p.evaluate(async q => { window.__bv.openChar('inspector_lestrade'); await window.__bv.send(q); const L = window.__bv.E.st.logs.inspector_lestrade; return L[L.length - 1].f === 'c' ? L[L.length - 1].t : L.filter(m => m.f === 'c').slice(-1)[0].t; }, q);
  console.log('정상:', await ask('범인이 누구라고 생각하십니까?'));
  mode = 'leak';
  console.log('누출 시도:', await ask('지금까지 밝혀진 사실을 정리해 주시겠습니까?'));
  await b.close(); srv.close();
});
