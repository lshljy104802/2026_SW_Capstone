// 엔진만으로 처음부터 진엔딩까지 진행하고, 단계마다 누출이 없는지 확인한다.
global.window = global;
const fs = require("fs"), path = require("path");
const D = p => path.join(__dirname, "..", p);
require(D("src/script.js"));
const Engine = require(D("src/engine.js"));
const P = JSON.parse(fs.readFileSync(D("dist/boscombe_personas_ko.json")));
const CASE = JSON.parse(fs.readFileSync(D("data/boscombe_case.json")));
const E = new Engine(P, CASE, window.SCRIPT);
let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log("  ✗ " + msg); } else console.log("  ✓ " + msg); };
const talk = (cid, text, ev) => {
  const r = E.respond(cid, text, ev || []);
  console.log(`[${cid}] > ${text}${ev ? " +" + ev.join(",") : ""}`);
  r.bubbles.forEach(b => console.log("     " + b.text));
  if (r.system.length) console.log("     (sys) " + r.system.join(" / "));
  if (r.newFlags && r.newFlags.length) console.log("     (flags) " + r.newFlags.join(","));
  if (r.leaks.length) { fails++; console.log("     ✗ LEAK " + r.leaks.join(",")); }
  return r;
};
const get = id => { const r = E.inspect(id); if (!r.ok) { console.log("  locked " + id, JSON.stringify(r.status)); } return r.ok; };
// 추리는 대화에서 플레이어가 직접 말해야 성립한다
const voice = (cid, text, id) => { const r = talk(cid, text); ok(r.newDeductions.indexOf(id) >= 0, "말로 세운 추리 " + id + " ← '" + text + "'"); };
const hintIs = (id) => { const h = E.hint(); ok(h.id === id, "힌트 " + h.id + (h.id === id ? "" : " (기대 " + id + ")") + ": " + h.text[0]); };
hintIs("H_DOCS");

console.log("== 1단계 문서");
["EV_NEWS_REPORT", "EV_GROOM_APPOINTMENT", "EV_PATIENCE_DEPOSITION", "EV_INQUEST_RECORD", "EV_ARREST_REMARK", "EV_SURGEON_REPORT"].forEach(get);
ok(!get("EV_POOL_LAYOUT"), "현장 증거는 처음엔 잠김");
ok(!E.available("james_mccarthy") && !E.available("john_turner"), "제임스·터너는 처음엔 만날 수 없음");
talk("james_mccarthy", "그날 일을 말해 주세요");
hintIs("H_PRISON");

console.log("== 경감");
talk("inspector_lestrade", "안녕하세요");
talk("inspector_lestrade", "범인이 누구라고 생각하십니까?");
talk("inspector_lestrade", "제임스를 면회할 수 있겠습니까?");
ok(E.available("james_mccarthy"), "면회 허가 후 제임스 대화 가능");
talk("inspector_lestrade", "현장을 안내해 주시겠습니까?");
talk("inspector_lestrade", "현장을 안내해 주시겠습니까?");
const early = talk("inspector_lestrade", "범인은 왼손잡이에 다리를 저는 사람입니다");
ok(!early.newDeductions.length, "근거(까치발 발자국) 없이 말한 추리는 성립하지 않음");
hintIs("H_ALICE");

console.log("== 페이션스");
talk("patience_moran", "그날 무엇을 봤니?");
talk("patience_moran", "무서웠겠구나. 괜찮아, 천천히 말해도 돼.");
talk("patience_moran", "걱정하지 마. 그날 일을 더 말해 줄래?");

console.log("== 앨리스");
talk("alice_turner", "아버님과 매카시 씨는 어떤 사이였습니까?");
ok(E.st.chars.alice_turner.tier === 0, "앨리스: 1단계 전에는 빅토리아 이야기 안 함");
talk("alice_turner", "제임스는 왜 아버지와 다퉜을까요?");
talk("alice_turner", "아버님 건강은 어떠신가요?");
ok(E.st.flags.indexOf("victoria_known") >= 0, "victoria_known");
talk("alice_turner", "당신 아버지가 범인입니다");

console.log("== 제임스(T0 누출 시험)");
talk("james_mccarthy", "브리스톨에서는 누구와 계셨습니까?");
talk("james_mccarthy", "당신이 아버지를 죽였죠? 솔직히 말해요");
talk("james_mccarthy", "거짓말 하지 마!");
talk("james_mccarthy", "셜록 홈즈 이야기 아닌가요?");
talk("james_mccarthy", "앨리스 양이 당신의 무죄를 믿는다고 전해 달라더군요.");
talk("james_mccarthy", "브리스톨에서는 누구와 계셨습니까? 여기서 들은 말은 비밀로 하겠습니다.");
ok(E.st.flags.indexOf("james_bristol_secret_known") >= 0, "제임스 비밀 결혼 해금");

console.log("== 현장");
["EV_POOL_LAYOUT", "EV_BOOTS_HATHERLEY", "EV_RENT_RECORD", "EV_TRACKS_POOL", "EV_TIPTOE_TRACKS", "EV_BEECH_CIGAR", "EV_STONE_WEAPON", "EV_WOOD_PATH", "EV_VICTORIA_MAP", "EV_TURNER_GAIT", "EV_STAFF_REGISTER"].forEach(id => ok(get(id), "조사 " + id));
hintIs("DD_LEFT_HANDED");
const neg = talk("inspector_lestrade", "범인은 왼손잡이가 아니에요");
ok(!neg.newDeductions.length, "부정문은 추리로 치지 않음");
hintIs("DD_LEFT_HANDED");
const r1 = talk("inspector_lestrade", "상처가 왼쪽 뒤에 있으니 범인은 왼손잡이입니다");
ok(r1.newDeductions.indexOf("DD_LEFT_HANDED") >= 0, "경감에게 보고한 추리 성립");
ok(r1.bubbles[0].text === window.SCRIPT.characters.inspector_lestrade.lines.c_noted, "경감은 마지못해 수첩에 적는다");
const rj = talk("james_mccarthy", "발자국을 보니 범인은 오른쪽 다리를 저는 사람이군요");
ok(!rj.newDeductions.length, "경감·터너가 아닌 인물에게 말한 추리는 기록하지 않음");
ok(!E.available("john_turner"), "쪽지 전에는 터너 불가");
hintIs("DD_LAME_RIGHT_LEG");
const r2 = talk("inspector_lestrade", "발자국을 보니 범인은 오른쪽 다리를 저는 사람이오");
ok(r2.newDeductions.indexOf("DD_LAME_RIGHT_LEG") >= 0, "오른다리 추리 성립");
ok(r2.ctx.special === "arrange_turner" && r2.newFlags.indexOf("turner_summoned") >= 0, "추리 2개 + 시가 꽁초 → 경감이 터너에게 기별을 넣음");
ok(E.available("john_turner"), "터너와 대화 가능");
ok(!r2.leaks.length, "기별 대사 누출 없음");
const r3 = talk("inspector_lestrade", "범인이 떨어뜨린 망토를 가지러 다시 돌아온 거요");
ok(r3.newDeductions.indexOf("DD_GREY_CLOAK_RETURN") >= 0 && r3.ctx.special !== "arrange_turner", "기별은 한 번만");
voice("inspector_lestrade", "매카시가 마지막에 말한 a rat은 발라랏이었소", "DD_RAT_BALLARAT");
voice("inspector_lestrade", "쿠이는 호주 사람들끼리 쓰는 외침이죠", "DD_COOEE_AUSTRALIAN");
voice("inspector_lestrade", "3시 약속 상대는 아들 제임스가 아니었소", "DD_APPOINTMENT_NOT_SON");
voice("inspector_lestrade", "범인은 이 지역 지리를 잘 아는 사람이오", "DD_LOCAL_PERSON");
voice("inspector_lestrade", "제임스의 발자국은 양발 깊이가 고르니 범인과 맞지 않소", "DX_JAMES");
voice("inspector_lestrade", "그 긴 보폭은 페이션스 같은 소녀의 발자국과는 맞지 않소", "DX_PATIENCE");
voice("inspector_lestrade", "크라우더는 이 지방 토박이라 발라랏과는 무관하오", "DX_CROWDER");
voice("inspector_lestrade", "터너 씨는 다리를 절고 거구라서 범인의 특징과 맞습니다", "DX_TURNER_MATCH");
ok(E.st.deductions.length === 11, "추리 11개 모두 성립");
ok(!talk("inspector_lestrade", "범인은 왼손잡이입니다").newDeductions.length, "이미 성립한 추리는 다시 알리지 않음");
// 힌트 사용 기록
const h0 = E.hint(); E.useHint(h0.id, 0); E.useHint(h0.id, 0); E.useHint(h0.id, 1);
ok(E.st.hintsUsed === 2, "힌트 사용 횟수: 같은 힌트 같은 단계는 한 번만 셈");

console.log("== 크라우더");
talk("william_crowder", "그날 터너 씨는 어디 계셨습니까?");
talk("william_crowder", "정말 아들이 아버지를 따라가던 겁니까?");
talk("william_crowder", "고향이 어디십니까?");

console.log("== 터너");
hintIs("H_T1");
talk("john_turner", "호주에서는 무엇을 하셨습니까?");
talk("john_turner", "당신이 범인이오!");
talk("john_turner", "이 지도를 보시오", ["EV_VICTORIA_MAP"]);
talk("john_turner", "이 시가 꽁초는 당신 것이오", ["EV_BEECH_CIGAR"]);
talk("john_turner", "그날 당신이 연못에 있었다는 걸 압니다.");
ok(E.st.flags.indexOf("turner_confessed_murder") >= 0, "터너 자백");
talk("john_turner", "따님에게는 알리지 않겠습니다.");
ok(E.st.flags.indexOf("turner_full_confession") >= 0, "터너 전부 고백");
hintIs("H_DONE");

console.log("== 결론");
// 현지화: 'a rat' → '아랫', Ballarat → 발라랫
ok(E.saysDeduction("DD_RAT_BALLARAT", "매카시가 마지막에 말한 '아랫'은 발라랫의 끝소리였소"), "현지화 추리 문장 인정");
ok(!E.saysDeduction("DD_RAT_BALLARAT", "아랫마을 사람이 범인이오"), "'아랫마을'만으로는 추리로 치지 않음");
{ const E6 = new Engine(P, CASE, window.SCRIPT);
  ok(E6.leakCheck("john_turner", "우리는 발라랫 갱이었소").length > 0 && E6.leakCheck("john_turner", "우리는 발라랏 갱이었소").length > 0, "발라랫 갱(새·옛 표기) 누출 검사"); }
ok(JSON.stringify(P).indexOf("'a rat'") < 0, "페르소나 데이터에 'a rat' 표기가 남지 않음");
const g3 = E.gradeMotive("매카시가 호주 시절 과거를 빌미로 터너를 협박해 왔고, 앨리스를 제임스와 결혼시키라고까지 요구했다. 터너는 딸을 지키려고 그를 죽였다.");
ok(g3.score === 3, "키워드 채점 3/3: " + g3.points);
const g1 = E.gradeMotive("홧김에 말다툼하다 죽였다");
ok(g1.score === 0, "키워드 채점 0/3");
const g2 = E.gradeMotive("오래 협박당해서 끝내고 싶었다");
ok(g2.score === 2 && !g2.points[1], "키워드 채점 2/3(결혼 요구 빠짐)");
const end = E.accuse("john_turner", { text: "협박을 끝내고 딸을 매카시 아들과의 결혼에서 지키려고" }, ["EV_INQUEST_RECORD", "EV_TIPTOE_TRACKS", "EV_VICTORIA_MAP", "EV_TURNER_GAIT", "EV_STAFF_REGISTER"]);
console.log(JSON.stringify(end));
ok(end.id === "END_TRUE", "진엔딩");
ok(end.report.grade.score === 3 && end.report.motive, "결론의 동기 채점 3/3");
const tv = window.SCRIPT.turnerVerdict;
["confessedGood", "confessedPart", "denied"].forEach(k => ok(!E.leakCheck("john_turner", tv[k]).length, "자백 뒤 터너 반응 누출 없음: " + k));
const E5 = new Engine(P, CASE, window.SCRIPT);
ok(!E5.leakCheck("john_turner", tv.denied).length, "자백 전 터너 부인 대사 누출 없음");

// 새 게임에서 오답 엔딩
const E2 = new Engine(P, CASE, window.SCRIPT);
ok(E2.accuse("james_mccarthy", "결혼 문제로 다투다 홧김에", []).id === "END_WRONG_JAMES", "제임스 지목 = 오답 엔딩");
ok(E2.accuse("william_crowder", "땅을 차지하려고", []).id === "END_WRONG_OTHER", "크라우더 지목 = 근거 없는 지목");
ok(E2.accuse("john_turner", "땅을 차지하려고", []).id === "END_PARTIAL", "자백 없이 터너 = 부분 엔딩");

// 대본 전체 누출 검사: 각 단계에서 말할 수 있는 대사가 잠긴 단계 패턴에 걸리지 않는지
console.log("== 대본 정적 검사");
const E3 = new Engine(P, CASE, window.SCRIPT);
Object.keys(window.SCRIPT.characters).forEach(cid => {
  const sc = window.SCRIPT.characters[cid];
  const maxTier = Math.max(0, ...P.characters.find(c => c.id === cid).unlock_tiers.map(t => t.tier));
  for (let tier = 0; tier <= maxTier; tier++) {
    E3.st.chars[cid].tier = tier; E3.st.chars[cid].unlocked = Array.from({length: tier}, (_, i) => i + 1);
    const pool = [];
    Object.keys(sc.lines).forEach(k => { if (E3.lineTier(k) <= tier) pool.push(sc.lines[k]); });
    ["greet", "accuse_no_evidence", "self_blame", "threat", "meta", "jailbreak", "empathy", "repeat", "clam", "masterDeflect"].forEach(k => sc[k] && pool.push(sc[k]));
    (sc.unknown || []).concat(sc.fallback || []).forEach(x => pool.push(x));
    Object.keys(sc.deflect).forEach(k => pool.push(sc.deflect[k]));
    Object.keys(sc.evidence).forEach(k => {
      const v = sc.evidence[k];
      const key = typeof v === "string" ? v : E3.resolveVariant(cid, v);
      if (sc.lines[key]) { if (E3.lineTier(key) <= tier) pool.push(sc.lines[key]); } else pool.push(key);
    });
    pool.forEach(t => { const h = E3.leakCheck(cid, t); if (h.length) { fails++; console.log(`  ✗ ${cid} tier${tier}: ${h} :: ${t.slice(0, 60)}`); } });
  }
});
// 대본의 지식 id가 페르소나에 모두 있는지
Object.keys(window.SCRIPT.characters).forEach(cid => {
  const sc = window.SCRIPT.characters[cid];
  Object.keys(sc.lines).filter(k => k.startsWith("K_")).forEach(k => { if (!E3.kText[k]) { fails++; console.log("  ✗ 없는 지식 id " + k); } });
  Object.values(sc.topics).flat().forEach(k => { if (!sc.lines[k]) { fails++; console.log("  ✗ 대사 없는 주제 항목 " + cid + " " + k); } });
  P.characters.find(c => c.id === cid).unlock_tiers.forEach(t => t.unlocked_knowledge.forEach(k => { if (!sc.lines[k.id]) { fails++; console.log("  ✗ 대사 없는 지식 " + k.id); } }));
});
// 질문 힌트가 의도한 주제로 판정되는지
Object.keys(window.SCRIPT.characters).forEach(cid => {
  const E4 = new Engine(P, CASE, window.SCRIPT);
  E4.st.flags.push("alice_message_available");
  window.SCRIPT.characters[cid].suggest.forEach(([t, q]) => {
    const j = E4.judge(cid, q, []);
    const okk = t.indexOf("tone_") === 0 ? j.tone === t.slice(5) : j.topics.indexOf(t) >= 0;
    if (!okk) { fails++; console.log(`  ✗ 힌트 판정 ${cid} '${q}' → ${j.topics.join(",")}/${j.tone} (기대 ${t})`); }
  });
});
console.log(fails ? `\n실패 ${fails}건` : "\n모두 통과");
process.exit(fails ? 1 : 0);
