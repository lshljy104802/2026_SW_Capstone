// 점검 모드를 브라우저에서 끝까지 돌려 결과를 파일로 남긴다
// node test/qa_run.js <게임 주소(파일 경로 또는 http://…)> <결과 JSON 경로>
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  let url = process.argv[2], out = process.argv[3] || 'qa_result.json';
  if (!/^https?:|^file:/.test(url)) url = 'file://' + path.resolve(url);
  url += (url.includes('?') ? '&' : '?') + 'qa=1';
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('dialog', d => { errs.push('dialog: ' + d.message()); d.dismiss(); });
  await p.goto(url);
  await p.waitForTimeout(1500);
  await p.evaluate(() => { const m = document.getElementById('modal'); if (m) m.remove(); });
  await p.waitForFunction(() => window.__bv && window.__bv.ui.ai && window.__bv.ui.ai.state !== 'checking', null, { timeout: 15000 }).catch(() => {});
  await p.evaluate(() => window.__qa.open());
  const t0 = Date.now();
  await p.evaluate(() => window.__qa.run(window.__qa.cases));
  const res = await p.evaluate(() => window.__qa.results());
  const mode = await p.evaluate(() => document.getElementById('qaMode').textContent);
  require('fs').writeFileSync(out, JSON.stringify({ mode, results: res, errors: errs }, null, 1));
  const cnt = k => res.filter(r => r.result === k).length;
  console.log(mode, '| 문항', res.length, '통과', cnt('통과'), '주의', cnt('주의'), '실패', cnt('실패'), '|', ((Date.now() - t0) / 1000).toFixed(0) + '초');
  res.filter(r => r.result !== '통과').forEach(r => console.log(r.result, r.id, r.name, '|', r.fails.concat(r.warns).join(' / '), '|', (r.reply || '').slice(0, 90).replace(/\n/g, ' ')));
  console.log('errors', errs);
  await p.screenshot({ path: out.replace(/\.json$/, '.png') });
  await b.close();
})();
