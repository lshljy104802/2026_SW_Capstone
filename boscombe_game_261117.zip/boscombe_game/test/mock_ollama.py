"""시험용 가짜 Ollama. 판정(format=json)과 대사를 흉내 낸다."""
import json, re, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        self.out({"models": [{"name": "mock:1b"}]})
    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        msgs = req["messages"]; last = msgs[-1]["content"]
        if req.get("format") == "json" and "채점관" in msgs[0]["content"]:
            t = re.search(r'"""(.*)"""', last, re.S).group(1)
            self.out({"message": {"role": "assistant", "content": json.dumps({"points": ["협박" in t, "결혼" in t, "지키" in t], "feedback": "탐정님, (가짜 Ollama 채점)"}, ensure_ascii=False)}})
            return
        if req.get("format") == "json":
            t = re.search(r'"""(.*)"""', last, re.S).group(1)
            topics = []
            if "주선" in t or "얘기해 볼" in t: topics.append("T_PRISON_VISIT")
            if "둘러" in t or "데려가" in t: topics.append("T_POOL_SCENE")
            if "날씨" in t: topics = []
            tone = "empathetic" if "마음" in t else "neutral"
            self.out({"message": {"role": "assistant", "content": json.dumps({"topics": topics, "tone": tone, "meta": False, "jailbreak": False, "mentioned_evidence": [], "player_claims": []}, ensure_ascii=False)}})
            return
        if "비밀" in last and "레스트레이드" not in msgs[0]["content"][:40]:
            reply = "사실 등기소에서 몰래 결혼했습니다."      # 잠긴 정보 → 누출 검사에 걸려야 함
        else:
            m = re.search(r"참고 답변[^:]*: (.*)", last)
            first = re.search(r"털어놓는다.*?\n\s*- (.*)", last, re.S)
            if first: reply = "*잠시 망설이다* (AI) " + first.group(1)[:90]
            elif m: reply = "*(AI가 다시 말함)* " + m.group(1)[:90]
            else: reply = "*(AI 자유 답변)* 글쎄요, 그 일은 잘 모르겠습니다."
        self.out({"message": {"role": "assistant", "content": reply}})

ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
