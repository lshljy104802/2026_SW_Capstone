#!/bin/bash
cd "$(dirname "$0")" || exit 1
if [ -f runtime/launcher.pid ]; then
  kill "$(cat runtime/launcher.pid)" 2>/dev/null && echo "게임 서버를 껐습니다." || echo "서버가 이미 꺼져 있습니다."
  rm -f runtime/launcher.pid
else
  echo "실행 중인 게임 서버가 없습니다."
fi
