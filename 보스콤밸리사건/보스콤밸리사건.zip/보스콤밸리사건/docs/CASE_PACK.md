# 사건 팩 형식 (cases/&lt;id&gt;/pack.cjs)

사건 하나 = CommonJS 파일 하나. 엔진·대화·화면은 이 파일만 읽는다. 예시는 [cases/abbey/pack.cjs](../cases/abbey/pack.cjs)(기존 원장을 묶은 것)와 그 원본 [data/content.cjs](../data/content.cjs).
점검: `node scripts/check-pack.cjs <id>`(참조·도달 가능성), 정답 경로: `cases/<id>/golden.json`을 `npm test`가 끝까지 재생한다.

## 플래그 (조건·부여에 쓰는 문자열)

| 플래그 | 뜻 |
|---|---|
| `ev:EV03` | 증거 열람 |
| `k:NODE_ID` | 인물 지식 노드 획득 |
| `heard:S1` | 진술 카드 확보 |
| `broken:S1` / `crack:ID` | 진술이 증거로 깨짐 / 그 모순 반응 획득 |
| `met:P1` | 현장에서 거절 인물에게 말을 걸어 거절을 확인 |
| `loc:ID` | 장소가 지도에 열림 |
| `summoned:P1` / `admitted:P1` / `confessed:P1` | 소환 승인 / 부분 인정 / 자백 |
| `@이름` | `conditions`에 정의한 특수 조건 |

## 필드

```js
module.exports = {
  id: "silver",                       // 폴더명과 같게
  title: "실버 블레이즈 사건",
  source: "아서 코넌 도일, 「실버 블레이즈」(1892)",
  setting: "셜록 홈즈 「실버 블레이즈」 사건(1890년대 다트무어)",   // 인물 모델 시스템 프롬프트에 들어감
  brief: "첫 화면 사건 개요 문단(정답 암시 금지)",
  startLocation: "kingspyland",
  map: { zones: { estate: "왼쪽 구역 이름", offsite: "오른쪽 구역 이름" },
         edges: [["a","b"], ["a","c",true]] },          // true = 점선(먼 거리)
  locations: [ { id, name, kind:"estate"|"offsite"|"interrogation", x, y, start?:true, art?:"dining", shape?:"pond" } ],
     // 지도 SVG 960×520. estate는 x 40~620, offsite는 x 700~920, y 60~470. interrogation 하나 필수(x:0,y:0,start:true)
  spots: [ { id, locationId, label, requires:[플래그], reveals:"EV01", grants?:[플래그] } ],   // 증거 하나당 지점 하나. grants=조사 시 얻는 플래그(장소 열기 등)
  start: { evidence:["EV01"], flags:[] },
  people: [ {
    pid:"P1", key:"영문키", name, role,
    stance:"cooperative"|"refusing",
    location:"장소id",
    companion?:true,                 // 어디서나 대화(수사 동행자 1명만)
    talkAt?:["장소id"],               // 협조자가 추가로 대화 가능한 장소
    visibleWhen:[플래그],             // 인물 목록에 나타나는 조건
    portrait?:"파일.png",             // 없으면 이니셜
    profile:{ voice:"말투·태도(인물 모델에 그대로 들어감)", look:"외양" },
    lines:{ unknown:"모를 때", meta:"설정 밖 질문 회피", smalltalk:"인사 받기" },
    cracks:{ crackId:"모순을 찔렸을 때 반응(지문 섞인 서술 가능)" },
  } ],
  refusals: { P1: { text:"현장 거절 대사(초기 진술 요지 포함)", grants:["heard:S1", ...] } },   // refusing 인물마다
  nodes: [ {
    id:"X_topic", pid:"P1", place:"scene"|"interrogation"|"any",   // refusing 인물 노드는 interrogation
    topic:"평가 모델이 질문과 대조할 주제 설명(쉼표로 여러 표현)",
    keywords:/규칙 대체용 정규식/,
    requires:[플래그], accuse?:true,    // accuse=추궁 의도일 때만 열림(인정·자백 노드)
    text:"이 노드가 열릴 때 인물이 말해도 되는 사실(정본 응답, 1~4문장, 그 인물 말투)",
    grants:[플래그],
  } ],
  objections: [ { statement:"S1", evidence:["EV05"], crack:"crackId", note:"화면에 남는 모순 설명 한 줄" } ],
  summons: { P1: { needMet:true, groups:[{label, ids:[EV...]}], altFlags?:[플래그], approve:"판사 승인 문장", deny:"기각 문장(무엇이 부족한지)" } },
  conditions: {
    "@x_proof": { type:"proof", pid:"P4", groups:[{label, ids:[...]}] },     // 심문실에서 그 인물에게 대화 첨부로 누적 제시한 증거가 각 그룹 1개 이상
    "@y_cracks": { type:"cracks", statements:["S1","S2"], cracks:["c1","c2","c3"], min:2 },   // 그 진술들에서 얻은 서로 다른 crack 수
  },
  evidence: [ { id:"EV01", title, typeKo:"검시·감식|현장 물품|현장 흔적|관찰 기록|기록|진술 기록", where, text } ],
  statements: [ { id:"S1", speaker:"P1", speakerName, text } ],   // 거짓 진술 + 참 진술 섞기
  timeline: { EV01:[{time, text}] },                               // 열람 시 수사 기록 타임라인에 추가
  suspects: [ { pid, name } ],                                     // 결론 탭 범인 선택지(만날 수 없는 용의자 포함 가능)
  scoring: {
    culprit: { pids:["P4"], points:40, label:"범인 지목" },
    items: [ { label, field:"method"|"motive"|"all", re:/정규식/, points } ],
    evidence: { groups:[{label, ids}], perGroup:5 },             // 합계 100점
  },
  answer: { summary:"정답 해설 문단", culpritName, timeline:[["23:00","..."], ...] },
  leak: { keywords:["아직 공개 안 된 진실을 드러내는 단어"], patterns:[/정규식/] },  // 인물 모델 응답에 나오면 정본 응답으로 대체
  art: { base:"/art/" },
};
```

## 설계 기준 (11/05 교수님 피드백)

- **가이드 없음**: 추천 질문·행동 제한 없음. 플레이어는 자유 질문만 한다. 그래서 노드 `topic`이 넓은 표현을 덮어야 한다.
- **페르소나 중심**: 인물마다 공개 프로필(말투·외양) + 기본으로 말하는 노드(requires 없음) 1~2개 + 조건부 노드. 숨긴 사실은 노드로 열리기 전에는 인물 모델에 주지 않는다.
- **연쇄**: 협조자 노드 → 장소·조사 지점·진술 확보 → 증거 → 이의 제기 → 판사 소환 → 심문실 노드 → 인정·자백. 처음부터 다 열리면 안 된다.
- **다인물**: 대화 가능한 인물 7~9명, 결론 선택지 용의자 4명 이상. 헛다리 용의자는 동기가 있지만 증거(알리바이·신체 특징·기록)로 걸러지게.
- **자백**: 범인은 `proof` 조건(관계·기회·능력·위장 등 3~4그룹)을 채우고 추궁(accuse)하면 자백. 거짓말한 공범·조력자는 `cracks` 조건으로 부분 인정.
- **원작 충실**: 사건·증거·진실은 원작 그대로. 게임용 추가(조사 지점 배치, 이름 없는 인물에게 말투 부여, 판사 장치)는 허용하되 원작의 범행·결말은 바꾸지 않는다.
- **한국어**: 모든 화면 문자열·대사는 한국어. 인물 이름은 한국어 표기(예: 존 스트레이커).
