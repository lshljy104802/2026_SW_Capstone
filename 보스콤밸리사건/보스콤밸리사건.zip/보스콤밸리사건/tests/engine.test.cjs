// 이 테스트는 애비 그레인지 등 다른 사건 팩을 전제로 하므로 전부 적재한다(기본 적재는 보스콤 한 편).
process.env.ABBEY_CASES = "abbey,boscombe,naval,silver,bruce,priory";
const test = require("node:test");
const assert = require("node:assert/strict");
const E = require("../engine.cjs");
const caseData = require("../data/abbey_case.json");

// 가짜 deps: 모델을 부르지 않고 규칙으로 대체되게 한다.
const deps = { evaluate: async () => ({ ok: false }), speak: async () => ({ ok: false }) };
const act = (s, a) => E.applyAction(s, a, deps);
const lastNpc = (s, pid) => [...(s.chats[pid] || [])].reverse().find((m) => m.from === "npc");

async function expectErr(p, code) {
  await assert.rejects(p, (e) => e.code === code);
}
async function openEv(s, spot, ev) {
  await act(s, { type: "inspect", spotId: spot });
  await act(s, { type: "open", evidenceId: ev });
}

test("공개 상태에 잠긴 증거 본문·정답·잠긴 노드 text가 없다", async () => {
  const s = E.createSession();
  await act(s, { type: "inspect", spotId: "bellrope" });
  const json = JSON.stringify(E.publicState(s));
  const ev03 = caseData.public.evidence.find((e) => e.id === "EV03");
  assert.ok(!json.includes(ev03.text));
  assert.ok(!json.includes(caseData.answer.summary));
  for (const n of require("../cases/abbey/pack.cjs").nodes) assert.ok(!json.includes(n.text), n.id);
  assert.equal(E.publicState(s).submitted, null);
  assert.ok(E.publicState(s).evidence.find((e) => e.id === "EV01").text);
  assert.equal(E.publicState(s).evidence.find((e) => e.id === "EV03").text, undefined);
  assert.ok(JSON.parse(JSON.stringify(s)));
});

test("진행 예시 정답 경로: 크로커 자백 + 결론 100점", async () => {
  const s = E.createSession();
  await act(s, { type: "talk", pid: "P5", text: "무슨 사건인가요?" });
  for (const [sp, ev] of [["bellrope", "EV03"], ["chair", "EV06"], ["glasses", "EV07"], ["knot", "EV05"], ["shelf", "EV04"]]) await openEv(s, sp, ev);
  await act(s, { type: "talk", pid: "P1", text: "안녕하세요 부인" });
  assert.ok(s.flags.includes("met:P1"));
  await act(s, { type: "travel", locationId: "servants" });
  await act(s, { type: "talk", pid: "P6", text: "그날 밤 비명 소리가 났을 때 어디 계셨나요?" });
  await act(s, { type: "talk", pid: "P6", text: "테레사가 정문에서 무엇을 봤나요?" });
  await act(s, { type: "talk", pid: "P6", text: "정원 연못 얼음에 이상한 점은 없었나요?" });
  assert.ok(s.flags.includes("loc:lodge") && s.flags.includes("loc:pond"));
  await act(s, { type: "talk", pid: "P5", text: "강도 일당은 누구입니까?" });
  await act(s, { type: "travel", locationId: "yard" });
  await openEv(s, "wanted", "EV15");
  await openEv(s, "telegram", "EV18");
  await act(s, { type: "object", statementId: "C1", evidenceId: "EV18" });
  await act(s, { type: "object", statementId: "C2", evidenceId: "EV03" });
  await act(s, { type: "object", statementId: "C3", evidenceId: "EV07" });
  await act(s, { type: "travel", locationId: "interrogation" });
  const r = await act(s, { type: "summon", pid: "P1", evidenceIds: ["EV03"] });
  assert.equal(r.events.find((e) => e.kind === "judge").verdict, "approved");
  const adm = await act(s, { type: "talk", pid: "P1", text: "강도가 있었다는 말은 거짓이지요? 사실대로 말하세요." });
  assert.ok(adm.events.some((e) => e.kind === "admission"));
  assert.equal(E.publicState(s).people.find((p) => p.pid === "P1").stance, "admitted");
  await act(s, { type: "talk", pid: "P5", text: "부인의 출신이 어디입니까?" });
  await act(s, { type: "travel", locationId: "servants" });
  await openEv(s, "household", "EV13");
  await act(s, { type: "talk", pid: "P5", text: "부인이 타고 온 배는 무엇입니까?" });
  await act(s, { type: "travel", locationId: "shipping" });
  await openEv(s, "manifest", "EV19");
  await act(s, { type: "travel", locationId: "sydenham" });
  await act(s, { type: "talk", pid: "P4", text: "잠시 이야기 좀 하시죠" });
  await openEv(s, "observe", "EV20");
  await act(s, { type: "travel", locationId: "interrogation" });
  const j = await act(s, { type: "summon", pid: "P4", evidenceIds: ["EV19", "EV05"] });
  assert.equal(j.events.find((e) => e.kind === "judge").verdict, "approved");
  await act(s, { type: "talk", pid: "P4", text: "이 증거들을 보시오.", attachments: ["EV19", "EV05", "EV20", "EV03"] });
  const c = await act(s, { type: "talk", pid: "P4", text: "당신이 유스터스 경을 죽였지요? 사실대로 말하시오." });
  assert.ok(c.events.some((e) => e.kind === "confession"));
  assert.equal(lastNpc(s, "P4").source, "rule");
  const sub = await act(s, {
    type: "submit", culprit: "P4", method: "부지깽이로 가격", motive: "부인을 지팡이로 때리는 남편으로부터 지키려고",
    reasoning: "강도 사건으로 위장했다", evidenceIds: ["EV19", "EV05", "EV20", "EV03"],
  });
  assert.equal(sub.events[0].score, 100);
  const st = E.publicState(s);
  assert.equal(st.submitted.score, 100);
  assert.equal(st.submitted.answer.culpritName, "잭 크로커");
});

test("판사 기각: 무관 증거 · 미열람 증거 첨부 거부", async () => {
  const s = E.createSession();
  await act(s, { type: "talk", pid: "P1", text: "부인, 말씀 좀" });
  await act(s, { type: "inspect", spotId: "window" }); // 발견만, 미열람
  await act(s, { type: "travel", locationId: "interrogation" });
  await expectErr(act(s, { type: "summon", pid: "P1", evidenceIds: ["EV09"] }), "evidence_not_opened");
  const r = await act(s, { type: "summon", pid: "P1", evidenceIds: ["EV01"] });
  assert.equal(r.events[0].verdict, "denied");
  assert.equal(s.judge.length, 1);
  assert.ok(!s.flags.includes("summoned:P1"));
});

test("소환 전 거절 인물 대화는 거절 대사", async () => {
  const s = E.createSession();
  const r = await act(s, { type: "talk", pid: "P1", text: "그날 밤 일을 말씀해 주세요" });
  assert.ok(r.events.some((e) => e.kind === "refused"));
  assert.match(lastNpc(s, "P1").text, /쉬게 해 주세요/);
  await act(s, { type: "travel", locationId: "interrogation" });
  await expectErr(act(s, { type: "talk", pid: "P1", text: "안녕하세요" }), "not_present");
  // met 없이 소환 → 기각 사유
  const s2 = E.createSession();
  await openEv(s2, "bellrope", "EV03");
  await act(s2, { type: "travel", locationId: "interrogation" });
  const j = await act(s2, { type: "summon", pid: "P1", evidenceIds: ["EV03"] });
  assert.match(j.events[0].reason, /먼저 현장에서 면담/);
});

test("이의 제기 실패(무관 증거)는 진술 유지", async () => {
  const s = E.createSession();
  await act(s, { type: "talk", pid: "P5", text: "무슨 사건인가요?" });
  await openEv(s, "chair", "EV06");
  await openEv(s, "window", "EV09");
  const r = await act(s, { type: "object", statementId: "C1", evidenceId: "EV09" });
  assert.equal(r.events[0].success, false);
  const st = E.publicState(s);
  assert.equal(st.statements.find((x) => x.id === "C1").status, "standing");
  assert.ok(st.chats.P1.some((m) => m.from === "system" && /반박할 수 없습니다/.test(m.text)));
  const ok = await act(s, { type: "object", statementId: "C2", evidenceId: "EV06" });
  assert.equal(ok.events[0].success, true);
  assert.equal(E.publicState(s).statements.find((x) => x.id === "C2").status, "broken");
});

test("accuse 노드는 추궁 의도가 아니면 열리지 않는다", async () => {
  const s = E.createSession();
  s.flags.push("met:P4", "summoned:P4", "loc:sydenham", "ev:EV19", "ev:EV05", "ev:EV20", "ev:EV03");
  s.discovered.push("EV19", "EV05", "EV20", "EV03");
  s.place = "interrogation";
  s.locationId = "interrogation";
  await act(s, { type: "talk", pid: "P4", text: "증거입니다", attachments: ["EV19", "EV05", "EV20", "EV03"] });
  await act(s, { type: "talk", pid: "P4", text: "그날 밤 식당에 있었나요?" });
  assert.ok(!s.flags.includes("confessed:P4"));
  await act(s, { type: "talk", pid: "P4", text: "당신이 유스터스 경을 죽였나요?" });
  assert.ok(s.flags.includes("confessed:P4"));
  // 증거 부족이면 추궁해도 열리지 않음
  const t = E.createSession();
  t.flags.push("met:P4", "summoned:P4", "ev:EV19", "loc:sydenham");
  t.discovered.push("EV19");
  t.place = "interrogation";
  t.locationId = "interrogation";
  await act(t, { type: "talk", pid: "P4", text: "당신이 죽였지요? 자백하시오", attachments: ["EV19"] });
  assert.ok(!t.flags.includes("confessed:P4"));
});

test("첫 제출 후 재제출 거부", async () => {
  const s = E.createSession();
  await act(s, { type: "submit", culprit: "P1", method: "독", motive: "돈", reasoning: "", evidenceIds: [] });
  assert.equal(E.publicState(s).submitted.score, 0);
  await expectErr(act(s, { type: "submit", culprit: "P4", method: "부지깽이", motive: "지키려", reasoning: "", evidenceIds: [] }), "already_submitted");
});

test("미열람 증거 첨부는 evidence_not_opened", async () => {
  const s = E.createSession();
  await act(s, { type: "inspect", spotId: "bellrope" });
  await expectErr(act(s, { type: "talk", pid: "P5", text: "이것 보세요", attachments: ["EV03"] }), "evidence_not_opened");
  assert.equal((s.chats.P5 || []).length, 0);
});

test("P3(랜들 일당) 지목은 허용되어 0점, start 장소 hasNew는 false", async () => {
  const s = E.createSession();
  assert.ok(E.publicState(s).locations.every((l) => l.hasNew === false));
  s.flags.push("loc:pond");
  assert.equal(E.publicState(s).locations.find((l) => l.id === "pond").hasNew, true);
  await act(s, { type: "travel", locationId: "pond" });
  assert.equal(E.publicState(s).locations.find((l) => l.id === "pond").hasNew, false);
  await act(s, { type: "submit", culprit: "P3", method: "", motive: "", reasoning: "", evidenceIds: [] });
  assert.equal(E.publicState(s).submitted.score, 0);
});

test("자백 노드가 열리는 턴에는 부분 인정 노드를 함께 열지 않는다(브루스-파팅턴)", async () => {
  const pack = require("../cases/bruce/pack.cjs");
  const s = E.createSession("bruce");
  // 조건을 직접 채워 두 accuse 노드(C_admit, C_confess)가 동시에 열릴 수 있는 상태로 만든다
  s.place = "interrogation"; s.locationId = "interrogation";
  for (const f of ["summoned:P6", "met:P6", ...pack.people.find((p) => p.pid === "P6").visibleWhen.filter((x) => !x.startsWith("@"))]) s.flags.push(f);
  const cr = pack.conditions["@val_cracks"];
  s.objections.push({ statementId: cr.statements[0], evidenceId: "EV15", crack: cr.cracks[0] }, { statementId: cr.statements[1], evidenceId: "EV18", crack: cr.cracks[1] });
  s.presented.P6 = pack.conditions["@val_proof"].groups.map((g) => g.ids[0]);
  for (const id of s.presented.P6) s.flags.push(`ev:${id}`);
  await act(s, { type: "talk", pid: "P6", text: "당신이 설계도를 빼돌린 범인이죠? 사실대로 말하시오. 거짓말은 그만." });
  assert.ok(s.flags.includes("confessed:P6"));
  assert.ok(!s.flags.includes("k:C_admit"), "부분 인정 노드가 같이 열림");
  assert.match(lastNpc(s, "P6").text, /졌소/);
});

test("[보스콤] 증거 맞대기: 맞는 짝은 착안을 열고, 아닌 짝은 헛짚음으로만 남는다", async () => {
  const s = E.createSession("boscombe");
  await expectErr(act(s, { type: "combine", a: "EV_INQUEST_RECORD", b: "EV_VICTORIA_MAP" }), "evidence_not_opened");
  for (const id of ["EV_INQUEST_RECORD", "EV_GROOM_APPOINTMENT"]) { s.discovered.includes(id) || s.discovered.push(id); s.flags.includes(`ev:${id}`) || s.flags.push(`ev:${id}`); }
  await expectErr(act(s, { type: "combine", a: "EV_INQUEST_RECORD", b: "EV_INQUEST_RECORD" }), "same_evidence");
  const r = await act(s, { type: "combine", a: "EV_GROOM_APPOINTMENT", b: "EV_INQUEST_RECORD" });
  assert.ok(r.events.some((e) => e.kind === "combo" && e.success && e.id === "CB_APPOINT"));
  assert.ok(s.flags.includes("cmb:CB_APPOINT"));
  const st = E.publicState(s);
  assert.equal(st.insights.length, 1);
  assert.match(st.insights[0].text, /약속/);
  // 아직 얻지 않은 착안의 본문은 공개 상태에 없다
  const pack = require("../cases/boscombe/pack.cjs");
  const json = JSON.stringify(st);
  for (const c of pack.combos.filter((x) => x.id !== "CB_APPOINT")) assert.ok(!json.includes(c.ask), c.id);
  // 같은 짝을 다시 맞대도 착안은 하나, 접촉 기록은 쌓인다
  await act(s, { type: "combine", a: "EV_INQUEST_RECORD", b: "EV_GROOM_APPOINTMENT" });
  assert.equal(E.publicState(s).insights.length, 1);
  assert.equal(E.publicState(s).contactStats.combine.hits, 2);
});

test("[보스콤] 대질: 말을 들은 뒤에만 성립하고, 크라우더 진술을 깨뜨린다", async () => {
  const s = E.createSession("boscombe");
  s.flags.push("loc:prison");
  let r = await act(s, { type: "confront", a: "P1", b: "P5" });
  assert.ok(r.events.some((e) => e.kind === "confront" && !e.success && e.reason === "unheard"));
  assert.ok(!s.flags.includes("broken:S1"));
  s.flags.push("k:J_walk");
  r = await act(s, { type: "confront", a: "P1", b: "P5" });
  assert.ok(r.events.some((e) => e.kind === "confront" && e.success && e.id === "CF_FOLLOW"));
  assert.ok(s.flags.includes("broken:S1") && s.flags.includes("crack:follow_guess"));
  const st = E.publicState(s);
  assert.equal(st.statements.find((x) => x.id === "S1").status, "broken");
  assert.equal(st.insights[0].lines.length, 3);
  r = await act(s, { type: "confront", a: "P3", b: "P6" });
  assert.ok(r.events.some((e) => e.kind === "confront" && !e.success && e.reason === "none"));
  assert.equal(E.publicState(s).contactStats.confront.tries, 3);
});
