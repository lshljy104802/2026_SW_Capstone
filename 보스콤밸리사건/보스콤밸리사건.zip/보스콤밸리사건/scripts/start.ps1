﻿param([switch]$NoBrowser, [switch]$NoPrompt)
# 딸깍 실행: Node 찾기(동봉 → 설치된 22 이상 → 자동 내려받기) → API 키 확인(없으면 입력창) → 서버 시작 → 브라우저 열기
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$runtimeDir = Join-Path $projectRoot 'runtime'
New-Item -ItemType Directory -Path $runtimeDir -Force | Out-Null
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName Microsoft.VisualBasic
$title = '보스콤 밸리 사건'
function Show-Box([string]$text, [string]$icon = 'Information') {
    if ($NoPrompt) { Write-Host $text; return }
    [void][System.Windows.Forms.MessageBox]::Show($text, $title, 'OK', $icon)
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ── 1. Node.js
$NodeVersion = 'v24.13.1'
$node = $null
$bundled = Join-Path $projectRoot 'node\node.exe'
if (Test-Path -LiteralPath $bundled) { $node = $bundled }
if (-not $node) {
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) {
        try { $major = [int]((& $cmd.Source -v).TrimStart('v').Split('.')[0]) } catch { $major = 0 }
        if ($major -ge 22) { $node = $cmd.Source }
    }
}
if (-not $node) {
    Write-Host 'Node.js를 내려받는 중입니다(약 30MB, 처음 한 번만)...'
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
    $zipUrl = "https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-win-$arch.zip"
    $tmpZip = Join-Path $env:TEMP "boscombe-node-$NodeVersion-$arch.zip"
    $tmpDir = Join-Path $env:TEMP "boscombe-node-$NodeVersion-$arch"
    try {
        $ProgressPreference = 'SilentlyContinue'
        Invoke-WebRequest -Uri $zipUrl -OutFile $tmpZip -UseBasicParsing
        if (Test-Path -LiteralPath $tmpDir) { Remove-Item -LiteralPath $tmpDir -Recurse -Force }
        Expand-Archive -LiteralPath $tmpZip -DestinationPath $tmpDir -Force
        New-Item -ItemType Directory -Path (Split-Path $bundled) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $tmpDir "node-$NodeVersion-win-$arch\node.exe") -Destination $bundled -Force
        $node = $bundled
    } catch {
        Show-Box ("Node.js를 내려받지 못했습니다. 인터넷 연결을 확인하거나 https://nodejs.org 에서 Node.js(22 이상)를 설치한 뒤 다시 실행해 주세요.`n`n" + $_.Exception.Message) 'Error'
        exit 1
    }
}

# ── 2. .env와 API 키
$envPath = Join-Path $projectRoot '.env'
$examplePath = Join-Path $projectRoot '.env.example'
if (-not (Test-Path -LiteralPath $envPath) -and (Test-Path -LiteralPath $examplePath)) { Copy-Item -LiteralPath $examplePath -Destination $envPath }
$script:lines = @()
if (Test-Path -LiteralPath $envPath) { $script:lines = @(Get-Content -LiteralPath $envPath -Encoding utf8) }
function Get-EnvValue([string]$name) {
    foreach ($l in $script:lines) { if ($l -match ('^\s*' + $name + '\s*=\s*["'']?([^"'']*)["'']?\s*$')) { return $Matches[1].Trim() } }
    return ''
}
function Set-EnvValue([string]$name, [string]$value) {
    $found = $false
    for ($i = 0; $i -lt $script:lines.Count; $i++) {
        if ($script:lines[$i] -match ('^\s*#?\s*' + $name + '\s*=')) { $script:lines[$i] = "$name=$value"; $found = $true; break }
    }
    if (-not $found) { $script:lines += "$name=$value" }
    [IO.File]::WriteAllLines($envPath, [string[]]$script:lines, (New-Object Text.UTF8Encoding $false))
}
function Test-ApiKey([string]$key) {
    try {
        $null = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/models?limit=1' -Headers @{ 'x-api-key' = $key; 'anthropic-version' = '2023-06-01' } -UseBasicParsing -TimeoutSec 15
        return 'ok'
    } catch {
        $code = $null
        try { $code = [int]$_.Exception.Response.StatusCode } catch { }
        if ($code -eq 401 -or $code -eq 403) { return 'bad' }
        return 'offline'
    }
}
$provider = Get-EnvValue 'ABBEY_PROVIDER'
if (-not $provider) { $provider = 'anthropic' }
if ($provider -eq 'anthropic') {
    $key = Get-EnvValue 'ANTHROPIC_API_KEY'
    $status = if ($key) { Test-ApiKey $key } else { 'empty' }
    $tries = 0
    while (($status -eq 'empty' -or $status -eq 'bad') -and -not $NoPrompt -and $tries -lt 3) {
        $tries++
        if ($status -eq 'bad') {
            $msg = "키가 맞지 않습니다(만료·오타). 다시 붙여 넣어 주세요.`n`n비워 두고 확인을 누르면 AI 없이 미리 써 둔 대사로 진행합니다."
        } else {
            $msg = "Claude API 키를 붙여 넣어 주세요(sk-ant-로 시작).`n한 번 넣으면 이 폴더의 .env에 저장되어 다음부터는 묻지 않습니다.`n`n비워 두고 확인을 누르면 AI 없이 미리 써 둔 대사로 진행합니다."
        }
        $key = ([Microsoft.VisualBasic.Interaction]::InputBox($msg, $title, '')).Trim()
        if (-not $key) { $status = 'skip'; break }
        $status = Test-ApiKey $key
        if ($status -ne 'bad') { Set-EnvValue 'ANTHROPIC_API_KEY' $key; Set-EnvValue 'ABBEY_PROVIDER' 'anthropic' }
    }
    if ($status -eq 'offline') {
        Show-Box 'Claude API에 연결하지 못했습니다(인터넷·방화벽 확인). 게임은 켜고, 연결이 안 되는 동안은 미리 써 둔 대사로 답합니다.' 'Warning'
    } elseif ($status -ne 'ok') {
        $env:ABBEY_PROVIDER = 'rule'
        Write-Host 'API 키 없이 실행합니다(정본 대사·규칙 판정).'
    }
}

# ── 3. 포트: 이미 켜진 게임이면 그대로 열고, 다른 프로그램이 쓰면 빈 포트를 찾는다
$portValue = if ($env:PORT) { $env:PORT } else { Get-EnvValue 'PORT' }
if (-not $portValue) { $portValue = '3220' }
function Test-GameServer([string]$url) {
    try { $h = Invoke-RestMethod -Uri "$url/api/health" -TimeoutSec 2; return [bool]($h.ok -and $h.app -eq 'wd-abbey-claude') } catch { return $false }
}
function Test-PortBusy([int]$p) {
    $c = New-Object Net.Sockets.TcpClient
    try { $c.Connect('127.0.0.1', $p); return $true } catch { return $false } finally { $c.Close() }
}
$port = [int]$portValue
$baseUrl = "http://127.0.0.1:$port"
if (-not (Test-GameServer $baseUrl)) {
    while ((Test-PortBusy $port) -and $port -lt ([int]$portValue + 20)) { $port++ }
    $env:PORT = "$port"
    $baseUrl = "http://127.0.0.1:$port"
    $serverPath = Join-Path $projectRoot 'server.cjs'
    $pidPath = Join-Path $runtimeDir 'launcher.pid'
    $process = Start-Process -FilePath $node -ArgumentList @(('"' + $serverPath + '"')) -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimeDir 'server.stdout.log') -RedirectStandardError (Join-Path $runtimeDir 'server.stderr.log')
    $process.Id | Set-Content -LiteralPath $pidPath -Encoding ascii
    $ready = $false
    for ($attempt = 0; $attempt -lt 60; $attempt++) {
        if (Test-GameServer $baseUrl) { $ready = $true; break }
        if ($process.HasExited) { break }
        Start-Sleep -Milliseconds 250
    }
    if (-not $ready) {
        Show-Box ("게임 서버가 켜지지 않았습니다. runtime\server.stderr.log 내용을 확인해 주세요.`n" + $baseUrl) 'Error'
        exit 1
    }
}
Write-Host "보스콤 밸리 사건 실행 중: $baseUrl  (끌 때는 STOP.cmd)"
if (-not $NoBrowser) { Start-Process $baseUrl }
