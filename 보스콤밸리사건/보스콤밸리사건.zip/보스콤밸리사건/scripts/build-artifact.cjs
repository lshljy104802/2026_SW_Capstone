// 확정 UI(public/)와 엔진·대화·사건 팩을 고치지 않고 그대로 묶어 Claude 아티팩트용 단일 HTML을 만든다.
// 서버가 하던 일(세션·/api/*)은 페이지 안의 얇은 대체 층이 하고, 모델 호출은 페이지가 직접 Haiku를 부른다(sample 기능).
// 사용: node scripts/build-artifact.cjs  →  artifact/index.html + artifact/art/*.png(가로 1024로 줄인 그림)
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const ROOT = path.join(__dirname, "..");
const OUT = path.join(ROOT, "artifact");
const ART_SRC = path.resolve(ROOT, "..", "31_WD-ABBEY_자유심문_공유본_20261105", "public", "assets", "art");

// ── 1. CommonJS 모듈 수집(engine.cjs에서 시작해 require를 따라간다. 사건 팩은 폴더를 훑어 넣는다)
const mods = {};
const key = (abs) => "/app/" + path.relative(ROOT, abs).split(path.sep).join("/");
function addModule(abs) {
  const k = key(abs);
  if (mods[k]) return;
  const src = fs.readFileSync(abs, "utf8");
  if (abs.endsWith(".json")) { mods[k] = `module.exports = ${JSON.stringify(JSON.parse(src))};`; return; }
  mods[k] = src;
  for (const m of src.matchAll(/require\("(\.[^"]+)"\)/g)) addModule(path.resolve(path.dirname(abs), m[1]));
}
addModule(path.join(ROOT, "engine.cjs"));
// 경쟁판은 보스콤 한 편만 싣는다(서버판 기본값 ABBEY_CASES=boscombe와 같다)
const caseIds = ["boscombe"];
for (const id of caseIds) addModule(path.join(ROOT, "cases", id, "pack.cjs"));

const bundle = `
const process = { env: { ABBEY_CASES: ${JSON.stringify(caseIds.join(","))} } };
const __mods = {${Object.entries(mods).map(([k, src]) => `${JSON.stringify(k)}: function (module, exports, require, __dirname) {\n${src}\n}`).join(",\n")}};
const __cache = {};
const __norm = (p) => { const out = []; for (const s of p.split("/")) { if (s === "..") out.pop(); else if (s && s !== ".") out.push(s); } return "/" + out.join("/"); };
const __shims = {
  "node:crypto": { randomBytes: (n) => ({ toString: () => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, "0")).join("") }) },
  "node:fs": { readdirSync: () => ${JSON.stringify(caseIds)}, existsSync: (f) => !!__mods[__norm(f)] },
  "node:path": { join: (...a) => __norm(a.join("/")) },
};
function __require(from, spec) {
  if (__shims[spec]) return __shims[spec];
  const k = __norm(spec.startsWith(".") ? from + "/" + spec : spec);
  if (__cache[k]) return __cache[k].exports;
  if (!__mods[k]) throw new Error("모듈 없음: " + k);
  const module = (__cache[k] = { exports: {} });
  const dir = k.slice(0, k.lastIndexOf("/"));
  __mods[k](module, module.exports, (s) => __require(dir, s), dir);
  return module.exports;
}
window.__engine = __require("/app", "./engine.cjs");
window.__dialogue = __require("/app", "./dialogue.cjs");
`;

// ── 2. 서버 대체 층: /api/* 요청을 페이지 안에서 처리하고, 모델은 sample로 부른다.
const shim = fs.readFileSync(path.join(OUT, "local-server.js"), "utf8");

// ── 3. 확정 UI를 그대로 싣는다. 바꾸는 것은 그림 경로(/art/ → art/)뿐이다.
const html = fs.readFileSync(path.join(ROOT, "public", "index.html"), "utf8");
const body = html.slice(html.indexOf("<body>") + 6, html.indexOf("</body>")).replace(/<script[^>]*src="app\.js"[^>]*><\/script>/, "");
const css = fs.readFileSync(path.join(ROOT, "public", "styles.css"), "utf8");
let app = fs.readFileSync(path.join(ROOT, "public", "app.js"), "utf8");
if (!app.includes("'/art/interrogation.png'")) throw new Error("app.js의 심문실 그림 경로를 찾지 못함");
app = app.replace("'/art/interrogation.png'", "'art/interrogation.png'");
const esc = (s) => s.replace(/<\/script/gi, "<\\/script");

const page = `<title>보스콤 밸리 사건</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Hahmlet:wght@400;600;800&family=Black+Han+Sans&family=Noto+Sans+KR:wght@400;500;700;900&display=swap">
<meta charset="utf-8">
<style>
${css}
/* 아티팩트 보정: 화면 높이를 뷰어 안쪽에 맞추고, 호출 상태 표시를 붙인다 */
html,body{height:100%}
body{min-height:0}
.layout{height:auto;flex:1}
.model-chip{font-size:12px;color:var(--cream2,#d9d5c3);margin-left:8px;white-space:nowrap}
</style>
${body}
<script>
${esc(bundle)}
${esc(shim)}
</script>
<script type="module">
${esc(app)}
</script>
`;
fs.writeFileSync(path.join(OUT, "index.html"), page);

// ── 4. 그림: 원본(장당 2~3.6MB)을 가로 1024로 줄여 artifact/art에 둔다(저장소에는 올리지 않는다)
fs.mkdirSync(path.join(OUT, "art"), { recursive: true });
const py = `
import sys, os
from PIL import Image
src, dst = sys.argv[1], sys.argv[2]
for f in sorted(os.listdir(src)):
    if not f.endswith('.png'): continue
    im = Image.open(os.path.join(src, f)).convert('RGB')
    w = 640 if f.startswith('portrait') else 1024
    if im.width > w: im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    im = im.quantize(colors=256, method=Image.MEDIANCUT, dither=Image.FLOYDSTEINBERG)
    im.save(os.path.join(dst, f), optimize=True)
    print(f, os.path.getsize(os.path.join(dst, f)) // 1024, 'KB')
`;
const pyFile = path.join(require("node:os").tmpdir(), "boscombe_art_resize.py");
fs.writeFileSync(pyFile, py);
console.log(execFileSync("python", ["-I", pyFile, ART_SRC, path.join(OUT, "art")], { encoding: "utf8" }));
console.log(`index.html ${(page.length / 1024).toFixed(0)}KB · 모듈 ${Object.keys(mods).length}개 · 사건 ${caseIds.join(", ")}`);
