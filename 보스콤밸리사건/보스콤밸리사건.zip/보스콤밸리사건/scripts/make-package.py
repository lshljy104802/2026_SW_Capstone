# 다른 노트북용 딸깍 실행판 zip을 만든다(API 키는 넣지 않는다).
# 사용: python -I scripts/make-package.py <출력.zip> <node-win-x64.zip 경로> [실행안내.txt]
#  - 저장소에 올라간 이 폴더 파일(.env·세션·사용량 기록·artifact 제외)
#  - art/: 31번 공유본 그림을 가로 1024(초상 640)로 줄인 것(artifact/art에서 가져온다. 없으면 build-artifact.cjs 먼저)
#  - node/node.exe: 공식 Windows 휴대용 Node(설치 불필요)
import os, subprocess, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out, node_zip = sys.argv[1], sys.argv[2]
guide = sys.argv[3] if len(sys.argv) > 3 else None
TOP = "보스콤밸리사건"

listed = subprocess.run(["git", "ls-files", "-z", "--", "."], cwd=ROOT, capture_output=True).stdout.decode("utf-8").split("\0")
files = [f for f in listed if f and not f.startswith("artifact/")]
bad = [f for f in files if f == ".env" or f.startswith((".runtime/", "runtime/"))]
if bad:
    sys.exit(f"넣으면 안 되는 파일: {bad}")

art_dir = os.path.join(ROOT, "artifact", "art")
arts = sorted(f for f in os.listdir(art_dir) if f.endswith(".png"))
if not arts:
    sys.exit("artifact/art가 비어 있음: node scripts/build-artifact.cjs 먼저")

def add(z, src, arc, exe=False):
    info = zipfile.ZipInfo.from_file(src, arc)
    info.compress_type = zipfile.ZIP_DEFLATED
    if exe:
        info.external_attr = (0o100755 << 16)
    with open(src, "rb") as fh:
        z.writestr(info, fh.read())

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for f in files:
        add(z, os.path.join(ROOT, f), f"{TOP}/{f}", exe=f.endswith(".command"))
    for f in arts:
        add(z, os.path.join(art_dir, f), f"{TOP}/art/{f}")
    if guide:
        add(z, guide, f"{TOP}/실행안내.txt")
    with zipfile.ZipFile(node_zip) as nz:
        base = nz.namelist()[0].split("/")[0]
        for name in ("node.exe", "LICENSE"):
            info = zipfile.ZipInfo(f"{TOP}/node/{name}", date_time=nz.getinfo(f"{base}/{name}").date_time)
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, nz.read(f"{base}/{name}"))

with zipfile.ZipFile(out) as z:
    names = z.namelist()
print(f"{out}: {len(names)}개 파일, {os.path.getsize(out):,}바이트, .env 포함={any(n.endswith('/.env') for n in names)}")
