// runtime/usage.jsonl 합계: 호출 수, 토큰 합(캐시 포함), 평균 지연, API 단가로 환산한 비용 (provider/모델/역할별)
// 단가(100만 토큰당 US$: 입력·출력·캐시 읽기·캐시 쓰기). Haiku 5.5는 프롬프트 10만 토큰 이하 구간 단가이고,
// 캐시는 표준 배율(읽기 0.1배·쓰기 1.25배)로 잡았다. 목록에 없는 모델은 비용을 계산하지 않는다.
const PRICE = {
  "claude-haiku-5-5": [0.1, 0.5, 0.01, 0.125],
};
const fs = require("node:fs");
const path = require("node:path");
const file = process.argv[2] || path.join(__dirname, "..", "runtime", "usage.jsonl");
if (!fs.existsSync(file)) {
  console.log("기록 없음: " + file);
  process.exit(0);
}
const groups = {};
function add(key, r) {
  if (!groups[key]) groups[key] = { calls: 0, ok: 0, inTok: 0, outTok: 0, cr: 0, cw: 0, lat: 0, usd: 0, priced: true };
  const g = groups[key];
  g.calls++;
  if (r.ok) g.ok++;
  const i = Number(r.input_tokens) || 0;
  const o = Number(r.output_tokens) || 0;
  const cr = Number(r.cache_read_tokens) || 0;
  const cw = Number(r.cache_write_tokens) || 0;
  g.inTok += i;
  g.outTok += o;
  g.cr += cr;
  g.cw += cw;
  g.lat += Number(r.latency_ms) || 0;
  const p = PRICE[r.model];
  if (p) g.usd += (i * p[0] + o * p[1] + cr * p[2] + cw * p[3]) / 1e6;
  else if (r.provider !== "rule") g.priced = false;
}
for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
  if (!line.trim()) continue;
  try {
    const r = JSON.parse(line);
    add("전체", r);
    add(`${r.provider}/${r.model} · ${r.role || "-"}`, r);
  } catch {}
}
for (const [k, g] of Object.entries(groups)) {
  const cache = g.cr || g.cw ? ` (캐시 읽기 ${g.cr} · 쓰기 ${g.cw})` : "";
  const usd = g.priced ? `, API 환산 약 $${g.usd.toFixed(4)}` : ", API 환산: 단가표에 없는 모델 포함";
  console.log(`${k}: 호출 ${g.calls}회(성공 ${g.ok}), 입력 ${g.inTok}${cache} · 출력 ${g.outTok} 토큰, 평균 지연 ${g.calls ? Math.round(g.lat / g.calls) : 0}ms${usd}`);
}
