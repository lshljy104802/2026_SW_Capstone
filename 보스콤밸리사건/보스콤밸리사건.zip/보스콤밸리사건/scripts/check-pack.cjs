// 사건 팩 정적 점검: 참조 무결성과, 플래그만 따라갔을 때 모든 증거·인물·노드에 도달할 수 있는지.
// 사용: node scripts/check-pack.cjs <id>
const path = require("node:path");

function checkPack(pack) {
  const errs = [];
  const warn = [];
  const ev = new Set(pack.evidence.map((e) => e.id));
  const st = new Set(pack.statements.map((s) => s.id));
  const loc = new Set(pack.locations.map((l) => l.id));
  const ppl = new Map(pack.people.map((p) => [p.pid, p]));
  const nodeIds = new Set(pack.nodes.map((n) => n.id));
  const crackIds = new Set([...pack.objections.map((o) => o.crack), ...pack.people.flatMap((p) => Object.keys(p.cracks || {}))]);
  const condIds = new Set(Object.keys(pack.conditions || {}));

  for (const k of ["id", "title", "brief", "startLocation", "map", "locations", "spots", "start", "people", "refusals", "nodes", "objections", "summons", "evidence", "statements", "suspects", "scoring", "answer", "leak"]) {
    if (pack[k] === undefined) errs.push(`필드 없음: ${k}`);
  }
  if (!loc.has("interrogation")) errs.push("interrogation 장소 없음");
  if (!loc.has(pack.startLocation)) errs.push("startLocation이 locations에 없음");

  const checkFlag = (f, where) => {
    const [kind, id] = f.includes(":") ? [f.slice(0, f.indexOf(":")), f.slice(f.indexOf(":") + 1)] : [f, ""];
    if (f.startsWith("@")) { if (!condIds.has(f)) errs.push(`${where}: 정의 안 된 조건 ${f}`); return; }
    const ok = {
      ev: () => ev.has(id), k: () => nodeIds.has(id), heard: () => st.has(id), broken: () => st.has(id),
      crack: () => crackIds.has(id), met: () => ppl.has(id), loc: () => loc.has(id),
      summoned: () => ppl.has(id), admitted: () => ppl.has(id), confessed: () => ppl.has(id),
      f: () => true, cmb: () => (pack.combos || []).some((c) => c.id === id), cf: () => (pack.confronts || []).some((c) => c.id === id), shown: () => ppl.has(id.split(":")[0]) && ev.has(id.split(":")[1]),
    }[kind];
    if (!ok) errs.push(`${where}: 알 수 없는 플래그 종류 ${f}`);
    else if (!ok()) errs.push(`${where}: 없는 대상을 가리킴 ${f}`);
  };

  const revealed = new Map();
  for (const sp of pack.spots) {
    if (!loc.has(sp.locationId)) errs.push(`spot ${sp.id}: 장소 없음 ${sp.locationId}`);
    if (!ev.has(sp.reveals)) errs.push(`spot ${sp.id}: 증거 없음 ${sp.reveals}`);
    if (revealed.has(sp.reveals)) warn.push(`증거 ${sp.reveals}를 지점 둘이 공개(${revealed.get(sp.reveals)}, ${sp.id})`);
    revealed.set(sp.reveals, sp.id);
    sp.requires.forEach((f) => checkFlag(f, `spot ${sp.id}`));
    (sp.grants || []).forEach((f) => checkFlag(f, `spot ${sp.id}.grants`));
  }
  for (const id of ev) if (!revealed.has(id) && !pack.start.evidence.includes(id)) errs.push(`증거 ${id}를 공개하는 지점이 없음`);
  for (const p of pack.people) {
    if (!loc.has(p.location)) errs.push(`인물 ${p.pid}: 장소 없음`);
    (p.visibleWhen || []).forEach((f) => checkFlag(f, `인물 ${p.pid}.visibleWhen`));
    if (!p.profile || !p.profile.voice) errs.push(`인물 ${p.pid}: profile.voice 없음`);
    if (!p.lines || !p.lines.unknown) errs.push(`인물 ${p.pid}: lines.unknown 없음`);
    if (p.stance === "refusing") {
      if (!pack.refusals[p.pid]) errs.push(`거절 인물 ${p.pid}: refusals 없음`);
      if (!pack.summons[p.pid]) errs.push(`거절 인물 ${p.pid}: summons 없음`);
    }
  }
  for (const [pid, r] of Object.entries(pack.refusals)) r.grants.forEach((f) => checkFlag(f, `refusal ${pid}`));
  for (const n of pack.nodes) {
    if (!ppl.has(n.pid)) errs.push(`노드 ${n.id}: 인물 없음`);
    if (!(n.keywords instanceof RegExp)) errs.push(`노드 ${n.id}: keywords가 정규식이 아님`);
    const person = ppl.get(n.pid);
    if (person && person.stance === "refusing" && n.place !== "interrogation") warn.push(`노드 ${n.id}: 거절 인물 노드인데 place가 interrogation이 아님`);
    n.requires.forEach((f) => checkFlag(f, `노드 ${n.id}`));
    n.grants.forEach((f) => checkFlag(f, `노드 ${n.id}.grants`));
  }
  for (const o of pack.objections) {
    if (!st.has(o.statement)) errs.push(`이의 ${o.statement}: 진술 없음`);
    o.evidence.forEach((e) => { if (!ev.has(e)) errs.push(`이의 ${o.statement}: 증거 없음 ${e}`); });
    const s = pack.statements.find((x) => x.id === o.statement);
    const speaker = s && ppl.get(s.speaker);
    if (speaker && !(speaker.cracks || {})[o.crack]) warn.push(`이의 ${o.statement}/${o.crack}: 화자 ${s.speaker}의 cracks 반응 대사 없음`);
  }
  for (const s of pack.statements) if (!ppl.has(s.speaker)) errs.push(`진술 ${s.id}: 화자 없음`);
  // 접촉 2·3단계(선택): 증거↔증거 착안, 인물↔인물 대질
  const seenPair = new Set();
  for (const c of pack.combos || []) {
    if (!ev.has(c.a) || !ev.has(c.b)) errs.push(`착안 ${c.id}: 증거 없음 ${c.a}/${c.b}`);
    const k = [c.a, c.b].sort().join("+");
    if (seenPair.has(k)) errs.push(`착안 ${c.id}: 같은 증거 짝이 겹침`);
    seenPair.add(k);
    if (!c.title || !c.text || !c.ask) errs.push(`착안 ${c.id}: title·text·ask 중 빠진 것`);
    if (c.talkTo && !ppl.has(c.talkTo)) errs.push(`착안 ${c.id}: talkTo 인물 없음`);
  }
  for (const c of pack.confronts || []) {
    if (!ppl.has(c.a) || !ppl.has(c.b)) errs.push(`대질 ${c.id}: 인물 없음`);
    const k = "P:" + [c.a, c.b].sort().join("+");
    if (seenPair.has(k)) errs.push(`대질 ${c.id}: 같은 인물 짝이 겹침`);
    seenPair.add(k);
    (c.requires || []).forEach((f) => checkFlag(f, `대질 ${c.id}`));
    (c.lines || []).forEach(([pid]) => { if (pid !== c.a && pid !== c.b) errs.push(`대질 ${c.id}: 대사 화자 ${pid}가 두 인물이 아님`); });
    if (c.breaks && !st.has(c.breaks.statement)) errs.push(`대질 ${c.id}: 진술 없음 ${c.breaks.statement}`);
  }
  for (const [pid, r] of Object.entries(pack.summons)) {
    r.groups.forEach((gr) => gr.ids.forEach((e) => { if (!ev.has(e)) errs.push(`소환 ${pid}: 증거 없음 ${e}`); }));
    (r.altFlags || []).forEach((f) => checkFlag(f, `소환 ${pid}.altFlags`));
    (r.requires || []).forEach((f) => checkFlag(f, `소환 ${pid}.requires`));
  }
  for (const [name, c] of Object.entries(pack.conditions || {})) {
    if (c.type === "proof") c.groups.forEach((gr) => gr.ids.forEach((e) => { if (!ev.has(e)) errs.push(`조건 ${name}: 증거 없음 ${e}`); }));
    else if (c.type === "cracks") c.statements.forEach((x) => { if (!st.has(x)) errs.push(`조건 ${name}: 진술 없음 ${x}`); });
    else if (c.type === "count") c.flags.forEach((f) => checkFlag(f, `조건 ${name}`));
    else if (c.type === "any") c.of.flat().forEach((f) => checkFlag(f, `조건 ${name}`));
    else errs.push(`조건 ${name}: type은 proof|cracks|count|any`);
  }
  const sc = pack.scoring;
  const exGroups = sc.exclusions ? sc.exclusions.suspects.flatMap((x) => x.groups) : [];
  const total = sc.culprit.points + (sc.confession ? sc.confession.points : 0) + sc.items.reduce((a, b) => a + b.points, 0) + sc.evidence.groups.length * sc.evidence.perGroup + exGroups.length * (sc.exclusions ? sc.exclusions.perGroup : 0);
  for (const g of [...sc.evidence.groups, ...exGroups]) g.ids.forEach((e) => { if (!ev.has(e)) errs.push(`채점 묶음 '${g.label}': 증거 없음 ${e}`); });
  if (sc.exclusions) for (const x of sc.exclusions.suspects) {
    if (!pack.suspects.some((p) => p.pid === x.pid)) errs.push(`배제 대상 ${x.pid}가 suspects에 없음`);
    if (sc.culprit.pids.includes(x.pid)) errs.push(`배제 대상 ${x.pid}가 정답 범인임`);
  }
  if (total !== 100) errs.push(`채점 합계 ${total} (100이어야 함)`);
  for (const it of sc.items) (it.needs || []).forEach((f) => checkFlag(f, `채점 '${it.label}'.needs`));
  const checkHints = (list, where) => (list || []).forEach((x, i) => {
    if (!x.text) errs.push(`${where}[${i}]: text 없음`);
    if (x.until) checkFlag(x.until, `${where}[${i}].until`);
    (x.when || []).forEach((w) => checkFlag(w, `${where}[${i}].when`));
    if (x.progress && !condIds.has(x.progress)) errs.push(`${where}[${i}]: 정의 안 된 progress ${x.progress}`);
  });
  for (const l of pack.locations) checkHints(l.hints, `장소 ${l.id}.hints`);
  checkHints(pack.leads, "leads");
  checkHints(pack.roomHints, "roomHints");
  for (const [pid, list] of Object.entries(pack.prompts || {})) {
    if (!ppl.has(pid)) errs.push(`prompts: 없는 인물 ${pid}`);
    checkHints(list.map((x) => ({ ...x, text: x.q })), `prompts.${pid}`);
  }
  sc.culprit.pids.forEach((p) => { if (!pack.suspects.some((x) => x.pid === p)) errs.push(`정답 범인 ${p}가 suspects에 없음`); });

  // 도달 가능성(낙관적): 조건을 만족하는 모든 것을 반복해서 연다. 이의 제기·소환·proof도 가능하다고 본다.
  const F = new Set([...pack.start.flags, ...pack.start.evidence.map((e) => `ev:${e}`)]);
  for (const l of pack.locations) if (l.start) F.add(`loc:${l.id}`);
  const cond = (f) => {
    if (f.startsWith("shown:")) {
      const [pid, e] = f.slice(6).split(":");
      const p = ppl.get(pid);
      return F.has(`ev:${e}`) && F.has(`vis:${pid}`) && (p.stance !== "refusing" || F.has(`summoned:${pid}`));
    }
    if (!f.startsWith("@")) return F.has(f);
    const c = pack.conditions[f];
    if (c.type === "count") return c.flags.filter(cond).length >= c.min;
    if (c.type === "any") return c.of.some((grp) => grp.every(cond));
    if (c.type === "proof") return c.groups.every((gr) => gr.ids.some((e) => F.has(`ev:${e}`))) && F.has(`summoned:${c.pid}`);
    return c.cracks.filter((x) => F.has(`crack:${x}`)).length >= c.min;
  };
  const all = (arr) => (arr || []).every(cond);
  let grew = true;
  while (grew) {
    const n0 = F.size;
    for (const sp of pack.spots) if (F.has(`loc:${sp.locationId}`) && all(sp.requires)) { F.add(`ev:${sp.reveals}`); (sp.grants || []).forEach((g) => F.add(g)); }
    for (const p of pack.people) {
      if (!all(p.visibleWhen)) continue;
      F.add(`vis:${p.pid}`);
      if (p.stance === "refusing" && F.has(`loc:${p.location}`)) { F.add(`met:${p.pid}`); pack.refusals[p.pid].grants.forEach((g) => F.add(g)); }
    }
    for (const n of pack.nodes) {
      const p = ppl.get(n.pid);
      if (!F.has(`vis:${n.pid}`)) continue;
      if (p.stance === "refusing" && !F.has(`summoned:${n.pid}`)) continue;
      if (all(n.requires)) { F.add(`k:${n.id}`); n.grants.forEach((g) => F.add(g)); }
    }
    for (const o of pack.objections) if (F.has(`heard:${o.statement}`) && o.evidence.some((e) => F.has(`ev:${e}`))) { F.add(`broken:${o.statement}`); F.add(`crack:${o.crack}`); }
    for (const [pid, r] of Object.entries(pack.summons)) {
      if (F.has(`met:${pid}`) && (r.groups.every((gr) => gr.ids.some((e) => F.has(`ev:${e}`))) || (r.altFlags || []).some((f) => F.has(f))) && all(r.requires)) F.add(`summoned:${pid}`);
    }
    grew = F.size > n0;
  }
  for (const id of ev) if (!F.has(`ev:${id}`)) errs.push(`도달 불가 증거 ${id}`);
  for (const n of pack.nodes) if (!F.has(`k:${n.id}`)) errs.push(`도달 불가 노드 ${n.id}`);
  for (const p of pack.people) if (!F.has(`vis:${p.pid}`)) errs.push(`도달 불가 인물 ${p.pid}`);
  for (const l of pack.locations) if (!F.has(`loc:${l.id}`)) errs.push(`도달 불가 장소 ${l.id}`);
  if (!sc.culprit.pids.some((p) => F.has(`confessed:${p}`))) warn.push("정답 범인의 자백(confessed:) 플래그에 도달하지 못함");
  return { errs, warn, stats: { people: pack.people.length, suspects: pack.suspects.length, evidence: ev.size, statements: st.size, nodes: pack.nodes.length, locations: loc.size } };
}

if (require.main === module) {
  const id = process.argv[2];
  if (!id) { console.error("사용: node scripts/check-pack.cjs <id>"); process.exit(2); }
  const pack = require(path.join(__dirname, "..", "cases", id, "pack.cjs"));
  const r = checkPack(pack);
  console.log(JSON.stringify(r.stats));
  r.warn.forEach((w) => console.log("경고:", w));
  r.errs.forEach((e) => console.log("오류:", e));
  console.log(r.errs.length ? `실패 (오류 ${r.errs.length})` : "통과");
  process.exit(r.errs.length ? 1 : 0);
}
module.exports = { checkPack };
