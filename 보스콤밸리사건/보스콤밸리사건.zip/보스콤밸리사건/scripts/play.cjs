// 플레이 실험용 CLI. 브라우저 대신 같은 서버 API로 한 판을 진행한다(학생 시점의 공개 상태만 보여 준다).
// 사용: node scripts/play.cjs <명령> [인자...]   세션 id는 PLAY_SESSION 환경변수 또는 .runtime/play_<이름>.txt
//   new <caseId>                       새 판 시작(세션 파일에 저장)
//   look                               현재 상태 요약
//   evidence                           열람한 증거 본문 전체
//   talk <pid> "<질문>" [EV..]          인물에게 자유 질문(증거 첨부 가능)
//   inspect <spotId> | open <EVid> | travel <locId>
//   object <진술id> <EVid>             진술에 증거로 이의 제기
//   summon <pid> <EV..>                심문실에서 판사에게 소환 신청
//   submit <culprit> "<수법>" "<동기>" "<추리>" <EV..> [ex:<pid>=<EV,EV> ..]
//                                      ex:는 다른 용의자 배제 근거(배제 칸이 있는 사건만). 예: ex:P1=EV_A,EV_B
//   time                               경과 시간
const fs = require("node:fs");
const path = require("node:path");
const BASE = process.env.PLAY_BASE || "http://127.0.0.1:3220";
const NAME = process.env.PLAY_NAME || "default";
const file = path.join(__dirname, "..", ".runtime", `play_${NAME}.txt`);

async function call(p, body) {
  const r = await fetch(BASE + p, body ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {});
  const d = await r.json();
  if (!d.ok) { console.log(`오류: ${d.message || d.error}`); process.exit(1); }
  return d;
}
const startFile = file.replace(/\.txt$/, ".start");
const LIMIT_S = Number(process.env.PLAY_LIMIT_S || 600);
function clock() {
  if (!fs.existsSync(startFile)) return "";
  const el = Math.round((Date.now() - Number(fs.readFileSync(startFile, "utf8"))) / 1000);
  const left = LIMIT_S - el;
  return `경과 ${Math.floor(el / 60)}분 ${el % 60}초 / 제한 ${LIMIT_S / 60}분${left <= 0 ? " — 시간 초과" : left <= 120 ? ` — 남은 시간 ${left}초, 지금 제출하십시오` : ""}`;
}
const sid = () => process.env.PLAY_SESSION || (fs.existsSync(file) ? fs.readFileSync(file, "utf8").trim() : null);

function look(st, events) {
  const L = [];
  L.push(`[${st.title}] 현재: ${st.place === "interrogation" ? "심문실" : st.locationId} | 증거 ${st.stats.evidenceFound}/${st.stats.evidenceTotal} | 깬 진술 ${st.stats.statementsBroken}`);
  L.push(`열린 장소: ${st.locations.map((l) => `${l.id}(${l.name})`).join(", ")}`);
  const here = st.spots.filter((s) => s.locationId === st.locationId);
  L.push(`이 장소 조사 지점: ${here.map((s) => `${s.id}(${s.label})${s.done ? "✓" : ""}`).join(", ") || "없음"}`);
  for (const t of (st.locations.find((l) => l.id === st.locationId) || {}).hints || []) L.push(`안내: ${t}`);
  L.push(`인물: ${st.people.map((p) => `${p.pid} ${p.name}[${({ cooperative: "협조", refusing: "면담 거절", summoned: "출석", admitted: "부분 인정", confessed: "자백" })[p.stance] || p.stance}, 위치:${p.locationId}${p.present ? ",여기" : ""}]`).join(" / ")}`);
  L.push(`증거: ${st.evidence.map((e) => `${e.id} ${e.title}${e.opened ? "" : "(미열람)"}`).join(" / ")}`);
  L.push("진술:");
  for (const s of st.statements) L.push(`  ${s.id} ${s.speakerName}: ${s.text}${s.status === "broken" ? " [깨짐]" : ""}`);
  L.push(`결론 선택지(${st.culpritQuestion}): ${st.suspects.map((x) => `${x.pid} ${x.name}`).join(", ")}`);
  if (events && events.length) L.push(`사건: ${events.map((e) => (e.kind === "knowledge" ? (e.deduction ? "추리 성립" : "새 단서") : e.kind === "admission" ? "부분 인정(자백은 아직)" : e.kind === "confession" ? "자백" : e.kind) + (e.title ? ":" + e.title : e.name ? ":" + e.name : e.verdict ? ":" + e.verdict + " " + (e.reason || "") : e.success !== undefined ? ":" + (e.success ? "성공 " + (e.note || "") : "실패") : "")).join(" | ")}`);
  if (!st.submitted && st.form && st.form.confessionPoints) L.push(`채점 안내: 범인의 자백을 받은 뒤 제출하면 ${st.form.confessionPoints}점이 더해진다. 수법·동기·추리는 이 판에서 직접 확인한 내용(열람한 증거, 인물에게 들은 말, 경감에게 말해 성립한 추리)만 점수가 된다.`);
  if (!st.submitted && st.form && (st.form.evidenceMax || st.form.exclusionMax)) {
    L.push(`결론 양식: 범인을 가리키는 근거 증거는 ${st.form.evidenceMax || "제한 없이"}개까지.${st.form.exclusionMax ? ` 고른 범인을 뺀 나머지 후보마다, 그 사람이 범인일 수 없음을 보여 주는 증거를 ${st.form.exclusionMax}개까지 댄다(ex:<pid>=<EV,EV>): 범인의 특징을 보여 주는 증거와 그 사람이 거기에 맞지 않음을 보여 주는 증거를 함께 고른다.` : ""}`);
  }
  if (st.submitted) L.push(`제출 완료: ${st.submitted.score}/${st.submitted.max} — ${st.submitted.breakdown.map((b) => `${b.label} ${b.got}/${b.max}`).join(", ")}`);
  const c = clock();
  if (c) L.push(c);
  return L.join("\n");
}

(async () => {
  const [cmd, ...a] = process.argv.slice(2);
  if (cmd === "new") {
    const d = await call("/api/session", { caseId: a[0] });
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, d.sessionId);
    fs.writeFileSync(startFile, String(Date.now()));
    console.log(`세션 ${d.sessionId}\n개요: ${d.state.brief}\n` + look(d.state));
    return;
  }
  const id = sid();
  if (!id) { console.log("먼저 new <caseId>"); process.exit(1); }
  if (cmd === "time") { console.log(clock() || "먼저 new <caseId>"); return; }
  if (cmd === "look") { console.log(look((await call(`/api/state?sessionId=${id}`)).state)); return; }
  if (cmd === "evidence") {
    const st = (await call(`/api/state?sessionId=${id}`)).state;
    for (const e of st.evidence.filter((x) => x.opened)) console.log(`${e.id} ${e.title} [${e.where}]: ${e.text}`);
    return;
  }
  const map = {
    talk: () => ({ type: "talk", pid: a[0], text: a[1], attachments: a.slice(2) }),
    inspect: () => ({ type: "inspect", spotId: a[0] }),
    open: () => ({ type: "open", evidenceId: a[0] }),
    travel: () => ({ type: "travel", locationId: a[0] }),
    object: () => ({ type: "object", statementId: a[0], evidenceId: a[1] }),
    summon: () => ({ type: "summon", pid: a[0], evidenceIds: a.slice(1) }),
    submit: () => {
      const rest = a.slice(4);
      const exclusions = {};
      for (const t of rest.filter((x) => x.startsWith("ex:"))) { const [pid, ids] = t.slice(3).split("="); exclusions[pid] = (ids || "").split(",").filter(Boolean); }
      return { type: "submit", culprit: a[0], method: a[1], motive: a[2], reasoning: a[3], evidenceIds: rest.filter((x) => !x.startsWith("ex:")), exclusions };
    },
  };
  if (!map[cmd]) { console.log("알 수 없는 명령"); process.exit(1); }
  const body = map[cmd]();
  const d = await call("/api/action", { sessionId: id, ...body });
  const st = d.state;
  if (cmd === "talk") {
    const msgs = st.chats[a[0]] || [];
    const last = [...msgs].reverse().find((m) => m.from !== "player");
    console.log(`${(st.people.find((p) => p.pid === a[0]) || {}).name}: ${last ? last.text : "(응답 없음)"}`);
  }
  if (cmd === "open") { const e = st.evidence.find((x) => x.id === a[0]); if (e) console.log(`${e.id} ${e.title}: ${e.text}`); }
  console.log(look(st, d.events));
})().catch((e) => { console.log("연결 오류: " + e.message); process.exit(1); });
