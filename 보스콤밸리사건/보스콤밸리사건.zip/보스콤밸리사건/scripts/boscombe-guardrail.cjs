// 보스콤 키트의 guardrail_tests(인물별 레드팀 질문)를 실제 모델로 한 번씩 돌린다.
// 사용: node scripts/boscombe-guardrail.cjs [출력.md]   (ABBEY_PROVIDER 등 환경변수는 서버와 같다)
const fs = require("node:fs");
const path = require("node:path");
const E = require("../engine.cjs");
const D = require("../dialogue.cjs");
const { config, generate } = require("../provider.cjs");
const kit = require("../data/boscombe_personas.json");

const cfg = config();
const base = D.makeDeps(cfg, generate);
const PID = { james_mccarthy: "P1", john_turner: "P2", alice_turner: "P3", patience_moran: "P4", william_crowder: "P5", inspector_lestrade: "P6" };
const TIER_NODE = { P1: ["J_T1", "J_T2"], P2: ["T_T1", "T_T2", "T_T3"] };

async function runOne(c, t) {
  const pid = PID[c.id];
  const pack = E.PACKS.boscombe.pack;
  const s = E.createSession("boscombe");
  s.flags.push("loc:prison", "met:P2", "summoned:P2");
  const m = t.input.match(/^\[T(\d) 상태\]\s*(.*)$/);
  const tier = m ? Number(m[1]) : 0;
  const text = m ? m[2] : t.input;
  for (const id of (TIER_NODE[pid] || []).slice(0, tier)) {
    const n = pack.nodes.find((x) => x.id === id);
    s.flags.push(`k:${id}`, ...n.grants);
  }
  if (pid === "P2") { s.place = "interrogation"; s.locationId = "interrogation"; } else { s.locationId = pack.people.find((p) => p.pid === pid).location; }
  const log = {};
  const deps = {
    evaluate: async (ctx) => (log.eval = await base.evaluate(ctx)),
    speak: async (ctx) => (log.speak = await base.speak(ctx)),
  };
  const { events } = await E.applyAction(s, { type: "talk", pid, text, attachments: [] }, deps);
  const last = s.chats[pid][s.chats[pid].length - 1];
  const raw = log.speak && log.speak.ok ? log.speak.text : null;
  return {
    name: c.name, tier, text, expected: t.expected, reply: last.text, source: last.source,
    replaced: raw && last.source === "rule" ? raw : null, // 모델 답이 누설 검사에 걸려 정본 대사로 바뀐 경우의 원문
    matched: log.eval && log.eval.ok ? log.eval.matched : null, intent: log.eval && log.eval.ok ? log.eval.intent : null,
    opened: events.filter((e) => e.kind === "knowledge").map((e) => e.nodeId),
    ms: (log.eval ? log.eval.latency_ms || 0 : 0) + (log.speak ? log.speak.latency_ms || 0 : 0),
  };
}

(async () => {
  const jobs = [];
  for (const c of kit.characters) for (const t of c.guardrail_tests) jobs.push(runOne(c, t));
  const rows = await Promise.all(jobs);
  const cell = (x) => String(x == null ? "" : x).replace(/\|/g, "/").replace(/\n/g, " ");
  const out = [
    `# 보스콤 가드레일 시험 실측 (${new Date().toLocaleDateString("sv-SE")})`,
    "",
    `평가 모델 ${cfg.evaluator.model} / 인물 모델 ${cfg.persona.model} (${cfg.persona.provider}, effort ${cfg.persona.effort}). 키트 \`guardrail_tests\` ${rows.length}문항을 한 번씩, 재생성 없이 돌렸다.`,
    "",
    "| 인물 | 단계 | 질문 | 기대(키트) | 실제 응답 | 출처 | 열린 노드 | 지연(ms) |",
    "|---|---|---|---|---|---|---|---|",
    ...rows.map((r) => `| ${r.name} | T${r.tier} | ${cell(r.text)} | ${cell(r.expected)} | ${cell(r.reply)}${r.replaced ? ` <br>(누설 검사로 교체됨. 모델 원문: ${cell(r.replaced)})` : ""} | ${r.source} | ${r.opened.join(", ") || "-"} | ${r.ms} |`),
    "",
  ].join("\n");
  const file = process.argv[2] || path.join(__dirname, "..", "docs", "boscombe_guardrail_실측.md");
  fs.writeFileSync(file, out);
  console.log(out);
})();
