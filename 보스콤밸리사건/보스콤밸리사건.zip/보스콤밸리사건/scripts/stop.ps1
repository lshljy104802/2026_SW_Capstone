﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$pidPath = Join-Path $projectRoot 'runtime/launcher.pid'
if (-not (Test-Path -LiteralPath $pidPath)) { Write-Host '실행 중인 게임 서버가 없습니다.'; exit 0 }
$serverPid = [int](Get-Content -LiteralPath $pidPath -Raw).Trim()
$serverPath = Join-Path $projectRoot 'server.cjs'
$serverProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$serverPid" -ErrorAction SilentlyContinue
if ($serverProcess) {
    if ($serverProcess.Name -ne 'node.exe' -or -not $serverProcess.CommandLine.Contains($serverPath)) { throw '이 번호의 프로세스는 다른 프로그램이라 그대로 두었습니다.' }
    Stop-Process -Id $serverPid -ErrorAction Stop
    Write-Host '게임 서버를 껐습니다.'
} else { Write-Host '서버가 이미 꺼져 있습니다.' }
Remove-Item -LiteralPath $pidPath -Force
