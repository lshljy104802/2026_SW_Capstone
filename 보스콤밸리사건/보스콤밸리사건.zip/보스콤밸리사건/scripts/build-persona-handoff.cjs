// ① Persona 파트용 인수 안내 문서(md) 생성. 인물·지식 노드 표는 사건 팩에서 뽑는다.
// 사용: node scripts/build-persona-handoff.cjs <출력.md>
const fs = require("node:fs");
const path = require("node:path");
const E = require("../engine.cjs");

const out = process.argv[2];
if (!out) { console.error("출력 경로가 필요합니다"); process.exit(2); }
const cell = (t) => String(t ?? "").replace(/\|/g, "／").replace(/\s*\n\s*/g, " ");
// 조건 플래그를 사람이 읽는 말로(증거 제목·인물 이름·장소 이름으로 풀어 쓴다)
function flagKo(pack, f) {
  const ev = (id) => `「${(pack.evidence.find((e) => e.id === id) || {}).title || id}」`;
  const who = (id) => (pack.people.find((x) => x.pid === id) || pack.suspects.find((x) => x.pid === id) || {}).name || id;
  const stmt = (id) => { const s = pack.statements.find((x) => x.id === id); return s ? `${s.speakerName}의 진술 "${s.text.slice(0, 18)}…"` : id; };
  if (f.startsWith("@")) {
    const c = (pack.conditions || {})[f];
    if (!c) return f;
    if (c.type === "proof") return `심문실에서 ${who(c.pid)}에게 증거를 종류별로 제시(${c.groups.map((g) => g.label).join("·")})`;
    return `${c.statements.map((x) => (pack.statements.find((s) => s.id === x) || {}).speakerName).filter((v, i, a) => a.indexOf(v) === i).join("·")} 진술에서 모순 ${c.min}개 이상 찾음`;
  }
  const [k, id] = [f.slice(0, f.indexOf(":")), f.slice(f.indexOf(":") + 1)];
  const node = () => { const n = pack.nodes.find((x) => x.id === id); return n ? `${who(n.pid)}에게서 "${n.topic.split(",")[0]}" 이야기를 들음` : id; };
  const loc = () => (pack.locations.find((l) => l.id === id) || {}).name || id;
  return ({ ev: () => `${ev(id)} 열람`, k: node, heard: () => `${stmt(id)} 확보`, broken: () => `${stmt(id)} 반박`, crack: () => "모순 발견", met: () => `${who(id)} 면담 거절 확인`, loc: () => `${loc()} 열림`, summoned: () => `${who(id)} 소환`, admitted: () => `${who(id)} 부분 인정`, confessed: () => `${who(id)} 자백` })[k]?.() || f;
}

const L = [];
const p = (...x) => L.push(...x, "");

p("# ① Persona 파트 인수 안내 — 11/05 피드백 반영분",
  "③(게임 구현·통합)에서 ①께 드리는 안내예요. 결론부터: **새로 처음부터 쓰실 건 없어요.** 피드백 때문에 페르소나 쪽에 새로 생긴 일은 ③이 초안을 먼저 만들어 두었고, ①께는 그 초안을 **검토·수정해 주시는 것**만 부탁드려요. 형식도 JSON이 아니라 표로 편하게 주시면 ③이 변환해서 붙일게요.");

p("## 1. 지금 v2에서 그대로 쓰고 있는 것",
  "보내 주신 `abbey_grange_personas_v2.json`이 게임의 뼈대예요. 아래 항목은 손대지 않고 그대로 가져다 쓰고 있어요.",
  "| v2 항목 | 게임에서 쓰는 곳 |\n|---|---|\n" +
  "| `public_profile.voice`, `look` | 인물 모델(Haiku 5.5)에 매번 그대로 들어가는 말투·외양 |\n" +
  "| `cracks` | 진술에 증거로 \"이의 있음\"을 걸었을 때 그 인물이 보이는 반응 대사 |\n" +
  "| `facts`의 `leak_keywords`, `leak_check.banned_patterns` | 인물 모델 답에 아직 밝히면 안 되는 단어가 나오면 정본 대사로 바꾸는 누설 검사 |\n" +
  "| `unknown_responses`, `meta_question_deflection` | 모르는 질문·설정 밖 질문에 대한 대답 |\n" +
  "| `statements`(sL1~sC2), `knows`/`stance` 구분 | 진술 카드와, 인물별로 무엇을 숨기고 무엇을 말하는지의 기준 |",
  "실제 Haiku로 대화해 봤을 때 부인은 끝까지 크로커 이름을 말하지 않았고, 테레사는 \"부인 진술에 맞췄다\"까지만 인정했어요. v2 가드레일이 잘 작동하고 있어요.");

p("### 1-1. ① 문서의 공개 등급이 게임에서 가는 곳",
  "「페르소나 데이터와 지식 경계 가드레일, 검수 방안」의 구조(open·lie·gated·sealed, knows·must_not_know)를 게임에서는 아래처럼 받고 있어요. 필드 이름만 다르고 원칙(\"모르는 건 프롬프트에 아예 안 넣는다\")은 같아요.",
  "| ① 문서 | 게임(사건 팩) | 프롬프트에 들어가나 |\n|---|---|---|\n" +
  "| open (처음부터 말하는 사실) | 조건 없는 지식 노드 + `public_profile` | 질문 주제가 맞으면 포함 |\n" +
  "| lie (지키는 거짓 진술) | `statements` → 진술 카드 | 포함(이의 제기로 깨짐) |\n" +
  "| gated (발견 뒤에만) | 조건(증거·진술 반박·소환) 붙은 지식 노드, `cracks` | 조건 충족 뒤에만 포함 |\n" +
  "| sealed (정답급) | 아무 노드에도 없음 + 누설 단어 목록(`leak_keywords`) | 절대 안 들어감, 답에 나오면 정본 대사로 교체 |\n" +
  "| `must_not_know` | 그 인물 노드에 아예 없음(목록으로 따로 두지 않음) | 안 들어감 → \"모른다\" 대사 |\n" +
  "| `max_admission` | 부분 인정 노드의 \"말하는 내용\" | 인정 조건 충족 뒤 |\n" +
  "| `hint_levels`(홉킨스) | 이번 피드백(\"가이드 없이\")에 따라 쓰지 않음 | — |",
  "애비 그레인지는 보내 주신 v2의 `knows`·`must_not_know`를 기준으로 노드를 만들었어요. 새 사건 2편은 ③ 초안이라 인물별 `must_not_know` 목록이 따로 없어요. ① 형식(knows·must_not_know)으로 다시 정리해 주시면 그쪽을 정본으로 바꿔 끼울게요.");

p("## 2. 피드백으로 페르소나 쪽에 새로 생긴 것 (③이 초안 작성 완료)",
  "교수님 피드백 중 페르소나에 걸리는 건 세 줄이에요.",
  "- \"페르소나에 공개지식은 기본으로 주고 대화하면서 열리는 지식이 달라지도록\"",
  "- \"질문에 맞는 대답을 했는지 평가하고 다음 지식이 열리도록\"",
  "- \"자백까지 유도할 수 있게\"",
  "그래서 v2에 **\"열리는 지식\"(지식 노드)** 이라는 층이 하나 더 필요해졌어요. 지식 하나 = \"이 인물이, 이런 질문을 받고, 이 조건이 갖춰졌으면, 이 내용을 말한다\"예요. ③이 v2의 `knows`·`cracks`·`max_admission`을 바탕으로 애비 그레인지 인물 5명의 지식 노드 22개를 먼저 써 두었어요(부록 A).",
  "**부탁드리는 것:** 부록 A 표의 \"말하는 내용\"이 그 인물답고 v2 설정과 맞는지만 봐 주세요. 표의 \"검토\" 칸에 ○(그대로)/수정(고친 문장)/✕(빼기) 중 하나만 적어 주시면 돼요.");

p("## 3. 정해 주셔야 할 것 두 가지",
  "v2와 피드백이 부딪히는 곳이라 ③이 임의로 정하지 않고 임시로만 맞춰 두었어요.",
  "| 항목 | v2 규칙 | 피드백 | ③이 임시로 해 둔 것 |\n|---|---|---|---|\n" +
  "| 자백 | K7·`max_admission`: 크로커 자백은 결과 화면 전용 | \"자백까지 유도할 수 있게\" | 크로커는 관계·선원 기술·키·위장 증거 4종을 모두 들이대고 추궁해야 자백. 부인·테레사는 v2 `max_admission` 그대로(부분 인정까지만) |\n" +
  "| 크로커 등장 시점 | `availability`: d_link 발견 전엔 명단에 없음 | 판사 소환 장치 | 해운사 기록(EV19)을 열면 명단에 등장 → 시드넘에서 면담 거절 → 판사 소환 |",
  "둘 다 지금대로 괜찮으면 \"그대로\" 한마디면 돼요.");

p("## 4. 표로 주시면 ③이 붙여요 (양식)",
  "고치거나 새 지식을 넣고 싶으실 때 아래 표 형식이면 엑셀·구글 시트·한글 표 어느 것이든 괜찮아요. ID·플래그 같은 건 ③이 채워요.",
  "| 인물 | 언제 열리나(조건, 말로) | 어떤 질문에 | 말하는 내용(그 인물 말투로 1~3문장) | 메모 |\n|---|---|---|---|---|\n" +
  "| 테레사 | 정문의 세 남자 진술이 깨진 뒤, 심문실에서 추궁하면 | 거짓말이냐, 부인과 입 맞췄냐 | …마님 말씀에 맞춰 드린 건 맞아요. 하지만 누가 있었는지는 말하지 않겠습니다. | 이름은 끝까지 안 말함 |",
  "조건을 정확히 몰라도 \"이 증거를 본 뒤\", \"이 사람이 자백한 뒤\" 정도로 적어 주시면 ③이 맞춰 넣을게요.");

p("## 5. 새 사건 2편 (다인물 확장)",
  "인물이 5명뿐이라 중반이 얇다는 문제가 있어서, 같은 방식으로 인물이 더 많은 홈즈 단편 2편을 ③이 초안으로 만들었어요(부록 B). 원작 범위 안에서 만들었고, 이름 없는 인물에게 말투를 붙인 정도만 게임용 추가예요. **세 사건 모두 지금 들어 있는 인물·증거 데이터는 게임이 돌아가는지 보려고 ③이 임시로 채운 것**이고, ① 페르소나·② 증거 파트가 만든 데이터가 오면 그걸 정본으로 바꿔 끼워요.",
  "①께서 여력이 되시면 부록 B 인물들의 **말투·성격(voice) 한 줄씩만** 봐 주셔도 큰 도움이 돼요. 안 보셔도 게임은 돌아가요.");

p("## 6. 모델 비교(① 과제)는 ③ 서버로 돌릴 수 있어요",
  "교수님 지시 ①의 \"모델 비교\"는 서버 설정 한 줄(`ABBEY_PERSONA_MODEL`)로 인물 모델을 바꿔 같은 질문을 돌릴 수 있게 해 두었어요. 비교하고 싶은 질문 목록(인물별 5~10개)만 주시면 ③이 Haiku 5.5 / Sonnet 5.5 등으로 돌려서 응답·지연 시간·누설 여부 표를 드릴게요. 결과 해석과 보고는 ① 몫으로 남겨 둘게요.");

p("## 7. 일정 제안",
  "| 날짜 | 내용 |\n|---|---|\n| 11/10(화) | 부록 A 검토 칸 채워서 회신(○/수정/✕), 3번 두 가지 결정 |\n| 11/11(수) | ③이 반영 → 플레이 링크 공유 |\n| 11/12(목) | 미팅 |",
  "어려우시면 3번 두 가지만 먼저 알려 주셔도 돼요. 나머지는 ③ 초안대로 가고 미팅 뒤에 고쳐도 괜찮아요.");

// 부록 A: 애비 그레인지 지식 노드
const packs = E.PACKS;
const abbey = packs.abbey && packs.abbey.pack;
if (abbey) {
  p("## 부록 A. 애비 그레인지 — 인물별 열리는 지식(③ 초안)", "\"검토\" 칸에 ○ / 수정(고친 문장) / ✕ 를 적어 주세요.");
  for (const person of abbey.people) {
    const nodes = abbey.nodes.filter((n) => n.pid === person.pid);
    if (!nodes.length) continue;
    const where = person.stance === "refusing" ? "현장에선 면담 거절 → 판사 소환 뒤 심문실" : "현장에서 바로 대화";
    p(`### ${person.name} (${where})`,
      "| 언제 열리나 | 어떤 질문에 | 말하는 내용 | 검토 |\n|---|---|---|---|\n" +
      nodes.map((n) => `| ${cell(n.requires.length ? n.requires.map((f) => flagKo(abbey, f)).join(", ") : "처음부터")}${n.accuse ? " + 추궁할 때만" : ""} | ${cell(n.topic)} | ${cell(n.text)} |  |`).join("\n"));
  }
}

// 부록 B: 새 사건 인물 표
const extra = Object.values(packs).map((x) => x.pack).filter((k) => k.id !== "abbey");
if (extra.length) {
  p("## 부록 B. 새 사건 인물 (③ 초안, 말투만 봐 주셔도 충분)");
  for (const k of extra) {
    p(`### ${k.title}`, `${k.source || ""} · 인물 ${k.people.length}명 · 용의자 ${k.suspects.length}명 · 증거 ${k.evidence.length}건 · 지식 노드 ${k.nodes.length}개`,
      "| 인물 | 역할 | 처음 태도 | 말투(voice) | 검토 |\n|---|---|---|---|---|\n" +
      k.people.map((x) => `| ${cell(x.name)} | ${cell(x.role)} | ${x.stance === "refusing" ? "거절(소환 필요)" : "협조"} | ${cell(x.profile.voice)} |  |`).join("\n"));
  }
}

p("---", "질문은 언제든 편하게 주세요. — ③");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, L.join("\n"), "utf8");
console.log("작성:", out, `(${L.length}줄)`);
