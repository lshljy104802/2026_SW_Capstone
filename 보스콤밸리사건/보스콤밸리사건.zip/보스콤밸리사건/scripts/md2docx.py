# 간단한 md → docx 변환(제목 #, 문단, 글머리 -, 표 |, **굵게**, `코드`만 지원).
# 사용: python -I -X utf8 scripts/md2docx.py 입력.md 출력.docx
import re
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

FONT = "맑은 고딕"


def set_font(run, size=None, bold=None, mono=False):
    run.font.name = "Consolas" if mono else FONT
    run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    if size:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold


def add_inline(par, text, size=10.5):
    for part in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("**"):
            set_font(par.add_run(part[2:-2]), size, True)
        elif part.startswith("`"):
            r = par.add_run(part[1:-1])
            set_font(r, size - 1, mono=True)
            r.font.color.rgb = RGBColor(0x8A, 0x3B, 0x12)
        else:
            set_font(par.add_run(part), size)


def main(src, dst):
    lines = open(src, encoding="utf-8").read().split("\n")
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = FONT
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    st.font.size = Pt(10.5)
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[-| ]+\|$", lines[i + 1]):
            rows = [ln]
            i += 2
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(lines[i])
                i += 1
            cells = [[c.strip() for c in r.strip("|").split("|")] for r in rows]
            n = len(cells[0])
            t = doc.add_table(rows=len(cells), cols=n)
            t.style = "Table Grid"
            t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(cells):
                for ci in range(n):
                    par = t.cell(ri, ci).paragraphs[0]
                    txt = row[ci] if ci < len(row) else ""
                    if ri == 0:
                        set_font(par.add_run(txt.replace("**", "")), 9.5, True)
                    else:
                        add_inline(par, txt, 9.5)
            doc.add_paragraph()
            continue
        if ln.startswith("#"):
            level = len(ln) - len(ln.lstrip("#"))
            h = doc.add_heading(level=min(level, 3))
            set_font(h.add_run(ln.lstrip("#").strip()), {1: 18, 2: 14, 3: 12}.get(level, 12), True)
        elif ln.startswith("- "):
            add_inline(doc.add_paragraph(style="List Bullet"), ln[2:])
        elif ln.strip() == "---":
            doc.add_paragraph()
        elif ln.strip():
            add_inline(doc.add_paragraph(), ln)
        i += 1
    doc.save(dst)
    print("작성:", dst)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
