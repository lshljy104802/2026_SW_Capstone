// API 연동 시험: 키가 실제 외부 API(api.anthropic.com / api.openai.com)로 통하는지 최소 호출로 확인한다.
// 사용: node scripts/api-check.cjs [.env 경로]  (생략하면 이 폴더의 .env)   (키 값은 출력하지 않는다)
const fs = require("node:fs");
const envPath = process.argv[2] || require("node:path").join(__dirname, "..", ".env");
if (envPath && fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z_]+)\s*=\s*(.+?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
  }
}

async function anthropic() {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return "ANTHROPIC: 키 없음";
  const t = Date.now();
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 30, messages: [{ role: "user", content: "한 단어로만 답해: 연결 확인" }] }),
  });
  const d = await r.json();
  if (!r.ok) return `ANTHROPIC: 실패 ${r.status} ${d.error && d.error.type} ${d.error && d.error.message}`;
  return `ANTHROPIC: 성공 model=${d.model} 입력${d.usage.input_tokens}/출력${d.usage.output_tokens}토큰 ${Date.now() - t}ms 답="${(d.content[0] || {}).text}"`;
}

async function openai() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return "OPENAI: 키 없음";
  const h = { authorization: `Bearer ${key}`, "content-type": "application/json" };
  const lm = await fetch("https://api.openai.com/v1/models", { headers: h });
  const ld = await lm.json();
  if (!lm.ok) return `OPENAI: 실패 ${lm.status} ${ld.error && ld.error.message}`;
  const ids = ld.data.map((m) => m.id);
  const model = process.env.OPENAI_TEST_MODEL || ids.filter((i) => /^gpt-[\d.]+-mini$/.test(i)).sort().pop() || ids.find((i) => /mini/.test(i));
  const t = Date.now();
  const r = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: h,
    body: JSON.stringify({ model, input: "한 단어로만 답해: 연결 확인", max_output_tokens: 30 }),
  });
  const d = await r.json();
  if (!r.ok) return `OPENAI: 모델 목록은 됨(${ids.length}개), 호출 실패 ${r.status} ${d.error && d.error.message}`;
  return `OPENAI: 성공 model=${d.model} 입력${d.usage && d.usage.input_tokens}/출력${d.usage && d.usage.output_tokens}토큰 ${Date.now() - t}ms 답="${d.output_text || ""}"`;
}

(async () => {
  for (const f of [anthropic, openai]) {
    try { console.log(await f()); } catch (e) { console.log(`${f.name}: 오류 ${e.message}`); }
  }
})();
