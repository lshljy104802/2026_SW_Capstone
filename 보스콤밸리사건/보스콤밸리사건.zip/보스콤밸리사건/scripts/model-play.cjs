// 모델 플레이 실험 실행기: 판마다 새 claude 프로세스(헤드리스)를 띄워 play.cjs로만 한 판을 풀게 한다. 순차 실행(FIFO).
// 사용: node scripts/model-play.cjs <출력 폴더> <이름>=<모델ID>[:effort] ...
//   예: node scripts/model-play.cjs .runtime/playtest_20261111 sonnet55_1=claude-sonnet-5-5 sonnet55_2=claude-sonnet-5-5
// 환경변수: PLAY_BASE(게임 서버, 기본 http://127.0.0.1:3230) · PLAY_CASE(기본 boscombe) · PLAY_LIMIT_S(기본 600)
// 플레이어 조건: 도구는 Bash 하나, 허용 명령은 `node play.cjs …`뿐(파일 열람·웹 검색 불가), 사용자·프로젝트 설정과 MCP는 싣지 않는다.
// 판마다 남기는 것: <이름>.stream.jsonl(전체 대화·명령 기록), <이름>.json(점수·시간·토큰), progress.log(한 줄 요약).
const fs = require("node:fs");
const path = require("node:path");
const { spawn, execFileSync } = require("node:child_process");

const ROOT = path.join(__dirname, "..");
const [outArg, ...runArgs] = process.argv.slice(2);
if (!outArg || !runArgs.length) { console.error("사용: node scripts/model-play.cjs <출력 폴더> <이름>=<모델ID>[:effort] ..."); process.exit(2); }
const OUT = path.resolve(ROOT, outArg);
const BASE = process.env.PLAY_BASE || "http://127.0.0.1:3230";
const CASE = process.env.PLAY_CASE || "boscombe";
const LIMIT_S = Number(process.env.PLAY_LIMIT_S || 600);
const PROMPT = fs.readFileSync(path.join(__dirname, "model-play-prompt.md"), "utf8").replace(/\{CASE\}/g, CASE).replace(/\{LIMIT_MIN\}/g, String(LIMIT_S / 60));
fs.mkdirSync(OUT, { recursive: true });
const log = (line) => { fs.appendFileSync(path.join(OUT, "progress.log"), line + "\n"); console.log(line); };

function runOne(tag, model, effort) {
  return new Promise((resolve) => {
    const cwd = path.join(OUT, `cwd_${tag}`);
    fs.mkdirSync(cwd, { recursive: true });
    // 플레이어의 작업 폴더에는 실제 CLI를 부르는 한 줄짜리 파일만 둔다(사건 팩·문서가 보이지 않게).
    fs.writeFileSync(path.join(cwd, "play.cjs"), `require(${JSON.stringify(path.join(ROOT, "scripts", "play.cjs"))});\n`);
    for (const f of [`play_${tag}.txt`, `play_${tag}.start`]) fs.rmSync(path.join(ROOT, ".runtime", f), { force: true });
    const streamFile = path.join(OUT, `${tag}.stream.jsonl`);
    const out = fs.createWriteStream(streamFile);
    const args = ["-p", "--model", model, "--effort", effort, "--tools", "Bash", "--allowedTools", "Bash(node play.cjs:*)",
      "--setting-sources", "", "--strict-mcp-config", "--no-session-persistence", "--output-format", "stream-json", "--verbose"];
    const started = Date.now();
    const child = spawn(process.env.ABBEY_CLAUDE_BIN || "claude", args, { cwd, windowsHide: true, shell: false, env: { ...process.env, PLAY_NAME: tag, PLAY_BASE: BASE, PLAY_LIMIT_S: String(LIMIT_S) } });
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      try { execFileSync("taskkill", ["/T", "/F", "/PID", String(child.pid)], { stdio: "ignore" }); } catch { child.kill(); }
    }, LIMIT_S * 1000);
    child.stdout.pipe(out);
    child.stderr.on("data", () => {});
    child.on("error", (e) => { clearTimeout(timer); resolve({ tag, model, effort, error: "spawn_failed: " + e.message }); });
    child.on("close", async () => {
      clearTimeout(timer);
      const ended = Date.now();
      out.end();
      await new Promise((r) => setTimeout(r, 300));
      const r = { tag, model, effort, caseId: CASE, startedAt: new Date(started).toISOString(), wallSeconds: Math.round((ended - started) / 1000), timedOut };
      // 플레이어 쪽 기록
      let commands = 0;
      for (const line of fs.readFileSync(streamFile, "utf8").split("\n")) {
        if (!line.trim()) continue;
        let m; try { m = JSON.parse(line); } catch { continue; }
        if (m.type === "assistant") for (const b of (m.message && m.message.content) || []) if (b.type === "tool_use") commands += 1;
        if (m.type === "result") {
          r.report = m.result || "";
          r.costUsd = m.total_cost_usd;
          r.turns = m.num_turns;
          r.usage = m.usage || null;
          r.modelUsage = m.modelUsage || null;
          r.denials = (m.permission_denials || []).length;
          r.cliError = !!m.is_error;
        }
      }
      r.commands = commands;
      // 게임 쪽 기록
      try {
        const sidFile = path.join(ROOT, ".runtime", `play_${tag}.txt`);
        const sid = fs.readFileSync(sidFile, "utf8").trim();
        r.sessionId = sid;
        const t0 = Number(fs.readFileSync(sidFile.replace(/\.txt$/, ".start"), "utf8"));
        const st = (await (await fetch(`${BASE}/api/state?sessionId=${sid}`)).json()).state;
        r.evidence = `${st.evidence.filter((e) => e.opened).length}/${st.stats.evidenceTotal}`;
        r.statementsBroken = st.stats.statementsBroken;
        r.talks = Object.values(st.chats).flat().filter((m) => m.from === "player").length;
        r.modelReplies = Object.values(st.chats).flat().filter((m) => m.from === "npc" && m.source === "model").length;
        r.ruleReplies = Object.values(st.chats).flat().filter((m) => m.from === "npc" && m.source === "rule").length;
        r.knowledge = st.knowledge.map((k) => k.nodeId);
        r.judge = st.judge.map((j) => `${j.pid}:${j.verdict}`);
        r.stances = Object.fromEntries(st.people.map((p) => [p.name, p.stance]));
        if (st.submitted) {
          r.submitted = true;
          r.score = st.submitted.score;
          r.breakdown = st.submitted.breakdown;
          r.playSeconds = Math.round((st.submitted.submittedAt - t0) / 1000);
        } else r.submitted = false;
        const sf = path.join(ROOT, ".runtime", "sessions", `${sid}.json`);
        if (fs.existsSync(sf)) {
          const raw = JSON.parse(fs.readFileSync(sf, "utf8"));
          r.confessed = raw.flags.filter((f) => f.startsWith("confessed:"));
          if (raw.submitted) r.input = raw.submitted.input;
        }
      } catch (e) {
        r.gameError = e.message;
      }
      fs.writeFileSync(path.join(OUT, `${tag}.json`), JSON.stringify(r, null, 1));
      resolve(r);
    });
    child.stdin.end(PROMPT);
  });
}

(async () => {
  for (const a of runArgs) {
    const [tag, spec] = a.split("=");
    const [model, effort = "medium"] = spec.split(":");
    log(`START ${tag} ${model} ${effort} ${new Date().toLocaleTimeString("sv-SE")}`);
    const r = await runOne(tag, model, effort);
    const who = r.input ? r.input.culprit : "-";
    log(`DONE ${tag} | ${r.error || (r.submitted ? `제출 ${r.score}점 범인 ${who} ${r.playSeconds}초` : r.timedOut ? "시간 초과·미제출" : "미제출 종료")} | 벽시계 ${r.wallSeconds}초 명령 ${r.commands} 대화 ${r.talks} 증거 ${r.evidence} 자백 ${(r.confessed || []).join(",") || "없음"} 거부 ${r.denials} 비용 $${r.costUsd != null ? r.costUsd.toFixed(3) : "?"}`);
  }
  log("ALL_DONE");
})();
