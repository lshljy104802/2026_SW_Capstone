// HTTP 서버 (node:http, 외부 패키지 없음, 127.0.0.1 전용)
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

function loadEnv(file) {
  try {
    for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (!m || line.trim().startsWith("#")) continue;
      let v = m[2];
      if (/^(".*"|'.*')$/.test(v)) v = v.slice(1, -1);
      if (process.env[m[1]] === undefined) process.env[m[1]] = v;
    }
  } catch {}
}
loadEnv(path.join(__dirname, ".env"));

const engine = require("./engine.cjs");
const { config, generate } = require("./provider.cjs");
const dialogue = require("./dialogue.cjs");

const cfg = config();
const deps = dialogue.makeDeps(cfg, generate);
const PUBLIC_DIR = path.join(__dirname, "public");
// 그림: 배포판은 이 폴더의 art/에, 개발 저장소는 31번 공유본에 있다
const ART_DIR = [path.join(__dirname, "art"), path.resolve(__dirname, "..", "31_WD-ABBEY_자유심문_공유본_20261105", "public", "assets", "art")].find((d) => fs.existsSync(d)) || path.join(__dirname, "art");
const SESS_DIR = path.join(__dirname, ".runtime", "sessions");
fs.mkdirSync(SESS_DIR, { recursive: true });
const MAX_BODY = 64 * 1024;
const ID_RE = /^[a-f0-9]{16}$/;

const TYPES = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8", ".svg": "image/svg+xml",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".ico": "image/x-icon",
  ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8",
};

const cache = new Map();
function sessFile(id) {
  return path.join(SESS_DIR, `${id}.json`);
}
function saveSession(s) {
  try {
    const tmp = sessFile(s.id) + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(s));
    fs.renameSync(tmp, sessFile(s.id));
  } catch (e) {
    console.error("세션 저장 실패:", e.message);
  }
}
function loadSession(id) {
  if (typeof id !== "string" || !ID_RE.test(id)) return null;
  if (cache.has(id)) return cache.get(id);
  try {
    const s = JSON.parse(fs.readFileSync(sessFile(id), "utf8"));
    if (s && s.id === id) {
      s.pending = false;
      cache.set(id, s);
      return s;
    }
  } catch {}
  return null;
}

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
  res.end(body);
}
const fail = (res, status, error, message) => send(res, status, { ok: false, error, message });

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject({ status: 413, error: "body_too_large", message: "요청 본문이 너무 큽니다." });
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      const text = Buffer.concat(chunks).toString("utf8");
      if (!text.trim()) return resolve({});
      try {
        const v = JSON.parse(text);
        resolve(v && typeof v === "object" ? v : {});
      } catch {
        reject({ status: 400, error: "bad_json", message: "JSON 형식이 올바르지 않습니다." });
      }
    });
    req.on("error", () => reject({ status: 400, error: "read_failed", message: "요청을 읽지 못했습니다." }));
  });
}

function serveFile(res, file) {
  fs.readFile(file, (err, data) => {
    if (err) return fail(res, 404, "not_found", "찾을 수 없습니다.");
    res.writeHead(200, { "content-type": TYPES[path.extname(file).toLowerCase()] || "application/octet-stream", "cache-control": "no-store" });
    res.end(data);
  });
}

function serveStatic(res, pathname) {
  let rel;
  try {
    rel = decodeURIComponent(pathname);
  } catch {
    return fail(res, 400, "bad_path", "경로가 올바르지 않습니다.");
  }
  if (rel.includes("\0") || rel.includes("\\")) return fail(res, 400, "bad_path", "경로가 올바르지 않습니다.");
  if (rel === "/") rel = "/index.html";
  const file = path.resolve(PUBLIC_DIR, "." + rel);
  if (file !== PUBLIC_DIR && !file.startsWith(PUBLIC_DIR + path.sep)) return fail(res, 404, "not_found", "찾을 수 없습니다.");
  if (!TYPES[path.extname(file).toLowerCase()]) return fail(res, 404, "not_found", "찾을 수 없습니다.");
  serveFile(res, file);
}

async function handleApi(req, res, url) {
  const p = url.pathname;
  if (p === "/api/health" && req.method === "GET") {
    return send(res, 200, { ok: true, app: "wd-abbey-claude", provider: cfg.persona.provider, models: { evaluator: cfg.evaluator.model, persona: cfg.persona.model } });
  }
  if (p === "/api/cases" && req.method === "GET") {
    return send(res, 200, { ok: true, cases: engine.listCases() });
  }
  if (p === "/api/session" && req.method === "POST") {
    const body = await readBody(req);
    // caseId를 주면 그 사건으로 새 세션, sessionId만 주면 복원
    let s = body.caseId ? null : loadSession(body.sessionId);
    if (!s) {
      try {
        s = engine.createSession(body.caseId && engine.PACKS[String(body.caseId)] ? String(body.caseId) : undefined) // 적재되지 않은 사건은 기본 사건(보스콤)으로;
      } catch (e) {
        if (e instanceof engine.GameError) return fail(res, e.status, e.code, e.message);
        throw e;
      }
      cache.set(s.id, s);
      saveSession(s);
    }
    return send(res, 200, { ok: true, sessionId: s.id, state: engine.publicState(s) });
  }
  if (p === "/api/state" && req.method === "GET") {
    const s = loadSession(url.searchParams.get("sessionId"));
    if (!s) return fail(res, 404, "session_not_found", "세션을 찾을 수 없습니다.");
    return send(res, 200, { ok: true, state: engine.publicState(s) });
  }
  if (p === "/api/action" && req.method === "POST") {
    const body = await readBody(req);
    const s = loadSession(body.sessionId);
    if (!s) return fail(res, 404, "session_not_found", "세션을 찾을 수 없습니다.");
    if (body.stream === true) {
      // 한 줄 = JSON 하나. {phase:"judged"|"text", ...}가 오고 마지막 줄이 {done:true, ok, state, events} 또는 오류
      res.writeHead(200, { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-store", "x-accel-buffering": "no" });
      const line = (o) => { try { res.write(JSON.stringify(o) + "\n"); } catch {} };
      try {
        const { events } = await engine.applyAction(s, body, { ...deps, progress: line });
        saveSession(s);
        line({ done: true, ok: true, state: engine.publicState(s), events });
      } catch (e) {
        if (e instanceof engine.GameError) line({ done: true, ok: false, error: e.code, message: e.message });
        else { console.error("행동 처리 오류:", e); line({ done: true, ok: false, error: "internal", message: "서버 내부 오류가 발생했습니다." }); }
      }
      return res.end();
    }
    try {
      const { events } = await engine.applyAction(s, body, deps);
      saveSession(s);
      return send(res, 200, { ok: true, state: engine.publicState(s), events });
    } catch (e) {
      if (e instanceof engine.GameError) return fail(res, e.status, e.code, e.message);
      console.error("행동 처리 오류:", e);
      return fail(res, 500, "internal", "서버 내부 오류가 발생했습니다.");
    }
  }
  return fail(res, 404, "not_found", "알 수 없는 API입니다.");
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://127.0.0.1");
    if (url.pathname.startsWith("/api/")) return await handleApi(req, res, url);
    if (req.method !== "GET" && req.method !== "HEAD") return fail(res, 405, "method_not_allowed", "허용되지 않는 요청입니다.");
    if (url.pathname.startsWith("/art/")) {
      const name = url.pathname.slice(5);
      if (!/^[A-Za-z0-9._-]+\.png$/.test(name) || name.includes("..")) return fail(res, 404, "not_found", "찾을 수 없습니다.");
      return serveFile(res, path.join(ART_DIR, name));
    }
    return serveStatic(res, url.pathname);
  } catch (e) {
    if (e && e.status) return fail(res, e.status, e.error, e.message);
    console.error(e);
    if (!res.headersSent) fail(res, 500, "internal", "서버 내부 오류가 발생했습니다.");
  }
});

const PORT = Number(process.env.PORT || 3220);
server.listen(PORT, "127.0.0.1", () => {
  console.log(`WD-ABBEY Claude판 http://127.0.0.1:${PORT} (provider: ${cfg.persona.provider})`);
});
