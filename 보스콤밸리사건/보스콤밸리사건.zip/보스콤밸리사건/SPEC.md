# WD-ABBEY Claude판 — 설계·API 계약 (2026-11-08)

「애비 그레인지」 한 사건을 **자유 채팅 + 이의 제기(역전재판식) + 동적 지도**로 푸는 판. 11/05 교수님 피드백 원문(`../31_WD-ABBEY_자유심문_공유본_20261105/docs/feedback-source.json`)을 기준으로 한다.

## 피드백 → 구현 대응

| 피드백 | 구현 |
|---|---|
| 가이드 없이 채팅으로만 인물 조사, 행동 제한 없음 | 추천 질문·행동 포인트 없음. 자유 입력만 |
| 페르소나 개발 집중, 공개지식 기본 + 대화로 열리는 지식 | `data/content.cjs`의 인물별 지식 노드(NODES). 공개 프로필·진술은 기본, 노드는 질문 주제+선행 조건 충족 시 공개 |
| 질문에 맞는 대답인지 평가 → 다음 지식 | 평가 모델(Haiku 5.5)이 질문과 노드 topic을 대조 → 서버가 requires 확인 → 인물 모델이 허용 사실만으로 대사 생성 → 누설 검사 |
| 해금 조건 평가 모델, 인물 모델 | `provider.cjs` 두 슬롯(evaluator/persona). 실패 시 규칙(키워드) 분류 + 정본 응답 |
| 자백까지 유도 | 크로커: 심문실에서 관계·선원·키·위장 증거를 누적 제시하고 추궁하면 자백. 부인·테레사는 부분 인정 |
| 자백해도 결론 탭 | 결론 제출은 자백과 독립, 첫 제출 확정 |
| 우측 인물 얼굴+대화, 좌측 메인(지도·증거) | 2단 레이아웃. 좌측 탭: 지도/증거/진술/수사기록/결론 |
| 지도 동적·상호작용 | SVG 저택·외부 지도. 장소가 수사 진행에 따라 열리고, 인물 위치 표시, 장소 클릭 → 조사 지점 |
| 심문실 소환에 증거 첨부 | 판사 심사(SUMMONS). 부족하면 기각 사유 기록 |
| Papers Please·역전재판 벤치마킹 | 역전재판: 진술 카드에 증거로 "이의 있음" → 진술 깨짐 도장·인물 반응. Papers Please: 증거 서류를 책상처럼 펼쳐 두 장을 나란히 대조 |

## 폴더

```
server.cjs        HTTP 서버(node:http, 외부 패키지 없음). 포트 3220(PORT 환경변수)
engine.cjs        세션 상태·행동 처리·공개 상태 생성(순수 로직, 모델 호출은 주입된 provider)
dialogue.cjs      평가 모델·인물 모델 프롬프트, 규칙 대체, 누설 검사
provider.cjs      Claude CLI / Anthropic API / rule (2.1판에서 가져옴)
data/content.cjs  해금 원장(장소·조사 지점·인물·지식 노드·이의 표·판사·채점)
data/abbey_case.json, data/abbey_grange_personas_v2.json  사건·인물 정본
public/           index.html, app.js, styles.css (빌드 없음, ES 모듈)
tests/            node --test
```

그림: 서버가 `/art/<파일>`을 `../31_WD-ABBEY_자유심문_공유본_20261105/public/assets/art/`에서 제공한다(바이너리 중복 저장 안 함). 파일이 없으면 404 → 화면은 이니셜 원형 아바타로 대체.

## 환경변수

`PORT`(3220), `ABBEY_PROVIDER`(`claude-cli`|`anthropic`|`rule`, 기본 claude-cli), `ABBEY_EVALUATOR_MODEL`/`ABBEY_PERSONA_MODEL`(기본 `claude-haiku-5-5`), `ABBEY_EVALUATOR_EFFORT`/`ABBEY_PERSONA_EFFORT`(기본 `high`), 타임아웃 `ABBEY_*_TIMEOUT_MS`(기본 60000).

## API

모든 응답은 JSON. 오류는 `{ok:false, error:"코드", message:"한국어"}` + 4xx.

| 메서드·경로 | 입력 | 출력 |
|---|---|---|
| `GET /api/health` | – | `{ok:true, app:"wd-abbey-claude", provider, models:{evaluator,persona}}` |
| `POST /api/session` | `{sessionId?}` | `{ok:true, sessionId, state}` (없거나 모르는 id면 새로 생성) |
| `GET /api/state?sessionId=` | – | `{ok:true, state}` |
| `POST /api/action` | `{sessionId, type, ...}` | `{ok:true, state, events:[Event]}` |

### 행동(type)

| type | 필드 | 동작 |
|---|---|---|
| `travel` | `locationId` | 열린 장소로 이동. `interrogation`이면 심문실 |
| `inspect` | `spotId` | 현재 장소의 보이는 조사 지점 조사 → 증거 발견(미열람 상태로 목록에 추가) |
| `open` | `evidenceId` | 발견한 증거 열람 → 본문 공개, `ev:` 플래그 |
| `talk` | `pid, text, attachments:[evId]` | 자유 대화. 첨부는 열람한 증거만 |
| `object` | `statementId, evidenceId, pid?` | 진술 카드에 증거로 이의 제기. 성공 시 진술 broken. 화자가 심문실에 출석해 있고 현재 심문실이면 반응 대사가 그 인물 채팅에 추가 |
| `summon` | `pid, evidenceIds:[]` | 심문실에서만. 판사 심사 → 승인/기각 기록 |
| `note` | `text` | 개인 메모 저장(최대 2000자) |
| `submit` | `culprit(pid), method, motive, reasoning, evidenceIds` | 첫 제출만 유효. 채점·해설 공개 |
| `reset` | – | 새 수사 |

### Event (애니메이션·토스트용)

`{kind, ...}` — `kind`: `evidence_found{evidenceId,title}`, `evidence_opened{evidenceId}`, `location_unlocked{locationId,name}`, `person_appeared{pid,name}`, `statement_heard{statementId}`, `knowledge{pid,nodeId,text}`, `objection{statementId,evidenceId,success,note?}`, `judge{pid,verdict:"approved"|"denied",reason}`, `confession{pid}`, `admission{pid}`, `refused{pid}`, `submitted{score}`.

### 공개 상태(state)

정답·잠긴 증거 본문·잠긴 노드·조건표는 절대 넣지 않는다.

```js
{
  version: 1,
  sessionId: "…",
  place: "scene" | "interrogation",
  locationId: "dining",                 // 현재 장소(심문실이면 "interrogation")
  brief: "사건 개요 문단",
  locations: [ { id, name, kind:"estate"|"offsite"|"interrogation", x, y, unlocked:true, current:bool, hasNew:bool, art:"/art/dining.png" } ],
                                         // 잠긴 장소는 목록에 넣지 않는다
  spots: [ { id, locationId, label, done:bool } ],      // 열린 지점만, 모든 장소 포함
  evidence: [ { id, title, typeKo, where, opened:bool, text?:string } ], // 발견한 것만. text는 opened일 때만
  statements: [ { id, speaker:"P1", speakerName, text, status:"standing"|"broken", brokenBy:[evId], notes:[string] } ],
  people: [ { pid, name, role, stance:"cooperative"|"refusing"|"summoned"|"admitted"|"confessed",
              locationId, present:bool,      // present = 지금 플레이어와 같은 장소(또는 출석한 심문실)
              canTalk:bool, refusal?:string, portrait:"/art/portrait-P1.png", initials:"메" } ],
  chats: { P5:[ {from:"player"|"npc"|"system", text, attachments:[evId], ts, source?:"model"|"rule"} ], … },
  knowledge: [ { pid, nodeId, text, ts } ],    // 얻은 인물 지식(수사 기록용)
  judge: [ { pid, verdict, reason, evidenceIds, ts } ],
  timeline: [ { time, text, evidenceId } ],
  notes: "",
  pending: false,
  submitted: null | { score, max:100, breakdown:[{label, got, max}], answer:{ summary, culpritName, timeline:[[t,text]] }, submittedAt },
  stats: { evidenceFound, evidenceTotal:20, statementsBroken, statementsTotal }
}
```

## 인물 대화 처리(서버)

1. 유효성: 인물이 보이고(`visibleWhen`), 대화 가능(협조자는 같은 장소 또는 심문실에서 – 홉킨스는 어디서나 OK, 하인은 신관·심문실), 거절 인물은 심문실에 소환된 경우만. 소환 전 거절 인물에게 talk → `REFUSALS` 대사 + grants + `met:` 플래그, event `refused`.
2. 후보 노드 = 그 인물의 노드 중 place 맞고 아직 얻지 않은 것(조건 무관) + 이미 얻은 것.
3. 평가 모델: 질문·첨부 증거 제목·후보 노드 `{id, topic}` → JSON `{"matched":["NODE"...], "intent":"ask"|"accuse"|"smalltalk"|"meta"}`. 실패 시 노드 keywords 정규식 + 추궁어(죽였|범인|거짓|자백|사실대로) 규칙.
4. 서버: matched 중 requires 충족(특수 조건 `@lady_cracks>=3`, `@croker_proof`)·`accuse` 노드는 intent=accuse일 때만 → 공개. 크로커에게 첨부한 증거는 `presented.P4`에 누적(심문실에서만).
5. 인물 모델: 공개 프로필·말투·이미 얻은 노드 text·이번에 공개할 노드 text·그 인물의 진술·이번 첨부 증거 제목만 주고 2~4문장 한국어 대사. 공개할 노드가 없으면 모르는/회피 응답(`unknown_responses`)의 결로 짧게. 규칙: 주어진 사실 밖의 사건 사실 금지, AI·게임 언급 금지.
6. 누설 검사: 그 인물이 아직 공개하지 않은 X항목 `leak_keywords`와 `guardrails.leak_check.banned_patterns`에 걸리면 정본 응답(노드 text들을 이어 붙이거나 unknown_response)으로 대체, `source:"rule"`.

## 진행 예시(정답 경로 한 가지)

홉킨스에게 사건 질문(C1~C4) → 식당 조사(종 줄·의자·잔) → 부인에게 말 걸기(거절, met:P1) → 하인에게 그날 밤·테레사·연못 질문(C5, 정문·연못 열림) → 홉킨스에게 강도 질문(경찰청) → 전보 EV18 → 진술 C1·C2·C3에 이의 → 심문실에서 부인 소환(EV03 첨부) → 추궁해 부분 인정 → 홉킨스에게 출신·배 질문 → 해운사 EV19 → 시드넘에서 크로커 거절(met:P4) → 인상 EV20 → 판사에 EV19+EV05 제출 → 심문실에서 크로커에게 증거 4그룹 제시 후 추궁 → 자백 → 결론 제출.
