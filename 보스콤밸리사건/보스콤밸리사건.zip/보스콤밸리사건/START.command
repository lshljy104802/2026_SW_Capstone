#!/bin/bash
# macOS 딸깍 실행: Node 찾기(동봉 → 설치된 22 이상 → 자동 내려받기) → API 키 확인(없으면 입력창) → 서버 시작 → 브라우저 열기
cd "$(dirname "$0")" || exit 1
NODE_VERSION=v24.13.1
NODE=""
if [ -x node-mac/bin/node ]; then
  NODE="$PWD/node-mac/bin/node"
elif command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 22 ]; then
  NODE="$(command -v node)"
else
  ARCH=$(uname -m); [ "$ARCH" = "arm64" ] || ARCH=x64
  echo "Node.js를 내려받는 중입니다(처음 한 번만)..."
  mkdir -p node-mac
  if curl -fL "https://nodejs.org/dist/$NODE_VERSION/node-$NODE_VERSION-darwin-$ARCH.tar.gz" -o /tmp/boscombe-node.tgz \
     && tar -xzf /tmp/boscombe-node.tgz -C node-mac --strip-components 1; then
    NODE="$PWD/node-mac/bin/node"
  else
    osascript -e 'display alert "보스콤 밸리 사건" message "Node.js를 내려받지 못했습니다. https://nodejs.org 에서 설치한 뒤 다시 실행해 주세요."'
    exit 1
  fi
fi

[ -f .env ] || cp .env.example .env
KEY=$(grep '^ANTHROPIC_API_KEY=' .env | head -1 | cut -d= -f2-)
PROVIDER=$(grep '^ABBEY_PROVIDER=' .env | head -1 | cut -d= -f2-)
if [ "${PROVIDER:-anthropic}" = "anthropic" ] && [ -z "$KEY" ]; then
  KEY=$(osascript -e 'text returned of (display dialog "Claude API 키를 붙여 넣어 주세요(sk-ant-로 시작). 한 번 넣으면 .env에 저장됩니다.\n\n비워 두면 AI 없이 미리 써 둔 대사로 진행합니다." default answer "" with title "보스콤 밸리 사건")' 2>/dev/null)
  if [ -n "$KEY" ]; then
    if grep -q '^ANTHROPIC_API_KEY=' .env; then
      sed -i '' "s|^ANTHROPIC_API_KEY=.*|ANTHROPIC_API_KEY=$KEY|" .env
    else
      echo "ANTHROPIC_API_KEY=$KEY" >> .env
    fi
  else
    export ABBEY_PROVIDER=rule
  fi
fi

PORT=$(grep '^PORT=' .env | head -1 | cut -d= -f2); PORT=${PORT:-3220}
if ! curl -s "http://127.0.0.1:$PORT/api/health" | grep -q wd-abbey-claude; then
  while lsof -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; do PORT=$((PORT + 1)); done
  export PORT
  mkdir -p runtime
  "$NODE" server.cjs > runtime/server.stdout.log 2> runtime/server.stderr.log &
  echo $! > runtime/launcher.pid
  for i in $(seq 1 60); do curl -s "http://127.0.0.1:$PORT/api/health" | grep -q wd-abbey-claude && break; sleep 0.25; done
fi
open "http://127.0.0.1:$PORT"
echo "보스콤 밸리 사건 실행 중: http://127.0.0.1:$PORT (끌 때는 STOP.command)"
