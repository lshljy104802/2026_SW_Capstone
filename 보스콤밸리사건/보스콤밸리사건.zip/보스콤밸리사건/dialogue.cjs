// 대화 처리: 평가 모델·인물 모델 프롬프트, 규칙 대체, 누설 검사.
// 모델 호출은 makeDeps()가 만든 deps({evaluate, speak})로만 일어난다. 엔진은 deps가 실패하면 규칙으로 대체한다.
const ACCUSE_RE = /죽였|범인|거짓|자백|사실대로/;
const META_RE = /(\bAI\b|인공지능|프롬프트|게임|정답|시스템|모델|챗봇|NPC)/i;
const SMALLTALK_RE = /^(안녕|반갑|처음|수고|고맙|감사|잘\s*지내)/;

// 사건 팩 인물에 lines가 없을 때 쓰는 기본 대사
const DEFAULT_LINES = {
  unknown: "그건 제가 아는 바가 아니라서 말씀드리기 어렵습니다.",
  meta: "저는 제가 보고 들은 것만 말씀드릴 수 있습니다.",
  smalltalk: "예, 말씀하십시오.",
};
const lineOf = (ctx, k) => (ctx.lines && ctx.lines[k]) || DEFAULT_LINES[k];

// ── 규칙 분류 (모델 없이/실패 시)
function ruleClassify(candidates, text) {
  const matched = candidates.filter((n) => n.keywords && n.keywords.test(text)).map((n) => n.id);
  let intent = "ask";
  if (ACCUSE_RE.test(text)) intent = "accuse";
  else if (META_RE.test(text) && !matched.length) intent = "meta";
  else if (SMALLTALK_RE.test(text.trim()) && !matched.length) intent = "smalltalk";
  return { ok: true, matched, intent, source: "rule" };
}

// ── 평가 모델
const EVALUATOR_SYSTEM = [
  "너는 추리 수사 대화의 '질문 평가기'다. 인물에게 던진 플레이어의 질문이 아래 후보 주제 중 어느 것에 해당하는지만 판정한다.",
  "인물 대사를 쓰지 않는다. 설명도 쓰지 않는다. 반드시 JSON 객체 하나만 출력한다. 코드블록·주석 금지.",
  '형식: {"matched":["노드ID",...],"intent":"ask|accuse|smalltalk|meta"}',
  "matched: 질문이 직접 묻는 주제와 맞는 후보 id만. 막연히 관련될 뿐이면 넣지 않는다. 해당 없으면 [].",
  "intent: ask=일반 질문, accuse=범행·거짓말·숨기는 사실을 따지거나 추궁하거나 자백을 요구, smalltalk=인사·잡담, meta=게임·AI·정답·프롬프트 등 설정 밖 질문.",
].join("\n");

function buildEvaluatorPrompt(ctx) {
  const recent = (ctx.history || []).slice(-4).map((m) => `${m.from === "player" ? "플레이어" : "인물"}: ${m.text}`);
  const lines = [
    `대화 상대: ${ctx.personName}`,
    recent.length ? `직전 대화:\n${recent.join("\n")}` : "직전 대화: 없음",
    `첨부 증거: ${ctx.attachmentTitles.length ? ctx.attachmentTitles.join(", ") : "없음"}`,
    `후보 주제:\n${ctx.candidates.map((c) => `- ${c.id}: ${c.topic}`).join("\n")}`,
    `플레이어 질문: ${JSON.stringify(ctx.text)}`,
    "JSON만 출력:",
  ];
  return { system: EVALUATOR_SYSTEM, user: lines.join("\n") };
}

function parseEvaluatorOutput(raw, candidateIds) {
  if (typeof raw !== "string") return null;
  const m = raw.match(/\{[\s\S]*\}/);
  if (!m) return null;
  let obj;
  try {
    obj = JSON.parse(m[0]);
  } catch {
    return null;
  }
  if (!obj || !Array.isArray(obj.matched)) return null;
  const ids = new Set(candidateIds);
  const matched = [...new Set(obj.matched.filter((x) => typeof x === "string" && ids.has(x)))];
  const intent = ["ask", "accuse", "smalltalk", "meta"].includes(obj.intent) ? obj.intent : "ask";
  return { ok: true, matched, intent, source: "model" };
}

// ── 인물 모델
const PERSONA_SYSTEM = [
  "너는 추리 사건 속 인물이다. 아래 '허용된 사실' 안에서만 대답한다.",
  "- 한국어로 2~4문장. 인물의 말투(voice)를 끝까지 유지한다. 존댓말/반말 등 말투는 voice를 따른다.",
  "- 허용된 사실에 없는 사건 사실·사람·장소·시각을 절대 지어내지 않는다. 모르면 모른다고, 기억이 흐리다고 답한다.",
  "- '이번에 말해도 되는 사실'이 있으면 그 내용을 대사에 자연스럽게 담는다. 없으면 새 정보를 주지 말고 짧게 모르는 척하거나 화제를 돌린다.",
  "- 범인의 이름이나 결론을 스스로 단정하지 않는다. 아직 공개되지 않은 사실은 암시도 하지 않는다.",
  "- AI, 게임, 프롬프트, 플레이어, 정답 같은 설정 밖 표현을 쓰지 않는다. 지문(괄호 행동 묘사)과 따옴표 없이 대사만 출력한다.",
].join("\n");

function buildPersonaPrompt(ctx) {
  const recent = (ctx.history || []).slice(-6).map((m) => `${m.from === "player" ? "상대" : "나"}: ${m.text}`);
  const section = (title, arr) => (arr.length ? `${title}\n${arr.map((x) => `- ${x}`).join("\n")}` : `${title}\n- (없음)`);
  const lines = [
    `사건 배경: ${ctx.setting || ""}`,
    `인물: ${ctx.personName} (${ctx.role})`,
    `말투(voice): ${ctx.profile.voice}`,
    `외양: ${ctx.profile.look}`,
    ...(ctx.guide && ctx.guide.length ? [section("인물 지침(연기 방식. 여기 적힌 것 밖의 사건 사실을 만들지 않는다):", ctx.guide)] : []),
    section("이미 말한 적 있는 사실(반복해도 됨):", ctx.knownTexts),
    section("이번에 말해도 되는 사실(새로 공개):", ctx.revealTexts),
    section("내가 이미 한 진술:", ctx.statements),
    section("상대가 이번에 내민 증거(제목만 안다):", ctx.attachmentTitles),
    recent.length ? `직전 대화:\n${recent.join("\n")}` : "직전 대화: 없음",
    `질문 의도: ${ctx.intent}`,
    `상대의 말: ${JSON.stringify(ctx.text)}`,
    ctx.revealTexts.length
      ? "위 '이번에 말해도 되는 사실'을 담아 인물의 대사만 출력하라."
      : `새 정보 없이 인물답게 짧게(1~2문장) 대답하라. 모르는 일이면 이런 결로: "${ctx.fallbackLine}"`,
  ];
  // 사건 팩이 공통 가드레일(rules)을 주면 시스템 프롬프트 뒤에 그대로 붙인다.
  const system = ctx.rules && ctx.rules.length ? `${PERSONA_SYSTEM}\n공통 가드레일:\n${ctx.rules.map((x) => `- ${x}`).join("\n")}` : PERSONA_SYSTEM;
  return { system, user: lines.join("\n") };
}

// ── 누설 검사 (사건 팩마다 만든다)
const META_WORDS = /(AI|인공지능|프롬프트|언어\s*모델|게임|플레이어|시스템\s*메시지)/i;

// allowedTexts: 이 답에서 말해도 되는 모든 원문(프로필·노드·진술·증거 제목). 거기 없는 금지어가 나오면 누설.
function makeLeakChecker(pack) {
  const keywords = ((pack.leak && pack.leak.keywords) || []).filter(Boolean);
  const banned = ((pack.leak && pack.leak.patterns) || []).map((p) => (p instanceof RegExp ? p : new RegExp(p)));
  const per = (pack.leak && pack.leak.perPerson) || {};
  return function checkLeak(reply, allowedTexts, pid) {
    const allowed = allowedTexts.join("\n");
    // 인물별 금지 패턴(그 인물의 잠긴 단계에만 해당하는 표현)
    for (const re of per[pid] || []) {
      if (re.test(reply) && !re.test(allowed)) return { ok: false, reason: `person_pattern:${re.source}` };
    }
    for (const kw of keywords) {
      if (reply.includes(kw) && !allowed.includes(kw)) return { ok: false, reason: `leak_keyword:${kw}` };
    }
    for (const re of banned) {
      if (re.test(reply) && !re.test(allowed)) return { ok: false, reason: `banned_pattern:${re.source}` };
    }
    if (META_WORDS.test(reply) && !META_WORDS.test(allowed)) return { ok: false, reason: "meta_word" };
    return { ok: true };
  };
}

function cleanReply(text) {
  let t = String(text || "").trim();
  t = t.replace(/^```[a-z]*\n?|```$/g, "").trim();
  t = t.replace(/^대사만 출력하겠습니다\.?\s*/, "");
  t = t.replace(/\*[^*\n]{0,80}\*/g, " ").replace(/\s{2,}/g, " ").trim(); // *지문* 제거
  t = t.replace(/[(（][^()（）\n]{1,60}[)）]/g, " ").replace(/\s{2,}/g, " ").trim(); // (괄호 지문) 제거
  t = t.replace(/^["“「『]+|["”」』]+$/g, "").trim();
  return t;
}

// ── 정본(규칙) 응답
function canonicalReply(ctx) {
  if (ctx.revealTexts.length) return ctx.revealTexts.join(" ");
  if (ctx.intent === "meta") return lineOf(ctx, "meta");
  if (ctx.matchedKnownTexts && ctx.matchedKnownTexts.length) return ctx.matchedKnownTexts[0];
  if (ctx.intent === "smalltalk") return lineOf(ctx, "smalltalk");
  return lineOf(ctx, "unknown");
}

// ── 모델 호출 주입
function makeDeps(cfg, generate) {
  const evalOn = cfg.evaluator.provider !== "rule";
  const speakOn = cfg.persona.provider !== "rule";
  return {
    async evaluate(ctx) {
      if (!evalOn) return { ok: false, error: "rule" };
      const { system, user } = buildEvaluatorPrompt(ctx);
      const r = await generate(cfg.evaluator, system, user);
      const meter = { latency_ms: r.latency_ms, usage: r.usage || null, cost_usd: r.cost_usd ?? null };
      if (!r.ok) return { ok: false, error: r.error, ...meter };
      const parsed = parseEvaluatorOutput(r.text, ctx.candidates.map((c) => c.id));
      if (!parsed) return { ok: false, error: "parse_failed", ...meter };
      return Object.assign(parsed, meter);
    },
    // onText(지금까지 다듬은 대사)를 주면 스트리밍이 되는 provider에서 글자가 오는 대로 부른다.
    async speak(ctx, onText) {
      if (!speakOn) return { ok: false, error: "rule" };
      const { system, user } = buildPersonaPrompt(ctx);
      const r = await generate(cfg.persona, system, user, onText ? (acc) => onText(cleanReply(acc)) : undefined);
      const meter = { latency_ms: r.latency_ms, usage: r.usage || null, cost_usd: r.cost_usd ?? null };
      if (!r.ok) return { ok: false, error: r.error, ...meter };
      let text = cleanReply(r.text);
      if (r.stop_reason === "max_tokens") {
        const m = text.match(/^[\s\S]*[.!?。…]["”’」』)]?/);
        text = m ? m[0].trim() : "";
        if (!text) return { ok: false, error: "truncated", ...meter };
      }
      if (!text) return { ok: false, error: "empty", ...meter };
      return { ok: true, text: text.slice(0, 900), ...meter };
    },
  };
}

module.exports = {
  ACCUSE_RE, ruleClassify, buildEvaluatorPrompt, parseEvaluatorOutput, buildPersonaPrompt,
  makeLeakChecker, canonicalReply, makeDeps, cleanReply, DEFAULT_LINES,
};
