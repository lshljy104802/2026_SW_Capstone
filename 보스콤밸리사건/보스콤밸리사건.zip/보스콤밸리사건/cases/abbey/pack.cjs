// 사건 팩: 「애비 그레인지」. 기존 원장(data/content.cjs + 팀 JSON 2종)을 사건 팩 형식으로 묶는다.
// 형식 설명은 docs/CASE_PACK.md.
const C = require("../../data/content.cjs");
const caseData = require("../../data/abbey_case.json");
const personas = require("../../data/abbey_grange_personas_v2.json");

const g = personas.guardrails;
const SMALLTALK = {
  lady: "…무슨 일이신가요. 말씀하세요.",
  theresa: "무슨 용건이신지 말씀하시죠.",
  croker: "용건이 뭐요. 짧게 말하시오.",
  hopkins: "예, 말씀하십시오. 제가 아는 데까지는 도와 드리겠습니다.",
  servant: "예, 무엇을 도와 드릴까요.",
};

const people = C.PEOPLE.map((p) => {
  const ch = personas.characters[p.key];
  const prof = (ch && ch.public_profile) || C.EXTRA_PROFILES[p.key] || {};
  return {
    pid: p.pid,
    key: p.key,
    name: p.name,
    role: p.role,
    stance: p.stance,
    location: p.location,
    companion: p.pid === "P5",
    talkAt: p.pid === "P6" ? ["servants"] : undefined,
    visibleWhen: p.visibleWhen,
    portrait: p.portrait,
    profile: { voice: prof.voice || "", look: prof.look || "" },
    lines: {
      unknown: g.unknown_responses[p.key] || "그건 제가 아는 바가 아니라서 말씀드리기 어렵습니다.",
      meta: g.meta_question_deflection[p.key] || "저는 제가 보고 들은 것만 말씀드릴 수 있습니다.",
      smalltalk: SMALLTALK[p.key],
    },
    cracks: { ...((ch && ch.cracks) || {}), ...((C.EXTRA_CRACKS[p.key]) || {}) },
  };
});

const leakKeywords = [];
for (const [id, f] of Object.entries(personas.facts)) {
  if (id.startsWith("X") && Array.isArray(f.leak_keywords)) leakKeywords.push(...f.leak_keywords);
}

// 기존 조건 이름(@lady_cracks>=3, @croker_proof)을 일반 조건으로 정의
const nodes = C.NODES.map((n) => ({
  ...n,
  requires: n.requires.map((r) => (r === "@lady_cracks>=3" ? "@lady_cracks" : r)),
}));

module.exports = {
  id: "abbey",
  title: "애비 그레인지 사건",
  source: "아서 코넌 도일, 「애비 그레인지 저택」(1904)",
  setting: "셜록 홈즈 「애비 그레인지」 사건(1897년 켄트주 저택)",
  brief: caseData.public.brief,
  startLocation: "dining",
  map: {
    zones: { estate: "애비 그레인지 저택", offsite: "런던 · 시드넘" },
    edges: [["dining", "servants"], ["dining", "lodge"], ["dining", "pond"], ["servants", "pond"],
      ["dining", "yard", true], ["yard", "shipping", true], ["shipping", "sydenham", true]],
    // 지도 장식(선택): 저택 본관·신관 윤곽
    // 지도는 시안 v3 M안의 저택 평면도를 그대로 쓴다(public/app.js의 abbeyHouse)
    decor: [{ type: "plan", id: "abbey" }],
  },
  locations: C.LOCATIONS.map((l) => ({ ...l, shape: l.id === "pond" ? "pond" : undefined })),
  spots: C.SPOTS,
  start: C.START,
  people,
  refusals: C.REFUSALS,
  nodes,
  objections: C.OBJECTIONS,
  summons: C.SUMMONS,
  conditions: {
    "@lady_cracks": { type: "cracks", statements: ["C1", "C2", "C3"], cracks: C.LADY_CRACKS, min: 3 },
    "@croker_proof": { type: "proof", pid: "P4", groups: C.CROKER_PROOF },
  },
  evidence: caseData.public.evidence.map((e) => ({ id: e.id, title: e.title, typeKo: e.type_ko, where: e.where, text: e.text })),
  statements: caseData.public.statements.map((x) => ({ id: x.id, speaker: x.speaker, speakerName: x.speaker_name, text: x.text })),
  timeline: C.TIMELINE,
  suspects: [
    { pid: "P1", name: "메리 브래컨스톨 부인" }, { pid: "P2", name: "테레사 라이트" },
    { pid: "P3", name: "랜들 일당" }, { pid: "P4", name: "잭 크로커" },
  ],
  scoring: {
    culprit: { pids: ["P4"], points: 40, label: "범인 지목" },
    items: [
      { label: "흉기·방법", field: "method", re: C.SCORING.method.keywords, points: 15 },
      { label: "동기", field: "motive", re: C.SCORING.motive.keywords, points: 15 },
      { label: "강도 위장 간파", field: "all", re: C.SCORING.staging.keywords, points: 10 },
    ],
    evidence: { groups: C.CROKER_PROOF, perGroup: 5 },
  },
  answer: {
    summary: caseData.answer.summary,
    culpritName: "잭 크로커",
    timeline: caseData.answer.timeline,
  },
  leak: { keywords: leakKeywords, patterns: (g.leak_check.banned_patterns || []).map((p) => new RegExp(p)) },
  art: { base: "/art/" },
};
