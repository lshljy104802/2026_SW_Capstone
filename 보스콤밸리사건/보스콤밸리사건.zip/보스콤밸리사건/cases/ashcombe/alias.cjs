// 이름 변형표: 보스콤 밸리 사건의 인물·지명·핵심 낱말을 다른 이름으로 바꾼다.
// 목적은 모델이 원작 소설을 떠올려 결말을 기억으로 맞히는 것을 줄이는 것이다(WHODUNIT 논문 3절의 방식).
// 영어 이름은 페르소나 키트 scenario.name_augmentation.alias_map을 따랐고, 한글 표기와 지명 몇 개(로스·헤리퍼드·브리스톨)를 보탰다. 조사가 어긋나지 않게 받침이 같은 이름으로 골랐고,
// 그 때문에 키트 표와 다른 것이 있다(McCarthy→Cayley, Lestrade→Gregory, Moran→Dane, Ballarat→Mallacoot·a rat→a coot).
// 'Ballarat → a rat'처럼 낱말 끝만 들리는 단서는 'Mallacoot → a coot'로 같은 구조를 유지한다.
// 긴 것부터 차례로 바꾼다(순서가 뜻이 있다).
const MAP = [
  // 낱말 끝 단서
  ["'a rat'(쥐)", "'a coot'"], ["a rat", "a coot"], ["A RAT", "A COOT"],
  ["BALLARAT", "MALLACOOT"], ["Ballarat", "Mallacoot"], ["ballarat", "mallacoot"], ["발라랏", "말라쿳"], ["발라랫", "말라쿳"],
  ["Black Jack", "Red Tom"], ["블랙 잭", "레드 톰"],
  // 인물
  ["앨리스 터너", "클라라 핼로웨이"], ["존 터너", "에드먼드 핼로웨이"], ["터너", "핼로웨이"], ["앨리스", "클라라"],
  ["제임스 매카시", "헨리 케일리"], ["찰스 매카시", "토머스 케일리"], ["매카시", "케일리"], ["제임스", "헨리"], ["찰스", "토머스"],
  ["윌리엄 크라우더", "월터 파이크"], ["크라우더", "파이크"], ["윌리엄", "월터"],
  ["페이션스 모런", "머시 데인"], ["페이션스", "머시"], ["모런", "데인"],
  ["레스트레이드", "그레고리"], ["존 콥", "샘 홉"],
  ["Alice Turner", "Clara Halloway"], ["John Turner", "Edmund Halloway"], ["Turner", "Halloway"],
  ["James McCarthy", "Henry Cayley"], ["Charles McCarthy", "Thomas Cayley"], ["McCarthy", "Cayley"],
  ["William Crowder", "Walter Pike"], ["Crowder", "Pike"], ["Patience Moran", "Mercy Dane"], ["Moran", "Dane"], ["Lestrade", "Gregory"],
  // 지명
  ["보스콤", "애시콤"], ["Boscombe", "Ashcombe"], ["해덜리", "웩슬리"], ["Hatherley", "Wexley"],
  ["헤리퍼드", "셀비"], ["Hereford", "Selby"], ["로스", "말버리"], ["Ross", "Marbury"],
  ["브리스톨", "리버풀"], ["Bristol", "Liverpool"],
];
function alias(s) {
  let out = String(s);
  for (const [a, b] of MAP) out = out.split(a).join(b);
  return out;
}
// 사건 팩 전체를 훑어 문자열·정규식·함수 결과까지 같은 표로 바꾼다. 팩 안의 참조(id·플래그)도 함께 바뀌므로 서로 어긋나지 않는다.
function deep(v) {
  if (typeof v === "string") return alias(v);
  if (v instanceof RegExp) return new RegExp(alias(v.source), v.flags);
  if (Array.isArray(v)) return v.map(deep);
  if (typeof v === "function") return (...args) => deep(v(...args));
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [alias(k), deep(x)]));
  return v;
}
module.exports = { alias, deep, MAP };
