// 사건 팩: 「애시콤 밸리 사건」 = 보스콤 밸리 사건의 이름 변형판.
// 사건 구조·증거·조건·채점은 cases/boscombe/pack.cjs 그대로이고, 인물·지명·핵심 낱말만 alias.cjs의 표로 바꾼다.
// 모델 플레이 실험에서 원작 기억으로 푸는 것을 줄이려고 만들었다. 사람 대상 수업에는 보스콤 판을 쓴다.
const base = require("../boscombe/pack.cjs");
const { deep } = require("./alias.cjs");

const pack = deep(base);
pack.id = "ashcombe";
pack.source = "수사 실습용 사건(이름 변형판)";
module.exports = pack;
