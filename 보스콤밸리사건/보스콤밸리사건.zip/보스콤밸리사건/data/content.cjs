// WD-ABBEY Claude판 콘텐츠 원장 (서버 전용, 브라우저로 보내지 않는다).
// 증거 본문·진술 원문은 data/abbey_case.json, 인물 말투·숨긴 사실은 data/abbey_grange_personas_v2.json이 정본이다.
// 여기에는 "언제 무엇이 열리는가"만 둔다.
//
// 플래그 규칙 (session.flags 집합에 문자열로 저장)
//   ev:EVxx      증거를 열람함
//   k:NODE       인물 지식 노드를 얻음
//   heard:Cx     진술 카드를 확보함
//   broken:Cx    진술이 증거로 깨짐(이의 제기 성공)
//   crack:ID     모순 반응을 얻음(d_rope 등)
//   met:Px       현장에서 그 인물에게 말을 걸어 봄(거절 확인 포함)
//   loc:ID       장소가 지도에 열림
//   summoned:Px  판사가 소환을 승인함
//   confessed:Px 자백함
//   admitted:Px  부분 인정(max_admission)까지 감

const LOCATIONS = [
  { id: "dining", name: "식당", kind: "estate", x: 320, y: 210, start: true, art: "dining" },
  { id: "servants", name: "신관(하인 숙소)", kind: "estate", x: 74, y: 112, start: true, art: "house" },
  { id: "lodge", name: "정문 관리소", kind: "estate", x: 612, y: 443, art: "house" },
  { id: "pond", name: "정원 연못", kind: "estate", x: 316, y: 338, art: "pond" },
  { id: "yard", name: "런던 경찰청", kind: "offsite", x: 760, y: 120, art: "records" },
  { id: "shipping", name: "해운사 사무소(팰맬)", kind: "offsite", x: 860, y: 260, art: "records" },
  { id: "sydenham", name: "시드넘 숙소", kind: "offsite", x: 780, y: 420, art: "lodging" },
  { id: "interrogation", name: "심문실", kind: "interrogation", x: 0, y: 0, start: true, art: "interrogation" },
];

// 조사 지점. requires의 모든 플래그가 있어야 지도에 나타난다. grants는 조사할 때 얻는 플래그.
const SPOTS = [
  { id: "body", locationId: "dining", label: "유스터스 경의 시신", requires: [], reveals: "EV10" },
  { id: "fireplace", locationId: "dining", label: "벽난로와 부지깽이", requires: [], reveals: "EV02" },
  { id: "bellrope", locationId: "dining", label: "종 줄", requires: [], reveals: "EV03" },
  { id: "shelf", locationId: "dining", label: "벽난로 위 벽 선반", requires: ["ev:EV03"], reveals: "EV04" },
  { id: "chair", locationId: "dining", label: "참나무 의자", requires: [], reveals: "EV06" },
  { id: "knot", locationId: "dining", label: "의자의 결박 매듭", requires: ["ev:EV06"], reveals: "EV05" },
  { id: "glasses", locationId: "dining", label: "찬장의 와인잔", requires: [], reveals: "EV07" },
  { id: "bottle", locationId: "dining", label: "와인병과 코르크", requires: ["ev:EV07"], reveals: "EV08" },
  { id: "window", locationId: "dining", label: "프랑스식 창문 밖", requires: [], reveals: "EV09" },
  { id: "injury", locationId: "dining", label: "부인의 부상 관찰", requires: ["met:P1"], reveals: "EV11" },
  { id: "servant_log", locationId: "servants", label: "하인 진술 조서", requires: ["k:S_night"], reveals: "EV12" },
  { id: "household", locationId: "servants", label: "부인·하녀 인물 기록", requires: ["k:H_background"], reveals: "EV13" },
  { id: "village", locationId: "servants", label: "마을 탐문 기록", requires: ["k:S_master"], reveals: "EV14" },
  { id: "carriage", locationId: "lodge", label: "관리인의 마차 시간표", requires: [], reveals: "EV17" },
  { id: "ice", locationId: "pond", label: "연못 얼음 구멍", requires: [], reveals: "EV16" },
  { id: "wanted", locationId: "yard", label: "랜들 일당 수배 기록", requires: [], reveals: "EV15" },
  { id: "telegram", locationId: "yard", label: "뉴욕발 전보", requires: ["ev:EV15"], reveals: "EV18" },
  { id: "manifest", locationId: "shipping", label: "록 오브 지브롤터호 기록", requires: [], reveals: "EV19", grants: ["loc:sydenham"] },
  { id: "observe", locationId: "sydenham", label: "크로커의 인상 관찰", requires: ["met:P4"], reveals: "EV20" },
];

// 시작 때 열린 증거(검시 요약)와 장소.
const START = { evidence: ["EV01"], flags: [] };

// 등장 인물. stance: cooperative(현장에서 대화) | refusing(현장 거절 → 판사 소환 필요).
// visibleWhen: 지도·인물 목록에 나타나는 조건.
const PEOPLE = [
  { pid: "P5", key: "hopkins", name: "스탠리 홉킨스 경위", role: "수사 책임자", stance: "cooperative", location: "dining", visibleWhen: [], portrait: "portrait-P5.png" },
  { pid: "P6", key: "servant", name: "저택 하인 대표", role: "신관에서 일하는 고참 하인(게임용 추가 인물)", stance: "cooperative", location: "servants", visibleWhen: [], portrait: "portrait-P6.png" },
  { pid: "P1", key: "lady", name: "메리 브래컨스톨 부인", role: "피해자의 아내", stance: "refusing", location: "dining", visibleWhen: [], portrait: "portrait-P1.png" },
  { pid: "P2", key: "theresa", name: "테레사 라이트", role: "부인의 하녀(유모 출신)", stance: "refusing", location: "servants", visibleWhen: ["heard:C5"], portrait: "portrait-P2.png" },
  { pid: "P4", key: "croker", name: "잭 크로커", role: "시드넘에 머무는 선장", stance: "refusing", location: "sydenham", visibleWhen: ["ev:EV19"], portrait: "portrait-P4.png" },
];

// 하인 대표(P6)는 원작에 이름 없는 인물이라 말투만 정한다.
const EXTRA_PROFILES = {
  servant: {
    voice: "조심스럽고 공손한 하인 말투. 본 것과 들은 것을 구분해 말하고, 주인 이야기에는 목소리를 낮춘다.",
    look: "희끗한 머리에 단정한 조끼 차림의 고참 하인.",
  },
};

// 현장에서 거절하는 인물이 처음 말을 걸었을 때 하는 말과 그때 확보되는 진술.
const REFUSALS = {
  P1: {
    text: "경위님께 이미 다 말씀드렸어요. 세 사람이 창문으로 들어왔고… 더는 그 밤 이야기를 하고 싶지 않아요. 저를 쉬게 해 주세요.",
    grants: ["heard:C1", "heard:C2", "heard:C3", "heard:C4"],
  },
  P2: {
    text: "마님은 지금 누구도 만나실 수 없어요. 저도 할 말은 경위님께 다 했습니다. 정문 근처에 남자 셋이 있었다고요. 주인님이 어떤 분이었는지는 마을 사람 누구에게 물어도 압니다.",
    grants: ["heard:C5", "heard:C6"],
  },
  P4: {
    text: "이틀 뒤면 사우샘프턴에서 새 배를 맡소. 준비할 게 산더미라 낯선 사람과 노닥거릴 시간은 없소. 볼일이 있으면 정식으로 부르시오.",
    grants: ["heard:C7"],
  },
};

// 인물 지식 노드. 평가 모델이 질문과 topic을 대조하고, 서버가 requires를 확인한다.
// place: "scene"(현장) | "interrogation" | "any". 거절 인물의 노드는 모두 심문실 전용이다.
// text: 그 인물이 이번 답에서 말해도 되는 사실(정본 응답). grants: 얻는 플래그.
const NODES = [
  // ── 홉킨스 경위 (P5)
  { id: "H_brief", pid: "P5", place: "any", topic: "사건 개요, 무슨 일이 있었나, 부인의 진술 내용, 지금까지 파악된 것", keywords: /사건|무슨\s*일|개요|경위|진술|부인.*(말|진술)|어떻게\s*된/, requires: [],
    text: "자정 무렵 하녀의 비명에 하인들이 내려와 보니 유스터스 경이 식당 바닥에 쓰러져 있었고 부인은 의자에 묶여 있었습니다. 부인 말로는 11시 넘어 식당 창문이 열려 있었고 수염 난 남자와 젊은 남자 둘이 들어와 자신을 때려 기절시키고 종 줄로 묶었으며, 뛰어든 남편을 부지깽이로 쳤다고 합니다. 진술 조서를 드리지요.",
    grants: ["heard:C1", "heard:C2", "heard:C3", "heard:C4"] },
  { id: "H_randall", pid: "P5", place: "any", topic: "강도, 랜들 일당, 외부 침입자, 용의자, 수배", keywords: /강도|랜들|일당|침입|수배|용의자|도둑/, requires: ["heard:C1"],
    text: "인상착의로 보면 루이셤의 랜들 일당이 떠오릅니다. 아버지와 두 아들인데 2주 전 시드넘에서 강도질을 해서 수배 중이지요. 런던 경찰청에 수배 기록이 있습니다.",
    grants: ["loc:yard"] },
  { id: "H_background", pid: "P5", place: "any", topic: "부인의 출신, 과거, 결혼, 영국에 온 경위, 하녀 테레사의 내력", keywords: /출신|과거|결혼|고향|호주|애들레이드|어디서\s*왔|내력|이력|테레사.*(누구|어떤)/, requires: [],
    text: "부인은 남호주 애들레이드 출신으로 결혼 전 이름이 메리 프레이저입니다. 1년 반쯤 전에 하녀 테레사와 배를 타고 영국에 왔고, 결혼한 지는 1년 남짓입니다. 신관에 두 사람의 인물 기록을 정리해 두었습니다.",
    grants: [] },
  { id: "H_ship", pid: "P5", place: "any", topic: "부인이 타고 온 배, 항해, 배 이름, 해운사, 승객 명부", keywords: /배|항해|선박|해운|명부|승객|지브롤터/, requires: ["ev:EV13"],
    text: "부인이 타고 온 배는 애들레이드-사우샘프턴 항로의 '록 오브 지브롤터'호입니다. 해운사 사무소가 런던 팰맬에 있으니 승객과 선원 기록을 볼 수 있을 겁니다.",
    grants: ["loc:shipping"] },
  { id: "H_shelf", pid: "P5", place: "any", topic: "벽 선반 높이, 종 줄에 손이 닿는 사람, 키, 재현 실험", keywords: /선반|높이|키|닿|재현/, requires: ["ev:EV04"],
    text: "저희 경관 중 제일 키 큰 사람이 똑같이 올라서 봐도 3인치쯤 모자랐습니다. 아주 키가 크고 몸이 날랜 사람이어야 합니다. 곡예사나… 돛대를 타는 사람 정도겠지요.",
    grants: [] },
  { id: "H_knot", pid: "P5", place: "any", topic: "매듭의 종류, 묶은 방법, 누가 묶을 수 있나", keywords: /매듭|묶|결박/, requires: ["ev:EV05"],
    text: "그 매듭은 육지 사람이 묶는 방식이 아닙니다. 배에서 선원들이 쓰는 매듭이에요.",
    grants: [] },
  { id: "H_telegram", pid: "P5", place: "any", topic: "랜들 일당이 체포됐는지, 전보, 뉴욕", keywords: /체포|전보|뉴욕|잡혔/, requires: ["ev:EV18"],
    text: "전보가 맞다면 랜들 일당은 사건 이틀 뒤 아침 뉴욕에서 잡혔습니다. 대서양을 건너는 데만 엿새는 걸리니… 그날 밤 켄트에 있었을 수가 없군요. 부인이 본 세 남자는 대체 누구였을까요.",
    grants: [] },

  // ── 저택 하인 대표 (P6)
  { id: "S_night", pid: "P6", place: "any", topic: "그날 밤 상황, 비명, 하인들이 어디 있었나, 발견 당시", keywords: /그날|밤|비명|발견|어디\s*있|자고|하인들|소리/, requires: [],
    text: "저희 여덟은 모두 신관에서 자고 있었습니다. 신관에서는 식당 종소리도 안 들립니다. 테레사가 먼저 달려 내려갔고 저희는 그 소란에 깨서 갔지요. 마님은 의자에 묶여 계셨고 주인님은… 쓰러져 계셨습니다.",
    grants: [] },
  { id: "S_master", pid: "P6", place: "any", topic: "주인 유스터스 경의 성격, 술버릇, 평판, 부인과의 관계", keywords: /주인|유스터스|성격|술|평판|부부|관계|어떤\s*분/, requires: [],
    text: "목소리를 낮춰 말씀드리면… 주인님은 술만 드시면 사람이 변하셨습니다. 마님이 아끼던 개에 석유를 붓고 불을 붙인 일도 있었지요. 마을에서 다 아는 얘기입니다.",
    grants: [] },
  { id: "S_theresa", pid: "P6", place: "any", topic: "하녀 테레사, 테레사가 본 것, 정문 쪽, 수상한 사람", keywords: /테레사|하녀|정문|수상|남자\s*셋|봤/, requires: ["k:S_night"],
    text: "테레사 말로는 비명 한참 전에 달빛 아래 정문 관리소 근처에서 남자 셋을 봤답니다. 관리소에 가 보시면 그날 밤 마차 사정도 아실 수 있을 겁니다.",
    grants: ["heard:C5", "loc:lodge"] },
  { id: "S_pond", pid: "P6", place: "any", topic: "정원, 연못, 아침에 이상한 점, 얼음, 흔적", keywords: /정원|연못|얼음|이상한|흔적|아침/, requires: ["k:S_night"],
    text: "그러고 보니 오늘 아침 정원사가 연못 얼음에 구멍이 하나 뚫려 있더라고 했습니다. 밤새 얼었을 텐데 이상하다고요.",
    grants: ["loc:pond"] },

  // ── 메리 부인 (P1) — 심문실 전용
  { id: "L_husband", pid: "P1", place: "interrogation", topic: "남편, 결혼 생활, 남편의 술버릇, 행복했나", keywords: /남편|결혼|생활|행복|술/, requires: [],
    text: "남편은 술꾼이었어요. 이 결혼은 행복하지 않았습니다. 그 이상은… 말씀드리기 어려워요.",
    grants: [] },
  { id: "L_injury", pid: "P1", place: "interrogation", topic: "팔의 붉은 자국, 눈 위 멍, 상처", keywords: /팔|자국|멍|상처|다쳤|모자핀/, requires: ["ev:EV11"],
    text: "팔 자국은… 남편이 모자핀으로 찌른 거예요. 눈 위 멍은 그 남자 주먹에 맞은 거고요.",
    grants: [] },
  { id: "L_voyage", pid: "P1", place: "interrogation", topic: "영국에 올 때 탄 배, 항해, 배에서 만난 사람, 크로커", keywords: /배|항해|지브롤터|크로커|선원|항해사/, requires: ["ev:EV19"],
    text: "그 배에서 많은 분께 친절을 받았어요. 그 이야기는… 지금 하고 싶지 않아요.",
    grants: [] },
  { id: "L_admit", pid: "P1", place: "interrogation", topic: "강도가 정말 있었나, 진술이 거짓인가, 누구를 감싸는가 추궁", keywords: /거짓|감싸|강도.*(없|아니)|사실대로|진실/, requires: ["@lady_cracks>=3"], accuse: true,
    text: "…네. 강도는 없었어요. 제가 드린 말씀은 사실이 아니에요. 하지만 그 사람이 누구인지는, 저를 죽인다 해도 말씀드리지 않겠어요.",
    grants: ["admitted:P1"] },
  { id: "L_after", pid: "P1", place: "interrogation", topic: "크로커의 자백 이후 그날 밤의 진실, 남편이 무엇을 했나", keywords: /자백|그날\s*밤|진실|지팡이|남편이.*(때|쳤)/, requires: ["confessed:P4"],
    text: "잭이 다 말했다면… 그래요. 그이가 창가에 왔고, 남편이 뛰어들어 지팡이로 제 얼굴을 쳤어요. 잭은 저를 지키려 했을 뿐이에요. 강도 이야기는 테레사와 셋이서 꾸민 거예요.",
    grants: [] },

  // ── 테레사 (P2) — 심문실 전용
  { id: "T_master", pid: "P2", place: "interrogation", topic: "주인 유스터스 경, 유리병, 학대, 미워하나", keywords: /주인|유스터스|유리병|미워|학대|모자핀/, requires: [],
    text: "주인님이 제게 유리병을 던진 적도 있어요. 마님 팔의 자국은 모자핀으로 찌른 거고요. 네, 저는 그분을 몹시 미워했습니다.",
    grants: [] },
  { id: "T_admit", pid: "P2", place: "interrogation", topic: "부인 진술에 맞춰 말했나, 정문에서 본 남자 셋이 거짓인가 추궁", keywords: /거짓|맞춰|입을\s*맞|감싸|사실대로/, requires: ["broken:C5"], accuse: true,
    text: "…마님 말씀에 맞춰 드린 건 맞아요. 하지만 누가 있었는지는 제 입으로 말하지 않겠습니다.",
    grants: ["admitted:P2"] },
  { id: "T_after", pid: "P2", place: "interrogation", topic: "크로커의 자백 이후 그날 밤 내려가서 본 것", keywords: /자백|내려갔|그날\s*밤|꾸몄/, requires: ["confessed:P4"],
    text: "제가 내려갔을 땐 이미 끝나 있었어요. 크로커 선장과 함께 강도가 든 것처럼 꾸미자고 한 건 저예요. 마님을 지키려고요.",
    grants: [] },

  // ── 잭 크로커 (P4) — 심문실 전용
  { id: "K_voyage", pid: "P4", place: "interrogation", topic: "록 오브 지브롤터호, 부인과 아는 사이인가, 항해, 일등항해사", keywords: /지브롤터|배|항해|부인|메리|아는\s*사이|항해사/, requires: [],
    text: "그 배의 일등항해사였소. 지금은 선장이 됐고. 프레이저 양… 부인은 그때 승객이었지. 그분을 건드리지 마시오.",
    grants: ["crack:d_link"] },
  { id: "K_night", pid: "P4", place: "interrogation", topic: "그날 밤 어디 있었나, 알리바이", keywords: /그날|어젯밤|밤에|어디\s*있|알리바이/, requires: [],
    text: "출항 준비 때문에 시드넘 숙소에 있었소.",
    grants: [] },
  { id: "K_confess", pid: "P4", place: "interrogation", topic: "범행 추궁, 당신이 유스터스 경을 죽였나, 그날 밤 식당에 있었나", keywords: /죽였|범인|당신이|네가|자백|식당에\s*있|부지깽이/, requires: ["@croker_proof"], accuse: true,
    text: "…그래, 내가 했소. 그날 밤 창가로 그녀를 보러 갔지. 그 짐승 같은 자가 뛰어들어 지팡이로 그녀 얼굴을 후려쳤소. 나는 부지깽이를 집어 그를 쳤고, 그는 쓰러졌소. 그다음은 테레사와 함께 강도가 든 것처럼 꾸몄소. 종 줄을 자르고, 매듭을 묶고, 잔에 와인을 따르고, 은식기는 연못에 버렸지. 그녀에겐 죄가 없소.",
    grants: ["confessed:P4"] },
];

// 이의 제기 판정표: 진술 카드 + 증거 → 그 진술이 깨짐.
// crack은 personas_v2.characters[*].cracks의 키. 반응 대사는 그 인물의 cracks에서 가져온다.
// 심문실에 그 진술의 화자가 있어야 반응 대사가 나오지만, 진술 카드는 어디서든 깨진다(증거 대조).
const OBJECTIONS = [
  { statement: "C1", evidence: ["EV18"], crack: "d_randall", note: "랜들 일당은 이틀 뒤 아침 뉴욕에서 잡혔다. 그날 밤 켄트에 있을 수 없다." },
  { statement: "C2", evidence: ["EV03"], crack: "d_rope", note: "종 줄은 뜯긴 게 아니라 높은 곳에서 깨끗이 잘렸다." },
  { statement: "C2", evidence: ["EV06"], crack: "d_blood", note: "의자 좌석에 피가 있다. 부인은 남편이 피를 흘린 뒤에 묶였다." },
  { statement: "C3", evidence: ["EV07"], crack: "d_glass", note: "찌꺼기는 한 잔에만 있다. 실제로 마신 사람은 둘이다." },
  { statement: "C3", evidence: ["EV16"], crack: "d_silver", note: "은식기는 훔쳐 간 게 아니라 연못에 버려졌다." },
  { statement: "C5", evidence: ["EV18"], crack: "d_randall", note: "정문의 세 남자가 랜들 일당일 수 없다." },
  { statement: "C7", evidence: ["EV17"], crack: "d_alibi", note: "시드넘에서 저택까지 마차로 40분. 숙소에 있었다는 말로는 그날 밤을 설명하지 못한다." },
];
// d_alibi는 personas_v2에 없는 게임용 반응이다.
const EXTRA_CRACKS = {
  croker: { d_alibi: "'40분이면 다녀올 수 있다는 거요? 내가 갔다는 증거라도 있소?' 하고 목소리가 낮아진다." },
};

// 판사 소환 심사. evidence 조건은 "열람했고 첨부한" 증거 기준.
// anyOf: 그 중 하나 이상, groups: 각 그룹에서 하나 이상.
const SUMMONS = {
  P1: {
    needMet: true,
    groups: [{ label: "부인 진술과 어긋나는 물증", ids: ["EV03", "EV06", "EV07", "EV16", "EV18"] }],
    approve: "부인의 진술과 현장 물증이 어긋난다는 점이 소명되었습니다. 메리 브래컨스톨 부인의 출석을 명합니다.",
    deny: "제출된 자료로는 부인의 진술이 사실과 다르다고 볼 근거가 부족합니다. 진술과 어긋나는 물증을 제출하십시오.",
  },
  P2: {
    needMet: true,
    groups: [{ label: "테레사 진술과 어긋나는 기록", ids: ["EV18"] }],
    altFlags: ["admitted:P1"],
    approve: "하녀 테레사 라이트의 진술을 다시 확인할 필요가 인정됩니다. 출석을 명합니다.",
    deny: "하녀가 거짓을 말했다고 볼 기록이 없습니다. 그녀가 본 '세 남자'에 대한 반대 기록을 가져오십시오.",
  },
  P4: {
    needMet: true,
    groups: [
      { label: "부인과 크로커를 잇는 기록", ids: ["EV19"] },
      { label: "범인의 신체 특징(키·선원 기술)", ids: ["EV04", "EV05", "EV20"] },
    ],
    approve: "피해자의 부인과 해상에서 연결된 인물이며, 현장에 남은 범인의 특징과 겹칩니다. 잭 크로커 선장의 출석을 명합니다.",
    deny: "이 사람을 사건과 묶을 근거가 부족합니다. 부인과의 관계를 보여 줄 기록과, 현장 흔적이 이 사람을 가리킨다는 자료를 함께 제출하십시오.",
  },
};

// 크로커 자백 조건(@croker_proof): 심문실에서 크로커에게 누적 제시한 증거가 아래 각 그룹을 하나 이상 포함.
const CROKER_PROOF = [
  { label: "관계", ids: ["EV19"] },
  { label: "선원 기술", ids: ["EV05"] },
  { label: "키", ids: ["EV04", "EV20"] },
  { label: "위장", ids: ["EV03", "EV06", "EV07", "EV16"] },
];
// 부인 부분 인정 조건(@lady_cracks>=3): 부인 진술(C1~C3)에서 얻은 서로 다른 crack 수.
const LADY_CRACKS = ["d_randall", "d_rope", "d_blood", "d_glass", "d_silver"];

// 결론 채점(첫 제출로 확정, 100점).
const SCORING = {
  culprit: { pid: "P4", points: 40 },
  method: { points: 15, keywords: /부지깽이/ },
  motive: { points: 15, keywords: /지팡이|때리|폭행|보호|지키|구하|사랑|정당방위|감싸/ },
  evidence: { points: 20, groups: CROKER_PROOF, perGroup: 5 },
  staging: { points: 10, keywords: /위장|꾸미|꾸몄|조작|강도.*(아니|없|거짓)|거짓.*강도/ },
};

// 증거가 열람되면 수사 기록 타임라인에 들어갈 확인된 시각.
const TIMELINE = {
  EV01: [{ time: "23:00–23:50", text: "유스터스 경 사망 추정 시각대(검시)" }],
  EV10: [{ time: "00:00", text: "식당에서 시신 발견" }],
  EV12: [{ time: "00:00", text: "비명 → 테레사가 먼저 내려가고 하인들이 깸" }],
  EV18: [{ time: "D+2 09:00", text: "랜들 일당 뉴욕에서 체포" }],
  EV17: [{ time: "—", text: "시드넘 ↔ 애비 그레인지 마차 약 40분" }],
  EV19: [{ time: "D+2", text: "크로커, 사우샘프턴에서 배스 록호 출항 예정" }],
};

module.exports = {
  LOCATIONS, SPOTS, START, PEOPLE, EXTRA_PROFILES, REFUSALS, NODES,
  OBJECTIONS, EXTRA_CRACKS, SUMMONS, CROKER_PROOF, LADY_CRACKS, SCORING, TIMELINE,
};
