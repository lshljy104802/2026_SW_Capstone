const { spawn } = require("node:child_process");
const os = require("node:os");
const fs = require("node:fs");
const path = require("node:path");

const USAGE_FILE = path.join(__dirname, "runtime", "usage.jsonl");
// 호출 기록 한 줄 추가. 실패해도 게임은 멈추지 않는다.
function logUsage(c, result, latency_ms) {
  try {
    const u = result.usage || {};
    const line = {
      ts: new Date().toISOString(),
      provider: c.provider,
      model: (result.model_runtime && result.model_runtime[0]) || c.model,
      role: c.role || "",
      input_tokens: u.input_tokens ?? u.prompt_tokens ?? null,
      output_tokens: u.output_tokens ?? u.completion_tokens ?? null,
      // 캐시로 처리된 입력. 구독 CLI는 프롬프트 대부분이 캐시로 잡혀 input_tokens만 보면 2처럼 작게 나온다.
      cache_read_tokens: u.cache_read_input_tokens ?? (u.prompt_tokens_details && u.prompt_tokens_details.cached_tokens) ?? (u.input_tokens_details && u.input_tokens_details.cached_tokens) ?? null,
      cache_write_tokens: u.cache_creation_input_tokens ?? null,
      latency_ms,
      ok: !!result.ok,
    };
    if (!result.ok && result.error) line.error = result.error;
    fs.mkdirSync(path.dirname(USAGE_FILE), { recursive: true });
    fs.appendFileSync(USAGE_FILE, JSON.stringify(line) + "\n");
  } catch {}
}
function config(env = process.env) {
  const one = (prefix) => {
    const provider =
      env[`ABBEY_${prefix}_PROVIDER`] ||
      env.ABBEY_PROVIDER ||
      (env.ANTHROPIC_API_KEY ? "anthropic" : "claude-cli");
    return {
    role: prefix.toLowerCase(),
    provider,
    model: env[`ABBEY_${prefix}_MODEL`] || (provider === "openai" ? "gpt-5-mini" : "claude-haiku-5-5"),
    effort: env[`ABBEY_${prefix}_EFFORT`] || "high",
    timeout_ms: Number(env[`ABBEY_${prefix}_TIMEOUT_MS`] || 60000),
    };
  };
  return { evaluator: one("EVALUATOR"), persona: one("PERSONA") };
}
// API 단가(US$/100만 토큰: 입력·출력·캐시 읽기·캐시 쓰기). scripts/usage-summary.cjs와 같은 표.
const PRICE = { "claude-haiku-5-5": [0.1, 0.5, 0.01, 0.125] };
function costOf(model, u) {
  const p = PRICE[model];
  if (!p || !u) return null;
  return ((u.input_tokens || 0) * p[0] + (u.output_tokens || 0) * p[1] + (u.cache_read_input_tokens || 0) * p[2] + (u.cache_creation_input_tokens || 0) * p[3]) / 1e6;
}
// Anthropic Messages API 스트리밍: 글자가 오는 대로 onText(지금까지 전체)를 부르고, 끝나면 일반 호출과 같은 모양을 돌려준다.
async function anthropicStream(c, system, prompt, onText) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), c.timeout_ms);
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY || "", "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: c.model, max_tokens: 4000, output_config: { effort: c.effort }, system, messages: [{ role: "user", content: prompt }], stream: true }),
      signal: controller.signal,
    });
    if (!response.ok || !response.body) return { ok: false, error: "api_error_" + response.status };
    const dec = new TextDecoder();
    let buf = "", text = "", model = null, stop = null;
    const usage = {};
    for await (const chunk of response.body) {
      buf += dec.decode(chunk, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim();
        buf = buf.slice(i + 1);
        if (!line.startsWith("data:")) continue;
        let ev;
        try { ev = JSON.parse(line.slice(5)); } catch { continue; }
        if (ev.type === "message_start" && ev.message) { model = ev.message.model; Object.assign(usage, ev.message.usage || {}); }
        else if (ev.type === "content_block_delta" && ev.delta && ev.delta.type === "text_delta") {
          text += ev.delta.text;
          try { onText(text); } catch {}
        } else if (ev.type === "message_delta") { if (ev.usage) Object.assign(usage, ev.usage); if (ev.delta && ev.delta.stop_reason) stop = ev.delta.stop_reason; }
        else if (ev.type === "error") return { ok: false, error: "api_stream_error" };
      }
    }
    return { ok: true, text, model_runtime: model ? [model] : [], usage, stop_reason: stop };
  } catch {
    return { ok: false, error: "api_unavailable" };
  } finally {
    clearTimeout(timer);
  }
}
async function generateRaw(c, system, prompt, onText) {
  if (c.provider === "rule") return { ok: false, error: "rule" };
  if (c.provider === "anthropic" && onText) return anthropicStream(c, system, prompt, onText);
  if (c.provider === "anthropic") {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), c.timeout_ms);
      try {
        const response = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-api-key": process.env.ANTHROPIC_API_KEY || "",
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: c.model,
            max_tokens: 4000,
            output_config: { effort: c.effort },
            system,
            messages: [{ role: "user", content: prompt }],
          }),
          signal: controller.signal,
        });
        const data = await response.json();
        return response.ok
          ? {
              ok: true,
              text: (data.content || [])
                .filter((x) => x.type === "text")
                .map((x) => x.text)
                .join("\n"),
              model_runtime: data.model ? [data.model] : [],
              usage: data.usage || null,
              stop_reason: data.stop_reason || null,
            }
          : { ok: false, error: "api_error_" + response.status };
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return { ok: false, error: "api_unavailable" };
    }
  }
  if (c.provider === "openai") {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), c.timeout_ms);
      try {
        const response = await fetch("https://api.openai.com/v1/responses", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            authorization: "Bearer " + (process.env.OPENAI_API_KEY || ""),
          },
          body: JSON.stringify({
            model: c.model,
            instructions: system,
            input: prompt,
            max_output_tokens: 1500,
          }),
          signal: controller.signal,
        });
        const data = await response.json();
        if (!response.ok) return { ok: false, error: "api_error_" + response.status };
        let text = typeof data.output_text === "string" ? data.output_text : "";
        if (!text) {
          text = (data.output || [])
            .filter((o) => o.type === "message")
            .flatMap((o) => o.content || [])
            .filter((x) => x.type === "output_text")
            .map((x) => x.text)
            .join("");
        }
        return {
          ok: true,
          text,
          model_runtime: data.model ? [data.model] : [],
          usage: data.usage || null,
        };
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return { ok: false, error: "api_unavailable" };
    }
  }
  // 36번: 로컬 모델(Ollama). 모델 비교 실험(exaone·qwen·gemma 등)용. 주소는 OLLAMA_HOST(기본 127.0.0.1:11434).
  if (c.provider === "ollama") {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), c.timeout_ms);
    try {
      const host = (process.env.OLLAMA_HOST || "http://127.0.0.1:11434").replace(/\/$/, "");
      const response = await fetch(host + "/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          model: c.model, stream: false, keep_alive: process.env.OLLAMA_KEEP_ALIVE || "10m",
          messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
          options: { num_ctx: Number(process.env.OLLAMA_NUM_CTX || 8192), temperature: Number(process.env.OLLAMA_TEMPERATURE || 0.7) },
        }),
        signal: controller.signal,
      });
      const data = await response.json();
      if (!response.ok) return { ok: false, error: "api_error_" + response.status };
      let text = (data.message && data.message.content) || "";
      text = text.replace(/<think>[\s\S]*?<\/think>/g, "").trim(); // 생각 출력 모델 대비
      if (onText) try { onText(text); } catch {}
      return { ok: true, text, model_runtime: [c.model], usage: { input_tokens: data.prompt_eval_count || 0, output_tokens: data.eval_count || 0 }, stop_reason: data.done_reason === "length" ? "max_tokens" : data.done_reason || null };
    } catch {
      return { ok: false, error: "api_unavailable" };
    } finally {
      clearTimeout(timer);
    }
  }
  if (c.provider !== "claude-cli")
    return { ok: false, error: "unknown_provider" };
  return new Promise((resolve) => {
    let out = "",
      done = false;
    const cwd = path.join(os.tmpdir(), "abbey-claude");
    fs.mkdirSync(cwd, { recursive: true });
    const args = [
      "-p",
      "--model",
      c.model,
      "--system-prompt",
      system,
      "--tools",
      "",
      "--setting-sources",
      "",
      "--strict-mcp-config",
      "--no-session-persistence",
      "--output-format",
      "json",
      "--effort",
      c.effort,
    ];
    let child;
    try {
      child = spawn(process.env.ABBEY_CLAUDE_BIN || "claude", args, {
        cwd,
        windowsHide: true,
        shell: false,
      });
    } catch {
      return resolve({ ok: false, error: "spawn_failed" });
    }
    const timer = setTimeout(() => {
      child.kill();
      finish({ ok: false, error: "timeout" });
    }, c.timeout_ms);
    function finish(value) {
      if (!done) {
        done = true;
        clearTimeout(timer);
        resolve(value);
      }
    }
    child.stdout.on("data", (data) => {
      if (out.length < 100000) out += data;
    });
    child.stderr.on("data", () => {}); // Drain stderr without exposing credentials or filling the pipe.
    child.stdin.on("error", () => finish({ ok: false, error: "stdin_failed" }));
    child.on("error", () => finish({ ok: false, error: "spawn_failed" }));
    child.on("close", () => {
      try {
        const data = JSON.parse(out);
        finish(
          data.is_error
            ? { ok: false, error: "cli_error" }
            : {
                ok: true,
                text: data.result,
                model_runtime: Object.keys(data.modelUsage || {}),
                usage: data.usage || null,
              },
        );
      } catch {
        finish({ ok: false, error: "invalid_output" });
      }
    });
    child.stdin.end(prompt);
  });
}
// All sessions share three slots, so simultaneous model calls cannot overload the host.
let active = 0;
const waiting = [];
async function acquire() {
  if (active < 3) {
    active++;
    return;
  }
  await new Promise((resolve) => waiting.push(resolve));
}
function release() {
  const next = waiting.shift();
  if (next) next();
  else active--;
}
async function generate(c, system, prompt, onText) {
  const started = Date.now();
  await acquire();
  try {
    const result = await generateRaw(c, system, prompt, onText);
    const latency_ms = Date.now() - started;
    if (c.provider !== "rule") logUsage(c, result, latency_ms);
    const model = (result.model_runtime && result.model_runtime[0]) || c.model;
    const cost = c.provider === "claude-cli" ? null : c.provider === "ollama" ? 0 : costOf(model, result.usage); // 로컬은 API 비용 0
    return { ...result, latency_ms, cost_usd: cost };
  } catch {
    const latency_ms = Date.now() - started;
    const result = { ok: false, error: "provider_unavailable" };
    logUsage(c, result, latency_ms);
    return { ...result, latency_ms };
  } finally {
    release();
  }
}
module.exports = { config, generate, costOf };
