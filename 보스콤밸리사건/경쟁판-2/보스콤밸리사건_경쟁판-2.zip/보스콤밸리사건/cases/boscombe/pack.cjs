// 사건 팩: 「보스콤 밸리 사건」. ① 페르소나 파트가 보낸 키트(data/boscombe_personas.json, 스키마 v5)를 정본으로 읽어 사건 팩 형식으로 묶는다.
// 인물 프로필·지식 문장·해금 단계·가드레일·누설 패턴·증거·정답은 전부 JSON에서 가져온다. 이 파일이 보태는 것은
// (1) 지식 문장을 어떤 질문 주제에 묶을지(topic·keywords), (2) 지도 좌표, (3) 모를 때·잡담 대사, (4) 추리 카드에 대한 경감의 반응 대사뿐이다.
// 증거는 ② 증거 파트가 보낸 data/boscombe_case.json(증거 17건, 관찰 문장·해석·한계·배제 근거)을 정본으로 읽는다. 원문 목록은 docs/boscombe_증거목록.md.
// 대응표와 근사한 부분은 docs/boscombe_persona_연결.md.
const kit = require("../../data/boscombe_personas.json");
const cs = require("../../data/boscombe_case.json");
const VOICE = require("./voice.cjs"); // 36번: 인물 말투 정본 대사(SAY)와 증거 설명(EV)

const CH = Object.fromEntries(kit.characters.map((c) => [c.id, c]));
const PID = { james_mccarthy: "P1", john_turner: "P2", alice_turner: "P3", patience_moran: "P4", william_crowder: "P5", inspector_lestrade: "P6" };
const KEY = { james_mccarthy: "james", john_turner: "turner", alice_turner: "alice", patience_moran: "patience", william_crowder: "crowder", inspector_lestrade: "lestrade" };

// 키트 지식 문장 꺼내기: kn("james_mccarthy", 0, [1,2]) = base_knowledge 1·2번째, tier>0이면 그 단계의 unlocked_knowledge
function kn(cid, tier, idxs) {
  const c = CH[cid];
  const list = tier === 0 ? c.base_knowledge : c.unlock_tiers.find((t) => t.tier === tier).unlocked_knowledge;
  const picked = idxs ? idxs.map((i) => list[i - 1]) : list;
  if (picked.some((x) => !x)) throw new Error(`boscombe: 지식 항목 없음 ${cid} T${tier} ${idxs}`);
  return picked.map((x) => x.content).join(" ");
}
const tierFlags = (cid, tier) => CH[cid].unlock_tiers.find((t) => t.tier === tier).sets_flags.map((f) => `f:${f}`);
const tierDone = (cid, tier) => `f:${cid}.t${tier}`;

// ── 인물
const EXTRA = {
  james_mccarthy: {
    location: "prison", stance: "cooperative", visibleWhen: ["loc:prison"],
    lines: { unknown: "…그건 저도 모르겠습니다. 정말입니다.", meta: "무슨 말씀이신지… 저는 제가 겪은 일밖에 모릅니다.", smalltalk: "…예. 찾아와 주셔서 고맙습니다." },
  },
  john_turner: {
    location: "hall", stance: "refusing", visibleWhen: [],
    lines: { unknown: "…그건 내가 알 수 없는 일이오.", meta: "무슨 소린지 모르겠소. 늙은이를 놀리지 마시오.", smalltalk: "…앉으시오. 오래 말하기는 힘드오." },
  },
  alice_turner: {
    location: "hotel", talkAt: ["hall"], stance: "cooperative", visibleWhen: [],
    lines: { unknown: "그건 저도 몰라요. 정말이에요.", meta: "무슨 말씀이신지 모르겠어요. 지금 중요한 건 제임스예요.", smalltalk: "와 주셔서 정말 감사해요. 제임스를 꼭 도와주세요." },
  },
  patience_moran: {
    location: "lodge", stance: "cooperative", visibleWhen: [],
    lines: { unknown: "모, 몰라요… 전 못 봤어요.", meta: "…무슨 말인지 모르겠어요.", smalltalk: "…안녕하세요." },
    cracks: { hand_not_blow: "저, 저는… 때리는 건 못 봤어요. 손을 든 것만 보고 도망쳤어요." },
  },
  william_crowder: {
    location: "preserve", stance: "cooperative", visibleWhen: [],
    lines: { unknown: "그건 제가 본 게 아니라 모릅니다요.", meta: "무슨 말씀인지 통 모르겠습니다요.", smalltalk: "예, 나리. 뭘 물으시렵니까." },
    cracks: { follow_guess: "…듣고 보니 따라간다는 건 제 짐작이었습니다요. 같은 쪽으로 갔다는 것만 봤습니다요." },
  },
  inspector_lestrade: {
    location: "hotel", companion: true, stance: "cooperative", visibleWhen: [],
    lines: { unknown: "그건 내가 확인한 사실이 아니오.", meta: "무슨 뚱딴지같은 소리요. 사실을 다루기도 벅차오.", smalltalk: "오셨소. 헛걸음이 되지 않길 바라오." },
  },
};

function guideOf(c) {
  return (hasFlag) => {
    const g = [];
    for (const b of c.beliefs || []) g.push(`신념(사실이 아니라 내 의견으로만 말한다): ${b.content}`);
    for (const t of c.behavior_tells || []) g.push(`행동 단서(지문·서술로 쓰지 말고 말투와 머뭇거림으로만 드러낸다): ${t}`);
    if (c.cover_story) {
      g.push(`숨기는 방식 - 해도 되는 말: ${c.cover_story.allowed_statements.join(" / ")}`);
      g.push(`숨기는 방식 - 하지 않는 것: ${c.cover_story.forbidden.join(" / ")}`);
    }
    for (const d of c.deflection_policies || []) {
      if (d.until_tier < 99 && hasFlag(tierDone(c.id, d.until_tier))) continue; // 그 단계가 열리면 회피를 멈춘다
      const topic = kit.topics.find((t) => t.id === d.topic_id);
      g.push(`회피 주제 '${topic ? topic.label : d.topic_id}': ${d.policy}`);
    }
    for (const r of c.special_rules || []) g.push(`특수 규칙: ${r}`);
    g.push(`내가 알 수 있는 범위: ${c.knowledge_boundary.perception_scope}`);
    g.push(`내가 모르는 것(물으면 모른다고 답한다): ${c.knowledge_boundary.does_not_know.join(" / ")}`);
    return g;
  };
}

const people = kit.characters.map((c) => {
  const x = EXTRA[c.id];
  const p = c.profile;
  return {
    pid: PID[c.id], key: KEY[c.id], name: c.name, role: c.role,
    stance: x.stance, location: x.location, companion: x.companion, talkAt: x.talkAt, visibleWhen: x.visibleWhen,
    profile: { voice: `${p.speech_style} 성격: ${p.personality.join(", ")}. ${p.age}, ${p.occupation}.`, look: p.appearance },
    lines: x.lines,
    cracks: x.cracks || {},
    guide: guideOf(c),
  };
});

// ── 지식 노드. base_knowledge는 주제별로 묶어 조건 없는 노드로, unlock_tiers는 조건부 노드로.
// 키트의 trust·pressure 수치 조건은 이 엔진에 없으므로 주제 조건(topic) 쪽 갈래만 옮겼다.
const J = "james_mccarthy", T = "john_turner", A = "alice_turner", P = "patience_moran", C = "william_crowder", L = "inspector_lestrade";
const N = (id, cid, o) => ({ id, pid: PID[cid], place: cid === T ? "interrogation" : "any", requires: [], grants: [], ...o });
const tier = (id, cid, n, o) => N(id, cid, { text: kn(cid, n), ...o, grants: [...tierFlags(cid, n), tierDone(cid, n), ...(o.grants || [])] });

const nodes = [
  // 제임스 매카시 (감옥 면회 뒤)
  N("J_return", J, { topic: "브리스톨에서 돌아온 날 아침의 일, 귀가했을 때 아버지가 집에 있었나, 마차", keywords: /아침|귀가|돌아왔|돌아온|마차|콥/, text: kn(J, 0, [1, 2]) }),
  N("J_walk", J, { topic: "왜 연못 쪽으로 갔나, 총을 들고 나간 이유, 아버지를 따라간 것인가, 사냥터지기 크라우더를 봤나", keywords: /토끼|총|따라|크라우더|왜.*연못/, text: kn(J, 0, [3]) }),
  N("J_cooee", J, { topic: "쿠이(Cooee) 외침, 그 신호가 무엇인가, 아버지가 왜 쿠이를 외쳤나, 아버지를 만났을 때 반응", keywords: /쿠이|cooee|신호|외침|외쳤/i, text: kn(J, 0, [4, 11]) }),
  N("J_quarrel", J, { topic: "아버지와 다툰 사실 자체, 다툰 뒤 어떻게 헤어졌나(이유는 해당 없음)", keywords: /다퉜|다툼|싸웠|싸움|언성|헤어/, text: kn(J, 0, [5]) }),
  N("J_death", J, { topic: "비명을 듣고 돌아갔을 때, 아버지의 임종, 마지막으로 남긴 말, 'a rat'(쥐)", keywords: /비명|임종|마지막|유언|쥐|rat|숨[을이]/i, text: kn(J, 0, [6, 7]) }),
  N("J_grey", J, { topic: "땅에 있던 회색 물건, 회색 천·외투, 사라진 것", keywords: /회색|천 |외투|망토|사라[진졌]/, text: kn(J, 0, [8]) }),
  N("J_after", J, { topic: "아버지가 숨진 뒤 한 일, 숲지기 집에 도움을 청함, 주변에 누가 있었나, 아버지에게 원수가 있었나", keywords: /숲지기|도움|원수|원한|누가.*있|아무도/, text: kn(J, 0, [9, 10]) }),
  N("J_arrest", J, { topic: "체포될 때 한 말, '받아 마땅한 벌'이라고 한 것", keywords: /체포|마땅|벌이라/, text: kn(J, 0, [12]) }),
  // 36번: 키트의 신뢰 갈래를 되살렸다. J_T1 = 앨리스 전언 또는 신뢰 45 이상, J_T2 = 신뢰 65 이상 또는 비밀 보장 약속.
  tier("J_T1", J, 1, { topic: "앨리스가 무죄를 믿는다는 전언을 전함, 아버지와 말다툼한 진짜 이유, 손을 치켜든 이유", keywords: /무죄를 믿|전해|전언|이유|왜.*(다투|다퉜|싸)|손을/, requires: ["@J_T1_gate"] }),
  tier("J_T2", J, 2, { topic: "브리스톨에서 사흘 동안 누구와 무엇을 했나, 앨리스에게 청혼하지 못하는 이유, 비밀을 지키겠다는 약속", keywords: /브리스톨|사흘|비밀|청혼.*못/, requires: ["k:J_T1", "@J_T2_gate"] }),

  // 존 터너 (쪽지로 불러낸 뒤, 호텔 응접실)
  N("T_past", T, { topic: "호주 시절과 재산을 모은 경위(금광), 영지, 가족, 아내, 딸", keywords: /호주|금광|재산|영지|아내|가족/, text: kn(T, 0, [1, 3]) }),
  N("T_mccarthy", T, { topic: "찰스 매카시와 어떤 사이였나, 해덜리 농장을 내준 이유", keywords: /매카시|해덜리|농장|어떤 사이|관계/, text: kn(T, 0, [2]) }),
  N("T_health", T, { topic: "건강, 병, 의사의 말", keywords: /건강|병|당뇨|의사|몸/, text: kn(T, 0, [4]) }),
  N("T_marriage", T, { topic: "앨리스와 제임스의 결혼에 대한 생각", keywords: /결혼|혼인|사위/, text: kn(T, 0, [5]) }),
  N("T_note", T, { topic: "왜 호텔로 직접 왔나, 쪽지를 받았나", keywords: /쪽지|호텔|왜.*왔|찾아오/, text: kn(T, 0, [6]) }),
  tier("T_T1", T, 1, { topic: "매카시와의 진짜 관계, 쿠이 신호가 호주식이라는 지적, 'a rat'이 발라랏이라는 지적, 빅토리아 지도, 협박당했는가", keywords: /쿠이|cooee|발라랏|ballarat|지도|빅토리아|협박|쥐|rat/i, requires: ["@turner_crack"], grants: ["admitted:P2"] }),
  tier("T_T2", T, 2, { topic: "그날 연못에 있었는지 정면 추궁, 당신이 매카시를 죽였는가, 연못에서 한 일을 사실대로 말하라는 요구", keywords: /죽였|연못|범인|자백|사실대로|쳤/, accuse: true, requires: ["k:T_T1", "@turner_proof"], grants: ["confessed:P2"] }),
  tier("T_T3", T, 3, { topic: "무엇으로 협박을 받았나, 호주에서 저지른 과거, 딸 앨리스에게는 알리지 않겠다는 약속", keywords: /과거|무엇으로|발라랏|알리지|약속|따님|딸/, requires: ["k:T_T2", "@T_T3_gate"] }),

  // 앨리스 터너
  N("A_james", A, { topic: "제임스는 어떤 사람인가, 제임스가 무죄라고 믿는 이유", keywords: /제임스|무죄|결백|어떤 사람/, text: kn(A, 0, [1]) }),
  N("A_hire", A, { topic: "왜 경감과 탐정을 불렀나, 의뢰 경위", keywords: /경감|레스트레이드|고용|의뢰|불렀/, text: kn(A, 0, [2]) }),
  N("A_father", A, { topic: "아버지 존 터너의 건강, 면회가 가능한가, 아버지는 어디서 돈을 벌었나", keywords: /건강|면회|박사|편찮|병환|몸져/, text: kn(A, 0, [3, 4]) }),
  tier("A_T1", A, 1, { topic: "매카시 부자가 다툰 이유, 제임스와 앨리스의 결혼·약혼 이야기", keywords: /다툼|다퉜|다툰|싸|결혼|약혼|청혼/, grants: [] }),
  // 키트: 신뢰 60 이상(초기값 60). 앨리스를 몰아세워 신뢰가 떨어지면 다시 쌓기 전까지 닫힌다.
  tier("A_T2", A, 2, { topic: "아버지와 매카시 씨는 어떤 사이였나, 두 사람이 어떻게 알게 됐나, 아버지의 호주·빅토리아 시절 과거", keywords: /어떤 사이|관계|어떻게 알|과거|시절|빅토리아|옛날/, requires: ["m:P3:trust>=60"], grants: ["loc:telegraph"] }),

  // 페이션스 모런
  N("P_see", P, { topic: "그날 어디서 무엇을 봤나, 매카시 부자의 다툼, 아들이 손을 치켜든 것", keywords: /봤|보았|그날|다툼|다투|싸|꽃|손/, text: kn(P, 0) }),
  // 키트: 신뢰 40 이상·압박 50 이하. 압박 상한은 계기판으로, 신뢰 하한은 '추궁조가 아닐 것'(calm)으로 근사한다(초기 신뢰 20).
  tier("P_T1", P, 1, { topic: "다정하게 안심시키며 묻는 말, 도망쳐 집에 온 뒤의 일, 제임스가 숲지기 집에 왔을 때의 모습", keywords: /괜찮|무서워하지|천천히|그 ?(뒤|다음|후)|집에|도망/, requires: ["k:P_see", "m:P4:pressure<=50"], calm: true }),

  // 윌리엄 크라우더
  N("C_see", C, { topic: "그날 오후 무엇을 봤나, 매카시와 아들 제임스가 지나가는 모습", keywords: /봤|보았|그날|매카시|제임스|총|오후/, text: kn(C, 0) }),
  // 증거 파트의 EV_STAFF_REGISTER(이 지방 태생, 해외 기록 없음)와 맞춘 설정. 키트에는 없는 문장이라 팩에서 보탠다.
  N("C_origin", C, { topic: "크라우더는 어디 출신인가, 호주나 해외에 나간 적이 있나, 영지에서 얼마나 일했나", keywords: /고향|출신|태어|해외|외국|호주에|몇 년|얼마나 일/, text: "나는 이 지방에서 태어나 줄곧 터너 씨 영지에서 일해 왔다. 해외에 나가 본 적은 없다." }),
  tier("C_T1", C, 1, { topic: "아들이 정말 아버지를 따라간 것인가, 아들이 앞의 아버지를 봤는지 확실한가, 짐작이 아닌가", keywords: /따라|짐작|확실|정말|몰랐/ }),

  // 레스트레이드 경감 (수사 동행)
  N("L_case", L, { topic: "사건 개요, 지금까지 파악된 사실, 목격자, 체포 경위, 누가 범인이라고 보는가", keywords: /사건|개요|체포|범인|파악|목격/, text: `${kit.scenario.public_briefing.slice(4, 9).join(" ")} ${kn(L, 0, [2])}` }),
  N("L_hire", L, { topic: "누가 왜 경감을 고용했나, 탐정을 부른 경위", keywords: /앨리스|고용|의뢰|불렀/, text: kn(L, 0, [3]) }),
  N("L_paper", L, { topic: "검시 기록·신문 기사를 어디서 볼 수 있나, 의사 소견", keywords: /신문|검시|기록|소견/, text: kn(L, 0, [5]) }),
  tier("L_T1", L, 1, { topic: "제임스를 만나고 싶다, 감옥 면회 허가", keywords: /면회|감옥|만나/, grants: ["loc:prison"] }),
  tier("L_T2", L, 2, { topic: "현장(보스콤 연못)을 보고 싶다, 현장 안내, 경감이 현장에서 조사한 것, 해덜리 농장", keywords: /현장|연못|안내|수색|해덜리|농장/, text: `${kn(L, 0, [4])} ${kn(L, 2)}`, grants: ["loc:pond", "loc:hatherley"] }),
  tier("L_T3", L, 3, { topic: "터너 씨는 어떤 사람인가, 터너와 매카시의 관계, 터너의 건강", keywords: /터너|은인|소문/ }),
];

// 정본 대사: 지식 문장(메모체)과 같은 사실을 그 인물의 말투로. 규칙 모드·대체 때 이 대사가 나간다.
for (const n of nodes) {
  if (!VOICE.SAY[n.id]) throw new Error(`boscombe: 말투 대사 없음 ${n.id}`);
  n.say = VOICE.SAY[n.id];
}

// ── 추리 카드(deductions): 원작에서 탐정이 경감에게 추리를 말하면 경감이 비웃는다. 전제 증거·사실을 갖춘 뒤
// 플레이어가 그 추리를 직접 말하면 성립(k:DD_*)하고, 경감은 받아들이지 않는 반응만 한다(G04: 추리의 옳고 그름을 확인해 주지 않는다).
const reqOf = (cond) => (cond.all || []).map((c) => (c.type === "flag" ? `f:${c.flag}` : c.type === "evidence_owned" ? `ev:${c.evidence_id}` : null)).filter(Boolean);
const DD = {
  DD_APPOINTMENT_NOT_SON: [/약속.*(아들|제임스)|(아들|제임스).*약속/, "3시 약속 상대가 아들이 아니라고? 아버지가 아들이 어디 있는지 몰랐다 한들, 그게 아들이 죽이지 않았다는 사실이 되진 않소."],
  DD_COOEE_AUSTRALIAN: [/쿠이.*호주|호주.*쿠이|cooee.*호주|호주.*cooee/i, "외침 한마디로 호주 사람을 찾겠다는 거요? 공상이 지나치시오. 나는 사실만 다루겠소."],
  DD_RAT_BALLARAT: [/발라랏|ballarat/i, "죽어 가는 사람의 웅얼거림을 지도 위 지명에 갖다 붙이다니. 재미있는 이야기지만 배심원이 들어 줄 사실은 아니오."],
  DD_GREY_CLOAK_RETURN: [/망토|회색.*(가져|되찾|돌아|집어)/, "누군가 회색 옷을 떨어뜨렸다가 도로 집어 갔다? 그걸 본 사람은 피의자 한 사람뿐이오. 나는 그 말을 사실로 치지 않소."],
  DD_LEFT_HANDED: [/왼손/, "왼손잡이라… 왼손잡이 신사를 찾아 시골을 돌아다닐 순 없소. 경찰청의 웃음거리가 될 거요."],
  DD_LAME_RIGHT_LEG: [/(다리|발).*(절|전다|저는)|절름/, "다리를 저는 사람이라. 발자국 몇 개로 거기까지 가다니, 그런 건 내 수사 방식이 아니오."],
  DD_LOCAL_PERSON: [/(이 지역|근처|영지|동네|이곳).*(사람|익숙)|외부인이 아니/, "이 근방 사람이라… 그야 그렇겠지. 나는 그 근방 사람이 바로 피의자라고 보고 있소."],
};
// 전제 보정(증거 파트 증거에 맞춤): '이 지역 사람'은 연못 지형이 근거이고, '약속 상대는 아들이 아니다'는 마부의 증언이 있어야 한다.
const DD_REQ = {
  DD_LOCAL_PERSON: ["ev:EV_POOL_LAYOUT"],
  DD_APPOINTMENT_NOT_SON: (base) => [...base, "ev:EV_GROOM_APPOINTMENT"],
};
for (const d of kit.deductions) {
  const [keywords, text] = DD[d.id];
  const base = reqOf(d.requires);
  const over = DD_REQ[d.id];
  nodes.push(N(d.id, L, { topic: `(질문이 아니라) 탐정이 스스로 이 추리를 말함: ${d.claim}`, keywords, requires: typeof over === "function" ? over(base) : over || base, text, deduction: true }));
}

// ── 장소
// 장소 안내: 위에서부터 조건이 맞는 것 최대 두 줄. when(모두 충족) 뒤, until 전까지 보인다. 결론은 말하지 않고 '어디를 무엇으로 볼지'만 짚는다.
const HINTS = {
  hotel: [
    { until: "loc:pond", text: "사건 현장(연못과 농장)은 동행한 경감에게 안내를 청해야 갈 수 있다." },
    { until: "loc:prison", text: "제임스는 헤리퍼드 감옥에 있다. 직접 만나려면 경감에게 면회를 청해야 한다." },
    { until: "ev:EV_SURGEON_REPORT", text: "탁자 위 신문 다발에는 기사 말고도 주간지에 실린 검시 기록 전문이 있다. 상처가 어디에 났는지까지 적혀 있다." },
    { until: "k:A_T1", text: "앨리스 양은 제임스가 아버지와 다툰 까닭을 짐작하는 눈치다. 두 사람의 혼담을 꺼내 볼 만하다." },
    { when: ["k:A_T1"], until: "loc:telegraph", text: "앨리스 양의 아버지와 죽은 매카시 씨는 오래전부터 아는 사이였다고 한다. 두 노인이 어디서 처음 만났는지 물어볼 수 있다." },
    { when: ["ev:EV_TIPTOE_TRACKS"], until: "k:L_T3", text: "경감은 터너 씨와 매카시 씨 사이의 소문을 알고 있다. 터너 씨가 어떤 사람인지 물어볼 수 있다." },
  ],
  telegraph: [
    { until: "ev:EV_VICTORIA_MAP", text: "전보로 브리스톨에 지도를 청할 수 있다. 터너 씨와 매카시 씨가 젊은 날을 보낸 빅토리아 식민지의 지도다." },
    { when: ["ev:EV_VICTORIA_MAP"], until: "cmb:CB_RAT", text: "지도 위 지명을 검시 기록 속 임종의 말과 맞대기 보드에서 맞대 볼 수 있다." },
  ],
  prison: [
    { until: "k:J_arrest", text: "제임스는 체포될 때 이상한 말을 남겼다. 그 말을 왜 했는지 직접 물어볼 수 있다." },
    { until: "k:J_T1", text: "제임스는 아버지와 다툰 까닭을 끝내 말하지 않는다. 그가 아끼는 사람의 말을 전하면 마음이 풀릴지 모른다." },
    { when: ["k:J_T1"], until: "k:J_T2", text: "브리스톨에서 보낸 사흘에 대해서는 아직 말을 아낀다. 비밀을 지키겠다고 약속해 보라." },
    { until: "k:J_death", text: "아버지가 숨을 거두기 전 남긴 말을 제임스만 들었다." },
    { until: "k:J_grey", text: "제임스는 아버지 곁 땅바닥에서 무언가를 본 것 같다고 했다." },
  ],
  hall: [
    { until: "met:P2", text: "터너 씨는 병석에 있다. 앨리스 양은 이 저택에서도 만날 수 있다." },
    { when: ["met:P2"], until: "summoned:P2", text: "터너 씨는 직접 만나 주지 않는다. 판사의 허가로 쪽지를 보내면 호텔로 나올지 모른다(호텔 응접실)." },
  ],
  preserve: [
    { until: "k:C_see", text: "사냥터지기 크라우더가 그날 오후 매카시 부자가 지나가는 것을 봤다." },
    { when: ["k:C_see"], until: "broken:S1", text: "'아들이 아버지를 따라가는 것 같았다'는 말이 정말 본 것인지 짐작인지 짚어 볼 만하다. 마부의 증언이나 이의 제기, 대질이 길이다." },
    { until: "k:C_origin", text: "크라우더가 어디 출신인지, 이 영지에서 얼마나 일했는지는 아직 모른다." },
  ],
  lodge: [
    { until: "ev:EV_WOOD_PATH", text: "숲지기 모런은 영지 사람들을 잘 안다. 현장의 흔적이 숲길 쪽으로 이어지는 것을 확인한 뒤라면 물어볼 것이 생긴다." },
    { until: "k:P_see", text: "숲지기의 딸 페이션스는 그날 숲 가장자리에 있었다." },
    { when: ["k:P_see"], until: "k:P_T1", text: "페이션스는 겁에 질려 있다. 다그치지 말고 천천히 물으면 그 뒤의 일을 말해 줄지 모른다." },
    { when: ["ev:EV_WOOD_PATH"], until: "ev:EV_TURNER_HAND", text: "모런에게 영지 주인 터너 씨의 걸음걸이와 손버릇을 물어볼 수 있다." },
  ],
  pond: [
    { until: "ev:EV_BOOTS_HATHERLEY", text: "풀밭에 발자국이 뒤섞여 있다. 누구의 것인지 가려내려면 매카시 부자의 장화가 기준이 된다(해덜리 농장)." },
    { when: ["ev:EV_BOOTS_HATHERLEY"], until: "ev:EV_TIPTOE_TRACKS", text: "장화 모양을 알았으니, 시신 자리 주변 발자국을 하나씩 대 보면 어느 것이 누구의 것인지 갈린다." },
    { when: ["ev:EV_TIPTOE_TRACKS"], until: "ev:EV_WOOD_PATH", text: "낯선 자국은 너도밤나무 쪽과 숲길 쪽으로 이어진다." },
    { when: ["ev:EV_TIPTOE_TRACKS"], until: "k:DD_LAME_RIGHT_LEG", text: "낯선 자국의 왼발과 오른발 깊이가 다르다. 그 사람의 걸음을 경감에게 말해 볼 수 있다." },
  ],
  beech: [
    { until: "ev:EV_STONE_WEAPON", text: "누군가 이 나무 뒤에 한참 서 있었던 것 같다. 땅바닥과 이끼 사이를 살펴보라." },
    { when: ["ev:EV_BEECH_CIGAR", "ev:EV_TIPTOE_TRACKS"], until: "cmb:CB_WAIT", text: "나무 뒤 흔적과 까치발 자국을 맞대기 보드에서 맞대 보면 그 사람이 무엇을 했는지 보인다." },
    { when: ["ev:EV_STONE_WEAPON"], until: "cmb:CB_WEAPON", text: "돌과 검시 기록을 맞대 보라. 상처와 맞는지 볼 수 있다." },
  ],
  woodpath: [
    { until: "ev:EV_WOOD_PATH", text: "까치발 자국이 큰길 쪽으로 이어진다. 끝까지 따라가 보라." },
    { when: ["ev:EV_WOOD_PATH"], until: "ev:EV_TURNER_GAIT", text: "숲길 끝은 숲지기 집과 가깝다. 이 길을 자주 오가는 사람을 숲지기가 알 것이다." },
  ],
  hatherley: [
    { until: "ev:EV_BOOTS_HATHERLEY", text: "하녀에게 매카시 부자의 장화를 보여 달라고 할 수 있다. 연못가 발자국을 가려낼 기준이 된다." },
    { until: "ev:EV_RENT_RECORD", text: "농장 임대 서류가 남아 있다. 매카시가 어떤 조건으로 이 농장에 살았는지 보여 준다." },
    { when: ["ev:EV_RENT_RECORD"], until: "cmb:CB_RENT", text: "임대 서류를 신문 기사와 맞대 보면 두 집안의 관계가 달리 보인다." },
  ],
};
const locations = [
  { id: "interrogation", name: "호텔 응접실", kind: "interrogation", x: 0, y: 0, start: true },
  { id: "hotel", name: "로스의 호텔(헤리퍼드 암스)", kind: "offsite", x: 800, y: 120, start: true, art: "lodging" },
  { id: "telegraph", name: "로스 전신국", kind: "offsite", x: 800, y: 270, art: "records" },
  { id: "prison", name: "헤리퍼드 감옥", kind: "offsite", x: 800, y: 420 },
  { id: "hall", name: "터너 저택", kind: "estate", x: 480, y: 110, start: true, art: "house" },
  { id: "preserve", name: "터너 영지 사냥터", kind: "estate", x: 300, y: 170, start: true, shape: "field" },
  { id: "lodge", name: "숲지기 집", kind: "estate", x: 130, y: 130, start: true },
  { id: "pond", name: "보스콤 연못", kind: "estate", x: 330, y: 320, shape: "pond", art: "pond" },
  { id: "beech", name: "숲 가장자리 너도밤나무", kind: "estate", x: 500, y: 380, shape: "tree" },
  { id: "woodpath", name: "숲길(큰길까지)", kind: "estate", x: 584, y: 236, shape: "field" },
  { id: "hatherley", name: "해덜리 농장", kind: "estate", x: 130, y: 400 },
].map((l) => (HINTS[l.id] ? { ...l, hints: HINTS[l.id] } : l));

// 다음 실마리: 어느 장소에서든 화면 위에 한 줄. 위에서부터 처음 걸리는 것 하나만 보인다.
const leads = [
  { go: {pid:"P6"}, until: "loc:pond", text: "현장(보스콤 연못·해덜리 농장)은 동행한 레스트레이드 경감에게 안내를 청해야 열린다." },
  { go: {pid:"P6"}, until: "loc:prison", text: "갇혀 있는 제임스 매카시를 만나려면 경감에게 감옥 면회를 청하라." },
  { go: {loc:"hatherley"}, until: "ev:EV_BOOTS_HATHERLEY", text: "연못가 발자국을 가려내려면 먼저 해덜리 농장에서 매카시 부자의 장화를 봐 둬야 한다." },
  { go: {loc:"pond"}, until: "ev:EV_TIPTOE_TRACKS", text: "보스콤 연못의 발자국을 끝까지 살펴보라. 부자의 것이 아닌 자국이 섞여 있을지 모른다." },
  { go: {pid:"P3"}, until: "loc:telegraph", text: "앨리스 양에게 아버지와 매카시 씨가 어떤 사이였는지, 옛날 일을 물어보라." },
  { go: {loc:"telegraph"}, until: "ev:EV_VICTORIA_MAP", text: "로스 전신국에서 빅토리아 지도를 받아 두라. 임종의 말과 겹쳐 볼 자료다." },
  { go: {loc:"woodpath"}, until: "ev:EV_WOOD_PATH", text: "낯선 자국이 어디로 사라지는지 숲길을 따라가 보라." },
  { go: {loc:"lodge"}, until: "ev:EV_TURNER_GAIT", text: "숲길 끝의 숲지기 집에서 모런에게 영지 주인의 모습을 물어보라." },
  { go: {pid:"P6"}, until: "@turner_note", progress: "@turner_note", text: "현장 흔적에서 읽은 것(범인의 손, 걸음걸이, 임종의 말, 사라진 회색 옷)을 경감에게 직접 말해 추리로 세우라." },
  { go: {loc:"interrogation"}, until: "summoned:P2", text: "근거가 갖춰졌다. 호텔 응접실에서 판사에게 소환을 신청하면 터너 씨를 부를 수 있다." },
  { go: {pid:"P2"}, until: "admitted:P2", text: "터너 씨에게 매카시와의 진짜 관계를 캐물어라. 빅토리아 지도, '쿠이', 'a rat'이 열쇠다." },
  { go: {pid:"P2"}, until: "confessed:P2", progress: "@turner_proof", text: "터너 씨에게 그날 연못에 있었다는 흔적을 들이대고(증거 첨부) 정면으로 물어라." },
  { go: {pid:"P2"}, until: "k:T_T3", text: "자백은 받았다. 무엇으로 협박을 받았는지, 따님에게 알리지 않겠다고 약속하고 물을 수 있다. 결론은 언제든 낼 수 있다." },
  { go: {tab:"conclusion",label:"결론 쓰기"}, text: "수사는 끝까지 왔다. 결론 탭에서 범인·수법·동기와 근거 증거, 용의자 배제를 적어 사건을 닫으라." },
];
// 인물별 추천 질문(대화창 칩). 위에서부터 조건이 맞는 것 최대 3개, 이미 들은 이야기(until)는 빠진다.
// 해금 질문은 '무엇을 물을지'만 보여 주고 답은 담지 않는다. fill: true는 보내지 않고 입력창에 채워 플레이어가 끝맺는다.
const prompts = {
  P6: [
    { until: "k:L_case", q: "지금까지 파악된 사건 개요를 알려 주시죠." },
    { until: "loc:pond", q: "현장을 보고 싶습니다. 연못으로 안내해 주시죠." },
    { until: "loc:prison", q: "제임스를 직접 만나고 싶습니다. 감옥 면회 허가를 받을 수 있습니까?" },
    { until: "k:L_paper", q: "검시 기록이나 신문 기사는 어디서 볼 수 있습니까?" },
    { until: "k:L_hire", q: "누가 경감님을 이 사건에 불렀습니까?" },
    { when: ["ev:EV_TIPTOE_TRACKS"], until: "k:L_T3", q: "터너 씨는 어떤 분입니까? 매카시와는 어떤 사이였죠?" },
    { when: ["ev:EV_TIPTOE_TRACKS"], until: "@turner_note", fill: true, q: "현장에서 읽은 것을 말씀드리지요. 범인은 " },
    { when: ["@turner_note"], until: "summoned:P2", q: "터너 씨를 불러야겠습니다. 판사에게 쪽지 허가를 청하려면 어떻게 합니까?" },
  ],
  P3: [
    { until: "k:A_james", q: "제임스는 어떤 사람입니까? 왜 무죄라고 믿으십니까?" },
    { until: "k:A_T1", q: "제임스와 아버지는 왜 다퉜을까요? 결혼 이야기가 있었나요?" },
    { until: "k:A_T2", q: "아버님과 매카시 씨는 어떤 사이였습니까? 어떻게 알게 됐죠?" },
    { until: "k:A_father", q: "아버님의 건강은 어떠십니까? 뵐 수 있을까요?" },
    { until: "k:A_hire", q: "왜 경감과 탐정을 부르셨습니까?" },
  ],
  P1: [
    { when: ["k:A_T1"], until: "k:J_T1", q: "앨리스 양이 당신의 무죄를 믿는다고 전해 달라더군요. 아버지와 다툰 이유를 말해 주시겠습니까?" },
    { when: ["k:J_T1"], until: "k:J_T2", q: "브리스톨에서 사흘 동안 무슨 일이 있었습니까? 비밀은 지키겠습니다." },
    { until: "k:J_return", q: "브리스톨에서 돌아온 날 아침 일을 말씀해 주십시오." },
    { until: "k:J_cooee", q: "아버지를 만나기 전에 들은 외침은 무엇이었습니까?" },
    { until: "k:J_death", q: "아버님이 마지막으로 남긴 말이 무엇이었습니까?" },
    { until: "k:J_grey", q: "쓰러진 아버지 곁에 무언가 있었습니까?" },
    { until: "k:J_arrest", q: "체포될 때 왜 '받아 마땅한 벌'이라고 하셨습니까?" },
    { until: "k:J_walk", q: "그날 왜 총을 들고 연못 쪽으로 가셨습니까?" },
  ],
  P4: [
    { until: "k:P_see", q: "그날 숲 가장자리에서 무엇을 봤니?" },
    { when: ["k:P_see"], until: "k:P_T1", q: "괜찮아, 천천히 말해도 돼. 도망친 뒤에는 어떻게 됐니?" },
    { when: ["k:P_see"], until: "broken:S2", q: "제임스가 아버지를 때리는 걸 직접 봤니?" },
  ],
  P5: [
    { until: "k:C_see", q: "그날 오후 무엇을 보셨습니까?" },
    { when: ["k:C_see"], until: "k:C_T1", q: "아들이 정말 아버지를 따라간 겁니까, 아니면 짐작입니까?" },
    { until: "k:C_origin", q: "고향이 어디입니까? 이 영지에서 얼마나 일하셨죠?" },
  ],
  P2: [
    { until: "met:P2", q: "터너 씨, 따님 일로 잠시 말씀을 나눌 수 있겠습니까?" },
    { when: ["summoned:P2"], until: "k:T_mccarthy", q: "매카시 씨와는 어떤 사이였습니까?" },
    { when: ["summoned:P2"], until: "k:T_past", q: "호주에서는 어떻게 재산을 모으셨습니까?" },
    { when: ["summoned:P2"], until: "admitted:P2", fill: true, q: "이 지도를 보십시오(증거 첨부). 매카시가 남긴 말은 " },
    { when: ["admitted:P2"], until: "confessed:P2", fill: true, q: "그날 당신은 연못에 있었습니다. 증거가 있습니다: " },
    { when: ["confessed:P2"], until: "k:T_T3", q: "따님에게는 알리지 않겠습니다. 무엇으로 협박을 받으셨습니까?" },
  ],
};
// 호텔 응접실(심문실) 안내
const roomHints = [
  { until: "summoned:P2", text: "이곳에서 판사에게 소환을 신청한다. 병석의 지주를 부르려면 경감 앞에서 세운 추리와 숲지기 집에서 확인한 사실이 필요하다." },
  { when: ["summoned:P2"], until: "admitted:P2", text: "터너 씨가 앉아 있다. 지도나 증거를 첨부해 말하면 내미는 것이 된다." },
  { when: ["admitted:P2"], until: "confessed:P2", text: "터너 씨는 매카시와의 과거를 인정했다. 이제 그날 연못의 일을 물을 차례다." },
];
const LOC_NAME = Object.fromEntries(locations.map((l) => [l.id, l.name]));

// ── 증거·조사 지점: 증거 파트 JSON의 17건을 그대로 싣는다. 본문(text)은 해석 없는 관찰 문장이고, 해석(proves)·한계(limits)는 제출 뒤 해설에만 나온다.
// 진행 조건 scene_access_granted·victoria_known은 장소 해금(경감 T2 → 연못·해덜리, 앨리스 T2 → 전신국)으로 처리하고, 선행 증거(requires)는 지점 조건으로 옮긴다.
const CASE_LOC = { ross_hotel: "hotel", ross_telegraph: "telegraph", hatherley_farm: "hatherley", boscombe_pool: "pond", great_beech: "beech", wood_path: "woodpath", moran_lodge: "lodge" };
const SPOT_LABEL = {
  EV_NEWS_REPORT: "지역 신문 다발의 사건 기사", EV_GROOM_APPOINTMENT: "신문 기사 중 마부의 증언", EV_PATIENCE_DEPOSITION: "신문 기사 중 목격자 증언", EV_ARREST_REMARK: "경찰 기록의 체포 당시 발언",
  EV_SURGEON_REPORT: "주간 지역 신문의 검시 기록 전문", EV_POOL_LAYOUT: "연못 전경 둘러보기", EV_BOOTS_HATHERLEY: "하녀에게 부자의 장화를 보여 달라고 하기", EV_RENT_RECORD: "농장 임대 서류",
  EV_TRACKS_POOL: "시신이 있던 자리 주변의 발자국", EV_TIPTOE_TRACKS: "풀밭에 남은 낯선 발자국", EV_BEECH_CIGAR: "너도밤나무 뒤의 땅바닥", EV_STONE_WEAPON: "나무 아래 이끼 사이",
  EV_WOOD_PATH: "숲길로 이어지는 까치발 자국 따라가기", EV_VICTORIA_MAP: "브리스톨에 지도를 전보로 요청", EV_TURNER_GAIT: "숲지기 모런에게 영지 주인에 대해 묻기", EV_STAFF_REGISTER: "영지 고용인 명부", EV_TURNER_HAND: "숲지기 모런에게 터너 씨의 손버릇 묻기",
};
const TYPE_KO = { document: "기록", physical: "현장 물품", trace: "현장 흔적", observation: "현장 관찰", testimony_record: "증언 기록" };
const SPOT_GRANTS = { EV_TIPTOE_TRACKS: ["loc:beech", "loc:woodpath"] };
// 팩에서 보탠 증거: 증거 파트 17건에는 터너가 왼손잡이임을 확인할 기록이 없어(자백 대사에만 있다) 숲지기의 증언 한 건을 넣는다.
// 키트 gm_truth의 '왼손으로 돌을 휘둘렀다'에 맞춘 것이고, 증거 파트 JSON에 같은 내용이 들어오면 이 항목은 지운다.
const EXTRA_EVIDENCE = [{
  id: "EV_TURNER_HAND", stage: 3, type: "testimony_record", location: "moran_lodge", object: "숲지기 모런", title: "숲지기 모런이 전한 터너의 손버릇",
  text: "숲지기 모런의 말: 터너 씨는 왼손잡이다. 지팡이를 왼손으로 짚고, 사냥총도 왼쪽 어깨에 댄다.",
  requires: ["EV_WOOD_PATH"], proves: "터너는 왼손잡이다. 외과의 소견(뒤에서 친 일격이 왼쪽에 맞음)과 맞는다.", limits: "왼손잡이라는 것만으로는 그날 연못에 있었다고 할 수 없다.",
}];
const allEvidence = [...cs.evidence, ...EXTRA_EVIDENCE];
const NOTES = { ...cs.answer.evidence_notes, ...Object.fromEntries(EXTRA_EVIDENCE.map((e) => [e.id, { proves: e.proves, limits: e.limits }])) };
const startEvidence = kit.evidence_items.filter((e) => e.initially_owned).map((e) => e.id);
const caseEv = new Set(cs.evidence.map((e) => e.id));
for (const e of kit.evidence_items) if (!caseEv.has(e.id)) throw new Error(`boscombe: 키트 증거 ${e.id}가 증거 파트 JSON에 없음`);
const spots = [];
const evidence = allEvidence.map((e) => {
  const locId = CASE_LOC[e.location];
  if (!locId) throw new Error(`boscombe: 증거 ${e.id}의 장소 ${e.location}를 지도에 못 붙임`);
  if (!startEvidence.includes(e.id)) {
    spots.push({ id: `sp_${e.id.slice(3).toLowerCase()}`, locationId: locId, label: SPOT_LABEL[e.id] || e.object, reveals: e.id, requires: e.requires.map((r) => `ev:${r}`), grants: SPOT_GRANTS[e.id] || [] });
  }
  const v = VOICE.EV[e.id];
  if (!v) throw new Error(`boscombe: 증거 설명 없음 ${e.id}`);
  return { id: e.id, title: e.title, typeKo: TYPE_KO[e.type] || "기록", type: e.type, where: `${LOC_NAME[locId]} · ${cs.stages[e.stage]}`, text: e.text, look: v.look, use: v.use };
});

// ── 제출 뒤 해설: 증거별 해석·한계, 용의자 배제 근거(증거 파트 answer 블록)
const EV_TITLE = Object.fromEntries(allEvidence.map((e) => [e.id, e.title]));
const TRAIT_KO = {
  lame: "범인은 오른쪽 다리를 전다. 이 사람의 발자국은 양발 깊이가 고르다.",
  australian: "범인은 호주(발라랏)와 얽힌 사람이다. 이 사람은 이 지방 태생이고 해외에 나간 기록이 없다.",
  tall: "범인은 보폭이 긴 거구다. 이 사람은 14세 소녀다.",
};
const answerNotes = allEvidence.map((e) => ({ id: e.id, title: e.title, key: cs.answer.minimum_evidence.includes(e.id), ...NOTES[e.id] }));
const answerExclusions = Object.entries(cs.answer.exclusions).map(([cid, x]) => {
  const trait = (x.reason.match(/:\s*(\w+)$/) || [])[1];
  return { name: CH[cid].name, reason: TRAIT_KO[trait] || x.reason, evidence: x.evidence.map((id) => EV_TITLE[id]) };
});

// ── 누설 검사: 전역 스포일러 + 범인(터너) 단계의 표현은 모든 인물에게, 나머지는 그 인물의 잠긴 단계에만.
const rx = (s) => new RegExp(s, "i");
const perPerson = {};
const globalPatterns = kit.common_guardrail.global_spoiler_patterns.map(rx);
for (const c of kit.characters) {
  for (const t of c.unlock_tiers) {
    for (const pat of t.leak_patterns || []) {
      if (c.id === T && pat !== "20년") globalPatterns.push(rx(pat));
      else (perPerson[PID[c.id]] = perPerson[PID[c.id]] || []).push(rx(pat));
    }
  }
}

const gm = kit.gm_truth;
const note = kit.investigations.find((i) => i.id === "ACT_SEND_NOTE");
const noteFlags = note.requires.of.map((c) => (c.type === "deduction_made" ? `k:${c.deduction_id}` : `ev:${c.evidence_id}`));
const t1 = CH[T].unlock_tiers[0].conditions.any;
const t2 = CH[T].unlock_tiers[1].conditions.all.find((c) => c.type === "min_count");
const shownOrDd = (c) => (c.type === "evidence_presented" ? `shown:P2:${c.evidence_id}` : `k:${c.deduction_id}`);

module.exports = {
  id: "boscombe",
  title: kit.scenario.title,
  source: "아서 코넌 도일, 「보스콤 계곡의 수수께끼」(1891) · WHODUNIT 벤치마크 선정작",
  setting: `「보스콤 밸리 사건」(1880년대 영국 헤리퍼드셔 로스 근처 시골). 상대는 ${kit.scenario.player_role}. 시점: ${kit.scenario.scenario_time}`,
  brief: kit.scenario.public_briefing.join(" "),
  startLocation: "hotel",
  map: {
    zones: { estate: "보스콤 밸리", offsite: "로스 · 헤리퍼드" },
    edges: [["lodge", "pond"], ["preserve", "pond"], ["hall", "lodge"], ["hall", "preserve"], ["hatherley", "pond"], ["pond", "beech"],
      ["beech", "woodpath"], ["hotel", "hall", true], ["hotel", "telegraph"], ["hotel", "prison", true]],
    // 평면도 장식: 연못 동쪽의 숲
    decor: [{ type: "tree", x: 634, y: 306, r: 14 }, { type: "tree", x: 604, y: 344, r: 15 }, { type: "tree", x: 590, y: 404, r: 20 }, { type: "tree", x: 548, y: 452, r: 16 }, { type: "text", x: 600, y: 374, text: "보스콤 숲" }],
  },
  locations,
  leads,
  roomHints,
  prompts,
  spots,
  start: { evidence: startEvidence, flags: ["heard:S1", "heard:S2"] },
  people,
  refusals: { P2: { text: VOICE.REFUSAL.P2 || CH[T].availability.unavailable_message, grants: [] } },
  nodes,
  // 목격 증언 두 건은 사실이지만 '아들이 따라가서 쳤다'는 뜻으로 읽힌다. 그 읽기를 기록으로 깬다.
  objections: [
    { statement: "S1", evidence: ["EV_INQUEST_RECORD", "EV_GROOM_APPOINTMENT"], crack: "follow_guess", note: "아버지는 아들이 돌아온 줄 몰랐고, 3시에 만날 사람이 따로 있었다. '따라갔다'는 본 것이 아니라 짐작이다." },
    { statement: "S2", evidence: ["EV_SURGEON_REPORT"], crack: "hand_not_blow", note: "손을 치켜든 것은 사실이다. 그러나 상처는 뒤에서 맞은 것이고, 페이션스는 그 전에 자리를 떴다. 마주 보고 다투던 손이 낸 상처가 아니다." },
  ],
  // ── 접촉 2단계: 증거 ↔ 증거 맞대기(착안). 두 증거를 맞대면 둘 사이의 관계를 '질문'으로 짚어 준다.
  // 결론(누가·어느 손·어떤 다리)은 말하지 않는다. 플레이어가 그 답을 경감에게 직접 말해야 추리(k:DD_*)가 성립한다.
  // 맞대기 자체는 점수·해금과 무관하고, 성공·헛짚음은 접촉 기록으로 남는다(캡스톤 '추적·진술 분석' 데이터).
  combos: [
    { id: "CB_LEFT", a: "EV_SURGEON_REPORT", b: "EV_TIPTOE_TRACKS", title: "뒤에서 친 일격, 왼쪽의 상처",
      text: "낯선 장화는 숲 쪽에서 와서 매카시의 등 뒤로 다가왔다. 그런데 부서진 곳은 머리 뒤쪽의 왼편이다.",
      ask: "뒤에서 내리친 일격이 왼쪽에 맞으려면, 범인은 어느 손을 썼어야 하는가?", talkTo: "P6" },
    { id: "CB_LAME", a: "EV_TIPTOE_TRACKS", b: "EV_TRACKS_POOL", title: "고른 자국과 얕은 오른발",
      text: "제임스의 발자국은 양발 깊이가 고르다. 네모 장화 자국은 오른발이 늘 왼발보다 얕다.",
      ask: "한쪽 발을 늘 덜 디디는 사람은 어떤 걸음을 걷는가?", talkTo: "P6" },
    { id: "CB_RAT", a: "EV_INQUEST_RECORD", b: "EV_VICTORIA_MAP", title: "'a rat'과 지도 위의 글자",
      text: "죽어 가던 매카시가 웅얼거린 말은 'a rat'뿐이었다. 빅토리아 식민지 지도에는 'BALLARAT'이라는 지명이 있다.",
      ask: "제임스가 들은 것이 낱말의 끝부분뿐이었다면, 매카시는 무엇을 말하려 했는가?", talkTo: "P6" },
    { id: "CB_COOEE", a: "EV_INQUEST_RECORD", b: "EV_NEWS_REPORT", title: "아무도 모르는 귀가, 'Cooee'",
      text: "매카시는 아들이 돌아온 줄도 모르면서 아들을 보기 전에 'Cooee!'를 외쳤다. 신문은 매카시와 터너가 식민지 시절부터 아는 사이라고 적었다.",
      ask: "'Cooee'는 원래 어디 사람들이 쓰는 외침인가? 매카시는 그 외침으로 누구를 부르고 있었나?", talkTo: "P6" },
    { id: "CB_APPOINT", a: "EV_INQUEST_RECORD", b: "EV_GROOM_APPOINTMENT", title: "3시의 약속",
      text: "매카시는 마부에게 '3시에 중요한 약속이 있다'며 서둘렀다. 그러나 아들은 아무도 모르게 브리스톨에서 막 돌아온 참이었다.",
      ask: "아버지가 서둘러 만나러 간 사람은 정말 아들이었을까?", talkTo: "P6" },
    { id: "CB_CLOAK", a: "EV_INQUEST_RECORD", b: "EV_TIPTOE_TRACKS", title: "사라진 회색 천",
      text: "제임스가 달려갈 때 왼쪽 땅에 있던 회색 천은, 그가 일어나 둘러봤을 때 없었다. 네모 장화 자국은 숲에서 왔다가 돌아갔고, 다시 왔다가 돌아갔다.",
      ask: "왜 같은 사람이 두 번 다녀갔는가? 두 번째에는 무엇을 하러 왔는가?", talkTo: "P6" },
    { id: "CB_LOCAL", a: "EV_POOL_LAYOUT", b: "EV_TRACKS_POOL", title: "울타리 안의 연못",
      text: "연못에 오려면 해덜리 농장이나 터너 영지를 지나야 한다. 낯선 발자국 말고는 바깥에서 들어온 흔적이 없다.",
      ask: "이 연못가에 숨어 기다릴 수 있었던 사람은 어떤 사람인가?", talkTo: "P6" },
    { id: "CB_WEAPON", a: "EV_SURGEON_REPORT", b: "EV_STONE_WEAPON", title: "뭉툭한 흉기",
      text: "외과의는 무겁고 뭉툭한 것의 강한 일격이라 했다. 연못을 갈퀴로 뒤져도 다른 흉기는 없었고, 이 돌은 놓인 지 며칠 안 됐으며 빠져나온 자리가 없다.",
      ask: "이 돌은 원래 어디에 있던 것이 아니라 누가 들고 와서 버린 것일까?" },
    { id: "CB_WAIT", a: "EV_BEECH_CIGAR", b: "EV_TIPTOE_TRACKS", title: "너도밤나무 뒤의 기다림",
      text: "까치발 자국은 너도밤나무 쪽으로 이어지고, 그 뒤에는 시가 재와 꽁초가 있다. 끝은 깨물지 않고 거칠게 잘라 냈다.",
      ask: "지나가던 사람이었다면 왜 나무 뒤에서 시가를 피웠을까?" },
    { id: "CB_BODY", a: "EV_TIPTOE_TRACKS", b: "EV_TURNER_GAIT", title: "흔적과 한 사람의 몸",
      text: "네모 장화의 보폭은 길고 오른발 자국이 늘 얕다. 숲지기는 영지 주인을 '다리를 절며 느리게 걷지만 손발이 크고 체격이 거대하다'고 했다.",
      ask: "이 둘은 같은 사람을 말하고 있는가? 그렇다면 그를 응접실로 불러낼 근거는 충분한가?" },
    { id: "CB_HAND", a: "EV_SURGEON_REPORT", b: "EV_TURNER_HAND", title: "왼쪽 상처와 왼손잡이",
      text: "상처는 머리 뒤쪽의 왼편이다. 숲지기는 터너 씨가 지팡이를 왼손으로 짚고 총을 왼쪽 어깨에 댄다고 했다.",
      ask: "왼손잡이라는 것만으로 그날 연못에 있었다고 할 수 있는가? 무엇이 더 필요한가?" },
    { id: "CB_RENT", a: "EV_RENT_RECORD", b: "EV_NEWS_REPORT", title: "임대료 없는 농장",
      text: "터너는 식민지 시절부터 알던 매카시에게 해덜리 농장을 임대료 한 푼 받지 않고 내주었다.",
      ask: "부유한 지주가 왜 그토록 너그러웠을까? 두 사람 사이에 무엇이 있었나?" },
    { id: "CB_FACE", a: "EV_PATIENCE_DEPOSITION", b: "EV_SURGEON_REPORT", title: "치켜든 손, 뒤통수의 상처",
      text: "페이션스는 마주 보고 다투던 아들이 손을 치켜드는 것을 보고 달아났다. 상처는 뒤에서 맞은 것이다.",
      ask: "마주 선 사람의 손이 뒤통수를 칠 수 있는가? 페이션스는 실제로 무엇을 보았나?" },
    { id: "CB_CROWDER", a: "EV_STAFF_REGISTER", b: "EV_VICTORIA_MAP", title: "고향을 떠난 적 없는 사냥터지기",
      text: "크라우더는 이 지방에서 태어나 영지를 떠난 적이 없다. 임종의 말과 'Cooee'는 호주 식민지를 가리킨다.",
      ask: "크라우더가 매카시가 기다리던 사람일 수 있는가?" },
    { id: "CB_ARREST", a: "EV_ARREST_REMARK", b: "EV_INQUEST_RECORD", title: "'받아 마땅한 벌'",
      text: "제임스는 체포될 때 '받아 마땅한 벌'이라 하고는 곧 결백을 주장했다. 검시 심리에서도 다툰 이유만은 끝내 말하지 않았다.",
      ask: "그가 숨기는 것은 살인일까, 다툼의 이유일까? 그 이유를 아는 사람이 따로 있지 않을까?", talkTo: "P3" },
  ],
  // ── 접촉 3단계: 인물 ↔ 인물 대질. 각자에게서 들은 말을 맞대어 본다(한자리에 부르지 않는다).
  // 미리 쓴 대사만 쓴다(모델이 잠긴 사실을 흘리지 않게). breaks가 있으면 이의 제기와 같은 방식으로 진술이 깨진다.
  confronts: [
    { id: "CF_FOLLOW", a: "P5", b: "P1", requires: ["k:J_walk"], title: "따라간 것인가, 같은 길을 간 것인가",
      lines: [["P5", "매카시 씨가 앞서 가고, 몇 분 뒤 아드님이 총을 끼고 같은 쪽으로 갔습니다요. 따라가는 것 같았습니다요."],
        ["P1", "저는 연못 건너편 토끼굴로 가던 길이었습니다. 아버지가 앞에 계신 줄도 몰랐습니다."],
        ["P5", "…듣고 보니 따라간다는 건 제 짐작이었습니다요. 같은 쪽으로 가는 것만 봤습니다요."]],
      note: "크라우더가 본 것은 '같은 방향으로 갔다'는 것뿐이다. '따라갔다'는 그의 짐작이었다.",
      breaks: { statement: "S1", crack: "follow_guess" } },
    { id: "CF_HAND", a: "P4", b: "P1", requires: ["k:J_quarrel", "k:P_see"], title: "치켜든 손 다음에 일어난 일",
      lines: [["P4", "아들이 손을 치켜들어서… 무서워서 도망쳤어요."],
        ["P1", "손을 든 건 사실입니다. 하지만 저는 그대로 돌아서서 해덜리 쪽으로 걸어갔습니다. 비명은 한참 걸은 뒤에 들렸습니다."],
        ["P4", "저, 저는… 때리는 건 못 봤어요. 손을 든 것만 보고 도망쳤어요."]],
      note: "페이션스는 손을 치켜드는 순간까지만 보았다. 때리는 장면을 본 사람은 없다.",
      breaks: { statement: "S2", crack: "hand_not_blow" } },
    { id: "CF_WITNESS", a: "P5", b: "P4", requires: ["k:C_see", "k:P_see"], title: "두 목격자가 본 것",
      lines: [["P5", "저는 두 분이 연못 쪽으로 가는 것만 봤습니다요. 연못가에서 무슨 일이 있었는지는 모릅니다요."],
        ["P4", "저는 두 분이 다투는 것만 봤어요. 그다음은… 못 봤어요."]],
      note: "두 목격자 모두 매카시가 쓰러지는 장면은 보지 못했다. 제임스가 아버지를 쳤다는 목격자는 없다." },
    { id: "CF_ARREST", a: "P6", b: "P1", requires: ["k:J_arrest"], title: "체포 때의 한마디",
      lines: [["P6", "당신은 체포될 때 '받아 마땅한 벌'이라 하지 않았소. 그게 자백이 아니면 뭐요?"],
        ["P1", "…그 말이 무슨 뜻이었는지는, 지금은 말씀드릴 수 없습니다. 하지만 저는 아버지를 해치지 않았습니다."]],
      note: "제임스는 그 말의 이유를 숨긴다. 그가 감싸는 사람이 있다면, 그 사람에게서 이유를 들을 수 있을지 모른다." },
  ],
  summons: {
    P2: {
      needMet: true, groups: [], requires: ["@turner_note", "ev:EV_TURNER_GAIT"],
      approve: "숲지기 모런 편에 '소문을 피하려 호텔로 와 달라'는 쪽지를 보내도록 허가한다. 터너는 직접 호텔로 오겠다고 답했다.",
      deny: "병석의 지주를 불러낼 근거가 부족하다. 두 가지를 갖춘 뒤 다시 신청하라. 첫째, 현장 흔적에서 끌어낸 추리를 레스트레이드 경감에게 직접 말해 세 가지 이상 세울 것(범인이 어느 손을 썼는지, 어떻게 걷는지, 임종의 말이 무엇을 가리키는지 같은 것). 둘째, 그 흔적이 터너 씨의 모습과 맞는지 숲지기 집에서 확인할 것.",
      arrive: "쪽지를 받은 터너가 다리를 절며 호텔 응접실로 들어왔습니다",
    },
  },
  // ── 36번: 신뢰·압박 계기판(키트 state_model). 초기값은 인물별 initial_state, 영향 규칙은 common_affect_rules를 그대로 옮겼다.
  meters: Object.fromEntries(kit.characters.map((c) => [PID[c.id], { ...c.initial_state }])),
  meterRange: { min: kit.state_model.meters.trust.min, max: kit.state_model.meters.trust.max },
  affect: (() => {
    const R = Object.fromEntries(kit.state_model.common_affect_rules.map((r) => [r.id, r.effect]));
    // 관련 증거: 그 인물의 해금 조건에 evidence_presented로 나오는 증거(키트 기준)
    const evOf = (cond) => (!cond ? [] : cond.type === "evidence_presented" ? [cond.evidence_id] : [...(cond.any || []), ...(cond.all || []), ...(cond.of || [])].flatMap(evOf));
    return {
      tone: { empathetic: R.AF_EMPATHY, polite: R.AF_POLITE, threatening: R.AF_THREAT },
      accuseNoEvidence: R.AF_ACCUSE_NO_EVIDENCE,
      relevantEvidence: R.AF_RELEVANT_EVIDENCE,
      promise: R.AF_PROMISE_SECRECY,
      relevant: Object.fromEntries(kit.characters.map((c) => [PID[c.id], [...new Set(c.unlock_tiers.flatMap((t) => evOf(t.conditions)))]])),
    };
  })(),
  conditions: {
    "@J_T1_gate": { type: "any", of: [["k:A_T1"], ["m:P1:trust>=45"]] },
    "@J_T2_gate": { type: "any", of: [["m:P1:trust>=65"], ["promise:P1"]] },
    "@T_T3_gate": { type: "any", of: [["promise:P2"], ["m:P2:trust>=40"]] },
    "@turner_note": { type: "count", min: note.requires.min_count, flags: noteFlags },
    "@turner_crack": { type: "any", of: t1.map((c) => (c.all ? c.all.filter((x) => x.type === "deduction_made").map(shownOrDd) : [shownOrDd(c)])) },
    "@turner_proof": { type: "count", min: t2.min_count, flags: t2.of.map(shownOrDd) },
  },
  evidence,
  statements: [
    { id: "S1", speaker: "P5", speakerName: CH[C].name, text: "매카시 씨가 혼자 연못 쪽으로 걸어갔고, 몇 분 뒤 아들 제임스가 총을 끼고 같은 방향으로 갔습니다. 아들이 아버지를 따라가는 것 같았습니다." },
    { id: "S2", speaker: "P4", speakerName: CH[P].name, text: "숲 가장자리에서 매카시 씨와 아들이 격하게 다투는 걸 봤어요. 아들이 손을 치켜들어서, 무서워서 도망쳤어요." },
  ],
  timeline: {},
  // 용의자 후보는 증거 파트 JSON의 suspect 표시를 따른다(제임스·터너·크라우더·페이션스).
  suspects: cs.persons.filter((x) => x.suspect && PID[x.id]).map((x) => ({ pid: PID[x.id], name: CH[x.id].name })),
  scoring: {
    culprit: { pids: [PID[gm.culprit_id]], points: 20, label: "범인 지목" },
    // 자백: 범인을 불러내 근거를 내밀고 자백까지 받아야 얻는다(범인을 맞혔을 때만 인정).
    confession: { points: 10, label: "범인의 자백 확보" },
    items: [
      // needs: 이 중 하나라도 확인(증거 열람·인물에게 들음·추리 성립)했어야 점수를 준다. 원작 기억만으로 쓴 답을 거른다.
      { label: "흉기·방법", field: "method", re: /돌|둔기|뒤에서|머리|뒤통수/, points: 10, needs: ["ev:EV_STONE_WEAPON", "ev:EV_SURGEON_REPORT"] },
      { label: "동기", field: "motive", re: /협박|과거|강도|딸|앨리스|결혼/, points: 10, needs: ["ev:EV_RENT_RECORD", "k:A_T1", "k:L_T3", "k:T_T1"] },
      { label: "쿠이·'a rat' 해석", field: "all", re: /쿠이|cooee|발라랏|ballarat|호주/i, points: 10, needs: ["ev:EV_VICTORIA_MAP", "k:DD_COOEE_AUSTRALIAN", "k:DD_RAT_BALLARAT"] },
    ],
    evidence: {
      groups: [
        { label: "흉기", ids: ["EV_STONE_WEAPON", "EV_SURGEON_REPORT"] },
        { label: "제3자의 흔적(발자국·시가)", ids: ["EV_TIPTOE_TRACKS", "EV_WOOD_PATH", "EV_BEECH_CIGAR"] },
        { label: "동기의 단서(임대 기록)", ids: ["EV_RENT_RECORD"] },
        { label: "빅토리아 지도", ids: ["EV_VICTORIA_MAP"] },
        { label: "터너의 몸(걸음·왼손)", ids: ["EV_TURNER_GAIT", "EV_TURNER_HAND"] },
      ],
      perGroup: 2,
      max: 6, // 근거 증거는 6개까지만 고를 수 있다(전부 고르기로 점수를 얻지 못하게)
    },
    // 다른 용의자 배제: 용의자마다 증거를 3개까지 골라, 범인의 특징을 보여 주는 증거와 그 사람이 거기에 맞지 않음을 보여 주는 증거를 함께 대야 한다.
    // 근거 짝은 증거 파트 answer.exclusions(lame·australian·tall)에서 가져왔다.
    exclusions: {
      max: 3, perGroup: 5,
      suspects: [
        { pid: "P1", name: CH[J].name, groups: [{ label: "범인은 한쪽 다리를 전다", ids: ["EV_TIPTOE_TRACKS"] }, { label: "제임스의 발자국은 고르다", ids: ["EV_TRACKS_POOL"] }] },
        { pid: "P5", name: CH[C].name, groups: [{ label: "범인은 호주와 얽힌 사람이다", ids: ["EV_VICTORIA_MAP", "EV_INQUEST_RECORD"] }, { label: "크라우더는 이 지방을 떠난 적이 없다", ids: ["EV_STAFF_REGISTER"] }] },
        { pid: "P4", name: CH[P].name, groups: [{ label: "범인은 보폭이 긴 거구다", ids: ["EV_TIPTOE_TRACKS"] }, { label: "페이션스는 14세 소녀이고 다툼 중에 떠났다", ids: ["EV_PATIENCE_DEPOSITION"] }] },
      ],
    },
  },
  answer: {
    summary: `${gm.motive} ${gm.method} ${gm.canonical_ending}`,
    culpritName: CH[gm.culprit_id].name,
    timeline: gm.timeline.map((x) => [x.t, x.event]),
    notes: answerNotes,
    exclusions: answerExclusions,
  },
  leak: { keywords: [], patterns: globalPatterns, perPerson },
  // 키트의 공통 가드레일 G01~G10을 모든 인물에게 같은 문구로 주입한다(G11 응답 형식은 엔진 형식을 따르므로 제외).
  guardrailRules: kit.common_guardrail.rules.filter((r) => r.id !== "G11").map((r) => `${r.id} ${r.name}: ${r.rule.replace(/\[현재 보유 지식\]/g, "'허용된 사실'").replace(/\[신념\]/g, "'신념'").replace(/\[회피 주제\]/g, "'회피 주제'").replace(/\[시나리오 시점\]/g, "사건 배경의 시점")}`),
  art: { base: "/art/" },
  kit: { schema_version: kit.schema_version, guardrail_version: kit.common_guardrail.version },
};
