// WD-ABBEY Claude판 브라우저 화면. 빌드 없음, 외부 의존 없음.
// 서버 문자열은 전부 textContent(createTextNode)로만 넣는다.

const SVGNS = 'http://www.w3.org/2000/svg';
const STANCE_KO = { cooperative: '협조', refusing: '거절', summoned: '출석', admitted: '부분 인정', confessed: '자백' };
const STARTERS = ['그날 무슨 일이 있었는지 처음부터 말씀해 주십시오.', '6월 3일 오후에 당신은 어디에 있었습니까?', '누가 매카시 씨를 해쳤다고 생각하십니까?'];
const TABS = [['map', '지도'], ['evidence', '증거'], ['statements', '진술'], ['notes', '노트'], ['records', '수사 기록'], ['conclusion', '결론']];
// 지도 배치·길·안개 좌표는 서버 state.map에서 온다(사건 팩마다 다름).
const REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

let sessionId = null;
let state = null;
const ui = {
  tab: 'map', desk: [], attach: [], chatPid: null, busy: false, pendingMsg: null,
  pulse: new Set(), shake: null, lastScene: 'dining', seenBroken: new Set(), noteTimer: null, noteDraft: null, picked: null, miss: null, dragEv: null, contactPulse: null,
  fold: (() => { try { return JSON.parse(localStorage.getItem('boscombe.fold') || '{}'); } catch (e) { return {}; } })(),
  mapFit: false, pipPop: -1,
  leadOff: (() => { try { return localStorage.getItem('boscombe.leadOff') === '1'; } catch (e) { return false; } })(),
  guideOff: (() => { try { return localStorage.getItem('boscombe.guideOff') === '1'; } catch (e) { return false; } })(),
  draft: { culprit: '', method: '', motive: '', reasoning: '', evidenceIds: [], exclusions: {} },
};

const $ = (id) => document.getElementById(id);

// ---------- DOM 도우미 ----------
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  applyProps(el, props);
  appendKids(el, kids);
  return el;
}
function sv(tag, props, ...kids) {
  const el = document.createElementNS(SVGNS, tag);
  applyProps(el, props);
  appendKids(el, kids);
  return el;
}
function applyProps(el, props) {
  if (!props) return;
  for (const [k, v] of Object.entries(props)) {
    if (v === null || v === undefined || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.setAttribute('class', v);
    else if (k === 'data') for (const [dk, dv] of Object.entries(v)) el.dataset[dk] = dv;
    else if (k === 'value' || k === 'disabled' || k === 'checked') el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
}
function appendKids(el, kids) {
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
}
function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
function imgWithFallback(src, alt, fallback) {
  const img = h('img', { alt: alt || '', loading: 'lazy' });
  img.addEventListener('error', () => { img.replaceWith(fallback()); }, { once: true });
  img.src = src;
  return img;
}
function avatar(p) { return h('div', { class: 'avatar', 'aria-hidden': 'true' }, cameo(p)); }
// 초상 그림이 없는 인물: 동판화 카메오. 인물마다 해칭 각도가 달라 서로 구별된다.
function cameo(p, opt = {}) {
  const key = String(p.pid || p.name || '?');
  const seed = [...key].reduce((n, c) => n + c.charCodeAt(0), 0);
  const ang = [-35, 25, -60, 50, 10, -15, 70][seed % 7];
  const id = 'hx' + key.replace(/[^a-zA-Z0-9]/g, '') + (opt.tag || '');
  const ch = p.initials || (p.name || '?').trim().slice(0, 1);
  return sv('svg', { class: 'cameo' + (opt.cls ? ' ' + opt.cls : ''), viewBox: '0 0 120 140', 'aria-hidden': 'true' },
    sv('defs', null, sv('pattern', { id, width: 4, height: 4, patternUnits: 'userSpaceOnUse', patternTransform: `rotate(${ang})` },
      sv('rect', { width: 4, height: 4, class: 'cm-bg' }), sv('line', { x1: 0, y1: 0, x2: 0, y2: 4, class: 'cm-hatch' }))),
    sv('rect', { width: 120, height: 140, class: 'cm-ground' }),
    sv('ellipse', { cx: 60, cy: 70, rx: 52, ry: 62, class: 'cm-rim' }),
    sv('ellipse', { cx: 60, cy: 70, rx: 46, ry: 56, fill: `url(#${id})`, class: 'cm-field' }),
    sv('ellipse', { cx: 60, cy: 70, rx: 46, ry: 56, class: 'cm-line' }),
    sv('text', { x: 60, y: 88, class: 'cm-ch', 'text-anchor': 'middle' }, ch));
}

// ---------- 첫 화면: 사건 파일 표지 ----------
// 봉인을 뜯으면 표지가 걷히고 수사가 시작된다. 측량도는 잉크로 그려지듯 나타난다.
const INTRO_MAP = `
<svg class="intro-map" viewBox="0 0 520 440" role="img" aria-label="보스콤 연못 주변 측량도: 해덜리 농장에서 연못으로 난 길, 숲지기 집, 터너 저택, 연못가 시신 발견 지점">
  <defs>
    <pattern id="ih" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(-38)"><line x1="0" y1="0" x2="0" y2="6" class="ih-l"/></pattern>
  </defs>
  <rect class="d" pathLength="1" x="6" y="6" width="508" height="428" style="--d:0s"/>
  <rect class="d thin" pathLength="1" x="12" y="12" width="496" height="416" style="--d:.15s"/>
  <g class="contour">
    <path class="d thin" pathLength="1" d="M40 120 C120 90 190 140 250 110 S380 60 480 96" style="--d:.5s"/>
    <path class="d thin" pathLength="1" d="M40 150 C120 122 190 168 250 140 S380 92 480 126" style="--d:.6s"/>
    <path class="d thin" pathLength="1" d="M60 380 C140 350 210 392 290 370" style="--d:.7s"/>
  </g>
  <path class="wood" d="M150 200 C130 170 160 140 196 150 C210 120 252 124 260 150 C292 146 300 182 282 198 C300 224 270 246 246 232 C230 256 186 252 180 230 C150 238 132 220 150 200 Z" style="--d:.9s"/>
  <path class="d" pathLength="1" d="M150 200 C130 170 160 140 196 150 C210 120 252 124 260 150 C292 146 300 182 282 198 C300 224 270 246 246 232 C230 256 186 252 180 230 C150 238 132 220 150 200 Z" style="--d:.9s"/>
  <g class="trees">
    <circle class="d" pathLength="1" cx="186" cy="182" r="11" style="--d:1.1s"/><circle class="d" pathLength="1" cx="222" cy="168" r="13" style="--d:1.15s"/>
    <circle class="d" pathLength="1" cx="252" cy="196" r="10" style="--d:1.2s"/><circle class="d" pathLength="1" cx="208" cy="214" r="12" style="--d:1.25s"/>
  </g>
  <ellipse class="pond" cx="330" cy="292" rx="104" ry="56" style="--d:1.3s"/>
  <ellipse class="d" pathLength="1" cx="330" cy="292" rx="104" ry="56" style="--d:1.3s"/>
  <path class="d thin" pathLength="1" d="M276 284 l20 8 l-6 12 M330 268 l10 18 l20 6 M372 282 l-8 16" style="--d:1.6s"/>
  <g class="hedge">
    <path class="d thin" pathLength="1" d="M20 300 L120 290 L140 420" style="--d:1.0s"/>
    <path class="d thin" pathLength="1" d="M300 20 L320 110 L400 120 L500 112" style="--d:1.05s"/>
    <path class="d thin" pathLength="1" d="M450 180 L500 190 M440 360 L500 330" style="--d:1.1s"/>
  </g>
  <g class="trees">
    <circle class="d" pathLength="1" cx="140" cy="250" r="8" style="--d:1.3s"/><circle class="d" pathLength="1" cx="296" cy="214" r="9" style="--d:1.35s"/>
    <circle class="d" pathLength="1" cx="166" cy="132" r="7" style="--d:1.4s"/><circle class="d" pathLength="1" cx="384" cy="196" r="8" style="--d:1.45s"/>
    <circle class="d" pathLength="1" cx="456" cy="296" r="9" style="--d:1.5s"/><circle class="d" pathLength="1" cx="40" cy="214" r="7" style="--d:1.55s"/>
    <circle class="d" pathLength="1" cx="260" cy="396" r="8" style="--d:1.6s"/><circle class="d" pathLength="1" cx="372" cy="398" r="7" style="--d:1.65s"/>
  </g>
  <path class="d road" pathLength="1" d="M72 366 C112 340 152 342 190 330 S226 318 222 304" style="--d:1.7s"/>
  <path class="d road" pathLength="1" d="M88 66 C120 110 132 150 150 200" style="--d:1.8s"/>
  <path class="d road" pathLength="1" d="M440 70 C420 140 430 200 410 250" style="--d:1.9s"/>
  <rect class="bldg" x="50" y="364" width="44" height="30" style="--d:2s"/><rect class="d" pathLength="1" x="50" y="364" width="44" height="30" style="--d:2s"/>
  <rect class="bldg" x="70" y="44" width="36" height="26" style="--d:2.05s"/><rect class="d" pathLength="1" x="70" y="44" width="36" height="26" style="--d:2.05s"/>
  <rect class="bldg" x="414" y="38" width="64" height="38" style="--d:2.1s"/><rect class="d" pathLength="1" x="414" y="38" width="64" height="38" style="--d:2.1s"/>
  <g class="lbl" style="--d:2.2s">
    <text x="330" y="296" text-anchor="middle" class="big">보스콤 연못</text>
    <text x="72" y="412" text-anchor="middle" class="sm">해덜리 농장</text>
    <text x="112" y="62" class="sm">숲지기 집</text>
    <text x="446" y="31" text-anchor="middle" class="sm">터너 저택</text>
    <text x="216" y="270" text-anchor="middle" class="sm">숲</text>
  </g>
  <g class="mark" style="--d:2.6s">
    <path d="M214 314 l14 14 M228 314 l-14 14"/>
    <text x="236" y="358" text-anchor="middle" class="mk">시신 · 오후 3시경</text>
  </g>
  <g class="lbl" style="--d:2.3s">
    <g transform="translate(470 392)"><circle r="14" class="nc"/><path d="M0 -22 L4 0 L0 4 L-4 0 Z" class="na"/><text y="-26" text-anchor="middle" class="sm">북</text></g>
    <g transform="translate(330 404)"><rect width="80" height="4" class="sb"/><rect width="20" height="4" class="sf"/><rect x="40" width="20" height="4" class="sf"/><text y="20" class="sm">0</text><text x="80" y="20" text-anchor="end" class="sm">100야드</text></g>
  </g>
</svg>`;
function showIntro() {
  const resumed = !!(state && Object.values(state.chats || {}).some((c) => c.some((m) => m.from === 'player')));
  const seal = h('button', { type: 'button', class: 'intro-seal', 'aria-label': resumed ? '봉인을 뜯고 수사 이어하기' : '봉인을 뜯고 수사 시작' },
    sv('svg', { viewBox: '0 0 120 120', 'aria-hidden': 'true' },
      sv('path', { class: 'wax a', d: 'M60 4 C80 2 98 14 108 30 C120 48 116 70 108 86 C98 106 78 118 60 116 Z' }),
      sv('path', { class: 'wax b', d: 'M60 4 C40 2 20 12 10 30 C0 50 4 72 12 88 C22 106 42 118 60 116 Z' }),
      sv('circle', { class: 'emboss', cx: 60, cy: 60, r: 34 }),
      sv('text', { class: 'emboss-t', x: 60, y: 72, 'text-anchor': 'middle' }, 'B')),
    h('span', null, resumed ? '봉인을 뜯고 이어서 수사' : '봉인을 뜯고 수사 시작'));
  const mapBox = h('div', { class: 'intro-art' });
  mapBox.innerHTML = INTRO_MAP; // 고정된 자체 그림 문자열(외부 입력 없음)
  const box = h('div', { class: 'intro', role: 'dialog', 'aria-modal': 'true', 'aria-label': '사건 파일 표지', tabindex: '-1' },
    h('div', { class: 'intro-sheet' },
      h('div', { class: 'intro-copy' },
        h('h1', { class: 'intro-title' }, h('span', null, '보스콤'), h('span', null, '밸리'), h('span', { class: 'w' }, '사건')),
        h('p', { class: 'intro-lede' }, '6월 3일 월요일 오후 3시경, 찰스 매카시가 보스콤 연못가에서 머리를 맞고 숨졌다. 아들 제임스가 체포됐고 검시 배심은 고의적 살인으로 평결했다.'),
        h('p', { class: 'intro-lede strong' }, '앨리스 터너만이 그의 무죄를 믿는다.'),
        seal,
        h('p', { class: 'intro-src' }, state && state.source ? state.source : '')),
      mapBox));
  const done = () => {
    if (box.classList.contains('leaving')) return;
    box.classList.add('leaving');
    setTimeout(() => { box.remove(); firstGuide(); }, REDUCED ? 0 : 1100);
    try { sessionStorage.setItem('bv_intro', '1'); } catch (e) { /* 무시 */ }
  };
  seal.addEventListener('click', done);
  box.addEventListener('keydown', (e) => { if (e.key === 'Escape' || (e.key === 'Enter' && e.target === box)) done(); });
  $('overlay-root').append(box);
  box.focus({ preventScroll: true }); // 표지 자체에 초점: Enter·Esc로 넘기고, Tab이면 봉인 버튼으로
}

// ---------- 네트워크 ----------
async function api(path, body) {
  const opt = body ? { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {};
  let res;
  try { res = await fetch(path, opt); } catch (e) { throw new Error('서버에 연결하지 못했습니다. 게임 폴더의 START.cmd를 실행해 주세요.'); }
  let data = null;
  try { data = await res.json(); } catch (e) { /* 아래에서 처리 */ }
  if (!data || data.ok === false) throw new Error((data && data.message) || '요청을 처리하지 못했습니다.');
  return data;
}
async function startSession() {
  let saved = null;
  try { saved = localStorage.getItem('abbey_session'); } catch (e) { /* 무시 */ }
  const data = await api('/api/session', saved ? { sessionId: saved } : {});
  sessionId = data.sessionId;
  try { localStorage.setItem('abbey_session', sessionId); } catch (e) { /* 무시 */ }
  state = data.state;
  ui.chatPid = null;
}
// 행동 호출. 성공하면 상태를 바꾸고 events를 처리한다.
// 스트리밍 행동: 서버가 한 줄씩 {phase} 진행을 보내고 마지막 줄에 {done, state, events}. 스트리밍이 안 되면 일반 호출로.
async function apiStream(body, onProgress) {
  let res;
  try { res = await fetch('/api/action', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...body, stream: true }) }); }
  catch (e) { throw new Error('서버에 연결하지 못했습니다. 게임 폴더의 START.cmd를 실행해 주세요.'); }
  if (!res.body || !(res.headers.get('content-type') || '').includes('ndjson')) {
    const d = await res.json().catch(() => null);
    if (!d || d.ok === false) throw new Error((d && d.message) || '요청을 처리하지 못했습니다.');
    return d;
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '', last = null;
  for (;;) {
    const { value, done } = await reader.read();
    if (value) buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (!line) continue;
      let o; try { o = JSON.parse(line); } catch (e) { continue; }
      if (o.done) last = o; else { try { onProgress(o); } catch (e) { /* 화면 갱신 실패는 무시 */ } }
    }
    if (done) break;
  }
  if (!last || last.ok === false) throw new Error((last && last.message) || '요청을 처리하지 못했습니다.');
  return last;
}
async function act(body, opts = {}) {
  try {
    const req = { sessionId, ...body, hintsOn: !ui.leadOff };
    const data = opts.onProgress ? await apiStream(req, opts.onProgress) : await api('/api/action', req);
    const prev = state;
    state = data.state;
    if (body.type === 'reset') resetUi();
    handleEvents(data.events || [], prev);
    if (!opts.silent) renderAll();
    return data;
  } catch (e) {
    toast(e.message, 'error');
    if (!opts.silent) renderAll();
    return null;
  }
}
function resetUi() {
  ui.desk = []; ui.attach = []; ui.chatPid = null; ui.pendingMsg = null; ui.pulse.clear();
  ui.draft = { culprit: '', method: '', motive: '', reasoning: '', evidenceIds: [], exclusions: {} };
  ui.noteDraft = null; ui.seenBroken.clear(); ui.tab = 'map'; ui.picked = null; ui.miss = null; ui.dragEv = null; ui.contactPulse = null;
}

// ---------- 이벤트 ----------
function handleEvents(events, prev) {
  // 실마리 진행률이 올라가면 새로 찬 칸을 튀게 한다
  const a = prev && prev.lead && prev.lead.progress, b = state && state.lead && state.lead.progress;
  ui.pipPop = a && b && b.have > a.have && a.need === b.need ? b.have - 1 : -1;
  const big = events.some((e) => e.kind === 'confession'); // 자백 장면을 가리지 않게 단서 알림은 생략한다
  const pre = !!ui.preAnnounced; ui.preAnnounced = false; // 스트리밍 중 이미 알린 단서·장소
  for (const ev of events) {
    if (big && ev.kind === 'knowledge') continue;
    switch (ev.kind) {
      case 'evidence_found': toast('증거 발견: ' + (ev.title || ev.evidenceId)); break;
      case 'location_unlocked': ui.pulse.add(ev.locationId); if (!pre) toast('새 장소가 열렸습니다: ' + (ev.name || ev.locationId)); break;
      case 'person_appeared': toast('인물 등장: ' + (ev.name || ev.pid)); break;
      case 'statement_heard': toast('진술을 확보했습니다.'); break;
      case 'knowledge':
        if (ev.deduction) { showStamp('추리 성립', pre ? null : '수사 기록에 올랐습니다 · 상대가 비웃어도 성립합니다', pre); break; }
        if (!pre) toast('새 단서: ' + String(ev.text || '').slice(0, 60)); break;
      case 'objection':
        if (ev.success) { showCutin(ev.via === 'confront' ? '대질!' : '이의 있음!'); toast((ev.via === 'confront' ? '대질로 진술이 깨졌습니다' : '모순을 찾았습니다') + (ev.note ? ': ' + ev.note : '')); }
        else { ui.shake = ev.statementId; toast('이 증거로는 모순을 밝힐 수 없습니다.', 'error'); }
        break;
      case 'judge': showJudge(ev); break;
      case 'confession': showConfession(ev.pid); break;
      case 'admission': toast('부분 인정을 이끌어 냈습니다. 자백은 아직입니다.'); break;
      case 'refused': toast('상대가 대화를 거절했습니다.'); break;
      case 'submitted': toast('결론을 제출했습니다. 점수: ' + ev.score); ui.tab = 'conclusion'; break;
      default: break;
    }
  }
}
function toast(text, kind) {
  const box = $('toasts');
  const same = [...box.children].find((c) => c.dataset.text === text);
  if (same) { same.classList.remove('bump'); void same.offsetWidth; same.classList.add('bump'); return; }
  const t = h('div', { class: 'toast' + (kind === 'error' ? ' error' : ''), role: kind === 'error' ? 'alert' : 'status', data: { text }, onclick: () => t.remove() }, text);
  box.append(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, kind === 'error' ? 5000 : 3500);
}
// 도장 연출(추리 성립 등): 화면 가운데에 잠깐 찍히고 사라진다. 클릭을 막지 않는다.
function showStamp(word, sub, quiet) {
  if (!quiet) toast(word + (sub ? ' — ' + sub : ''));
  if (REDUCED) return;
  const c = h('div', { class: 'stampfx', 'aria-hidden': 'true' }, h('span', null, word));
  $('overlay-root').append(c);
  setTimeout(() => c.remove(), 1300);
}
function showCutin(word) {
  if (REDUCED) return;
  const c = h('div', { class: 'cutin', 'aria-hidden': 'true' }, h('span', null, word || '이의 있음!'));
  $('overlay-root').append(c);
  setTimeout(() => c.remove(), 850);
}
function hammerSvg() {
  return sv('svg', { viewBox: '0 0 64 64', 'aria-hidden': 'true' },
    sv('rect', { x: 8, y: 14, width: 34, height: 16, rx: 3, fill: '#c9a24b', transform: 'rotate(-30 25 22)' }),
    sv('rect', { x: 28, y: 28, width: 7, height: 32, rx: 2, fill: '#8a6a3a', transform: 'rotate(-30 31 44)' }),
    sv('rect', { x: 36, y: 54, width: 24, height: 6, rx: 2, fill: '#6b5a24' }));
}
function showJudge(ev) {
  const ok = ev.verdict === 'approved';
  const who = (state && state.people.find((p) => p.pid === ev.pid)) || { name: ev.pid };
  openModal('judge', (close) => h('div', { class: 'paper judge-card ' + (ok ? 'approved' : 'denied') },
    hammerSvg(), h('div', { class: 'big' }, ok ? '승인' : '기각'),
    h('p', null, '소환 대상: ' + who.name), h('p', null, ev.reason || ''),
    h('div', { class: 'actions' }, h('button', { type: 'button', class: 'primary', onclick: close, 'aria-label': '판결 닫기' }, '확인'))), { title: '판사의 판결' });
}
function showConfession(pid) {
  const p = state && state.people.find((x) => x.pid === pid);
  const chat = (state && state.chats && state.chats[pid]) || [];
  const last = [...chat].reverse().find((m) => m.from === 'npc');
  const text = last ? last.text : '…모든 것을 인정하겠소.';
  // 문장 단위로 한 줄씩 떠오르게 한다(진술서에 한 문장씩 받아 적는 느낌).
  const parts = text.match(/[^.!?。…]+[.!?。…]+["'”’]?\s*|[^.!?。…]+$/g) || [text];
  const box = h('div', { class: 'confession', role: 'dialog', 'aria-modal': 'true', 'aria-label': (p ? p.name : '') + '의 자백', tabindex: '0' },
    h('div', { class: 'cf-sheet' },
      h('div', { class: 'cf-band' }, h('span', null, '자백 조서'), h('span', null, state && state.title ? state.title : '')),
      h('div', { class: 'who' }, (p ? p.name : '') + '의 자백'),
      h('div', { class: 'line' }, parts.map((t, i) => h('span', { class: 'cf-s', style: `--i:${i}` }, t.trim() + ' '))),
      h('div', { class: 'cf-stamp', 'aria-hidden': 'true', style: `--n:${parts.length}` }, '자백'),
      h('div', { class: 'tap' }, '아무 곳이나 눌러 닫기 · 결론 탭에서 제출하면 자백 점수가 더해집니다')));
  const close = () => box.remove();
  box.addEventListener('click', close);
  box.addEventListener('keydown', (e) => { if (e.key === 'Escape' || e.key === 'Enter') close(); });
  $('overlay-root').append(box);
  box.focus();
}

// ---------- 모달 ----------
function openModal(name, build, opt = {}) {
  const prevFocus = document.activeElement;
  const back = h('div', { class: 'modal-back', data: { modal: name } });
  // Esc는 초점이 어디 있든 맨 위 창 하나만 닫는다(창 안 버튼을 코드로 누른 뒤에도 닫히게).
  const onKey = (e) => { if (e.key === 'Escape' && [...$('overlay-root').querySelectorAll('.modal-back')].pop() === back) { e.preventDefault(); close(); } };
  const close = () => { document.removeEventListener('keydown', onKey); back.remove(); if (prevFocus && prevFocus.focus && document.contains(prevFocus)) prevFocus.focus(); };
  document.addEventListener('keydown', onKey);
  const modal = h('div', { class: 'modal' + (opt.cls ? ' ' + opt.cls : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': opt.title || name },
    opt.title ? h('h2', null, opt.title) : null, build(close));
  back.append(modal);
  back.addEventListener('mousedown', (e) => { if (e.target === back) close(); });
  $('overlay-root').append(back);
  const f = modal.querySelector('button, input, textarea, select');
  if (f) f.focus();
  return close;
}
function confirmBox(title, message, okLabel) {
  return new Promise((resolve) => {
    let done = false;
    const fin = (v) => { if (!done) { done = true; resolve(v); } };
    const close = openModal('confirm', (c) => h('div', null, h('p', null, message),
      h('div', { class: 'actions' },
        h('button', { type: 'button', onclick: () => { c(); fin(false); }, 'aria-label': '취소' }, '취소'),
        h('button', { type: 'button', class: 'primary', onclick: () => { c(); fin(true); }, 'aria-label': okLabel }, okLabel))), { title });
    // Esc/바깥 클릭으로 닫힌 경우도 취소 처리
    const back = document.querySelector('[data-modal="confirm"]');
    const obs = new MutationObserver(() => { if (!document.body.contains(back)) { obs.disconnect(); fin(false); } });
    obs.observe($('overlay-root'), { childList: true });
    void close;
  });
}
function evidencePicker({ title, multi, preset, okLabel, extra }) {
  return new Promise((resolve) => {
    const opened = state.evidence.filter((e) => e.opened);
    const sel = new Set(preset || []);
    openModal('picker', (close) => {
      const list = h('div', { class: 'check-grid' }, opened.map((e) => {
        const input = h('input', { type: multi ? 'checkbox' : 'radio', name: 'pick', value: e.id, checked: sel.has(e.id) });
        input.addEventListener('change', () => {
          if (!multi) sel.clear();
          if (input.checked) sel.add(e.id); else sel.delete(e.id);
        });
        return h('label', null, input, h('span', null, e.title));
      }));
      return h('div', null, extra || null,
        opened.length ? list : h('div', { class: 'empty' }, '열람한 증거가 없습니다. 증거 탭에서 봉인을 먼저 열어 보세요.'),
        h('div', { class: 'actions' },
          h('button', { type: 'button', onclick: () => { close(); resolve(null); }, 'aria-label': '취소' }, '취소'),
          h('button', { type: 'button', class: 'primary', 'aria-label': okLabel, onclick: () => { close(); resolve([...sel]); } }, okLabel)));
    }, { title });
  });
}

// ---------- 수사 안내서: 기능 설명 ----------
// 머리줄 「수사 안내」와 각 탭 위 안내 띠의 「자세히」가 여기를 연다. 사건의 답은 담지 않는다.
const GUIDE = [
  { id: 'start', title: '처음 5분', lead: '로스의 호텔(헤리퍼드 암스)에서 시작합니다. 레스트레이드 경감이 늘 곁에 있고, 앨리스 터너도 호텔에 와 있습니다.',
    steps: [
      ['사건부터 듣기', '오른쪽 인물 패널에서 레스트레이드 경감을 고르고 사건 개요를 물어보세요. 추천 질문 칩을 눌러도 됩니다.'],
      ['장소 열기', '현장(연못·농장)과 감옥은 경감에게 청해야 열립니다. 앨리스에게 옛날 일을 물으면 전신국이 열립니다.'],
      ['조사하고 증거 읽기', '지도에서 장소로 옮긴 뒤 번호 핀을 눌러 조사합니다. 새 증거는 증거 탭에서 봉인을 뜯어 읽습니다.'],
      ['맞대고 깨뜨리기', '맞대기 보드에서 증거끼리·인물끼리 맞대고, 진술 탭에서 어긋나는 증거로 「이의 있음!」을 외칩니다.'],
      ['추리를 세우고 결론 내기', '현장에서 읽은 것을 경감에게 직접 말해 추리로 세우고, 근거가 차면 응접실에서 소환을 청합니다. 결론은 언제든 낼 수 있지만 첫 제출이 최종입니다.'],
    ] },
  { id: 'map', title: '지도와 조사', lead: '지도 탭 위쪽이 영지 지도, 오른쪽 띠가 로스·헤리퍼드 쪽 장소입니다.',
    items: [
      ['이동', '장소를 누르면 그곳으로 갑니다. 아직 열리지 않은 장소는 지도에서 가려져 있고, 새로 열린 장소에는 표시가 붙습니다.'],
      ['번호 핀', '지금 있는 장소의 조사 지점입니다. 누르면 그 자리를 살피고, 무언가 나오면 증거가 됩니다. 앞선 증거가 있어야 보이는 지점도 있습니다.'],
      ['장소 안내', '지도 아래 장소 패널에 그곳에서 해 볼 만한 일이 두 줄까지 나옵니다. 다 살피면 「모두 살폈습니다」로 바뀝니다.'],
      ['보기 전환', '「한눈에 보기 / 확대해서 보기」로 지도 크기를 바꾸고, 머리의 ▾를 눌러 지도와 보드를 접을 수 있습니다(브라우저가 기억).'],
    ] },
  { id: 'lead', title: '다음 실마리', lead: '지도 탭 맨 위 붉은 띠는 지금 막힌 곳의 다음 한 걸음을 짚어 줍니다. 답은 말하지 않고 “어디를 무엇으로 볼지”만 알려 줍니다.',
    items: [
      ['바로가기', '띠 오른쪽 버튼(「경감에게 →」 「해덜리 농장(으)로 →」 등)을 누르면 그 사람이 있는 곳이나 그 장소로 바로 옮깁니다.'],
      ['진행률', '추리 세우기처럼 여러 개가 필요한 단계는 ●○ 칸으로 몇 개를 채웠는지 보여 줍니다.'],
      ['숨기기', '「숨기기」를 누르면 실마리 띠와 추천 질문이 모두 사라집니다. 끝까지 숨긴 채 해결하면 결과 화면에 「실마리 없이 해결」 배지가 붙습니다.'],
    ] },
  { id: 'talk', title: '대화 — 자유 심문', lead: '정해진 선택지 없이 아무 말로나 묻습니다. 인물은 자기가 보고 들은 것, 그리고 지금 조건에서 털어놓을 수 있는 것만 말합니다.',
    items: [
      ['누구와', '오른쪽 위 인물 칩에서 고릅니다. 같은 장소에 있는 사람(● 표시)과만 대화할 수 있고, 없는 사람은 어디서 만날 수 있는지 알려 줍니다.'],
      ['추천 질문', '대화창 아래 칩은 진행도에 맞춘 질문입니다. 실선 칩은 바로 보내고, 점선 칩(… 로 끝남)은 입력창에 앞부분만 채워 주니 끝은 직접 맺으세요.'],
      ['증거 내밀기', '「증거 첨부」로 증거를 골라 질문과 함께 보내면 상대에게 내미는 것이 됩니다. 특히 터너 씨를 추궁할 때는 증거를 들이대야 합니다.'],
      ['말이 안 나올 때', '같은 걸 다르게 물어보거나, 그 사람이 아끼는 사람의 말을 전하거나, 다그치지 말고 천천히 물어보세요. 조건이 맞지 않으면 모른다고 하거나 말을 돌립니다.'],
      ['답이 오는 순서', '먼저 “새 단서 · 장소 열림” 알림이 뜨고, 이어서 대사가 문장 단위로 흘러나옵니다. AI 연결이 없을 때는 미리 써 둔 정본 대사로 답합니다.'],
      ['신뢰·압박', '말을 나눈 인물에게는 신뢰·압박 막대가 생깁니다. 위로하면 신뢰 +6, 정중하면 +2, 비밀을 지키겠다고 약속하면 +10이고, 증거 없이 몰아세우면 신뢰 −10·압박 +8, 위협하면 신뢰 −15·압박 +15, 관련 증거를 들이대면 압박 +15입니다. 신뢰가 쌓여야 털어놓는 비밀이 있고(제임스·앨리스), 겁을 너무 주면 입을 닫는 사람도 있습니다(페이션스).'],
      ['압박에 대해', '인물은 다그친다고 없는 일을 자백하지 않고, 모르는 사실을 지어내지 않습니다. 자백은 근거를 갖췄을 때만 나옵니다.'],
    ] },
  { id: 'evidence', title: '증거 카드', lead: '조사로 찾은 증거는 봉인된 채 증거 탭에 쌓입니다. 눌러서 봉인을 뜯어야 내용을 읽고 쓸 수 있습니다.',
    items: [
      ['카드 읽는 법', '맨 위는 종류(기록·현장 물품·현장 흔적·현장 관찰·증언 기록)와 찾은 곳, 그 아래 기울어진 글씨가 생김새, 본문이 관찰 기록, 맨 아래 「수사 메모」가 무엇을 볼 거리인지입니다.'],
      ['자세히', '카드 제목이나 「자세히」를 누르면 크게 펼쳐집니다. 이 증거를 누구에게 내밀었는지, 무엇과 맞대 착안을 얻었는지도 여기 모입니다.'],
      ['대조 책상', '「책상에 펼치기」로 두 장까지 나란히 놓고 읽습니다. 세 번째를 펼치면 먼저 놓은 것이 치워집니다.'],
      ['관찰 기록은 사실만', '증거에는 해석이 없습니다. “그래서 무엇을 뜻하는가”는 맞대고 묻고 말해서 세워야 하며, 해석과 한계는 결론을 낸 뒤 해설로 나옵니다.'],
    ] },
  { id: 'board', title: '맞대기 보드', lead: '지도 아래 보드에서 인물·증거 토큰을 끌어다 다른 토큰 위에 놓습니다. 끌기가 불편하면 하나를 누른 뒤 대상을 눌러도 됩니다.',
    table: [['증거 → 인물', '내밀기', '그 인물에게 증거를 보여 줍니다. 대화창에서 첨부해 보내는 것과 같습니다.'],
      ['증거 ↔ 증거', '착안', '관계가 있는 짝이면 두 증거를 붉은 실로 잇는 착안 카드가 열립니다. 카드는 결론 대신 질문을 던집니다.'],
      ['인물 ↔ 인물', '대질', '두 사람에게서 같은 일에 대한 말을 들은 뒤에만 성립합니다. 인물 토큰의 ⇄를 눌러 집습니다. 대질로 목격 진술이 깨지기도 합니다.']],
    items: [
      ['착안 다음에', '착안 카드의 질문에 답이 떠올랐다면 그 생각을 경감에게 직접 말해야 추리로 성립합니다. 카드의 「…에게 말하러 가기」로 바로 갈 수 있습니다.'],
      ['헛짚음', '이어지지 않는 짝을 맞대면 흔들리고 끝납니다. 감점은 없지만 횟수가 기록에 남아 결과 화면에 나옵니다.'],
    ] },
  { id: 'objection', title: '진술과 이의 제기', lead: '진술 탭에는 사건을 제임스에게 불리하게 만든 목격 진술 두 건이 처음부터 있습니다.',
    items: [
      ['이의 있음!', '진술 카드의 버튼을 누르고, 그 진술과 어긋나는 증거 하나를 고릅니다. 맞으면 「모순」 도장이 찍히고 진술이 깨집니다.'],
      ['틀려도 괜찮습니다', '맞지 않는 증거를 고르면 카드가 흔들리기만 합니다. 다른 증거로 다시 시도할 수 있습니다.'],
      ['다른 길', '두 목격자는 맞대기 보드의 대질로도 깨집니다. 어느 쪽으로 깨뜨려도 결과는 같습니다.'],
    ] },
  { id: 'deduce', title: '추리 세우기', lead: '이 게임의 추리는 고르는 것이 아니라 말하는 것입니다. 현장 흔적에서 읽은 것을 레스트레이드 경감에게 문장으로 말하세요.',
    items: [
      ['말하는 법', '예를 들어 “범인은 …” 하고 흔적이 가리키는 몸의 특징이나 말의 뜻을 짚어 말합니다. 대화창의 점선 칩이 앞부분을 채워 줍니다.'],
      ['경감의 반응', '경감은 원작대로 “공상”이라며 비웃습니다. 그래도 전제가 되는 증거를 갖추고 말했다면 「추리 성립」 도장이 찍히고 수사 기록에 오릅니다.'],
      ['어디에 쓰나', '성립한 추리는 터너 씨를 응접실로 부를 근거가 되고(세 가지 이상), 결론 채점에서도 “직접 확인한 내용”으로 인정됩니다.'],
    ] },
  { id: 'summon', title: '소환과 자백', lead: '병석의 지주 존 터너는 그냥 찾아가서는 만나 주지 않습니다.',
    items: [
      ['소환 신청', '호텔 응접실에서 「소환 신청」을 누르면 판사가 근거를 보고 승인하거나 기각합니다. 기각되면 무엇이 모자란지 판결문에 적혀 나옵니다.'],
      ['추궁', '터너 씨가 오면 증거를 첨부해 들이대며 묻습니다. 과거를 먼저 인정하게 만든 뒤(부분 인정), 그날 연못의 일을 정면으로 따져야 합니다.'],
      ['자백 조서', '자백을 받으면 조서가 한 줄씩 펼쳐집니다. 인물 패널의 「자백 조서 다시 보기」로 언제든 다시 볼 수 있습니다.'],
    ] },
  { id: 'notes', title: '노트·수사 기록', lead: '모은 것은 두 탭에 정리됩니다.',
    items: [
      ['노트', '사람별 카드에 들은 이야기, 아직 더 물어볼 거리의 수(무엇인지는 숨김), 내민 증거 수가 모입니다. 「찾아가서 묻기」로 그 사람에게 바로 갑니다.'],
      ['수사 기록', '얻은 인물 지식, 맞대기로 찾은 착안·대질, 판사 기록, 타임라인, 그리고 자동 저장되는 개인 메모 칸이 있습니다.'],
    ] },
  { id: 'conclusion', title: '결론과 채점', lead: '결론 탭은 처음부터 열려 있습니다. 제출하면 고칠 수 없습니다.',
    table: [['범인 지목', '20점', '용의자 네 사람 가운데 한 명'], ['자백 확보', '10점', '범인을 맞히고 자백까지 받았을 때'],
      ['수법·동기·해석', '30점', '이 판에서 직접 확인한 내용만 인정(원작 기억만으로 쓴 답은 점수 없음)'], ['근거 증거', '10점', '범인을 가리키는 증거, 6개까지 고르기'],
      ['용의자 배제', '30점', '다른 세 사람이 범인일 수 없는 근거, 한 사람에 3개까지']],
    items: [['결과 화면', '점수와 채점 막대, 정답 요약, 원작 타임라인, 증거별 해석과 한계, 그리고 이번 수사의 기록(착안·대질·헛짚음·걸린 시간·AI 호출 비용)이 나옵니다.']] },
  { id: 'tips', title: '작은 팁',
    items: [
      ['입력', 'Enter로 보내고 Shift+Enter로 줄을 바꿉니다. 창은 Esc로 닫힙니다.'],
      ['다시 보기', '「개요 보기」는 사건 개요를, 주소 끝의 #intro는 표지를 다시 엽니다.'],
      ['처음부터', '「새 수사」는 이 브라우저의 기록을 모두 지우고 새로 시작합니다.'],
      ['이 안내서', '언제든 머리줄의 「수사 안내」로 다시 열 수 있고, 각 탭 위 안내 띠의 「자세히」도 이곳의 해당 항목으로 옵니다.'],
    ] },
];
// 탭 위 한 줄 안내(→ 안내서 항목)
const TAB_GUIDE = {
  map: ['장소를 눌러 옮기고, 번호 핀을 눌러 조사합니다. 아래 맞대기 보드에서 증거·인물을 서로 맞대 봅니다.', 'map'],
  evidence: ['봉인을 뜯으면 생김새·관찰 기록·수사 메모가 나옵니다. 제목을 누르면 크게 보고, 두 장까지 책상에 펼쳐 대조합니다.', 'evidence'],
  statements: ['목격자의 진술입니다. 어긋나는 증거를 골라 「이의 있음!」을 외치면 진술을 깨뜨릴 수 있습니다.', 'objection'],
  notes: ['사람별로 들은 이야기와 아직 남은 물어볼 거리를 모았습니다.', 'notes'],
  records: ['얻은 지식, 맞대기 기록, 판사 판결, 타임라인과 개인 메모가 모여 있습니다.', 'notes'],
  conclusion: ['범인·수법·동기와 근거를 적어 제출합니다. 첫 제출이 최종입니다.', 'conclusion'],
};
function showGuide(sectionId) {
  let cur = GUIDE.find((g) => g.id === sectionId) || GUIDE[0];
  openModal('guide', (close) => {
    const nav = h('nav', { class: 'gd-nav', 'aria-label': '안내 항목' });
    const body = h('div', { class: 'gd-body', tabindex: '-1' });
    const draw = () => {
      clear(nav); clear(body);
      GUIDE.forEach((g, i) => nav.append(h('button', { type: 'button', class: 'gd-tab', 'aria-current': String(g === cur), onclick: () => { cur = g; draw(); body.scrollTop = 0; } },
        h('span', { class: 'gd-no' }, String(i + 1).padStart(2, '0')), g.title)));
      body.append(h('h3', { class: 'gd-title' }, cur.title));
      if (cur.lead) body.append(h('p', { class: 'gd-lead' }, cur.lead));
      if (cur.steps) body.append(h('ol', { class: 'gd-steps' }, cur.steps.map(([k, v]) => h('li', null, h('b', null, k), h('span', null, v)))));
      if (cur.table) body.append(h('div', { class: 'gd-table' }, cur.table.map((r) => h('div', { class: 'gd-tr' }, h('b', null, r[0]), h('span', { class: 'gd-tag' }, r[1]), h('span', null, r[2])))));
      if (cur.items) body.append(h('dl', { class: 'gd-items' }, cur.items.flatMap(([k, v]) => [h('dt', null, k), h('dd', null, v)])));
      const i = GUIDE.indexOf(cur);
      body.append(h('div', { class: 'gd-pager' },
        i > 0 ? h('button', { type: 'button', onclick: () => { cur = GUIDE[i - 1]; draw(); body.scrollTop = 0; } }, '← ' + GUIDE[i - 1].title) : h('span'),
        i < GUIDE.length - 1 ? h('button', { type: 'button', class: 'primary', onclick: () => { cur = GUIDE[i + 1]; draw(); body.scrollTop = 0; } }, GUIDE[i + 1].title + ' →')
          : h('button', { type: 'button', class: 'primary', onclick: close }, '수사로 돌아가기')));
      // 휴대폰에서는 항목 줄이 가로로 넘치므로 지금 항목을 가운데로 민다(세로 스크롤은 건드리지 않음)
      const on = nav.querySelector('[aria-current="true"]');
      if (on && nav.scrollWidth > nav.clientWidth) requestAnimationFrame(() => { nav.scrollLeft = on.offsetLeft - (nav.clientWidth - on.offsetWidth) / 2; });
    };
    draw();
    const tgl = h('input', { type: 'checkbox', checked: !ui.guideOff });
    tgl.addEventListener('change', () => { ui.guideOff = !tgl.checked; try { localStorage.setItem('boscombe.guideOff', ui.guideOff ? '1' : '0'); } catch (e) { /* 무시 */ } renderMain(); });
    return h('div', null, h('div', { class: 'guide' }, nav, body), h('label', { class: 'gd-toggle' }, tgl, h('span', null, '탭마다 위쪽에 한 줄 안내 띠 보이기')));
  }, { title: '수사 안내서', cls: 'wide guide-modal' });
}
// 이 브라우저에서 처음 수사를 시작할 때 한 번만 '처음 5분'을 펼친다.
function firstGuide() {
  let seen = false;
  try { seen = localStorage.getItem('boscombe.guideSeen') === '1'; localStorage.setItem('boscombe.guideSeen', '1'); } catch (e) { seen = true; }
  if (!seen && !document.querySelector('.modal-back')) showGuide('start');
}
function tabGuide(tab) {
  const g = TAB_GUIDE[tab];
  if (!g || ui.guideOff) return null;
  return h('div', { class: 'tab-guide' }, h('span', { class: 'tg-mark', 'aria-hidden': 'true' }, '?'), h('span', { class: 'tg-text' }, g[0]),
    h('button', { type: 'button', class: 'tg-more', 'aria-label': '이 화면 설명 자세히 보기', onclick: () => showGuide(g[1]) }, '자세히'),
    h('button', { type: 'button', class: 'tg-hide', 'aria-label': '탭 안내 띠 숨기기', title: '안내 띠 숨기기(수사 안내에서 다시 켤 수 있음)', onclick: () => {
      ui.guideOff = true; try { localStorage.setItem('boscombe.guideOff', '1'); } catch (e) { /* 무시 */ } renderMain();
      toast('탭 안내 띠를 숨겼습니다. 머리줄의 「수사 안내」에서 다시 켤 수 있습니다.');
    } }, '✕'));
}

// ---------- 렌더링 ----------
function renderAll() {
  if (!state) return;
  if (state.place === 'scene') ui.lastScene = state.locationId;
  renderTop(); renderTabs(); renderMain(); renderSide();
}
function renderTop() {
  const s = state.stats || {};
  const titleEl = document.querySelector('.case-title');
  if (titleEl && state.title) titleEl.textContent = state.title;
  if (state.title) document.title = `${state.title} — 자유 심문 수사판`;
  const box = $('stats'); clear(box);
  box.append(
    h('span', null, '증거 ', h('b', null, `${s.evidenceFound ?? 0}/${s.evidenceTotal ?? 0}`)),
    h('span', null, '깨뜨린 진술 ', h('b', null, `${s.statementsBroken ?? 0}/${s.statementsTotal ?? 0}`)));
}
function renderTabs() {
  const nav = $('tabs'); clear(nav);
  const newEv = state.evidence.some((e) => !e.opened);
  // 아직 쌓인 것이 없는 탭은 흐리게, 쌓인 것은 개수를 붙여 무엇이 열렸는지 한눈에 보이게 한다.
  const cnt = { evidence: state.evidence.length, statements: state.statements.length, notes: state.people.reduce((n, p) => n + (p.heard || 0), 0), records: state.knowledge.length + state.judge.length + (state.insights || []).length };
  TABS.forEach(([id, label]) => {
    const n = cnt[id];
    const b = h('button', { type: 'button', role: 'tab', class: 'tab' + (n === 0 ? ' quiet' : ''), id: 'tab-' + id, 'aria-selected': String(ui.tab === id), 'aria-label': label + ' 탭' + (n ? `, ${n}건` : ''), onclick: () => { ui.tab = id; renderTabs(); renderMain(); } }, label, n ? h('span', { class: 'cnt', 'aria-hidden': 'true' }, String(n)) : null);
    if (id === 'evidence' && newEv) b.append(h('span', { class: 'dot', title: '미열람 증거' }));
    nav.append(b);
  });
}
function renderMain() {
  const panel = $('tabpanel');
  const keepScroll = panel.scrollTop;
  clear(panel);
  panel.setAttribute('aria-labelledby', 'tab-' + ui.tab);
  const tg = state.submitted && ui.tab === 'conclusion' ? null : tabGuide(ui.tab);
  if (tg) panel.append(tg);
  ({ map: renderMap, evidence: renderEvidence, statements: renderStatements, notes: renderNotes, records: renderRecords, conclusion: renderConclusion })[ui.tab](panel);
  panel.scrollTop = keepScroll;
}

// --- 지도 ---
// 애비 그레인지 저택 도면: 시안 v3 M안의 평면도 그림을 그대로 옮긴 것(1000×700 도면을 영지 틀 안에 축소).
// 누를 수 있는 곳은 사건 팩의 장소(식당·신관·연못·정문 관리소)이고, 나머지 방은 도면 배경이다.
function abbeyHouse(svg, byId, fogged) {
  const INK = '#1c2230', FL = '#f0eedf';
  const g = sv('g', { class: 'house', transform: 'translate(8 30) scale(0.656)' });
  const raw = (html) => { const x = sv('g', null); x.innerHTML = html; return x; };
  const flr = (x, y, w, h, cls) => `<rect ${cls ? 'class="fl"' : `fill="${FL}"`} x="${x + 2}" y="${y + 2}" width="${w - 4}" height="${h - 4}"/>`;
  const trees = [[70, 300, 22], [118, 336, 18], [60, 420, 26], [160, 470, 20], [800, 330, 20], [850, 420, 24], [760, 520, 20], [620, 560, 22], [40, 220, 20], [820, 270, 16], [300, 560, 22], [200, 610, 18], [90, 560, 20]]
    .map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#c1cba3" stroke="#454c5a" stroke-width="1"/><circle cx="${x - r * 0.25}" cy="${y - r * 0.2}" r="${r * 0.45}" fill="none" stroke="#8a8467" stroke-width=".8"/>`).join('');
  const drive = `<path d="M930 692 C930 560 800 500 790 380 S770 250 750 190" fill="none" stroke="${INK}" stroke-width="30"/><path d="M930 692 C930 560 800 500 790 380 S770 250 750 190" fill="none" stroke="#d3d4b9" stroke-width="26"/>`;
  const terrace = '<rect x="360" y="352" width="230" height="30" fill="#dadec8" stroke="#454c5a" stroke-width=".8"/>' + [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((i) => `<line x1="${367 + i * 14}" y1="352" x2="${367 + i * 14}" y2="382" stroke="#a89f80" stroke-width=".6"/>`).join('');
  const walls = [[220, 40, 140, 160], [360, 40, 115, 160], [475, 40, 115, 160], [590, 40, 130, 310], [220, 200, 140, 150], [360, 200, 230, 150], [30, 60, 140, 130]]
    .map(([x, y, w, h]) => `<rect x="${x - 4}" y="${y - 4}" width="${w + 8}" height="${h + 8}" fill="${INK}"/>`).join('') + `<rect x="166" y="104" width="58" height="42" fill="${INK}"/>`;
  const gaps = [[355, 282, 10, 30], [585, 250, 10, 40], [585, 74, 10, 30], [355, 84, 10, 34], [262, 195, 38, 10], [170, 110, 54, 30]].map(([x, y, w, h]) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${FL}"/>`).join('');
  const frenchWin = `<rect x="436" y="346" width="88" height="9" fill="${FL}"/><path d="M438 350 q0 -30 30 -30 M522 350 q0 -30 -30 -30" fill="none" stroke="${INK}" stroke-width=".9" stroke-dasharray="3 2"/><line x1="436" y1="349" x2="524" y2="349" stroke="${INK}" stroke-width="1.4"/><line x1="436" y1="352" x2="524" y2="352" stroke="${INK}" stroke-width="1.4"/>`;
  const hall = [0, 1, 2, 3, 4, 5, 6, 7].map((i) => `<line x1="602" y1="${54 + i * 9}" x2="702" y2="${54 + i * 9}" stroke="${INK}" stroke-width="1"/>`).join('') + `<rect x="602" y="54" width="100" height="72" fill="none" stroke="${INK}" stroke-width="1.4"/><text x="652" y="148" text-anchor="middle" class="rk">계단 ↑</text><text class="rn" x="600" y="190">현관 홀</text>`;
  const porch = `<rect x="718" y="164" width="22" height="52" fill="${FL}" stroke="${INK}" stroke-width="1.6"/>` + [0, 1, 2, 3].map((i) => `<line x1="${722 + i * 5}" y1="166" x2="${722 + i * 5}" y2="214" stroke="${INK}" stroke-width=".8"/>`).join('') + `<rect x="716" y="176" width="8" height="28" fill="${FL}"/>`;
  const furn1 = `<rect x="395" y="202" width="62" height="20" fill="${INK}"/><rect x="404" y="204" width="44" height="12" fill="#dcdfc9"/><line x1="395" y1="224" x2="457" y2="224" stroke="${INK}" stroke-width="1.6"/>`
    + `<rect x="396" y="252" width="76" height="62" fill="#d2c58f" stroke="${INK}" stroke-width="1"/>` + [0, 1, 2, 3, 4, 5, 6].map((i) => `<line x1="${396 + i * 12 + 4}" y1="252" x2="${396 + i * 12 - 4}" y2="314" stroke="#8a7440" stroke-width=".8"/>`).join('')
    + `<rect x="494" y="230" width="26" height="30" fill="${FL}" stroke="${INK}" stroke-width="1.2"/><line x1="494" y1="234" x2="520" y2="234" stroke="${INK}" stroke-width="2.4"/>`
    + `<rect x="572" y="222" width="16" height="96" fill="#dcdfc9" stroke="${INK}" stroke-width="1.2"/><rect x="474" y="286" width="70" height="30" fill="none" stroke="${INK}" stroke-width="1" stroke-dasharray="4 2"/>`;
  const furn2 = `<rect x="236" y="318" width="108" height="22" fill="#dcdfc9" stroke="${INK}" stroke-width="1.2"/><line x1="236" y1="324" x2="344" y2="324" stroke="${INK}" stroke-width=".8"/>`;
  const furn4 = `<rect x="240" y="60" width="40" height="22" fill="#dcdfc9" stroke="${INK}" stroke-width="1"/><circle cx="252" cy="71" r="4" fill="none" stroke="${INK}"/><circle cx="268" cy="71" r="4" fill="none" stroke="${INK}"/><rect x="290" y="168" width="52" height="20" fill="none" stroke="${INK}" stroke-width="1"/>`
    + `<g stroke="${INK}" stroke-width="1" fill="#dcdfc9">` + [0, 1, 2].map((i) => `<rect x="${42 + i * 44}" y="70" width="34" height="48"/><rect x="${42 + i * 44}" y="134" width="34" height="46" fill="${FL}"/>`).join('') + '</g>';
  const pondHole = `<ellipse cx="500" cy="478" rx="10" ry="5.5" fill="${INK}"/><path d="M420 452 l22 10 l-6 16 M470 440 l12 22 l22 6 M520 452 l-10 20 M440 490 l30 -8 M482 494 l14 -12" fill="none" stroke="#7d8e90" stroke-width=".9"/>`;
  const upper = `<rect x="766" y="22" width="222" height="206" fill="none" stroke="${INK}" stroke-width="1" stroke-dasharray="5 3"/><text x="776" y="40" class="rk">2층 (삽입도)</text>`
    + `<rect x="774" y="48" width="104" height="166" fill="${INK}"/><rect x="778" y="52" width="96" height="158" fill="${FL}"/><rect x="878" y="48" width="104" height="106" fill="${INK}"/><rect x="882" y="52" width="96" height="98" fill="${FL}"/>`
    + `<rect x="906" y="148" width="40" height="8" fill="${FL}"/><line x1="906" y1="150" x2="946" y2="150" stroke="${INK}" stroke-width="1.2"/><line x1="906" y1="153" x2="946" y2="153" stroke="${INK}" stroke-width="1.2"/><rect x="786" y="150" width="46" height="46" fill="none" stroke="${INK}" stroke-width="1"/><text class="rn" x="784" y="76">안채 위층</text>`;
  const compass = `<g transform="translate(640 600)"><circle r="30" fill="none" stroke="${INK}" stroke-width="1"/><path d="M0 -42 L7 0 L0 8 L-7 0 Z" fill="${INK}"/><path d="M0 42 L5 0 L0 -6 L-5 0Z" fill="none" stroke="${INK}" stroke-width="1"/><line x1="-36" y1="0" x2="36" y2="0" stroke="${INK}" stroke-width=".8"/><text y="-50" text-anchor="middle" class="rn">북</text></g>`;
  const scale = `<g transform="translate(400 620)"><rect width="140" height="6" fill="none" stroke="${INK}" stroke-width="1"/><rect width="35" height="6" fill="${INK}"/><rect x="70" width="35" height="6" fill="${INK}"/><text y="28" class="rk">0</text><text x="62" y="28" class="rk">20</text><text x="118" y="28" class="rk">40야드</text></g>`;

  // 누를 수 있는 장소: 열렸으면 이동 버튼, 아직 닫혔으면 흐린 채로 이름 없이
  const room = (id, inner, labels, pulse) => {
    const l = byId[id];
    if (!l) { const x = raw(inner + (fogged[id] ? `<text class="rk" x="${fogged[id][0]}" y="${fogged[id][1]}" text-anchor="middle">아직 닫혀 있습니다</text>` : '')); x.setAttribute('class', 'rm lock'); return x; }
    const fresh = l.hasNew || ui.pulse.has(l.id);
    const x = sv('g', { class: 'rm' + (l.current ? ' sel' : ''), tabindex: '0', role: 'button',
      'aria-label': `${l.name}${l.current ? ' (현재 위치)' : ''}${fresh ? ' (새로 열림)' : ''}로 이동`,
      onclick: () => travel(l.id), onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); travel(l.id); } } });
    x.innerHTML = inner + labels(l) + (fresh ? pulse + `<text class="newtag" style="font-size:18px" x="${fogged[id][0]}" y="${fogged[id][1] - 60}" text-anchor="middle">새로 열림</text>` : '');
    return x;
  };
  g.append(raw(trees + drive + terrace + walls));
  g.append(room('dining', flr(360, 200, 230, 150, true) + furn1, (l) => `<text class="rn" x="366" y="244">${l.name}</text>`, '<rect class="pulse" x="356" y="196" width="238" height="158"/>'));
  g.append(raw(flr(220, 200, 140, 150) + furn2 + '<text class="rn" x="228" y="226">거실</text>' + flr(590, 40, 130, 310) + hall
    + '<rect x="362" y="42" width="111" height="156" fill="#dde0cf"/><rect x="477" y="42" width="111" height="156" fill="#dde0cf"/><text class="rk" x="372" y="68">당구실</text><text class="rk" x="487" y="68">총기실</text>'));
  g.append(room('servants', flr(220, 40, 140, 160, true) + '<rect class="fl" x="32" y="62" width="136" height="126"/><rect class="fl" x="170" y="108" width="52" height="34"/>' + furn4,
    (l) => `<text class="rn" x="228" y="190">주방</text><text class="rn" x="36" y="214">${l.name}</text>`, '<rect class="pulse" x="26" y="56" width="148" height="138"/>'));
  g.append(raw(gaps + frenchWin + porch));
  g.append(room('pond', `<ellipse cx="470" cy="470" rx="86" ry="44" fill="${INK}"/><ellipse cx="470" cy="470" rx="83" ry="41" class="fl water"/>` + pondHole,
    (l) => `<text class="rn" x="470" y="416" text-anchor="middle">${l.name}</text>`, '<ellipse class="pulse" cx="470" cy="470" rx="86" ry="44"/>'));
  g.append(room('lodge', `<rect x="868" y="596" width="106" height="66" fill="${INK}"/>` + flr(868, 596, 106, 66, true) + `<line x1="872" y1="629" x2="970" y2="629" stroke="${INK}" stroke-width=".8" stroke-dasharray="4 3"/><rect class="fl" x="900" y="658" width="30" height="8"/><rect x="886" y="682" width="14" height="10" fill="${INK}"/><rect x="960" y="682" width="14" height="10" fill="${INK}"/>`,
    (l) => `<text class="rn" x="921" y="584" text-anchor="middle">${l.name}</text>`, '<rect class="pulse" x="864" y="592" width="114" height="74"/>'));
  g.append(raw(upper + compass + scale));
  svg.append(g);
}

function renderMap(panel) {
  // 지도는 「애비 그레인지 시안 v3」 M안(저택 평면도)의 형태를 따른다: 측량도 종이, 잉크 벽선, 잔디·나무·진입로,
  // 번호 핀(조사 지점), 인물 말, 나침반·축척, 지도 밖 장소는 오른쪽 삽입도.
  const locs = state.locations.filter((l) => l.kind !== 'interrogation');
  const byId = Object.fromEntries(locs.map((l) => [l.id, l]));
  const m = state.map || { zones: {}, decor: [], fog: [], roads: [] };
  const INK = '#1c2230';
  const HOUSE = (m.decor || []).some((d) => d.type === 'plan' && d.id === 'abbey'); // 실제 저택 도면이 있는 사건
  const HOUSE_AT = { dining: [475, 290], servants: [100, 140], pond: [470, 476], lodge: [921, 636] };
  const svg = sv('svg', { class: 'plan-svg', viewBox: '0 0 960 520', role: 'group', 'aria-label': '수사 지도(평면도)' });
  const grs = sv('pattern', { id: 'grs', width: 9, height: 9, patternUnits: 'userSpaceOnUse' },
    sv('rect', { width: 9, height: 9, fill: '#d2d9bc' }), sv('circle', { cx: 2, cy: 2, r: 0.7, fill: '#9aa07a' }), sv('circle', { cx: 6.5, cy: 6, r: 0.7, fill: '#9aa07a' }));
  const hat = sv('pattern', { id: 'fogh', width: 7, height: 7, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(-40)' },
    sv('rect', { width: 7, height: 7, fill: '#dcdecb' }), sv('line', { x1: 0, y1: 0, x2: 0, y2: 7, stroke: '#bcbfa8', 'stroke-width': 1 }));
  // 종이 결: 아주 옅은 잡음을 곱해 측량도 종이처럼 보이게 한다
  const grain = sv('filter', { id: 'grain', x: 0, y: 0, width: '100%', height: '100%' },
    sv('feTurbulence', { type: 'fractalNoise', baseFrequency: 0.9, numOctaves: 2, seed: 7, result: 'n' }),
    sv('feColorMatrix', { type: 'matrix', values: '0 0 0 0 0.11  0 0 0 0 0.13  0 0 0 0 0.19  0 0 0 0.09 0' }));
  svg.append(sv('defs', null, grs, hat, grain));
  // 도면 틀: 종이, 잔디, 이중 테두리
  svg.append(
    sv('rect', { x: 0, y: 0, width: 960, height: 520, fill: '#e1e1d0' }),
    sv('rect', { x: 8, y: 8, width: 656, height: 504, fill: 'url(#grs)' }),
    sv('rect', { x: 8, y: 8, width: 656, height: 504, fill: 'none', stroke: INK, 'stroke-width': 1.8 }),
    sv('rect', { x: 13, y: 13, width: 646, height: 494, fill: 'none', stroke: INK, 'stroke-width': 0.6 }),
    sv('text', { class: 'zone', x: 336, y: HOUSE ? 26 : 500, 'text-anchor': 'middle' }, m.zones.estate || ''));
  if (HOUSE) abbeyHouse(svg, byId, HOUSE_AT);
  // 지도 밖 삽입도
  svg.append(
    sv('rect', { x: 678, y: 8, width: 274, height: 504, fill: '#e1e1d0', stroke: INK, 'stroke-width': 1.6 }),
    sv('text', { class: 'inset-title', x: 692, y: 34 }, '지도 밖 · 기차로 이동'),
    sv('text', { class: 'rk', x: 692, y: 54 }, m.zones.offsite || ''),
    sv('path', { d: 'M694 500 H936', stroke: '#bcb293', 'stroke-width': 8, fill: 'none' }),
    sv('path', { d: 'M694 500 H936', stroke: INK, 'stroke-width': 1, 'stroke-dasharray': '2 10', fill: 'none' }));

  const boxes = [...locs, ...(m.fog || [])].map((l) => [l.x, l.y]);
  const segDist = (px, py, r) => {
    const dx = r.x2 - r.x1, dy = r.y2 - r.y1, t = Math.max(0, Math.min(1, ((px - r.x1) * dx + (py - r.y1) * dy) / (dx * dx + dy * dy || 1)));
    return Math.hypot(px - (r.x1 + t * dx), py - (r.y1 + t * dy));
  };
  const rects = (m.decor || []).filter((d) => d.type === 'rect');
  const tree = (x, y, r) => [
    sv('circle', { cx: x, cy: y, r, fill: '#c1cba3', stroke: '#454c5a', 'stroke-width': 1 }),
    sv('circle', { cx: x - r * 0.25, cy: y - r * 0.2, r: r * 0.45, fill: 'none', stroke: '#8a8467', 'stroke-width': 0.8 })];
  // 나무: 정해진 자리 중 건물·길과 겹치지 않는 곳에만
  const SEEDS = [[44, 70, 15], [88, 250, 18], [52, 310, 13], [236, 60, 14], [420, 44, 16], [600, 60, 13], [628, 250, 17], [604, 300, 12], [232, 250, 14], [40, 478, 14],
    [250, 470, 17], [300, 440, 12], [420, 470, 15], [590, 470, 14], [640, 420, 12], [36, 190, 12], [390, 180, 13], [560, 190, 15], [200, 330, 12], [440, 250, 13]];
  for (const [x, y, r] of HOUSE ? [] : SEEDS) {
    if (boxes.some(([bx, by]) => Math.abs(bx - x) < 96 && Math.abs(by - y) < 72)) continue;
    if ((m.roads || []).some((rd) => segDist(x, y, rd) < r + 12)) continue;
    if (rects.some((d) => x > d.x - r && x < d.x + d.w + r && y > d.y - r && y < d.y + d.h + r)) continue;
    svg.append(...tree(x, y, r));
  }
  // 길: 영지 안은 진입로(잉크 테두리 + 자갈색), 먼 길은 점선
  for (const r of m.roads || []) {
    if (HOUSE && !r.dashed) continue; // 저택 도면에는 진입로가 이미 그려져 있다
    const a = { x1: r.x1, y1: r.y1, x2: r.x2, y2: r.y2, 'stroke-linecap': 'round', opacity: r.open ? 1 : 0.28 };
    if (r.dashed) svg.append(sv('line', { ...a, stroke: INK, 'stroke-width': 1.6, 'stroke-dasharray': '3 7' }));
    else svg.append(sv('line', { ...a, stroke: INK, 'stroke-width': 13 }), sv('line', { ...a, stroke: '#d3d4b9', 'stroke-width': 10 }));
  }
  for (const d of m.decor || []) {
    if (d.type === 'rect') svg.append(sv('rect', { x: d.x, y: d.y, width: d.w, height: d.h, fill: '#dde0cf', stroke: INK, 'stroke-width': 1.4 }));
    else if (d.type === 'line') svg.append(sv('line', { x1: d.x1, y1: d.y1, x2: d.x2, y2: d.y2, stroke: INK, 'stroke-width': 1.2, 'stroke-dasharray': '5 3' }));
    else if (d.type === 'text') svg.append(sv('text', { class: 'rk', x: d.x, y: d.y, 'text-anchor': 'middle' }, d.text));
    else if (d.type === 'tree') svg.append(...tree(d.x, d.y, d.r || 14));
  }
  // 아직 닫힌 곳: 점선 윤곽만
  for (const { x, y } of m.fog || []) {
    if (HOUSE && x < 664) continue; // 닫힌 방은 저택 도면에서 흐리게 그린다
    svg.append(sv('g', { class: 'rm lock', 'aria-hidden': 'true' },
      sv('rect', { x: x - 64, y: y - 30, width: 128, height: 60, fill: 'url(#fogh)', stroke: '#9a9e87', 'stroke-width': 1, 'stroke-dasharray': '2 4' }),
      sv('text', { class: 'fogt', x, y: y + 4, 'text-anchor': 'middle' }, '미측량')));
  }
  const nameLines = (name) => {
    if (name.length <= 9) return [name];
    const i = name.indexOf('(');
    if (i > 0) return [name.slice(0, i), name.slice(i)];
    const sp = name.lastIndexOf(' ', 9);
    return sp > 0 ? [name.slice(0, sp), name.slice(sp + 1)] : [name];
  };
  for (const l of locs) {
    if (HOUSE && HOUSE_AT[l.id]) continue;
    const fresh = l.hasNew || ui.pulse.has(l.id);
    const g = sv('g', {
      class: 'rm' + (l.current ? ' sel' : ''), tabindex: '0', role: 'button',
      'aria-label': `${l.name}${l.current ? ' (현재 위치)' : ''}${fresh ? ' (새로 열림)' : ''}로 이동`,
      onclick: () => travel(l.id),
      onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); travel(l.id); } },
    });
    let labelY = l.y - 12;
    if (l.shape === 'pond') {
      g.append(sv('ellipse', { cx: l.x, cy: l.y, rx: 84, ry: 42, fill: INK }), sv('ellipse', { class: 'fl water', cx: l.x, cy: l.y, rx: 81, ry: 39 }),
        sv('path', { d: `M${l.x - 50} ${l.y - 12} l22 10 l-6 14 M${l.x} ${l.y - 22} l12 20 l22 6 M${l.x + 40} ${l.y - 10} l-10 18 M${l.x - 30} ${l.y + 20} l30 -8`, fill: 'none', stroke: '#7d8e90', 'stroke-width': 0.9 }));
      if (fresh) g.append(sv('ellipse', { class: 'pulse', cx: l.x, cy: l.y, rx: 84, ry: 42 }));
    } else if (l.shape === 'tree') {
      g.append(sv('circle', { class: 'fl canopy', cx: l.x, cy: l.y, r: 40, stroke: INK, 'stroke-width': 1.8 }),
        sv('circle', { cx: l.x - 10, cy: l.y - 8, r: 18, fill: 'none', stroke: '#8a8467', 'stroke-width': 0.9 }), sv('circle', { cx: l.x, cy: l.y, r: 3.5, fill: INK }));
      if (fresh) g.append(sv('circle', { class: 'pulse', cx: l.x, cy: l.y, r: 40 }));
    } else if (l.shape === 'field') {
      g.append(sv('rect', { class: 'fl field', x: l.x - 70, y: l.y - 35, width: 140, height: 70, stroke: INK, 'stroke-width': 1.4, 'stroke-dasharray': '8 4' }));
      if (fresh) g.append(sv('rect', { class: 'pulse', x: l.x - 70, y: l.y - 35, width: 140, height: 70 }));
    } else {
      g.append(sv('rect', { x: l.x - 74, y: l.y - 39, width: 148, height: 78, fill: INK }), sv('rect', { class: 'fl', x: l.x - 68, y: l.y - 33, width: 136, height: 66 }),
        sv('rect', { class: 'fl', x: l.x - 14, y: l.y + 31, width: 28, height: 9 }), // 문
        sv('path', { d: `M${l.x - 14} ${l.y + 39} q0 -16 16 -16`, fill: 'none', stroke: INK, 'stroke-width': 0.9, 'stroke-dasharray': '3 2' }));
      if (fresh) g.append(sv('rect', { class: 'pulse', x: l.x - 74, y: l.y - 39, width: 148, height: 78 }));
    }
    const lines = nameLines(l.name);
    if (lines.length === 1) labelY += 6;
    lines.forEach((t, i) => g.append(sv('text', { class: i ? 'rk' : 'rn', x: l.x, y: labelY + i * 17, 'text-anchor': 'middle' }, t)));
    if (fresh) g.append(sv('text', { class: 'newtag', x: l.x, y: l.y - 46, 'text-anchor': 'middle' }, '새로 열림'));
    svg.append(g);
  }
  // 조사 지점 핀: 빈 원 = 미조사, 채운 원 = 조사함. 그 장소에 있으면 바로 조사, 아니면 먼저 이동한다.
  const pinSlot = {};
  state.spots.forEach((s, idx) => {
    const l = byId[s.locationId];
    if (!l) return;
    const n = pinSlot[l.id] = (pinSlot[l.id] || 0) + 1;
    const x = l.x - 54 + ((n - 1) % 5) * 27, y = l.y + (HOUSE && l.id === 'dining' ? -6 : 30) + Math.floor((n - 1) / 5) * 26;
    const go = async () => { if (state.locationId !== l.id || state.place !== 'scene') await travel(l.id); if (state.locationId === l.id) act({ type: 'inspect', spotId: s.id }); };
    svg.append(sv('g', { class: 'pin' + (s.done ? ' op' : ''), tabindex: '0', role: 'button', 'aria-label': `${s.label} 조사${s.done ? ' (완료)' : ''}`, transform: `translate(${x} ${y})`,
      onclick: (e) => { e.stopPropagation(); go(); }, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } } },
      sv('title', null, s.label), sv('circle', { class: 'hit', cx: 8, cy: -8, r: 16 }), sv('path', { class: 'ld', d: 'M0 0 L6 -6' }), sv('circle', { class: 'dot', r: 2.2 }),
      sv('circle', { class: 'b', cx: 10, cy: -10, r: 10 }), sv('text', { x: 10, y: -6 }, String(idx + 1))));
  });
  // 인물 말: 누르면 그 인물과의 대화로 넘어간다.
  const slot = {};
  for (const p of state.people) {
    if (!byId[p.locationId]) continue;
    const l = byId[p.locationId];
    const n = slot[l.id] = (slot[l.id] || 0) + 1;
    const rows = Math.max(1, Math.ceil((pinSlot[l.id] || 0) / 5));
    let cx = l.x - 50 + (n - 1) * 42, cy = l.y + (l.shape === 'pond' || l.shape === 'tree' ? 62 : 58) + (rows - 1) * 26;
    if (cy > 478) { cx = l.x - 96 - (n - 1) * 42; cy = l.y; } // 틀 아래로 넘치면 건물 왼쪽에 세운다
    const pick = () => { ui.chatPid = p.pid; renderSide(); renderMain(); };
    svg.append(sv('g', { class: 'pers' + (p.pid === ui.chatPid ? ' on' : ''), tabindex: '0', role: 'button', 'aria-label': `${p.name}와 대화`, transform: `translate(${cx} ${cy})`,
      onclick: (e) => { e.stopPropagation(); pick(); }, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } } },
      sv('title', null, p.name), sv('circle', { r: 13 }), sv('text', { class: 'i', y: 5 }, p.initials || p.name.slice(0, 1)), sv('text', { class: 'nm', y: 28 }, p.name.split(' ')[0])));
  }
  // 나침반·축척
  if (!HOUSE) svg.append(sv('g', { transform: 'translate(634 452)' },
    sv('circle', { r: 18, fill: 'none', stroke: INK, 'stroke-width': 1 }), sv('path', { d: 'M0 -26 L5 0 L0 5 L-5 0 Z', fill: INK }),
    sv('line', { x1: -22, y1: 0, x2: 22, y2: 0, stroke: INK, 'stroke-width': 0.8 }), sv('text', { class: 'rk', y: -30, 'text-anchor': 'middle' }, '북')));
  if (!HOUSE) svg.append(sv('g', { transform: 'translate(24 492)' },
    sv('rect', { width: 96, height: 5, fill: 'none', stroke: INK, 'stroke-width': 1 }), sv('rect', { width: 24, height: 5, fill: INK }), sv('rect', { x: 48, width: 24, height: 5, fill: INK })));
  svg.append(sv('rect', { x: 0, y: 0, width: 960, height: 520, filter: 'url(#grain)', 'pointer-events': 'none' }));
  panel.append(leadBanner());
  const mapBox = h('div', { class: 'map-box plan' + (ui.mapFit ? ' fit' : '') }, svg);
  panel.append(foldHead('map', '수사 지도', h('button', { type: 'button', class: 'map-fit', 'aria-pressed': String(ui.mapFit), onclick: () => { ui.mapFit = !ui.mapFit; renderMain(); } }, ui.mapFit ? '확대해서 보기' : '한눈에 보기')));
  if (!ui.fold.map) {
    panel.append(mapBox);
    // 좁은 화면에서 지도가 옆으로 넘칠 때 현재 장소가 보이게 스크롤을 맞춘다
    requestAnimationFrame(() => {
      if (mapBox.scrollWidth <= mapBox.clientWidth) return;
      const curLoc = locs.find((l) => l.current);
      if (curLoc && typeof curLoc.x === 'number') mapBox.scrollLeft = Math.max(0, (curLoc.x / 960) * mapBox.scrollWidth - mapBox.clientWidth / 2);
    });
  }
  panel.append(foldHead('board', '맞대기 보드'));
  if (!ui.fold.board) panel.append(buildContact());

  // 현재 장소 패널
  const cur = locs.find((l) => l.current);
  const inInterro = state.place === 'interrogation';
  const spots = state.spots.filter((s) => s.locationId === state.locationId);
  const body = h('div', { class: 'loc-body' });
  if (inInterro) {
    body.append(h('h3', null, '심문실'), h('p', null, '소환에 응한 인물과 마주 앉아 증거를 제시하고 추궁할 수 있습니다.'));
    if (!ui.leadOff) for (const t of state.roomHints || []) body.append(h('p', { class: 'hint tip' }, t));
  } else {
    body.append(h('h3', null, cur ? cur.name : '현재 위치'));
    if (!ui.leadOff) for (const t of (cur && cur.hints) || []) body.append(h('p', { class: 'hint tip' }, t));
    body.append(spots.length ? h('div', { class: 'spot-list' }, spots.map((s) => h('button', {
      type: 'button', class: 'spot' + (s.done ? ' done' : ''), 'aria-label': `${s.label} 조사${s.done ? ' (완료)' : ''}`,
      onclick: () => act({ type: 'inspect', spotId: s.id }),
    }, (s.done ? '✓ ' : '') + s.label))) : h('p', { class: 'hint' }, '여기서 더 조사할 지점이 아직 보이지 않습니다.'));
    if (spots.length && spots.every((s) => s.done)) body.append(h('p', { class: 'hint' }, '이곳에서 지금 볼 수 있는 것은 모두 살폈습니다.'));
  }
  const interroBtn = inInterro
    ? h('button', { type: 'button', class: 'go-interro', 'aria-label': '현장으로 돌아가기', onclick: () => travel(ui.lastScene) }, '현장으로 돌아가기')
    : h('button', { type: 'button', class: 'go-interro', 'aria-label': '심문실로 이동', onclick: () => travel('interrogation') }, '심문실로 이동');
  body.append(interroBtn);
  const artSrc = inInterro ? '/art/interrogation.png' : (cur && cur.art);
  const art = h('div', { class: 'loc-art' }, artSrc ? imgWithFallback(artSrc, cur ? cur.name : '심문실', () => h('div', { class: 'avatar', 'aria-hidden': 'true' }, '')) : null);
  panel.append(h('div', { class: 'loc-panel' }, art, body));
}
// 다음 실마리: 장소와 상관없이 지도 위에 늘 한 줄. 숨기기는 이 브라우저에만 기억한다.
function leadBanner() {
  const L = state.lead;
  if (!L) return h('div', { hidden: true });
  const toggle = h('button', { type: 'button', class: 'lead-toggle', 'aria-pressed': String(!!ui.leadOff), onclick: () => {
    ui.leadOff = !ui.leadOff;
    try { localStorage.setItem('boscombe.leadOff', ui.leadOff ? '1' : ''); } catch (e) { /* 저장 못 해도 화면은 그대로 */ }
    renderAll();
  } }, ui.leadOff ? '실마리 보기' : '숨기기');
  if (ui.leadOff) return h('div', { class: 'nextlead off' }, h('span', { class: 'lead-k' }, '다음 실마리'), toggle);
  const pr = L.progress ? h('span', { class: 'lead-pr', 'aria-label': `진행 ${L.progress.have}/${L.progress.need}` },
    ...Array.from({ length: L.progress.need }, (_, i) => h('i', { class: (i < L.progress.have ? 'on' : '') + (i === ui.pipPop ? ' pop' : '') })), ` ${Math.min(L.progress.have, L.progress.need)}/${L.progress.need}`) : null;
  ui.pipPop = -1;
  const goBtn = L.go && !leadDone(L.go) ? h('button', { type: 'button', class: 'lead-go', 'aria-label': '바로 가기: ' + goText(L.go), onclick: () => followLead(L.go) }, goText(L.go) + ' →') : null;
  return h('div', { class: 'nextlead', role: 'status' }, h('span', { class: 'lead-k' }, '다음 실마리'), h('div', { class: 'lead-body' }, h('p', { class: 'lead-t' }, L.text, pr), goBtn), toggle);
}
const goText = (g) => g.pid ? (g.label + '에게') : g.loc ? (g.loc === 'interrogation' ? '응접실로' : g.label + '(으)로') : g.label;
// 이미 그 자리·그 인물이면 버튼을 숨긴다
function leadDone(g) {
  if (g.tab) return ui.tab === g.tab;
  if (g.loc === 'interrogation') return state.place === 'interrogation';
  if (g.loc) return state.place === 'scene' && state.locationId === g.loc;
  const p = state.people.find((x) => x.pid === g.pid);
  return !!p && ui.chatPid === g.pid && p.canTalk;
}
// 실마리를 따라가기: 인물이면 그 사람이 있는 곳으로 옮긴 뒤 대화창을 연다
async function followLead(g) {
  if (ui.busy) return;
  if (g.tab) { ui.tab = g.tab; renderAll(); return; }
  if (g.loc) { if (state.locations.some((l) => l.id === g.loc) || g.loc === 'interrogation') await travel(g.loc); return; }
  await goPerson(g.pid);
}
async function goPerson(pid) {
  let p = state.people.find((x) => x.pid === pid);
  if (!p) return;
  if (!p.present && p.locationId) {
    const target = p.locationId === 'interrogation' ? 'interrogation' : p.locationId;
    if (target === 'interrogation' || state.locations.some((l) => l.id === target)) await travel(target);
    p = state.people.find((x) => x.pid === pid) || p;
  }
  ui.chatPid = pid;
  renderAll();
  const side = document.querySelector('.side-col');
  if (side && window.matchMedia('(max-width:900px)').matches) side.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' });
  const i = $('chat-input'); if (i && !i.disabled) i.focus({ preventScroll: true });
}
// 접는 머리: 지도·맞대기 보드. 접힘 상태는 이 브라우저에 기억한다.
function foldHead(key, title, extra) {
  const open = !ui.fold[key];
  return h('div', { class: 'foldhead' }, h('button', { type: 'button', class: 'fold-btn', 'aria-expanded': String(open), onclick: () => {
    ui.fold[key] = open;
    try { localStorage.setItem('boscombe.fold', JSON.stringify(ui.fold)); } catch (e) { /* 무시 */ }
    renderMain();
  } }, (open ? '▾ ' : '▸ ') + title), open ? extra || null : null);
}
async function travel(locationId) {
  if (state.place === 'scene') ui.lastScene = state.locationId;
  ui.pulse.delete(locationId);
  await act({ type: 'travel', locationId });
}

// --- 증거 ---
// 증거 종류 아이콘(선 그림). 종류마다 카드 윗변 색도 다르다(styles.css의 [data-type]).
const EV_ICON = {
  document: ['M6 3h9l3 3v15H6z', 'M15 3v3h3', 'M9 10h6', 'M9 13.5h6', 'M9 17h4'],
  physical: ['M4 16l3-8 6-3 6 5-1 8-9 2z', 'M7 8l5 4 6-2', 'M12 12l-1 9'],
  trace: ['M8.5 4.5c1.6 0 2.5 1.8 2.3 4.2-.2 2.2-1.2 3.3-2.5 3.3S6 10.8 6 8.6 6.9 4.5 8.5 4.5z', 'M7 14.2c.9-.3 2.4-.2 3 .4.5.6.1 2.2-1.1 2.6-1.1.4-2.2-.2-2.4-1.2-.1-.8 0-1.5.5-1.8z', 'M15.5 7.5c1.6 0 2.5 1.8 2.3 4.2-.2 2.2-1.2 3.3-2.5 3.3S13 13.8 13 11.6s.9-4.1 2.5-4.1z', 'M14 17.2c.9-.3 2.4-.2 3 .4.5.6.1 2.2-1.1 2.6-1.1.4-2.2-.2-2.4-1.2-.1-.8 0-1.5.5-1.8z'],
  observation: ['M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z', 'M12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z'],
  testimony_record: ['M4 5h16v11h-9l-5 4v-4H4z', 'M8 9.5h8', 'M8 12.5h5'],
};
function evIcon(type) {
  return sv('svg', { class: 'ev-ico', viewBox: '0 0 24 24', 'aria-hidden': 'true' }, (EV_ICON[type] || EV_ICON.document).map((d) => sv('path', { d })));
}
// 이 증거로 이미 한 일: 누구에게 내밀었는지, 어떤 증거와 맞대 연결을 찾았는지
function evUses(e) {
  const shownTo = state.people.filter((p) => wasShown(p.pid, e.id)).map((p) => p.name);
  const links = (state.insights || []).filter((i) => i.kind === 'combine' && (i.a === e.id || i.b === e.id));
  const objected = state.statements.filter((s) => (s.brokenBy || []).includes(e.id));
  return { shownTo, links, objected };
}
function evHead(e) {
  return h('div', { class: 'ev-head' }, evIcon(e.type), h('span', { class: 'ev-type' }, e.typeKo), h('span', { class: 'ev-where' }, e.where));
}
function renderEvidence(panel) {
  const opened = state.evidence.filter((e) => e.opened);
  ui.desk = ui.desk.filter((id) => opened.some((e) => e.id === id));
  const slots = h('div', { class: 'desk-slots' });
  for (let i = 0; i < 2; i += 1) {
    const e = opened.find((x) => x.id === ui.desk[i]);
    slots.append(h('div', { class: 'desk-slot' }, e
      ? h('div', { class: 'paper', data: { type: e.type || 'document' } }, evHead(e), h('h3', null, e.title),
        e.look ? h('p', { class: 'ev-look' }, e.look) : null,
        h('div', { class: 'body' }, e.text || ''),
        h('div', { class: 'row' },
          h('button', { type: 'button', 'aria-label': `${e.title} 자세히 보기`, onclick: () => showEvidence(e.id) }, '자세히'),
          h('button', { type: 'button', 'aria-label': `${e.title} 책상에서 치우기`, onclick: () => { ui.desk = ui.desk.filter((x) => x !== e.id); renderMain(); } }, '치우기')))
      : h('div', { class: 'slim-empty' }, i === 0 ? '증거 카드의 「책상에 펼치기」로 여기에 놓습니다' : '두 번째 증거를 놓으면 나란히 대조합니다')));
  }
  // 열람한 증거가 없을 때는 빈 책상을 그리지 않는다(처음 화면이 빈칸투성이로 보이지 않게).
  if (opened.length) panel.append(h('div', { class: 'desk' }, h('div', { class: 'desk-title' }, '대조 책상 — 열람한 증거를 두 장까지 나란히 펼칩니다'), slots));
  const sealed = state.evidence.length - opened.length;
  panel.append(h('h2', { class: 'section-title' }, '발견한 증거', h('span', { class: 'st-sub' }, `${opened.length}건 열람${sealed ? ` · 봉인 ${sealed}건` : ''} · 전체 ${state.stats ? state.stats.evidenceTotal : '?'}건`)));
  if (!state.evidence.length) { panel.append(h('div', { class: 'empty' }, '아직 발견한 증거가 없습니다. 지도에서 현장을 조사하세요.')); return; }
  panel.append(h('div', { class: 'ev-grid' }, state.evidence.map((e) => {
    if (!e.opened) {
      return h('button', { type: 'button', class: 'paper ev-card sealed', 'aria-label': `${e.title} 봉인 열기`, onclick: () => openEvidence(e.id) },
        h('span', { class: 'seal' }, '봉'), h('h3', null, e.title), h('div', { class: 'meta' }, `${e.typeKo} · ${e.where}`), h('div', { class: 'meta' }, '눌러서 봉인을 엽니다'));
    }
    const onDesk = ui.desk.includes(e.id);
    const att = ui.attach.includes(e.id);
    const u = evUses(e);
    const used = [u.shownTo.length ? `내밂 ${u.shownTo.length}` : null, u.links.length ? `착안 ${u.links.length}` : null, u.objected.length ? `이의 ${u.objected.length}` : null].filter(Boolean);
    return h('div', { class: 'paper ev-card', data: { type: e.type || 'document' } }, evHead(e),
      h('h3', null, h('button', { type: 'button', class: 'linkish ev-title', 'aria-label': `${e.title} 자세히 보기`, onclick: () => showEvidence(e.id) }, e.title)),
      e.look ? h('p', { class: 'ev-look' }, e.look) : null,
      h('div', { class: 'text' }, e.text || ''),
      e.use ? h('p', { class: 'ev-use' }, h('b', null, '수사 메모'), e.use) : null,
      used.length ? h('div', { class: 'ev-used' }, used.map((x) => h('span', null, x))) : null,
      h('div', { class: 'row' },
        h('button', { type: 'button', class: 'ev-more', 'aria-label': `${e.title} 자세히 보기`, onclick: () => showEvidence(e.id) }, '자세히'),
        h('button', { type: 'button', 'aria-label': `${e.title} ${onDesk ? '책상에서 치우기' : '책상에 펼치기'}`, onclick: () => toggleDesk(e.id) }, onDesk ? '책상에서 치우기' : '책상에 펼치기'),
        h('button', { type: 'button', 'aria-label': `${e.title} ${att ? '첨부 해제' : '대화에 첨부'}`, onclick: () => { toggleAttach(e.id); renderMain(); } }, att ? '첨부됨 ✓' : '대화에 첨부')));
  })));
}
// 증거 자세히 보기: 생김새·관찰 기록·수사 메모, 이 증거로 한 일, 바로 할 수 있는 일
function showEvidence(id) {
  const e = state.evidence.find((x) => x.id === id);
  if (!e || !e.opened) return;
  const u = evUses(e);
  const titleOf = (x) => (state.evidence.find((y) => y.id === x) || {}).title || x;
  const cur = state.people.find((p) => p.pid === ui.chatPid);
  openModal('evidence', (close) => {
    const go = (fn) => () => { close(); fn(); };
    const history = [
      u.shownTo.length ? h('li', null, h('b', null, '내민 상대 '), u.shownTo.join(', ')) : null,
      ...u.links.map((i) => h('li', null, h('b', null, '착안 '), h('button', { type: 'button', class: 'linkish', onclick: go(() => showInsight(i)) }, i.title), ` — ${titleOf(i.a === e.id ? i.b : i.a)}와(과) 맞댐`)),
      ...u.objected.map((s) => h('li', null, h('b', null, '이의 제기 '), `${s.speakerName}의 진술을 깨뜨림`)),
    ].filter(Boolean);
    const canObject = state.statements.some((s) => s.status !== 'broken');
    return h('div', { class: 'ev-detail', data: { type: e.type || 'document' } },
      evHead(e),
      h('h3', { class: 'evd-title' }, e.title),
      e.look ? h('p', { class: 'ev-look big' }, e.look) : null,
      h('div', { class: 'evd-sec' }, h('div', { class: 'evd-lbl' }, '관찰 기록'), h('div', { class: 'evd-body' }, e.text || ''),
        h('p', { class: 'evd-foot' }, '해석 없이 보고 적은 사실만 담았습니다. 무엇을 뜻하는지는 직접 맞대고 물어서 세워야 합니다.')),
      e.use ? h('div', { class: 'evd-sec memo' }, h('div', { class: 'evd-lbl' }, '수사 메모'), h('p', null, e.use)) : null,
      h('div', { class: 'evd-sec' }, h('div', { class: 'evd-lbl' }, '이 증거로 한 일'),
        history.length ? h('ul', { class: 'evd-hist' }, history) : h('p', { class: 'slim-empty' }, '아직 아무에게도 내밀지 않았고, 다른 증거와 맞대지도 않았습니다.')),
      h('div', { class: 'evd-sec' }, h('div', { class: 'evd-lbl' }, '할 수 있는 일'),
        h('div', { class: 'evd-acts' },
          h('button', { type: 'button', onclick: go(() => { if (!ui.attach.includes(e.id)) toggleAttach(e.id); renderAll(); const i = $('chat-input'); if (i && !i.disabled) i.focus(); toast(`「${e.title}」을(를) 대화에 첨부했습니다${cur ? ` · 지금 상대: ${cur.name}` : ''}`); }) },
            h('b', null, '대화에 첨부'), h('span', null, '다음 질문과 함께 상대에게 내밉니다')),
          h('button', { type: 'button', onclick: go(() => { ui.picked = { kind: 'ev', id: e.id }; ui.tab = 'map'; ui.fold.board = false; renderAll(); const b = $('contact'); if (b) b.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'center' }); }) },
            h('b', null, '맞대기 보드에서 집기'), h('span', null, '집은 채로 인물이나 다른 증거를 누릅니다')),
          h('button', { type: 'button', onclick: go(() => { if (!ui.desk.includes(e.id)) toggleDesk(e.id); ui.tab = 'evidence'; renderAll(); }) },
            h('b', null, '책상에 펼치기'), h('span', null, '다른 증거와 나란히 놓고 읽습니다')),
          canObject ? h('button', { type: 'button', onclick: go(() => { ui.tab = 'statements'; renderAll(); }) },
            h('b', null, '진술과 견주기'), h('span', null, '진술 탭에서 「이의 있음!」에 씁니다')) : null)),
      h('div', { class: 'actions' }, h('button', { type: 'button', class: 'primary', onclick: close, 'aria-label': '닫기' }, '닫기')));
  }, { title: '증거 자세히 보기', cls: 'wide' });
}
async function openEvidence(id) {
  const r = await act({ type: 'open', evidenceId: id });
  if (r && ui.desk.length < 2 && !ui.desk.includes(id)) { ui.desk.push(id); renderMain(); }
}
function toggleDesk(id) {
  if (ui.desk.includes(id)) ui.desk = ui.desk.filter((x) => x !== id);
  else { ui.desk.push(id); if (ui.desk.length > 2) ui.desk.shift(); }
  renderMain();
}
function toggleAttach(id) {
  ui.attach = ui.attach.includes(id) ? ui.attach.filter((x) => x !== id) : [...ui.attach, id];
  renderAttachRow();
}

// --- 진술 ---
function renderStatements(panel) {
  if (!state.statements.length) {
    // 빈 화면 대신 다음 행동: 지금 말을 걸 수 있는 사람을 바로 고르게 한다.
    const can = state.people.filter((p) => p.present && p.canTalk);
    panel.append(h('div', { class: 'lead' }, h('h3', null, '아직 확보한 진술이 없습니다'),
      h('p', null, '인물에게 그날의 일을 물으면 진술 카드가 여기에 쌓입니다. 진술과 어긋나는 증거를 내밀면 모순으로 깨뜨릴 수 있습니다.'),
      can.length ? h('div', { class: 'who-row' }, can.map((p) => h('button', { type: 'button', 'aria-label': `${p.name}에게 말 걸기`, onclick: () => { ui.chatPid = p.pid; renderSide(); const i = $('chat-input'); if (i && !i.disabled) i.focus(); } }, p.name + '에게 묻기')))
        : h('p', null, '지금 이 자리에서 대화할 수 있는 사람이 없습니다. 지도에서 다른 장소로 이동해 보세요.')));
    return;
  }
  const groups = new Map();
  for (const st of state.statements) {
    if (!groups.has(st.speaker)) groups.set(st.speaker, { name: st.speakerName, list: [] });
    groups.get(st.speaker).list.push(st);
  }
  for (const [pid, g] of groups) {
    const box = h('div', { class: 'stmt-group' }, h('h2', { class: 'section-title' }, g.name + '의 진술'));
    for (const st of g.list) {
      const broken = st.status === 'broken';
      const fresh = broken && !ui.seenBroken.has(st.id);
      ui.seenBroken.add(st.id);
      const card = h('div', { class: 'paper stmt' + (broken ? ' broken' : '') + (ui.shake === st.id ? ' shake' : ''), data: { id: st.id } },
        broken ? h('div', { class: 'stamp', style: fresh ? '' : 'animation:none' }, '모순') : null,
        h('div', { class: 'meta' }, g.name), h('div', { class: 'quote' }, '“' + st.text + '”'),
        (st.notes || []).length ? h('ul', { class: 'notes' }, st.notes.map((n) => h('li', null, n))) : null,
        broken ? null : h('button', { type: 'button', class: 'object-btn', 'aria-label': '이의 있음! 이 진술에 이의 제기', onclick: () => startObjection(st, pid) }, '이의 있음!'));
      box.append(card);
    }
    panel.append(box);
  }
  ui.shake = null;
}
async function startObjection(st, pid) {
  const ids = await evidencePicker({ title: '어떤 증거로 반박하시겠습니까?', multi: false, okLabel: '이의 제기', extra: h('p', { class: 'hint' }, '“' + st.text + '”') });
  if (!ids || !ids.length) { if (ids) toast('증거를 하나 고르세요.', 'error'); return; }
  await act({ type: 'object', statementId: st.id, evidenceId: ids[0], pid });
}

// --- 수사 기록 ---
function renderRecords(panel) {
  const nameOf = (pid) => (state.people.find((p) => p.pid === pid) || {}).name || pid;
  const left = h('div'), right = h('div');
  left.append(h('h2', { class: 'section-title' }, '얻은 인물 지식'));
  left.append(state.knowledge.length
    ? h('ul', { class: 'rec-list' }, state.knowledge.map((k) => h('li', null, h('span', { class: 'who' }, nameOf(k.pid)), k.text)))
    : h('div', { class: 'slim-empty' }, '아직 얻은 지식이 없습니다.'));
  left.append(h('h2', { class: 'section-title' }, '접촉 기록'));
  const ins = state.insights || [];
  left.append(ins.length
    ? h('ul', { class: 'rec-list' }, ins.map((i) => h('li', null, h('span', { class: 'who' }, `${i.kind === 'confront' ? '대질' : '착안'} · ${i.aTitle} ↔ ${i.bTitle}`),
      h('button', { type: 'button', class: 'linkish', 'aria-label': `${i.title} 펼치기`, onclick: () => showInsight(i) }, i.title))))
    : h('div', { class: 'slim-empty' }, '지도 탭의 맞대기 보드에서 증거끼리, 인물끼리 맞대면 여기에 남습니다.'));
  left.append(h('h2', { class: 'section-title' }, '판사 기록'));
  left.append(state.judge.length
    ? h('ul', { class: 'rec-list' }, state.judge.map((j) => h('li', { class: j.verdict }, h('span', { class: 'who' }, `${nameOf(j.pid)} 소환 · ${j.verdict === 'approved' ? '승인' : '기각'}`), j.reason)))
    : h('div', { class: 'slim-empty' }, '소환 신청 기록이 없습니다.'));
  right.append(h('h2', { class: 'section-title' }, '타임라인'));
  right.append(state.timeline.length
    ? h('ul', { class: 'rec-list' }, state.timeline.map((t) => h('li', null, h('span', { class: 'who' }, t.time), t.text)))
    : h('div', { class: 'slim-empty' }, '정리된 시간대 정보가 없습니다.'));
  right.append(h('h2', { class: 'section-title' }, '개인 메모'));
  const ta = h('textarea', { rows: 8, maxlength: 2000, 'aria-label': '개인 메모', placeholder: '추리 메모를 적어 두세요. 자동 저장됩니다.' });
  ta.value = ui.noteDraft !== null ? ui.noteDraft : (state.notes || '');
  const status = h('div', { class: 'hint' }, '');
  ta.addEventListener('input', () => {
    ui.noteDraft = ta.value; status.textContent = '저장 중…';
    clearTimeout(ui.noteTimer);
    ui.noteTimer = setTimeout(async () => {
      const r = await act({ type: 'note', text: ta.value }, { silent: true });
      status.textContent = r ? '저장됨' : '저장 실패';
    }, 1000);
  });
  right.append(ta, status);
  panel.append(h('div', { class: 'rec-grid' }, left, right));
}

// --- 결론 ---
function renderConclusion(panel) {
  const sub = state.submitted;
  if (sub) { renderResult(panel, sub); return; }
  const d = ui.draft;
  const q = state.culpritQuestion || '범인 지목';
  const opts = [h('option', { value: '' }, `${q}: 선택하세요`), ...(state.suspects || []).map((p) => h('option', { value: p.pid }, p.name))];
  const sel = h('select', { id: 'f-culprit', 'aria-label': q }, opts);
  sel.value = d.culprit;
  sel.addEventListener('change', () => { d.culprit = sel.value; renderMain(); });
  const text = (key, label, rows) => {
    const t = h('textarea', { id: 'f-' + key, rows, maxlength: 1500, 'aria-label': label });
    t.value = d[key]; t.addEventListener('input', () => { d[key] = t.value; });
    return h('div', { class: 'form-row' }, h('label', { for: 'f-' + key }, label), t);
  };
  const opened = state.evidence.filter((e) => e.opened);
  const fm = state.form || {};
  d.exclusions = d.exclusions || {};
  // 증거 고르기 칸: max가 있으면 그 개수까지만 고를 수 있다.
  const picker = (get, set, max, onChange) => (opened.length ? h('div', { class: 'check-grid' }, opened.map((e) => {
    const c = h('input', { type: 'checkbox', checked: get().includes(e.id) });
    c.addEventListener('change', () => {
      if (c.checked && max && get().length >= max) { c.checked = false; toast(`증거는 ${max}개까지 고를 수 있습니다.`, 'error'); return; }
      set(c.checked ? [...get(), e.id] : get().filter((x) => x !== e.id));
      if (onChange) onChange();
    });
    return h('label', null, c, h('span', null, e.title));
  })) : h('div', { class: 'empty' }, '열람한 증거가 없습니다.'));
  const grid = picker(() => d.evidenceIds, (v) => { d.evidenceIds = v; }, fm.evidenceMax);
  // 다른 용의자 배제: 고른 범인을 뺀 후보마다, 그 사람이 범인일 수 없음을 보여 주는 증거를 고른다.
  let exclBox = null;
  if (fm.exclusionMax) {
    const others = (state.suspects || []).filter((p) => p.pid !== d.culprit);
    exclBox = h('div', { class: 'form-row' }, h('span', { class: 'lbl' }, `다른 용의자를 배제하는 근거 (한 사람에 ${fm.exclusionMax}개까지)`),
      h('p', { class: 'hint' }, '범인의 특징을 보여 주는 증거와, 이 사람이 그 특징에 맞지 않음을 보여 주는 증거를 함께 고르세요.'),
      others.map((p) => {
        const count = h('span', { class: 'meta' });
        const upd = () => { count.textContent = ` — ${(d.exclusions[p.pid] || []).length}개 선택`; };
        upd();
        return h('details', { class: 'excl' }, h('summary', null, h('b', null, p.name), count),
          picker(() => d.exclusions[p.pid] || [], (v) => { d.exclusions[p.pid] = v; }, fm.exclusionMax, upd));
      }));
  }
  const form = h('form', { class: 'concl-form' },
    h('h2', { class: 'section-title' }, '결론 제출 — 첫 제출이 최종입니다'),
    h('p', { class: 'hint' }, fm.confessionPoints ? `언제든 제출할 수 있습니다. 범인의 자백을 받은 뒤 제출하면 ${fm.confessionPoints}점이 더해집니다. 수법·동기·추리는 이 판에서 직접 확인한 내용만 점수가 됩니다.` : '자백 여부와 관계없이 언제든 제출할 수 있습니다.'),
    h('div', { class: 'form-row' }, h('label', { for: 'f-culprit' }, '범인'), sel),
    text('method', '수법', 3), text('motive', '동기', 3), text('reasoning', '추리', 5),
    h('div', { class: 'form-row' }, h('span', { class: 'lbl' }, fm.evidenceMax ? `범인을 가리키는 근거 증거 (${fm.evidenceMax}개까지)` : '근거 증거'), grid),
    exclBox,
    h('button', { type: 'submit', class: 'primary', 'aria-label': '결론 제출' }, '결론 제출'));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!d.culprit) { toast('범인을 선택하세요.', 'error'); return; }
    const ok = await confirmBox('결론 제출', '제출하면 수정할 수 없습니다. 이 결론으로 제출할까요?', '제출');
    if (!ok) return;
    await act({ type: 'submit', culprit: d.culprit, method: d.method, motive: d.motive, reasoning: d.reasoning, evidenceIds: d.evidenceIds, exclusions: d.exclusions });
  });
  panel.append(form);
}
function renderResult(panel, sub) {
  const ans = sub.answer || {};
  const st = state.stats || {};
  const cs = state.contactStats || { present: { tries: 0 }, combine: { tries: 0, hits: 0 }, confront: { tries: 0, hits: 0 } };
  const bd = sub.breakdown || [];
  const right = bd[0] && bd[0].got > 0;
  const pct = sub.max ? sub.score / sub.max : 0;
  const grade = pct >= 0.95 ? '완벽한 해결' : pct >= 0.8 ? '사건 해결' : right ? '범인은 맞혔으나 근거 부족' : '미해결 — 엉뚱한 사람을 지목';
  const mins = st.startedAt && sub.submittedAt ? Math.max(1, Math.round((sub.submittedAt - st.startedAt) / 60000)) : null;
  const nIns = (state.insights || []);
  const miss = (cs.combine.tries - cs.combine.hits) + (cs.confront.tries - cs.confront.hits);
  // 판결문 머리: 점수와 한 줄 평, 그리고 이 수사가 남긴 기록(캡스톤의 '추적·분석' 데이터)
  panel.append(h('div', { class: 'verdict' + (right ? ' solved' : ' failed') },
    h('div', { class: 'vd-top' }, h('span', null, '수사 결과 보고'), h('span', null, state.title || '')),
    h('div', { class: 'vd-main' },
      h('div', null, h('div', { class: 'vd-grade' }, grade), h('div', { class: 'vd-score' }, h('b', null, String(sub.score)), h('span', null, ' / ' + sub.max))),
      h('div', { class: 'vd-stamp', 'aria-hidden': 'true' }, right ? '종결' : '미결')),
    h('div', { class: 'vd-stats' },
      [['증거 열람', `${st.evidenceFound ?? 0}/${st.evidenceTotal ?? 0}`], ['깨뜨린 진술', `${st.statementsBroken ?? 0}/${st.statementsTotal ?? 0}`],
        ['성립한 추리', `${st.deductions ?? 0}/${st.deductionsTotal ?? 0}`], ['착안', String(nIns.filter((i) => i.kind === 'combine').length)],
        ['대질', String(nIns.filter((i) => i.kind === 'confront').length)], ['증거 내밀기', String(cs.present.tries)], ['헛짚음', String(miss)],
        mins ? ['걸린 시간', `${mins}분`] : null,
        ...usageStats()].filter(Boolean).map(([k, v]) => h('div', null, h('span', null, k), h('b', null, v)))),
    h('div', { class: 'vd-badges' },
      right && !state.assisted ? h('span', { class: 'vd-badge gold' }, '실마리 없이 해결') : null,
      state.assisted ? h('span', { class: 'vd-badge' }, '실마리·추천 질문 사용') : right ? null : h('span', { class: 'vd-badge' }, '실마리 끄고 수사'))));
  panel.append(h('div', { class: 'paper' },
    h('h3', null, '채점 내역'),
    h('div', { class: 'bd-list' }, bd.map((b) => h('div', { class: 'bd-row' + (b.got >= b.max ? ' full' : b.got > 0 ? ' part' : ' zero') },
      h('span', { class: 'bd-l' }, b.label), h('span', { class: 'bd-bar', 'aria-hidden': 'true' }, h('i', { style: `width:${b.max ? (b.got / b.max) * 100 : 0}%` })), h('span', { class: 'bd-v' }, `${b.got} / ${b.max}`)))),
    h('h3', null, '정답 요약' + (ans.culpritName ? ' — ' + ans.culpritName : '')),
    h('p', null, ans.summary || ''),
    h('h3', null, '원작 타임라인'),
    h('ul', { class: 'rec-list' }, (ans.timeline || []).map((t) => h('li', null, h('span', { class: 'who' }, t[0]), t[1])))));
  // 증거 파트 데이터가 있는 사건: 용의자 배제 근거와 증거별 해석·한계
  if ((ans.exclusions || []).length) {
    panel.append(h('div', { class: 'paper' }, h('h3', null, '다른 용의자를 배제하는 근거'),
      h('ul', { class: 'rec-list' }, ans.exclusions.map((x) => h('li', null, h('span', { class: 'who' }, x.name), x.reason, h('div', { class: 'meta' }, '근거: ' + x.evidence.join(', ')))))));
  }
  if ((ans.notes || []).length) {
    panel.append(h('div', { class: 'paper' }, h('h3', null, '증거별 해석과 한계'), h('div', { class: 'meta' }, '◆ = 정답에 필요한 최소 근거 증거'),
      h('ul', { class: 'rec-list' }, ans.notes.map((n) => h('li', null, h('span', { class: 'who' }, (n.key ? '◆ ' : '') + n.title),
        h('div', null, '알 수 있는 것: ' + (n.proves || '')), h('div', { class: 'meta' }, '알 수 없는 것: ' + (n.limits || '')))))));
  }
}

// 이 판의 모델 호출 기록(결과 화면). 구독 CLI처럼 단가가 없는 호출이 섞이면 비용은 '—'.
function usageStats() {
  const u = state.usage;
  if (!u || !u.calls) return [['모델 호출', '없음']];
  return [['모델 호출', `${u.calls}회`], ['평균 응답', `${(u.ms / u.calls / 1000).toFixed(1)}초`],
    ['토큰', `${Math.round((u.inTok + u.outTok) / 1000)}k`], ['이번 판 API 비용', u.priced ? `$${u.usd.toFixed(u.usd < 0.01 ? 4 : 3)}` : '— (구독)']];
}

// --- 인물 노트: 사람별로 들은 이야기·진술·내민 증거·남은 물어볼 거리 ---
function renderNotes(panel) {
  panel.append(h('p', { class: 'hint' }, '사람별로 정리한 수사 노트입니다. 「더 물어볼 거리」는 지금까지 연 조건으로 아직 듣지 못한 이야기의 수입니다(무엇인지는 직접 물어봐야 압니다).'));
  const grid = h('div', { class: 'note-grid' });
  for (const p of state.people) {
    const know = state.knowledge.filter((k) => k.pid === p.pid);
    const stm = state.statements.filter((s) => s.speaker === p.pid);
    const shown = shownCount(p.pid);
    const loc = p.locationId === 'interrogation' ? '호텔 응접실' : (state.locations.find((l) => l.id === p.locationId) || {}).name || '';
    const card = h('article', { class: 'note-card' + (p.pid === ui.chatPid ? ' on' : '') },
      h('header', null, h('div', { class: 'nc-cameo' }, cameo(p, { tag: 'nt' })),
        h('div', null, h('h3', null, p.name), h('div', { class: 'nc-role' }, p.role),
          h('span', { class: 'badge ' + p.stance }, STANCE_KO[p.stance] || p.stance), h('span', { class: 'nc-where' }, (p.present ? '여기 있음' : '다른 곳') + (loc ? ' · ' + loc : '')))),
      h('div', { class: 'nc-nums' },
        h('span', null, '들은 이야기 ', h('b', null, String(p.heard || 0))),
        h('span', { class: p.topicsLeft ? 'more' : '' }, '더 물어볼 거리 ', h('b', null, p.topicsLeft === null ? '소환 뒤' : String(p.topicsLeft || 0))),
        h('span', null, '내민 증거 ', h('b', null, String(shown)))),
      meterBars(p, 'nc-meters'),
      know.length ? h('ul', { class: 'nc-list' }, know.map((k) => h('li', null, k.text))) : h('p', { class: 'slim-empty' }, '아직 들은 이야기가 없습니다.'),
      stm.length ? h('div', { class: 'nc-stm' }, stm.map((s) => h('p', { class: s.status === 'broken' ? 'broken' : '' }, (s.status === 'broken' ? '깨진 진술 · ' : '진술 · ') + s.text))) : null,
      h('button', { type: 'button', class: 'nc-talk', 'aria-label': p.name + '에게 가서 묻기', onclick: () => goPerson(p.pid) }, p.present ? '대화하기' : '찾아가서 묻기'));
    grid.append(card);
  }
  panel.append(grid);
}

// --- 우측 인물 패널 ---
function currentPerson() {
  if (!state.people.length) return null;
  let p = state.people.find((x) => x.pid === ui.chatPid);
  if (!p) {
    p = state.people.find((x) => x.present) || state.people[0];
    ui.chatPid = p.pid;
  }
  return p;
}
function renderSide() {
  const p = currentPerson();
  renderPortrait(p); renderChips(); renderSummonBar(); renderChat(p); renderAttachRow(); updateComposer(p);
}
// 신뢰·압박 막대(36번). 말을 나눈 뒤에만 서버가 값을 준다. 위로·정중함은 신뢰를, 증거 없는 추궁·위협은 압박을 올린다.
function meterBars(p, cls) {
  const m = p && p.meters;
  if (!m) return null;
  const bar = (k, label, v) => h('div', { class: 'mt-row ' + k, title: `${label} ${v} / 100` },
    h('span', { class: 'mt-l' }, label), h('span', { class: 'mt-bar', 'aria-hidden': 'true' }, h('i', { style: `width:${v}%` })), h('b', { class: 'mt-v' }, String(v)));
  return h('div', { class: 'meters' + (cls ? ' ' + cls : ''), role: 'group', 'aria-label': `${p.name}의 신뢰 ${m.trust}, 압박 ${m.pressure}` },
    bar('trust', '신뢰', m.trust), bar('pressure', '압박', m.pressure));
}
function renderPortrait(p) {
  const box = $('portrait'); clear(box);
  if (!p) { box.append(h('div', { class: 'empty' }, '인물이 없습니다.')); return; }
  const frame = h('div', { class: 'portrait-frame' }, p.portrait ? imgWithFallback(p.portrait, p.name, () => avatar(p)) : avatar(p));
  const loc = (state.locations.find((l) => l.id === p.locationId) || {}).name || (p.locationId === 'interrogation' ? '심문실' : '');
  box.append(frame, h('div', { class: 'pinfo' }, h('h2', null, p.name), h('div', { class: 'role' }, p.role),
    h('span', { class: 'badge ' + p.stance }, STANCE_KO[p.stance] || p.stance),
    h('div', { class: 'where' }, (p.present ? '지금 같은 곳에 있음' : '다른 곳에 있음') + (loc ? ' · ' + loc : '')),
    meterBars(p),
    p.stance === 'confessed' ? h('button', { type: 'button', class: 'replay', 'aria-label': `${p.name}의 자백 조서 다시 보기`, onclick: () => showConfession(p.pid) }, '자백 조서 다시 보기') : null));
}
function renderChips() {
  const box = $('chips'); clear(box);
  for (const p of state.people) {
    const mini = h('span', { class: 'mini' }, p.portrait ? imgWithFallback(p.portrait, '', () => document.createTextNode(p.initials || p.name.slice(0, 1))) : (p.initials || p.name.slice(0, 1)));
    box.append(h('button', {
      type: 'button', role: 'tab', class: 'chip' + (p.present ? ' here' : ''), 'aria-selected': String(p.pid === ui.chatPid),
      'aria-label': `${p.name}${p.present ? ' (이 자리에 있음)' : ''} 선택`, onclick: () => { ui.chatPid = p.pid; renderSide(); },
    }, mini, h('span', { class: 'presence' }), p.name));
  }
}
function renderSummonBar() {
  const box = $('summonbar'); clear(box);
  if (state.place !== 'interrogation') return;
  if (state.people.some((p) => p.stance === 'refusing')) box.append(h('button', { type: 'button', class: 'primary', 'aria-label': '소환 신청', onclick: startSummon }, '소환 신청'));
  // 판결 전문은 판결 순간 모달로 보여 주고, 여기서는 지금 보는 인물의 최근 판결만 한 줄로 남긴다.
  const last = [...state.judge].reverse().find((j) => j.pid === ui.chatPid);
  if (last) box.append(h('div', { class: 'judge-line ' + last.verdict, title: last.reason },
    h('span', { class: 'judge-ico', 'aria-hidden': 'true' }, hammerSvg()),
    h('b', null, `소환 ${last.verdict === 'approved' ? '승인' : '기각'}`),
    h('span', { class: 'meta' }, last.reason)));
}
async function startSummon() {
  const refusing = state.people.filter((p) => p.stance === 'refusing');
  if (!refusing.length) { toast('소환할 거절 인물이 없습니다.', 'error'); return; }
  let pid = refusing[0].pid;
  const radios = h('div', { class: 'check-grid', style: 'margin-bottom:10px' }, refusing.map((p, i) => {
    const r = h('input', { type: 'radio', name: 'summon-pid', value: p.pid, checked: i === 0 });
    r.addEventListener('change', () => { pid = p.pid; });
    return h('label', null, r, h('span', null, p.name));
  }));
  const ids = await evidencePicker({ title: '소환 신청', multi: true, okLabel: '판사에게 제출', extra: h('div', null, h('p', { class: 'hint' }, '소환할 인물을 고르고, 판사가 볼 증거를 첨부하세요.'), radios) });
  if (!ids) return;
  await act({ type: 'summon', pid, evidenceIds: ids });
}
function renderChat(p) {
  const log = $('chatlog'); clear(log);
  if (!p) return;
  const msgs = (state.chats && state.chats[p.pid]) || [];
  const title = (id) => (state.evidence.find((e) => e.id === id) || {}).title || id;
  const draw = (m) => {
    const el = h('div', { class: 'msg ' + (m.from || 'system'), data: m.source ? { source: m.source } : null },
      m.from === 'npc' ? h('span', { class: 'who' }, p.name) : null, m.text);
    if (m.attachments && m.attachments.length) el.append(h('span', { class: 'att' }, '첨부: ' + m.attachments.map(title).join(', ')));
    log.append(el);
  };
  if (!msgs.length && p.canTalk && !(ui.pendingMsg && ui.pendingMsg.pid === p.pid)) log.append(h('div', { class: 'msg system' }, `${p.name}에게 자유롭게 물어보세요.`));
  msgs.forEach(draw);
  if (ui.pendingMsg && ui.pendingMsg.pid === p.pid) {
    draw({ from: 'player', text: ui.pendingMsg.text, attachments: ui.pendingMsg.attachments });
    log.append(ui.pendingMsg.partial
      ? h('div', { class: 'msg npc streaming', 'aria-live': 'polite' }, h('span', { class: 'who' }, p.name), ui.pendingMsg.partial)
      : h('div', { class: 'msg npc thinking', role: 'status' }, h('span', { class: 'who' }, p.name), '생각 중…'));
  }
  // 추천 질문: 사건 팩이 인물별로 주면(prompts) 진행도에 맞춰 늘 보이고, 없으면 처음 두 질문까지 공통 질문을 제안한다.
  const asked = msgs.filter((m) => m.from === 'player');
  if (!ui.busy && !ui.leadOff && !state.submitted) {
    let list = null;
    if (Array.isArray(p.prompts)) list = p.prompts.filter((x) => !asked.some((m) => m.text === x.q));
    else if (asked.length < 2) list = STARTERS.filter((q) => !asked.some((m) => m.text === q)).map((q) => ({ q }));
    if (!p.canTalk && p.where) {
      log.append(h('div', { class: 'starters off' }, h('span', { class: 'lbl' }, `지금 이 자리에 없습니다 · ${p.where}에서 만날 수 있습니다`)));
    } else if (p.canTalk && list && list.length) {
      log.append(h('div', { class: 'starters' }, h('span', { class: 'lbl' }, '이렇게 물어볼 수 있습니다'),
        list.map((x) => h('button', { type: 'button', class: x.fill ? 'fill' : null, 'aria-label': x.fill ? `입력창에 채우기: ${x.q}` : `질문 보내기: ${x.q}`,
          onclick: () => {
            if (ui.busy) return;
            if (!x.fill) return talkTo(p, x.q, []);
            const inp = $('chat-input'); inp.value = x.q; inp.focus(); inp.setSelectionRange(x.q.length, x.q.length);
          } }, x.fill ? x.q.trim() + ' …' : x.q))));
    }
  }
  log.scrollTop = log.scrollHeight;
}
function renderAttachRow() {
  const row = $('attachrow'); clear(row);
  const title = (id) => (state && state.evidence.find((e) => e.id === id) || {}).title || id;
  for (const id of ui.attach) {
    row.append(h('button', { type: 'button', class: 'att-chip', 'aria-label': `${title(id)} 첨부 해제`, onclick: () => { toggleAttach(id); if (ui.tab === 'evidence') renderMain(); } }, title(id) + ' ✕'));
  }
}
function updateComposer(p) {
  const can = !!p && p.canTalk && !ui.busy;
  $('chat-input').disabled = !can;
  $('btn-send').disabled = !can;
  $('btn-attach').disabled = !p || ui.busy;
  $('chat-input').placeholder = !p ? '' : (p.canTalk ? '자유롭게 질문하세요' : (p.refusal || '지금은 이 인물과 대화할 수 없습니다.'));
}
// 대화 전송 공용: 입력창 전송과 증거 접촉이 같은 경로를 쓴다(대화창·이벤트 처리 동일).
async function talkTo(p, text, attachments, opts = {}) {
  const prevPid = ui.chatPid;
  ui.chatPid = p.pid;
  ui.busy = true; ui.pendingMsg = { pid: p.pid, text, attachments, partial: '' };
  renderSide();
  const onProgress = (o) => {
    if (!ui.pendingMsg) return;
    if (o.phase === 'judged') {
      const bits = [];
      if (o.clues) bits.push(`새 단서 ${o.clues}`);
      if (o.deductions) bits.push('추리 성립');
      for (const u of o.unlocks || []) bits.push('장소 열림: ' + u);
      if (bits.length) { toast(bits.join(' · ')); ui.preAnnounced = true; }
    } else if (o.phase === 'text' && o.text) {
      ui.pendingMsg.partial = o.text;
      if (ui.chatPid === p.pid) renderChat(p);
    }
  };
  const r = await act({ type: 'talk', pid: p.pid, text, attachments }, { silent: true, onProgress });
  ui.busy = false; ui.pendingMsg = null;
  if (r && opts.fromInput) ui.attach = [];
  if (r && opts.contact) ui.contactPulse = p.pid;
  if (!r && opts.contact) ui.chatPid = prevPid; // 접촉 실패(자리에 없음 등)면 인물 패널을 바꾸지 않는다
  renderAll();
  if (r && opts.contact) setTimeout(() => { ui.contactPulse = null; refreshContact(); }, 1200);
  return r;
}
async function sendChat() {
  const p = currentPerson();
  const input = $('chat-input');
  const text = input.value.trim();
  if (!p || !text || ui.busy || !p.canTalk) return;
  const attachments = [...ui.attach];
  input.value = '';
  const r = await talkTo(p, text, attachments, { fromInput: true });
  if (!r) input.value = text;
  if (!$('chat-input').disabled) $('chat-input').focus();
}

// ---------- 맞대기 보드: 지도 옆에서 인물·증거를 서로 맞댄다 ----------
// 증거 → 인물 = 내밀기(대화 첨부), 증거 ↔ 증거 = 착안, 인물 ↔ 인물 = 대질.
// 판정은 서버 규칙표가 하고, 화면은 결과만 그린다. 그 인물에게 내민 증거는 대화 기록의 첨부에서 복원한다.
function shownCount(pid) {
  return new Set(((state.chats && state.chats[pid]) || []).filter((m) => m.from === 'player').flatMap((m) => m.attachments || [])).size;
}
function wasShown(pid, evId) {
  return ((state.chats && state.chats[pid]) || []).some((m) => m.from === 'player' && (m.attachments || []).includes(evId));
}
const insightOf = (id) => (state.insights || []).find((i) => i.id === id);
const pairDone = (kind, a, b) => (state.insights || []).some((i) => i.kind === kind && ((i.a === a && i.b === b) || (i.a === b && i.b === a)));

// 집어 든 것(ui.picked = {kind:'ev'|'person', id})을 대상에 맞댄다.
async function touch(src, dst) {
  ui.picked = null; ui.dragEv = null;
  if (!src || !dst || ui.busy) { refreshContact(); return; }
  if (src.kind === 'ev' && dst.kind === 'person') {
    const e = state.evidence.find((x) => x.id === src.id);
    const p = state.people.find((x) => x.pid === dst.id);
    if (!e || !p) { refreshContact(); return; }
    await talkTo(p, '이 증거를 보십시오: ' + e.title, [src.id], { contact: true });
    return;
  }
  if (src.kind === 'person' && dst.kind === 'ev') { await touch(dst, src); return; }
  if (src.id === dst.id) { refreshContact(); return; }
  const type = src.kind === 'ev' ? 'combine' : 'confront';
  ui.busy = true; refreshContact();
  const r = await act({ type, a: src.id, b: dst.id }, { silent: true });
  ui.busy = false;
  renderAll();
  const ev = r && (r.events || []).find((x) => x.kind === (type === 'combine' ? 'combo' : 'confront'));
  if (!ev) return;
  if (ev.success) {
    showInsight(insightOf(ev.id), { fresh: ev.fresh });
  } else {
    ui.miss = [src.id, dst.id];
    refreshContact();
    setTimeout(() => { ui.miss = null; refreshContact(); }, 700);
    toast(type === 'combine' ? '두 증거 사이에서 이어지는 점을 찾지 못했습니다. (헛짚음도 기록에 남습니다)'
      : ev.reason === 'unheard' ? '맞댈 거리는 있어 보입니다. 두 사람에게서 먼저 그 일에 대한 말을 들어 보십시오.'
        : '두 사람의 말에서 맞부딪치는 지점을 찾지 못했습니다.', 'error');
  }
}

// 착안·대질 카드: 두 조각을 붉은 실로 잇고, 그 사이의 질문을 크게 보여 준다.
function threadSvg() {
  return sv('svg', { class: 'thread', viewBox: '0 0 120 40', preserveAspectRatio: 'none', 'aria-hidden': 'true' },
    sv('path', { class: 'th', d: 'M2 20 C30 4 50 36 60 20 S96 4 118 20', pathLength: 1 }),
    sv('circle', { class: 'pin', cx: 2, cy: 20, r: 4 }), sv('circle', { class: 'pin', cx: 118, cy: 20, r: 4 }));
}
function showInsight(i, opt = {}) {
  if (!i) return;
  const isCf = i.kind === 'confront';
  openModal('insight', (close) => {
    const head = h('div', { class: 'ins-pair' },
      h('span', { class: 'ins-node ' + (isCf ? 'p' : 'e') }, i.aTitle), threadSvg(), h('span', { class: 'ins-node ' + (isCf ? 'p' : 'e') }, i.bTitle));
    const body = isCf
      ? h('div', { class: 'ins-dialog' }, i.lines.map((l) => h('div', { class: 'ins-line' }, h('b', null, l.name), h('span', null, '“' + l.text + '”'))),
        h('p', { class: 'ins-note' }, i.note),
        i.breaks ? h('p', { class: 'ins-broke' }, '이 대질로 진술 하나가 깨졌습니다. 진술 탭에서 확인하세요.') : null)
      : h('div', null, h('p', { class: 'ins-text' }, i.text), h('p', { class: 'ins-ask' }, i.ask));
    const target = !isCf && i.talkTo && state.people.find((p) => p.pid === i.talkTo);
    const go = target ? h('button', { type: 'button', class: 'primary', 'aria-label': `${target.name}에게 말하러 가기`, onclick: () => {
      close(); ui.chatPid = target.pid; renderSide(); refreshContact();
      const inp = $('chat-input'); if (inp && !inp.disabled) inp.focus();
    } }, `${target.name}에게 말하러 가기`) : null;
    return h('div', { class: 'insight ' + (isCf ? 'cf' : 'cb') + (opt.fresh ? ' fresh' : '') },
      h('div', { class: 'ins-kind' }, isCf ? '대질' : '착안', opt.fresh === false ? h('span', null, ' · 이미 찾은 연결') : null),
      h('h3', null, i.title), head, body,
      !isCf ? h('p', { class: 'hint' }, target ? '답이 떠올랐다면 그 생각을 직접 말해야 추리로 성립합니다.' : '수사 기록의 「접촉 기록」에 남았습니다.') : null,
      h('div', { class: 'actions' }, h('button', { type: 'button', onclick: close, 'aria-label': '닫기' }, '닫기'), go));
  }, { title: isCf ? '대질 기록' : '착안' });
}

// 끌기: 포인터 이벤트로 직접 구현해 마우스·터치 모두에서 동작한다. 증거·인물 토큰 모두 끌 수 있다.
function startDrag(ev, tok, src, box) {
  if (ev.button !== 0 || ui.busy) return;
  const sx = ev.clientX, sy = ev.clientY;
  let ghost = null, over = null;
  const targetAt = (x, y) => {
    const el = document.elementFromPoint(x, y);
    const t = el && el.closest('#contact .ctok');
    if (!t || t === tok) return null;
    if (src.kind === 'person' && t.dataset.kind === 'ev') return null; // 인물은 인물에게만 맞댄다(증거는 증거 쪽에서 끌어 온다)
    return t;
  };
  const move = (m) => {
    if (!ghost) {
      if (Math.hypot(m.clientX - sx, m.clientY - sy) < 6) return;
      ghost = tok.cloneNode(true);
      ghost.classList.add('ghost'); ghost.removeAttribute('tabindex');
      ghost.style.width = tok.getBoundingClientRect().width + 'px';
      document.body.append(ghost);
      tok.classList.add('drag'); box.classList.add('dragging', 'from-' + src.kind);
    }
    m.preventDefault();
    ghost.style.transform = `translate(${m.clientX + 10}px, ${m.clientY + 6}px) rotate(-4deg)`;
    const t = targetAt(m.clientX, m.clientY);
    if (t !== over) { if (over) over.classList.remove('over'); over = t; if (over) over.classList.add('over'); }
  };
  const end = () => {
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
    if (!ghost) return; // 움직이지 않았으면 click으로 처리된다
    tok.dataset.dragged = '1';
    setTimeout(() => { delete tok.dataset.dragged; }, 0);
    ghost.remove(); tok.classList.remove('drag'); box.classList.remove('dragging', 'from-ev', 'from-person');
    if (over) { over.classList.remove('over'); touch(src, { kind: over.dataset.kind, id: over.dataset.id }); }
  };
  window.addEventListener('pointermove', move, { passive: false });
  window.addEventListener('pointerup', end);
  window.addEventListener('pointercancel', end);
}
function buildContact() {
  const box = h('section', { class: 'contact', id: 'contact', 'aria-label': '맞대기 보드' });
  fillContact(box);
  return box;
}
function refreshContact() { const box = $('contact'); if (box) { clear(box); fillContact(box); } }
function fillContact(box) {
  const opened = state.evidence.filter((e) => e.opened);
  const pk = ui.picked;
  const pkName = pk && (pk.kind === 'ev' ? (opened.find((e) => e.id === pk.id) || {}).title : (state.people.find((p) => p.pid === pk.id) || {}).name);
  const cs = state.contactStats || { present: { tries: 0 }, combine: { tries: 0, hits: 0 }, confront: { tries: 0, hits: 0 } };
  const nCb = (state.insights || []).filter((i) => i.kind === 'combine').length;
  const nCf = (state.insights || []).filter((i) => i.kind === 'confront').length;
  box.append(h('div', { class: 'cb-head' },
    h('h3', null, '맞대기 보드'),
    h('div', { class: 'cb-legend', 'aria-label': '맞대기 규칙' },
      h('span', null, h('i', { class: 'lg e' }), '→', h('i', { class: 'lg p' }), ' 내밀기'),
      h('span', null, h('i', { class: 'lg e' }), '↔', h('i', { class: 'lg e' }), ' 착안'),
      h('span', null, h('i', { class: 'lg p' }), '↔', h('i', { class: 'lg p' }), ' 대질'))));
  box.append(h('p', { class: 'hint cb-hint' + (pk ? ' live' : '') },
    pk ? `「${pkName}」을(를) 집었습니다. ${pk.kind === 'ev' ? '인물에게 내밀거나 다른 증거에 맞대세요.' : '대질할 다른 인물을 누르세요.'} (같은 것을 다시 누르면 내려놓기)`
      : '토큰을 끌어다 다른 토큰 위에 놓으세요. 누르기만 해도 됩니다: 증거를 누른 뒤 대상을 누르거나, 인물의 ⇄로 대질할 사람을 집으세요.'));

  const pRow = h('div', { class: 'ctok-row', role: 'group', 'aria-label': '인물' });
  for (const p of state.people) {
    const can = !!(p.present && p.canTalk);
    const n = shownCount(p.pid);
    const isPk = pk && pk.kind === 'person' && pk.id === p.pid;
    const mini = h('span', { class: 'cmini' }, p.portrait ? imgWithFallback(p.portrait, '', () => cameo(p, { tag: 'c' })) : cameo(p, { tag: 'c' }));
    const t = h('div', {
      class: 'ctok person' + (can ? '' : ' away') + (p.pid === ui.chatPid ? ' on' : '') + (ui.contactPulse === p.pid ? ' hit' : '') + (isPk ? ' picked' : '') + (ui.miss && ui.miss.includes(p.pid) ? ' miss' : '') + (pk && pk.kind === 'ev' && !can ? ' nodrop' : ''),
      tabindex: '0', role: 'button', data: { kind: 'person', id: p.pid },
      'aria-label': `${p.name}${can ? '' : ' (지금 대화할 수 없음)'}${pk ? (pk.kind === 'ev' ? '에게 집은 증거 내밀기' : (isPk ? ' 내려놓기' : '와(과) 대질')) : ' 선택'}${n ? `, 내민 증거 ${n}건` : ''}`,
    }, mini, h('span', { class: 'cname' }, p.name), h('span', { class: 'cstate' }, can ? '대화 가능' : '자리에 없음'));
    if (n) t.append(h('span', { class: 'cbadge', title: '이 인물에게 내민 증거' }, String(n)));
    const grab = h('button', { type: 'button', class: 'cgrab', 'aria-label': `${p.name}을(를) 대질할 인물로 집기`, title: '대질할 인물로 집기' }, '⇄');
    grab.addEventListener('click', (e) => { e.stopPropagation(); ui.picked = isPk ? null : { kind: 'person', id: p.pid }; refreshContact(); });
    grab.addEventListener('pointerdown', (e) => e.stopPropagation());
    t.append(grab);
    const go = () => {
      if (t.dataset.dragged) { delete t.dataset.dragged; return; }
      if (isPk) { ui.picked = null; refreshContact(); return; }
      if (pk) { touch(pk, { kind: 'person', id: p.pid }); return; }
      ui.chatPid = p.pid; renderSide(); refreshContact();
    };
    t.addEventListener('click', go);
    t.addEventListener('keydown', (e) => { if (e.target !== t) return; if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
    t.addEventListener('pointerdown', (ev) => { if (ev.target.closest('.cgrab')) return; startDrag(ev, t, { kind: 'person', id: p.pid }, box); });
    pRow.append(t);
  }
  const eRow = h('div', { class: 'ctok-row', role: 'group', 'aria-label': '열람한 증거' });
  const cur = state.people.find((x) => x.pid === ui.chatPid);
  for (const e of opened) {
    const given = cur && wasShown(cur.pid, e.id);
    const isPk = pk && pk.kind === 'ev' && pk.id === e.id;
    const linked = pk && pk.kind === 'ev' && !isPk && pairDone('combine', pk.id, e.id);
    const t = h('div', {
      class: 'ctok evid' + (isPk ? ' picked' : '') + (linked ? ' linked' : '') + (ui.miss && ui.miss.includes(e.id) ? ' miss' : '') + (pk && pk.kind === 'person' ? ' nodrop' : ''),
      tabindex: '0', role: 'button', 'aria-pressed': String(!!isPk), data: { kind: 'ev', id: e.id, type: e.type || 'document' }, title: e.look || e.title,
      'aria-label': `증거 ${e.title}${given ? ` (${cur.name}에게 내밈)` : ''}${linked ? ' (이미 이은 짝)' : ''}${pk && pk.kind === 'ev' && !isPk ? '에 맞대기' : ' 집기'}`,
    }, h('span', { class: 'hole', 'aria-hidden': 'true' }), h('span', { class: 'cname' }, e.title));
    if (given) t.append(h('span', { class: 'cstate' }, '내밈'));
    const sel = () => {
      if (t.dataset.dragged) { delete t.dataset.dragged; return; }
      if (isPk) { ui.picked = null; refreshContact(); return; }
      if (pk && pk.kind === 'ev') { touch(pk, { kind: 'ev', id: e.id }); return; }
      if (pk && pk.kind === 'person') { toast('인물은 다른 인물과만 대질합니다. 증거는 증거 쪽에서 인물에게 끌어 오세요.', 'error'); return; }
      ui.picked = { kind: 'ev', id: e.id }; refreshContact();
    };
    t.addEventListener('click', sel);
    t.addEventListener('keydown', (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); sel(); } });
    t.addEventListener('pointerdown', (ev) => startDrag(ev, t, { kind: 'ev', id: e.id }, box));
    eRow.append(t);
  }
  if (!opened.length) eRow.append(h('div', { class: 'empty' }, '열람한 증거가 없습니다. 지도에서 조사하고 증거 탭에서 봉인을 여세요.'));
  box.append(h('div', { class: 'clabel' }, '인물'), pRow, h('div', { class: 'clabel' }, '증거 (' + opened.length + ')'), eRow);

  // 이어 놓은 연결: 찾은 착안·대질을 실로 이은 쪽지로 모아 둔다. 누르면 다시 펼친다.
  const ins = state.insights || [];
  box.append(h('div', { class: 'clabel cb-tally' }, '이어 놓은 연결',
    h('span', null, `착안 ${nCb} · 대질 ${nCf} · 내밀기 ${cs.present.tries} · 헛짚음 ${(cs.combine.tries - cs.combine.hits) + (cs.confront.tries - cs.confront.hits)}`)));
  box.append(ins.length
    ? h('div', { class: 'links' }, ins.map((i) => h('button', { type: 'button', class: 'link-card ' + (i.kind === 'confront' ? 'cf' : 'cb'), 'aria-label': `${i.kind === 'confront' ? '대질' : '착안'}: ${i.title} 다시 보기`, onclick: () => showInsight(i) },
      h('span', { class: 'lk-kind' }, i.kind === 'confront' ? '대질' : '착안'), h('b', null, i.title), h('span', { class: 'lk-pair' }, `${i.aTitle} ↔ ${i.bTitle}`))))
    : h('div', { class: 'slim-empty' }, '아직 이은 연결이 없습니다. 서로 관계가 있어 보이는 두 증거를 맞대어 보세요.'));
}

// ---------- 시작 ----------
function wireStatic() {
  $('composer').addEventListener('submit', (e) => { e.preventDefault(); sendChat(); });
  $('chat-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendChat(); }
  });
  $('btn-attach').addEventListener('click', async () => {
    const ids = await evidencePicker({ title: '대화에 첨부할 증거', multi: true, preset: ui.attach, okLabel: '첨부' });
    if (ids) { ui.attach = ids; renderAttachRow(); if (ui.tab === 'evidence') renderMain(); }
  });
  $('btn-brief').addEventListener('click', () => {
    if (!state) return;
    openModal('brief', (close) => h('div', null, h('div', { class: 'brief' }, state.brief || ''),
      h('div', { class: 'actions' }, h('button', { type: 'button', class: 'primary', onclick: close, 'aria-label': '닫기' }, '닫기'))), { title: '사건 개요' });
  });
  $('btn-help').addEventListener('click', () => showGuide(TAB_GUIDE[ui.tab] ? TAB_GUIDE[ui.tab][1] : 'start'));
  const caseBtn = $('btn-case'); if (caseBtn) caseBtn.hidden = true; // 사건은 보스콤 밸리 하나뿐
  $('btn-reset').addEventListener('click', async () => {
    const ok = await confirmBox('새 수사', '지금까지의 수사 기록이 모두 사라집니다. 새 수사를 시작할까요?', '새 수사 시작');
    if (ok) await act({ type: 'reset' });
  });
}
// 사건 선택: 고른 사건으로 새 세션을 만든다(진행 중인 다른 사건 기록은 서버에 그대로 남는다).
async function chooseCase() {
  let list;
  try { list = (await api('/api/cases')).cases; } catch (e) { toast(e.message, 'error'); return; }
  openModal('cases', (close) => h('div', { class: 'case-list' },
    list.map((c) => h('button', {
      type: 'button', class: 'paper case-item' + (state && state.caseId === c.id ? ' current' : ''), 'aria-label': `${c.title} 시작`,
      onclick: async () => {
        if (state && state.caseId === c.id) { close(); return; }
        const ok = await confirmBox('사건 바꾸기', `「${c.title}」을 새로 시작할까요? 지금 사건 기록은 저장돼 있지만 이 화면에서는 새 사건으로 넘어갑니다.`, '시작');
        if (!ok) return;
        try {
          const data = await api('/api/session', { caseId: c.id });
          sessionId = data.sessionId; state = data.state;
          try { localStorage.setItem('abbey_session', sessionId); } catch (e) { /* 무시 */ }
          resetUi(); ui.chatPid = null; ui.tab = 'map';
          close(); renderAll();
        } catch (e) { toast(e.message, 'error'); }
      },
    }, h('b', null, c.title), h('span', { class: 'meta' }, c.source),
      h('span', { class: 'meta' }, `인물 ${c.people}명 · 용의자 ${c.suspects}명 · 증거 ${c.evidence}건`))),
    h('div', { class: 'actions' }, h('button', { type: 'button', onclick: close, 'aria-label': '닫기' }, '닫기'))), { title: '사건 선택' });
}
async function boot() {
  wireStatic();
  try {
    await startSession();
    renderAll();
    let seen = false;
    try { seen = sessionStorage.getItem('bv_intro') === '1'; } catch (e) { /* 무시 */ }
    if (!seen || location.hash === '#intro') showIntro(); else firstGuide();
  } catch (e) {
    toast(e.message, 'error');
    $('tabpanel').append(h('div', { class: 'empty' }, '서버가 꺼져 있습니다. 게임 폴더의 START.cmd를 더블클릭해 서버를 켠 뒤 새로고침하세요.'));
  }
}
boot();
