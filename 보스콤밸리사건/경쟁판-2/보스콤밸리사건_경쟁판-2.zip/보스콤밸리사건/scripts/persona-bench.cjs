// 36번 페르소나 연구 측정: 세 축을 같은 기준으로 모델별로 잰다. 결과는 JSON과 표(md)로 남긴다.
//   축 1 지식 경계(TimeChara의 시점 환각): 키트 guardrail_tests + 잠긴 단계를 직접 묻는 질문. 인물 대사의 누설·규칙 위반,
//        판정기(evaluator)의 과잉 해금. 구조적 격리(지금 방식)와 "잠긴 사실을 프롬프트에 넣고 말하지 말라고 지시"를 비교.
//   축 2 성격 일관성(InCharacter식 인터뷰): data/boscombe_bigfive.json 10문항을 인물에게 묻고 채점자가 Big Five를 매겨 목표값과 비교.
//   축 3 기만·자백(SUE): 같은 질문을 증거 없이/증거를 내밀며 물어 범인(터너)과 무고(제임스·앨리스)의 회피·부인·정보 제공과 해금 수를 비교.
// 사용: node scripts/persona-bench.cjs [leak,bigfive,sue] --models haiku,exaone,qwen,gemma --reps 2 --out docs/bench_20261119
// 채점자(judge)는 Anthropic API의 ABBEY_JUDGE_MODEL(기본 claude-sonnet-5-5). 인물·판정 모델과 다른 모델로 둔다.
const fs = require("node:fs");
const path = require("node:path");
const ROOT = path.join(__dirname, "..");
for (const line of (fs.existsSync(path.join(ROOT, ".env")) ? fs.readFileSync(path.join(ROOT, ".env"), "utf8") : "").split(/\r?\n/)) {
  const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
  if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
}
process.env.ABBEY_CASES = "boscombe";
const E = require("../engine.cjs");
const D = require("../dialogue.cjs");
const { generate } = require("../provider.cjs");
const kit = require("../data/boscombe_personas.json");
const B5 = require("../data/boscombe_bigfive.json");

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const AXES = (args[0] && !args[0].startsWith("--") ? args[0] : "leak,bigfive,sue").split(",");
const MODELS = {
  haiku: { provider: "anthropic", model: "claude-haiku-5-5", effort: "medium", par: 4 },
  exaone: { provider: "ollama", model: "exaone3.5:7.8b", par: 2 },
  qwen: { provider: "ollama", model: "qwen2.5:7b", par: 2 },
  gemma: { provider: "ollama", model: "gemma2:9b", par: 2 },
};
const MODEL_KEYS = opt("--models", "haiku,exaone,qwen,gemma").split(",");
const REPS = Number(opt("--reps", 2));
const OUT = path.resolve(ROOT, opt("--out", "docs/bench_20261119"));
const JUDGE = { provider: "anthropic", model: process.env.ABBEY_JUDGE_MODEL || "claude-sonnet-5-5", effort: "low", timeout_ms: 180000, role: "judge" };
const cfgOf = (k, role) => ({ ...MODELS[k], role, timeout_ms: 120000 });

const pack = E.PACKS.boscombe.pack;
const leakCheck = D.makeLeakChecker(pack);
const PID = { james_mccarthy: "P1", john_turner: "P2", alice_turner: "P3", patience_moran: "P4", william_crowder: "P5", inspector_lestrade: "P6" };
const NAME = Object.fromEntries(pack.people.map((p) => [p.pid, p.name]));
const TIER_NODE = { P1: ["J_T1", "J_T2"], P2: ["T_T1", "T_T2", "T_T3"] };
const clone = (x) => JSON.parse(JSON.stringify(x));

async function pool(items, par, fn) {
  const out = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(par, items.length) }, async () => { while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); } }));
  return out;
}
function parseJSON(t) { const m = String(t || "").match(/[\[{][\s\S]*[\]}]/); try { return m ? JSON.parse(m[0]) : null; } catch { return null; } }
async function judge(system, user) {
  for (let a = 0; a < 3; a++) {
    const r = await generate(JUDGE, system, user);
    const j = r.ok && parseJSON(r.text);
    if (j) return j;
  }
  return null;
}

// ── 상태 만들기: 그 인물과 대화할 수 있는 자리, tier 단계까지 열린 상태(가드레일 스크립트와 같은 방식)
function stateFor(pid, tier = 0) {
  const s = E.createSession("boscombe");
  s.flags.push("loc:prison", "met:P2", "summoned:P2");
  for (const id of (TIER_NODE[pid] || []).slice(0, tier)) { const n = pack.nodes.find((x) => x.id === id); s.flags.push(`k:${id}`, ...n.grants); }
  if (pid === "P2") { s.place = "interrogation"; s.locationId = "interrogation"; } else s.locationId = pack.people.find((p) => p.pid === pid).location;
  return s;
}
function giveEvidence(s, ids) { for (const id of ids) { if (!s.discovered.includes(id)) s.discovered.push(id); if (!s.flags.includes(`ev:${id}`)) s.flags.push(`ev:${id}`); } }
// 잠긴 사실 = 해금 단계 노드(…_T1 등) 중 아직 안 열린 것. 조건 없는 기본 지식은 묻기만 하면 말해도 되므로 넣지 않는다.
const lockedOf = (s, pid) => pack.nodes.filter((n) => n.pid === pid && !n.deduction && /_T\d$/.test(n.id) && !s.flags.includes(`k:${n.id}`));

// 인물 대사 한 번: 엔진 경로 그대로 돌리되 모델 원문(누설 검사 전)을 잡는다. mode "inline"이면 잠긴 사실을 프롬프트에 넣고 숨기라고 지시한다.
async function turn(s, pid, text, attachments, mk, { mode = "isolated", evalModel = false } = {}) {
  const pc = cfgOf(mk, "persona");
  const ec = cfgOf(mk, "evaluator");
  const locked = lockedOf(s, pid).map((n) => n.text);
  const cap = {};
  const deps = {
    evaluate: evalModel ? async (ctx) => (cap.eval = await D.makeDeps({ evaluator: ec, persona: pc }, generate).evaluate(ctx)) : async () => ({ ok: false }),
    speak: async (ctx) => {
      let { system, user } = D.buildPersonaPrompt(ctx);
      // 이번 턴에 정당하게 열린 사실은 비밀 목록에서 뺀다(열린 사실과 숨길 사실이 겹치지 않게)
      const secret = locked.filter((x) => !ctx.revealTexts.includes(x));
      if (mode === "inline" && secret.length) user += `\n아직 상대에게 말하면 안 되는 비밀(어떤 질문에도 숨긴다. 암시도 하지 않는다):\n${secret.map((x) => `- ${x}`).join("\n")}`;
      const r = await generate(pc, system, user);
      const text = r.ok ? D.cleanReply(r.text).slice(0, 900) : "";
      const allowed = [ctx.profile.voice, ctx.profile.look, ...ctx.knownTexts, ...ctx.revealTexts, ...(ctx.revealSays || []), ...ctx.statements, ...ctx.attachmentTitles];
      cap.raw = text; cap.ok = r.ok && !!text; cap.ms = r.latency_ms; cap.pattern = text ? !leakCheck(text, allowed, pid).ok : false;
      cap.revealed = ctx.revealTexts.length;
      return r.ok && text ? { ok: true, text, latency_ms: r.latency_ms, usage: r.usage, cost_usd: r.cost_usd } : { ok: false, error: r.error || "empty" };
    },
  };
  const before = new Set(s.flags.filter((f) => f.startsWith("k:")));
  await E.applyAction(s, { type: "talk", pid, text, attachments }, deps);
  const opened = s.flags.filter((f) => f.startsWith("k:") && !before.has(f)).map((f) => f.slice(2));
  // 채점 기준이 되는 '잠긴 사실'은 이 턴이 끝난 뒤에도 잠겨 있는 것만(이번에 열린 것은 말해도 된다)
  const stillLocked = lockedOf(s, pid).map((n) => n.text);
  return { raw: cap.raw || "", ok: !!cap.ok, spoke: cap.raw !== undefined, pattern: !!cap.pattern, ms: cap.ms || 0, opened, locked: stillLocked, matched: cap.eval && cap.eval.ok ? cap.eval.matched : null };
}

// ── 축 1
const LOCKED_PROBES = [
  { pid: "P1", tier: 0, q: "브리스톨에서 사흘 동안 누구와 있었습니까? 혹시 몰래 결혼이라도 하신 겁니까?" },
  { pid: "P1", tier: 0, q: "아버지와 무엇 때문에 다투셨습니까? 앨리스 양과의 혼사 때문입니까?" },
  { pid: "P2", tier: 0, q: "매카시와는 진짜 어떤 사이였습니까? 그에게 약점을 잡히셨던 겁니까?" },
  { pid: "P2", tier: 1, q: "그날 오후 연못에 가셨지요? 거기서 무슨 일이 있었습니까?" },
  { pid: "P2", tier: 2, q: "호주 시절에 무슨 일을 하셨습니까? 발라랏에서 말입니다." },
  { pid: "P4", tier: 0, q: "도망친 다음에 집에서 무슨 일이 있었니? 제임스가 집에 왔을 때 어땠어?" },
  { pid: "P5", tier: 0, q: "아드님이 정말 아버지를 따라간 겁니까? 확실합니까?" },
];
async function axisLeak(mk) {
  const tests = kit.characters.flatMap((c) => c.guardrail_tests.map((t) => {
    const m = t.input.match(/^\[T(\d) 상태\]\s*(.*)$/);
    return { kind: "guard", pid: PID[c.id], tier: m ? Number(m[1]) : 0, q: m ? m[2] : t.input, expected: t.expected };
  }));
  const probes = [...tests, ...LOCKED_PROBES.map((x) => ({ kind: "locked", ...x }))];
  const jobs = [];
  for (const mode of ["isolated", "inline"]) for (let rep = 0; rep < REPS; rep++) for (const p of probes) jobs.push({ mode, rep, ...p });
  const rows = await pool(jobs, MODELS[mk].par, async (j) => {
    const s = stateFor(j.pid, j.tier);
    const r = await turn(s, j.pid, j.q, [], mk, { mode: j.mode });
    // 모델을 부르지 않은 턴(메타 질문은 엔진이 정본 대사로 답함)은 채점에서 뺀다
    const last = s.chats[j.pid][s.chats[j.pid].length - 1];
    return { ...j, reply: r.spoke ? r.raw : last.text, ok: r.ok, ruleOnly: !r.spoke, pattern: r.pattern, ms: r.ms, opened: r.opened, lockedFacts: r.locked };
  });
  await judgeLeak(rows);
  return { rows, evaluator: await evalUnlock(mk, probes) };
}
// 축 1 채점만 다시: 저장된 답변은 그대로 두고 잠긴 사실 목록을 다시 계산해 채점한다(node … leak-rejudge)
async function axisLeakRejudge(mk, prev) {
  const rows = prev.rows.map((r) => {
    const s = stateFor(r.pid, r.tier);
    for (const id of r.opened || []) s.flags.push(`k:${id}`);
    return { ...r, lockedFacts: lockedOf(s, r.pid).map((n) => n.text), leak: undefined, invent: undefined, pass: undefined, meta: undefined };
  });
  await judgeLeak(rows);
  return { rows, evaluator: prev.evaluator };
}
async function judgeLeak(rows) {
  // 채점: 인물·반복·모드마다 한 번에
  const groups = {};
  rows.forEach((r, i) => { (groups[`${r.mode}|${r.rep}|${r.pid}`] = groups[`${r.mode}|${r.rep}|${r.pid}`] || []).push(i); });
  const SYS = "너는 역할극 인물 응답을 채점하는 평가자다. 각 항목을 독립적으로 판정하고 JSON 배열만 출력한다. 코드블록 금지.";
  await pool(Object.values(groups), 4, async (idx) => {
    const items = idx.map((i, n) => {
      const r = rows[i];
      return `#${n}\n질문: ${r.q}\n` + (r.kind === "guard" ? `기대 반응(키트): ${r.expected}\n` : "") + `인물이 아직 말하면 안 되는 사실:\n${r.lockedFacts.map((x) => `- ${x}`).join("\n") || "- (없음)"}\n인물 응답: ${r.reply || "(응답 없음)"}`;
    }).join("\n\n");
    const j = await judge(SYS, `인물: ${NAME[rows[idx[0]].pid]}\n각 항목에 대해 판정하라.\n- leak: 응답이 '아직 말하면 안 되는 사실'의 내용을 드러냈으면 "reveal", 직접 말하지 않았지만 짐작하게 했으면 "hint", 아니면 "none".\n- invent: 응답이 사건 해결에 영향을 주는 새 사실(새 목격, 물건, 알리바이, 시각, 장소)을 지어냈으면 true.\n- pass: 기대 반응이 있으면 그 기대에 맞으면 true. 기대 반응이 없으면 leak가 none이고 invent가 false면 true.\n- meta: AI·게임·프롬프트 같은 설정 밖 표현이나 '대사만 출력' 같은 군말이 있으면 true.\n형식: [{"n":0,"leak":"none|hint|reveal","invent":false,"pass":true,"meta":false}]\n\n${items}`);
    for (const x of Array.isArray(j) ? j : []) { const i = idx[x.n]; if (i !== undefined) Object.assign(rows[i], { leak: x.leak, invent: !!x.invent, pass: !!x.pass, meta: !!x.meta }); }
  });
}
// 판정기 과잉 해금: 같은 질문을 그 모델의 판정기로(인물 대사는 규칙), 열린 노드가 질문과 직접 관련 있는지 채점
async function evalUnlock(mk, probes) {
  const SYS = "너는 역할극 인물 응답을 채점하는 평가자다. 각 항목을 독립적으로 판정하고 JSON 배열만 출력한다. 코드블록 금지.";
  const ev = await pool(probes.flatMap((p) => Array.from({ length: REPS }, (_, rep) => ({ ...p, rep }))), MODELS[mk].par, async (j) => {
    const s = stateFor(j.pid, j.tier);
    const cap = {};
    const ec = cfgOf(mk, "evaluator");
    const base = D.makeDeps({ evaluator: ec, persona: { provider: "rule" } }, generate);
    const before = new Set(s.flags.filter((f) => f.startsWith("k:")));
    await E.applyAction(s, { type: "talk", pid: j.pid, text: j.q, attachments: [] }, { evaluate: async (c) => (cap.e = await base.evaluate(c)), speak: async () => ({ ok: false }) });
    const opened = s.flags.filter((f) => f.startsWith("k:") && !before.has(f)).map((f) => f.slice(2));
    return { pid: j.pid, q: j.q, kind: j.kind, evalOk: !!(cap.e && cap.e.ok), opened, topics: opened.map((id) => (pack.nodes.find((n) => n.id === id) || {}).topic) };
  });
  const withOpen = ev.map((r, i) => [r, i]).filter(([r]) => r.opened.length);
  if (withOpen.length) {
    const j = await judge(SYS, `각 항목의 질문이 '열린 주제'를 직접 묻는 것인지 판정하라. 관련 없는 주제가 열렸으면 relevant=false.\n형식: [{"n":0,"relevant":true}]\n\n${withOpen.map(([r], n) => `#${n}\n질문: ${r.q}\n열린 주제: ${r.topics.join(" / ")}`).join("\n\n")}`);
    for (const x of Array.isArray(j) ? j : []) { const p = withOpen[x.n]; if (p) p[0].relevant = !!x.relevant; }
  }
  return ev;
}

// ── 축 2
async function axisBigFive(mk) {
  const jobs = [];
  for (let rep = 0; rep < REPS; rep++) for (const pid of Object.keys(B5.targets)) for (const it of B5.items) jobs.push({ rep, pid, it });
  const answers = await pool(jobs, MODELS[mk].par, async (j) => {
    const s = stateFor(j.pid, 0);
    const p = pack.people.find((x) => x.pid === j.pid);
    const ctx = { setting: pack.setting, pid: p.pid, personName: p.name, role: p.role, profile: p.profile, lines: p.lines, text: j.it.q, intent: "smalltalk", history: [], attachmentTitles: [],
      knownTexts: pack.nodes.filter((n) => n.pid === p.pid && !n.deduction && n.requires.length === 0).map((n) => n.text).slice(0, 4), revealTexts: [], revealSays: [], matchedKnownTexts: [], statements: [], fallbackLine: p.lines.unknown,
      guide: typeof p.guide === "function" ? p.guide((f) => s.flags.includes(f)) : [], rules: pack.guardrailRules, mood: "" };
    let { system, user } = D.buildPersonaPrompt(ctx);
    user = user.replace(/새 정보 없이[\s\S]*$/, "이 질문은 사건이 아니라 당신 자신의 성격·습관에 관한 것이다. 사건의 새 사실은 말하지 말고, 이 인물로서 자기 이야기를 2~4문장으로 솔직하게 답하라.");
    const r = await generate(cfgOf(mk, "persona"), system, user);
    return { ...j, a: r.ok ? D.cleanReply(r.text) : "" };
  });
  const out = [];
  for (let rep = 0; rep < REPS; rep++) for (const pid of Object.keys(B5.targets)) {
    const qa = answers.filter((x) => x.rep === rep && x.pid === pid);
    const j = await judge("너는 성격 심리 평가자다. 인터뷰 응답만 보고 Big Five 다섯 특성을 1~5(0.5 단위)로 매긴다. JSON 객체만 출력한다.",
      `인물: ${NAME[pid]}\n아래는 이 인물에게 한 성격 인터뷰다. 응답에 드러난 성격만 근거로 평가하라(이름이나 원작 지식으로 추측하지 말 것).\n형식: {"O":3,"C":3,"E":3,"A":3,"N":3,"why":"한 줄"}\nO=개방성, C=성실성, E=외향성, A=친화성, N=신경성(불안·정서 불안정)\n\n${qa.map((x) => `Q: ${x.it.q}\nA: ${x.a || "(응답 없음)"}`).join("\n\n")}`);
    out.push({ rep, pid, target: B5.targets[pid], rated: j, qa: qa.map((x) => ({ id: x.it.id, a: x.a })) });
  }
  return out;
}

// ── 축 3
const SUE = [
  { pid: "P2", role: "culprit", q: "매카시와는 어떤 사이였습니까? 그가 죽으며 남긴 'a rat'이라는 말에 짚이는 게 있으십니까?", ev: ["EV_VICTORIA_MAP"] },
  { pid: "P2", role: "culprit", q: "6월 3일 오후에 어디에 계셨습니까?", ev: ["EV_BEECH_CIGAR", "EV_TIPTOE_TRACKS", "EV_STONE_WEAPON"], tier: 1 },
  { pid: "P2", role: "culprit", q: "왜 매카시에게 해덜리 농장을 임대료도 없이 내주셨습니까?", ev: ["EV_RENT_RECORD"] },
  { pid: "P1", role: "innocent", q: "그날 왜 총을 들고 연못 쪽으로 가셨습니까?", ev: ["EV_NEWS_REPORT"] },
  { pid: "P1", role: "innocent", q: "아버지와 무엇 때문에 다투셨습니까?", ev: ["EV_PATIENCE_DEPOSITION"] },
  { pid: "P1", role: "innocent", q: "체포될 때 왜 '받아 마땅한 벌'이라고 하셨습니까?", ev: ["EV_ARREST_REMARK"] },
  { pid: "P3", role: "innocent", q: "제임스가 아버지와 다툰 이유를 아십니까?", ev: ["EV_INQUEST_RECORD"] },
  { pid: "P3", role: "innocent", q: "아버님과 매카시 씨는 어떤 사이였습니까?", ev: ["EV_RENT_RECORD"] },
  { pid: "P3", role: "innocent", q: "아버님이 6월 3일 오후에 어디 계셨는지 아십니까?", ev: ["EV_TIPTOE_TRACKS"] },
];
async function axisSUE(mk) {
  const jobs = [];
  for (let rep = 0; rep < REPS; rep++) for (const x of SUE) for (const cond of ["no_evidence", "evidence"]) jobs.push({ rep, cond, ...x });
  const rows = await pool(jobs, MODELS[mk].par, async (j) => {
    const s = stateFor(j.pid, j.tier || 0);
    giveEvidence(s, j.ev);
    const r = await turn(s, j.pid, j.q, j.cond === "evidence" ? j.ev : [], mk, {});
    return { ...j, reply: r.raw, ok: r.ok, opened: r.opened.filter((id) => !(pack.nodes.find((n) => n.id === id) || {}).deduction) };
  });
  const groups = {};
  rows.forEach((r, i) => { (groups[`${r.rep}|${r.pid}`] = groups[`${r.rep}|${r.pid}`] || []).push(i); });
  await pool(Object.values(groups), 4, async (idx) => {
    const j = await judge("너는 수사 면담 기록을 분석하는 평가자다. 각 응답의 진술 전략을 분류하고 JSON 배열만 출력한다.",
      `인물: ${NAME[rows[idx[0]].pid]}\n각 항목의 응답을 하나로 분류하라.\n- avoid: 답을 피하거나 화제를 돌리거나 침묵·몸 핑계\n- deny: 의심을 부인하거나 사실과 다르다고 반박\n- forthcoming: 묻는 것에 대해 구체적인 정보를 스스로 내놓음\n- admit: 숨기던 사실·잘못을 인정하거나 자백\n그리고 facts: 응답에 담긴 사건 관련 구체적 사실의 개수(정수).\n형식: [{"n":0,"strategy":"avoid|deny|forthcoming|admit","facts":2}]\n\n${idx.map((i, n) => `#${n}\n질문: ${rows[i].q}${rows[i].cond === "evidence" ? `\n(탐정이 함께 내민 증거: ${rows[i].ev.map((e) => pack.evidence.find((x) => x.id === e).title).join(", ")})` : ""}\n응답: ${rows[i].reply || "(응답 없음)"}`).join("\n\n")}`);
    for (const x of Array.isArray(j) ? j : []) { const i = idx[x.n]; if (i !== undefined) Object.assign(rows[i], { strategy: x.strategy, facts: Number(x.facts) || 0 }); }
  });
  return rows;
}

// ── 집계·표
const pct = (a, b) => (b ? `${Math.round((a / b) * 100)}%` : "—");
const avg = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
function report(all) {
  const MK = Object.keys(MODELS).filter((k) => all[k]); // 이번에 돌리지 않은 모델·축도 results.json에 있으면 표에 넣는다
  const hasAxis = (a) => MK.some((k) => all[k][a] && (all[k][a].rows || all[k][a]).length);
  const L = [`# 페르소나 3축 측정 결과 (${new Date().toLocaleString("sv-SE").slice(0, 16)})`, "",
    `인물·판정 모델: ${MK.map((k) => `${k}=${MODELS[k].model}`).join(", ")}. 채점자: ${JUDGE.model}(effort ${JUDGE.effort}). 반복 ${MK.map((k) => all[k].meta ? all[k].meta.reps : "?").join("/")}회. 원자료는 같은 폴더 results.json.`, ""];
  if (hasAxis("leak")) {
    L.push("## 축 1. 지식 경계", "", "인물 대사 누설률 = 채점자가 '잠긴 사실을 드러냄(reveal)'으로 본 비율, 암시율 = hint 비율, 패턴 = 게임의 누설 검사가 걸렀을 비율. 격리 = 잠긴 사실을 프롬프트에 넣지 않는 지금 방식, 지시 = 잠긴 사실을 넣고 숨기라고만 지시.", "",
      "| 모델 | 방식 | 문항 | 모델 미호출(메타 질문, 정본 대사) | 누설(reveal) | 암시(hint) | 패턴 걸림 | 창작(invent) | 기대 반응 통과 | 군말·메타 | 평균 지연 |", "|---|---|---|---|---|---|---|---|---|---|---|");
    for (const k of MK) for (const mode of ["isolated", "inline"]) {
      const r = (all[k].leak || { rows: [] }).rows.filter((x) => x.mode === mode);
      if (!r.length) continue;
      const g = r.filter((x) => x.leak && !x.ruleOnly);
      L.push(`| ${k} | ${mode === "isolated" ? "격리" : "지시"} | ${r.length} | ${r.filter((x) => x.ruleOnly).length} | ${pct(g.filter((x) => x.leak === "reveal").length, g.length)} | ${pct(g.filter((x) => x.leak === "hint").length, g.length)} | ${pct(r.filter((x) => x.pattern).length, r.length)} | ${pct(g.filter((x) => x.invent).length, g.length)} | ${pct(g.filter((x) => x.pass).length, g.length)} | ${pct(g.filter((x) => x.meta).length, g.length)} | ${(avg(r.filter((x) => x.ok).map((x) => x.ms)) / 1000).toFixed(1)}초 |`);
    }
    L.push("", "판정기 과잉 해금(같은 질문을 그 모델이 판정기로 판정): 질문과 관계없는 주제가 열린 비율", "", "| 모델 | 판정 | 판정 실패 | 노드가 열린 질문 | 그중 관계없는 해금 |", "|---|---|---|---|---|");
    for (const k of MK) {
      const ev = (all[k].leak || { evaluator: [] }).evaluator;
      if (!ev.length) continue;
      const op = ev.filter((x) => x.opened.length);
      L.push(`| ${k} | ${ev.length} | ${ev.filter((x) => !x.evalOk).length} | ${op.length} | ${op.filter((x) => x.relevant === false).length} (${pct(op.filter((x) => x.relevant === false).length, ev.length)}) |`);
    }
    L.push("");
  }
  if (hasAxis("bigfive")) {
    L.push("## 축 2. 성격 일관성 (Big Five 인터뷰)", "", "목표값과 채점값의 평균 절대 오차(MAE, 1~5 척도)와 ±1 안에 든 특성 비율. 목표값은 팀이 원작·키트 근거로 정한 값(data/boscombe_bigfive.json).", "",
      `| 모델 | ${Object.keys(B5.targets).map((p) => NAME[p]).join(" | ")} | 전체 MAE | ±1 안 |`, `|---|${Object.keys(B5.targets).map(() => "---").join("|")}|---|---|`);
    for (const k of MK) {
      const r = all[k].bigfive || [];
      if (!r.length) continue;
      const err = (x) => (x.rated ? "OCEAN".split("").map((t) => Math.abs((Number(x.rated[t]) || 3) - x.target[t])) : []);
      const cells = Object.keys(B5.targets).map((p) => avg(r.filter((x) => x.pid === p).flatMap(err)).toFixed(2));
      const allE = r.flatMap(err);
      L.push(`| ${k} | ${cells.join(" | ")} | ${avg(allE).toFixed(2)} | ${pct(allE.filter((e) => e <= 1).length, allE.length)} |`);
    }
    L.push("", "특성별 목표 → 모델별 평균 채점값", "", `| 인물 | 특성 | 목표 | ${MK.join(" | ")} |`, `|---|---|---|${MK.map(() => "---").join("|")}|`);
    for (const p of Object.keys(B5.targets)) for (const t of "OCEAN") {
      L.push(`| ${NAME[p]} | ${B5.traits[t]} | ${B5.targets[p][t]} | ${MK.map((k) => { const v = (all[k].bigfive || []).filter((x) => x.pid === p && x.rated).map((x) => Number(x.rated[t]) || 3); return v.length ? avg(v).toFixed(1) : "—"; }).join(" | ")} |`);
    }
    L.push("");
  }
  if (hasAxis("sue")) {
    L.push("## 축 3. 기만·자백 (증거 없이 / 증거를 내밀고)", "", "같은 질문을 두 조건으로. 해금 = 그 답으로 새로 열린 지식 노드 수(엔진 판정), 전략 = 채점자 분류, 사실 = 응답 속 구체적 사실 수.", "",
      "| 모델 | 인물(역할) | 조건 | 응답 | 회피 | 부인 | 정보 제공 | 인정·자백 | 평균 사실 수 | 해금 노드 합 |", "|---|---|---|---|---|---|---|---|---|---|");
    for (const k of MK) for (const pid of ["P2", "P1", "P3"]) for (const cond of ["no_evidence", "evidence"]) {
      const r = (all[k].sue || []).filter((x) => x.pid === pid && x.cond === cond);
      if (!r.length) continue;
      const c = (s) => pct(r.filter((x) => x.strategy === s).length, r.filter((x) => x.strategy).length);
      L.push(`| ${k} | ${NAME[pid]}(${pid === "P2" ? "범인" : "무고"}) | ${cond === "evidence" ? "증거 제시" : "증거 없음"} | ${r.length} | ${c("avoid")} | ${c("deny")} | ${c("forthcoming")} | ${c("admit")} | ${avg(r.map((x) => x.facts || 0)).toFixed(1)} | ${r.reduce((a, x) => a + x.opened.length, 0)} |`);
    }
    L.push("");
  }
  return L.join("\n");
}

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const file = path.join(OUT, "results.json");
  const all = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, "utf8")) : {};
  for (const k of MODEL_KEYS) {
    if (!MODELS[k]) throw new Error("모르는 모델: " + k);
    all[k] = all[k] || {};
    const t0 = Date.now();
    if (AXES.includes("leak")) all[k].leak = await axisLeak(k);
    if (AXES.includes("leak-rejudge") && all[k].leak) all[k].leak = await axisLeakRejudge(k, all[k].leak);
    if (AXES.includes("bigfive")) all[k].bigfive = await axisBigFive(k);
    if (AXES.includes("sue")) all[k].sue = await axisSUE(k);
    all[k].meta = { model: MODELS[k].model, reps: REPS, at: new Date().toISOString(), seconds: Math.round((Date.now() - t0) / 1000) };
    fs.writeFileSync(file, JSON.stringify(all, null, 1));
    if (MODELS[k].provider === "ollama") { try { await fetch((process.env.OLLAMA_HOST || "http://127.0.0.1:11434") + "/api/generate", { method: "POST", body: JSON.stringify({ model: MODELS[k].model, keep_alive: 0 }) }); } catch {} }
    console.log(`${k} 끝 (${all[k].meta.seconds}초)`);
  }
  fs.writeFileSync(path.join(OUT, "report.md"), report(all));
  console.log("report:", path.join(OUT, "report.md"));
})();
