// 세션 상태·행동 처리·공개 상태 생성. 상태는 JSON 직렬화 가능한 순수 객체(flags는 배열).
// 사건 내용은 cases/<id>/pack.cjs(사건 팩)에서만 읽는다. 세션은 caseId로 팩을 고른다.
// 모델 호출은 deps({evaluate, speak})로 주입한다. deps가 없거나 실패하면 규칙+정본 응답으로 대체한다.
const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const D = require("./dialogue.cjs");

// ── 사건 팩 적재·색인
const CASES_DIR = path.join(__dirname, "cases");
const PACKS = {};
function indexPack(pack) {
  return {
    pack,
    EVIDENCE: Object.fromEntries(pack.evidence.map((e) => [e.id, e])),
    STATEMENTS: Object.fromEntries(pack.statements.map((x) => [x.id, x])),
    PEOPLE: Object.fromEntries(pack.people.map((p) => [p.pid, p])),
    LOCS: Object.fromEntries(pack.locations.map((l) => [l.id, l])),
    SPOTS: Object.fromEntries(pack.spots.map((x) => [x.id, x])),
    leak: D.makeLeakChecker(pack),
  };
}
// 적재 대상: 환경 변수 ABBEY_CASES(쉼표 목록, "all"이면 전부). 기본은 보스콤 밸리 한 편.
const ALLOWED = String(process.env.ABBEY_CASES || "boscombe").trim();
const ALLOW_ALL = /^(all|\*)$/i.test(ALLOWED);
const ALLOW_LIST = ALLOWED.split(",").map((x) => x.trim()).filter(Boolean);
for (const dir of fs.readdirSync(CASES_DIR)) {
  if (!ALLOW_ALL && !ALLOW_LIST.includes(dir)) continue;
  const file = path.join(CASES_DIR, dir, "pack.cjs");
  if (!fs.existsSync(file)) continue;
  try {
    const pack = require(file);
    PACKS[pack.id] = indexPack(pack);
  } catch (e) {
    console.error(`사건 팩 적재 실패: ${dir}`, e.message);
  }
}
const DEFAULT_CASE = (!ALLOW_ALL && PACKS[ALLOW_LIST[0]] && ALLOW_LIST[0]) || (PACKS.boscombe ? "boscombe" : Object.keys(PACKS)[0]);
const ORDER = ["abbey", "boscombe", "naval", "silver", "bruce", "priory"];
function listCases() {
  return Object.values(PACKS)
    .sort((a, b) => (ORDER.indexOf(a.pack.id) + 99) % 99 - (ORDER.indexOf(b.pack.id) + 99) % 99)
    .map(({ pack }) => ({
      id: pack.id,
      title: pack.title,
      source: pack.source || "",
      people: pack.people.length,
      suspects: pack.suspects.length,
      evidence: pack.evidence.length,
    }));
}
const K = (s) => PACKS[s.caseId || DEFAULT_CASE];

class GameError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

const now = () => Date.now();
const has = (s, f) => s.flags.includes(f);

function createSession(caseId) {
  const id = caseId && PACKS[caseId] ? caseId : DEFAULT_CASE;
  if (caseId && !PACKS[caseId]) throw new GameError("case_unknown", "알 수 없는 사건입니다.");
  const { pack } = PACKS[id];
  const s = {
    version: 2,
    caseId: id,
    id: crypto.randomBytes(8).toString("hex"),
    createdAt: now(),
    place: "scene",
    locationId: pack.startLocation,
    flags: [...pack.start.flags],
    discovered: [],
    spotsDone: [],
    visited: [pack.startLocation],
    seenSpots: {},
    objections: [], // {statementId, evidenceId, crack}
    brokenBy: {},
    stmtNotes: {},
    presented: {},
    chats: {},
    knowledge: [],
    judge: [],
    timeline: [],
    insights: [], // 접촉으로 얻은 착안·대질 {id, kind, a, b, ts}
    contacts: [], // 모든 접촉 시도 기록 {kind, a, b, ok, ref, ts}
    notes: "",
    pending: false,
    submitted: null,
  };
  for (const ev of pack.start.evidence) {
    s.discovered.push(ev);
    s.flags.push(`ev:${ev}`);
    pushTimeline(s, ev);
  }
  markSeen(s);
  return s;
}

function pushTimeline(s, evId) {
  for (const t of (K(s).pack.timeline || {})[evId] || []) s.timeline.push({ time: t.time, text: t.text, evidenceId: evId });
}

// ── 신뢰·압박 계기판(36번). 사건 팩에 meters가 있을 때만 쓴다. 조건 플래그 m:<pid>:<trust|pressure><>=|<=><수>로 읽는다.
function meterOf(s, pid) {
  const init = (K(s).pack.meters || {})[pid];
  if (!init) return null;
  s.meters = s.meters || {};
  if (!s.meters[pid]) s.meters[pid] = { trust: init.trust, pressure: init.pressure };
  return s.meters[pid];
}
function meterOk(s, f) {
  const m = f.match(/^m:(\w+):(trust|pressure)(>=|<=)(\d+)$/);
  const v = m && meterOf(s, m[1]);
  if (!v) return false;
  return m[3] === ">=" ? v[m[2]] >= Number(m[4]) : v[m[2]] <= Number(m[4]);
}
const flagOk = (s, f) => (f.startsWith("m:") ? meterOk(s, f) : has(s, f));
// 이번 질문이 계기판에 주는 영향(키트 common_affect_rules). 해금 판정 전에 적용해 같은 턴의 약속·위로가 바로 반영되게 한다.
function applyAffect(s, p, { tone, intent, attachments, promise }, events) {
  const A = K(s).pack.affect;
  const v = meterOf(s, p.pid);
  if (!A || !v) return null;
  const before = { ...v };
  const fx = [];
  if (A.tone[tone]) fx.push(["tone:" + tone, A.tone[tone]]);
  const shownToHim = s.flags.filter((f) => f.startsWith(`shown:${p.pid}:`)).length;
  if ((tone === "accusatory" || intent === "accuse") && shownToHim === 0) fx.push(["accuse_no_evidence", A.accuseNoEvidence]);
  if (attachments.some((id) => (A.relevant[p.pid] || []).includes(id))) fx.push(["relevant_evidence", A.relevantEvidence]);
  if (promise) { fx.push(["promise", A.promise]); addFlag(s, `promise:${p.pid}`, events); }
  const { min, max } = K(s).pack.meterRange || { min: 0, max: 100 };
  for (const [, e] of fx) for (const k of ["trust", "pressure"]) if (e && e[k]) v[k] = Math.max(min, Math.min(max, v[k] + e[k]));
  const rec = { pid: p.pid, tone, intent, rules: fx.map((x) => x[0]), before, after: { ...v }, ts: now() };
  (s.meterLog = s.meterLog || []).push(rec);
  return rec;
}
function moodOf(v) {
  if (!v) return "";
  const t = v.trust >= 60 ? "상대를 꽤 믿는다" : v.trust >= 30 ? "아직 조심스럽다" : "상대를 경계한다";
  const pr = v.pressure >= 60 ? "몹시 몰려 있다" : v.pressure >= 40 ? "긴장해 있다" : "비교적 차분하다";
  return `${t}, ${pr}(신뢰 ${v.trust}·압박 ${v.pressure})`;
}

// ── 조건 평가
function condMet(s, name) {
  const c = (K(s).pack.conditions || {})[name];
  if (!c) return false;
  if (c.type === "proof") {
    const got = s.presented[c.pid] || [];
    return c.groups.every((g) => g.ids.some((id) => got.includes(id)));
  }
  if (c.type === "cracks") {
    const set = new Set();
    for (const o of s.objections) if (c.statements.includes(o.statementId) && c.cracks.includes(o.crack)) set.add(o.crack);
    return set.size >= c.min;
  }
  // count: 플래그 목록 중 min개 이상 / any: 플래그 묶음(각 묶음은 모두 충족) 중 하나 이상
  if (c.type === "count") return c.flags.filter((f) => flagOk(s, f)).length >= c.min;
  if (c.type === "any") return c.of.some((grp) => grp.every((f) => flagOk(s, f)));
  return false;
}
// 조건 그룹이 요구하는 증거를 그 인물에게 누적 제시하게 하는 인물 목록
const proofPids = (s) => Object.values(K(s).pack.conditions || {}).filter((c) => c.type === "proof").map((c) => c.pid);
const reqMet = (s, r) => (r.startsWith("@") ? condMet(s, r) : flagOk(s, r));
const allMet = (s, reqs) => (reqs || []).every((r) => reqMet(s, r));

// ── 안내 문구: {when?: [조건], until?: 조건, text}. when을 모두 갖췄고 until이 아직이면 보인다(목록 순서 = 우선순위).
const hintLive = (s, x) => allMet(s, x.when) && !(x.until && reqMet(s, x.until));
const hintsFor = (s, list) => (list || []).filter((x) => hintLive(s, x)).map((x) => x.text);
// 자리에 없는 인물을 어디서 만날 수 있는지(화면 안내용)
function whereToMeet(pack, p, s) {
  const name = (id) => (pack.locations.find((l) => l.id === id) || {}).name || id;
  if (has(s, `summoned:${p.pid}`)) return name("interrogation");
  if (p.companion) return null;
  return [p.location, ...(p.talkAt || [])].map(name).join(" 또는 ");
}
// 다음 실마리: 장소와 상관없이 늘 한 줄. progress에 count 조건 이름을 주면 (가진 수/필요 수)를 함께 돌려준다.
function leadOf(s) {
  const x = (K(s).pack.leads || []).find((l) => hintLive(s, l));
  if (!x) return null;
  const out = { text: x.text };
  if (x.go) {
    const pk = K(s).pack;
    if (x.go.pid) { const p = pk.people.find((q) => q.pid === x.go.pid); out.go = { pid: x.go.pid, label: p ? p.name : x.go.pid }; }
    else if (x.go.loc) out.go = { loc: x.go.loc, label: (pk.locations.find((l) => l.id === x.go.loc) || {}).name || x.go.loc };
    else if (x.go.tab) out.go = { tab: x.go.tab, label: x.go.label || "결론 쓰기" };
  }
  const c = x.progress && (K(s).pack.conditions || {})[x.progress];
  if (c && c.type === "count") out.progress = { have: c.flags.filter((f) => has(s, f)).length, need: c.min };
  return out;
}

function openLocationIds(s) {
  return K(s).pack.locations.filter((l) => l.start || has(s, `loc:${l.id}`)).map((l) => l.id);
}
const visiblePids = (s) => K(s).pack.people.filter((p) => allMet(s, p.visibleWhen)).map((p) => p.pid);
function visibleSpots(s) {
  const open = openLocationIds(s);
  return K(s).pack.spots.filter((sp) => open.includes(sp.locationId) && allMet(s, sp.requires));
}
function markSeen(s) {
  const here = s.locationId;
  const seen = (s.seenSpots[here] = s.seenSpots[here] || []);
  for (const sp of visibleSpots(s)) if (sp.locationId === here && !seen.includes(sp.id)) seen.push(sp.id);
}

function personLoc(s, p) {
  if (p.stance === "cooperative") {
    if (p.companion) return { locationId: s.locationId, present: true };
    const ok = s.locationId === p.location || s.place === "interrogation" || (p.talkAt || []).includes(s.locationId);
    return { locationId: p.location, present: ok };
  }
  if (has(s, `summoned:${p.pid}`)) return { locationId: "interrogation", present: s.place === "interrogation" };
  return { locationId: p.location, present: s.place === "scene" && s.locationId === p.location };
}
function stanceOf(s, p) {
  if (has(s, `confessed:${p.pid}`)) return "confessed";
  if (has(s, `admitted:${p.pid}`)) return "admitted";
  if (has(s, `summoned:${p.pid}`)) return "summoned";
  return p.stance;
}

// ── 플래그·이벤트
function addFlag(s, flag, events) {
  if (has(s, flag)) return false;
  s.flags.push(flag);
  if (flag.startsWith("heard:")) events.push({ kind: "statement_heard", statementId: flag.slice(6) });
  else if (flag.startsWith("confessed:")) events.push({ kind: "confession", pid: flag.slice(10) });
  else if (flag.startsWith("admitted:")) events.push({ kind: "admission", pid: flag.slice(9) });
  return true;
}
function chat(s, pid, from, text, extra = {}) {
  (s.chats[pid] = s.chats[pid] || []).push({ from, text, attachments: extra.attachments || [], ts: now(), ...(extra.source ? { source: extra.source } : {}) });
}
const getEvOpened = (s, id) => has(s, `ev:${id}`);
const isFound = (s, id) => s.discovered.includes(id);

function needStr(v, code, max) {
  if (typeof v !== "string" || !v.trim()) throw new GameError(code, "내용을 입력해 주십시오.");
  return v.trim().slice(0, max);
}
function checkAttachments(s, list) {
  if (list === undefined) return [];
  if (!Array.isArray(list)) throw new GameError("bad_attachments", "첨부 형식이 올바르지 않습니다.");
  const ids = [...new Set(list.map(String))].slice(0, 8);
  for (const id of ids) {
    if (!K(s).EVIDENCE[id]) throw new GameError("evidence_unknown", "알 수 없는 증거입니다.");
    if (!getEvOpened(s, id)) throw new GameError("evidence_not_opened", "열람하지 않은 증거는 첨부할 수 없습니다.");
  }
  return ids;
}

// ── 행동
function doTravel(s, a) {
  const id = a.locationId;
  if (!K(s).LOCS[id]) throw new GameError("location_unknown", "알 수 없는 장소입니다.");
  if (id !== "interrogation" && !openLocationIds(s).includes(id)) throw new GameError("location_locked", "아직 갈 수 없는 장소입니다.");
  s.place = id === "interrogation" ? "interrogation" : "scene";
  s.locationId = id;
  if (!s.visited.includes(id)) s.visited.push(id);
  markSeen(s);
}

function doInspect(s, a, events) {
  const sp = K(s).SPOTS[a.spotId];
  if (!sp) throw new GameError("spot_unknown", "알 수 없는 조사 지점입니다.");
  if (s.place !== "scene" || sp.locationId !== s.locationId || !allMet(s, sp.requires)) {
    throw new GameError("spot_unavailable", "지금은 조사할 수 없는 지점입니다.");
  }
  if (!s.spotsDone.includes(sp.id)) s.spotsDone.push(sp.id);
  if (!isFound(s, sp.reveals)) {
    s.discovered.push(sp.reveals);
    events.push({ kind: "evidence_found", evidenceId: sp.reveals, title: K(s).EVIDENCE[sp.reveals].title });
  }
  for (const g of sp.grants || []) addFlag(s, g, events);
}

function doOpen(s, a, events) {
  const id = a.evidenceId;
  if (!K(s).EVIDENCE[id] || !isFound(s, id)) throw new GameError("evidence_not_found", "아직 발견하지 못한 증거입니다.");
  if (getEvOpened(s, id)) return;
  s.flags.push(`ev:${id}`);
  pushTimeline(s, id);
  events.push({ kind: "evidence_opened", evidenceId: id });
}

// 이 판의 모델 호출 수·토큰·비용(결과 화면용). 비용은 API provider일 때만 잡힌다.
function meter(s, r) {
  if (!r || typeof r.latency_ms !== "number") return;
  const u = (s.usage = s.usage || { calls: 0, inTok: 0, outTok: 0, usd: 0, priced: true, ms: 0 });
  u.calls++;
  u.ms += r.latency_ms;
  const t = r.usage || {};
  u.inTok += (t.input_tokens || 0) + (t.cache_read_input_tokens || 0) + (t.cache_creation_input_tokens || 0);
  u.outTok += t.output_tokens || 0;
  if (typeof r.cost_usd === "number") u.usd += r.cost_usd;
  else u.priced = false;
}
function historyOf(s, pid) {
  return (s.chats[pid] || []).filter((m) => m.from !== "system").map((m) => ({ from: m.from, text: m.text }));
}

async function doTalk(s, a, deps, events) {
  const { pack, PEOPLE, EVIDENCE, leak } = K(s);
  const p = PEOPLE[a.pid];
  if (!p) throw new GameError("person_unknown", "알 수 없는 인물입니다.");
  if (!visiblePids(s).includes(p.pid)) throw new GameError("person_hidden", "아직 만날 수 없는 인물입니다.");
  const text = needStr(a.text, "empty_text", 600);
  const attachments = checkAttachments(s, a.attachments);
  const loc = personLoc(s, p);
  if (!loc.present) {
    const msg = p.stance === "refusing" && !has(s, `summoned:${p.pid}`) && s.place === "interrogation"
      ? "그 인물은 아직 출석하지 않았습니다. 판사에게 소환을 신청하십시오."
      : "그 인물은 지금 이 장소에 없습니다.";
    throw new GameError("not_present", msg);
  }
  const hist = historyOf(s, p.pid);
  chat(s, p.pid, "player", text, { attachments });

  // 거절 인물: 소환 전
  if (p.stance === "refusing" && !has(s, `summoned:${p.pid}`)) {
    const ref = pack.refusals[p.pid];
    addFlag(s, `met:${p.pid}`, events);
    for (const g of ref.grants) addFlag(s, g, events);
    chat(s, p.pid, "npc", ref.text, { source: "rule" });
    events.push({ kind: "refused", pid: p.pid });
    return;
  }

  if (s.place === "interrogation" && proofPids(s).includes(p.pid)) {
    const got = (s.presented[p.pid] = s.presented[p.pid] || []);
    for (const id of attachments) if (!got.includes(id)) got.push(id);
  }
  // 대화에 첨부해 그 인물에게 내민 증거는 shown:<pid>:<증거> 플래그로 남긴다(count·any 조건에서 쓴다).
  for (const id of attachments) addFlag(s, `shown:${p.pid}:${id}`, events);
  for (const id of attachments) logContact(s, "present", id, p.pid, true);

  const candidates = pack.nodes.filter((n) => n.pid === p.pid && (n.place === "any" || n.place === s.place));
  const attachmentTitles = attachments.map((id) => EVIDENCE[id].title);
  let cls = null;
  if (deps && deps.evaluate) {
    try {
      cls = await deps.evaluate({ pid: p.pid, personName: p.name, text, attachmentTitles, history: hist, candidates: candidates.map((n) => ({ id: n.id, topic: n.topic })) });
    } catch {
      cls = null;
    }
  }
  meter(s, cls); // 실패한 호출도 호출 수·비용에 넣는다(규칙으로 바꾸기 전에)
  if (!cls || !cls.ok) cls = D.ruleClassify(candidates, text);
  const intent = cls.intent === "accuse" || D.ACCUSE_RE.test(text) ? "accuse" : cls.intent;
  // 36번: 말투 → 신뢰·압박. 판정기가 tone을 주지 않으면 규칙으로 채운다. 추궁 의도면 말투도 추궁으로 본다.
  let tone = cls.tone || D.ruleTone(text);
  if (intent === "accuse" && (tone === "neutral" || tone === "polite")) tone = "accusatory";
  const affect = applyAffect(s, p, { tone, intent, attachments, promise: D.PROMISE_RE.test(text) }, events);
  const lastPlayer = s.chats[p.pid][s.chats[p.pid].length - 1];
  lastPlayer.tone = tone;
  if (affect) lastPlayer.meter = { before: affect.before, after: affect.after, rules: affect.rules };

  const matched = candidates.filter((n) => cls.matched.includes(n.id));
  let reveal = matched.filter((n) => !has(s, `k:${n.id}`) && allMet(s, n.requires) && (!n.accuse || intent === "accuse") && (!n.calm || intent !== "accuse"));
  // 자백 노드가 열리는 턴에는 부분 인정 등 다른 추궁 노드를 함께 열지 않는다(대사가 "부인"으로 섞이는 문제 방지).
  if (reveal.some((n) => n.grants.some((g) => g.startsWith("confessed:")))) {
    reveal = reveal.filter((n) => !n.accuse || n.grants.some((g) => g.startsWith("confessed:")));
  }
  const matchedKnown = matched.filter((n) => has(s, `k:${n.id}`));
  const known = pack.nodes.filter((n) => n.pid === p.pid && has(s, `k:${n.id}`));

  const statements = pack.statements.filter((x) => x.speaker === p.pid && has(s, `heard:${x.id}`)).map((x) => x.text);
  const ctx = {
    setting: pack.setting || pack.title,
    pid: p.pid,
    personName: p.name,
    role: p.role,
    profile: { voice: p.profile.voice || "", look: p.profile.look || "" },
    lines: p.lines || {},
    text,
    intent,
    history: hist,
    attachmentTitles,
    knownTexts: known.map((n) => n.text),
    revealTexts: reveal.map((n) => n.text),
    matchedKnownTexts: matchedKnown.map((n) => n.text),
    // 36번: 같은 사실을 그 인물 말투로 쓴 정본 대사(없으면 사실 문장). 규칙 대체와 모델 말투 예시에 쓴다.
    revealSays: reveal.map((n) => n.say || n.text),
    matchedKnownSays: matchedKnown.map((n) => n.say || n.text),
    statements,
    fallbackLine: (p.lines && p.lines.unknown) || D.DEFAULT_LINES.unknown,
    // 사건 팩이 주는 인물 지침(신념·회피 방식·행동 단서 등)과 공통 가드레일. 잠긴 사실은 들어 있지 않다.
    guide: typeof p.guide === "function" ? p.guide((f) => has(s, f)) : p.guide || [],
    mood: moodOf(meterOf(s, p.pid)),
    rules: pack.guardrailRules || [],
  };
  const progress = deps && typeof deps.progress === "function" ? deps.progress : null;
  if (progress && reveal.length) {
    const unlocks = reveal.flatMap((n) => n.grants).filter((g) => g.startsWith("loc:")).map((g) => (pack.locations.find((l) => l.id === g.slice(4)) || {}).name || g.slice(4));
    progress({ phase: "judged", pid: p.pid, clues: reveal.filter((n) => !n.deduction).length, deductions: reveal.filter((n) => n.deduction).length, unlocks });
  }
  const canonical = D.canonicalReply(ctx);
  let reply = canonical;
  let source = "rule";
  if (!(intent === "meta" && !reveal.length) && deps && deps.speak) {
    const allowed = [ctx.profile.voice, ctx.profile.look, ...ctx.knownTexts, ...ctx.revealTexts, ...ctx.revealSays, ...known.map((n) => n.say || ""), ...statements, ...attachmentTitles];
    // 스트리밍: 문장이 끝날 때마다 '지금까지 전체'를 누설 검사하고, 통과한 앞부분만 화면에 보낸다.
    // 한 번이라도 걸리면 더 보내지 않고, 최종 검사에서 걸리면 정본 대사로 바꾼다(화면도 최종 상태로 덮어쓴다).
    let sent = 0, blocked = false;
    const onText = progress ? (acc) => {
      if (blocked) return;
      let cut = -1;
      const re = /[.!?。…]["”’」』)]?(\s|$)|\n/g;
      let m;
      while ((m = re.exec(acc))) cut = m.index + m[0].length;
      if (cut <= 0) return;
      let part = acc.slice(0, cut).trim();
      if ((part.match(/\*/g) || []).length % 2) part = part.slice(0, part.lastIndexOf("*")).trim(); // 닫히지 않은 *지문*
      if (part.length <= sent) return;
      if (!leak(part, allowed, p.pid).ok) { blocked = true; return; }
      sent = part.length;
      progress({ phase: "text", pid: p.pid, text: part });
    } : undefined;
    let r = null;
    try {
      r = await deps.speak(ctx, onText);
    } catch {
      r = null;
    }
    meter(s, r);
    if (r && r.ok && r.text) {
      if (leak(r.text, allowed, p.pid).ok) {
        reply = r.text;
        source = "model";
      }
    }
  }
  const ts = now();
  for (const n of reveal) {
    addFlag(s, `k:${n.id}`, events);
    for (const g of n.grants) addFlag(s, g, events);
    s.knowledge.push({ pid: p.pid, nodeId: n.id, text: n.text, ts });
    events.push({ kind: "knowledge", pid: p.pid, nodeId: n.id, text: n.text, deduction: !!n.deduction });
  }
  chat(s, p.pid, "npc", reply, { source });
}

function doObject(s, a, events) {
  const { pack, STATEMENTS, EVIDENCE, PEOPLE } = K(s);
  const st = STATEMENTS[a.statementId];
  if (!st) throw new GameError("statement_unknown", "알 수 없는 진술입니다.");
  if (!has(s, `heard:${st.id}`)) throw new GameError("statement_not_heard", "아직 확보하지 못한 진술입니다.");
  const evId = a.evidenceId;
  if (!EVIDENCE[evId]) throw new GameError("evidence_unknown", "알 수 없는 증거입니다.");
  if (!getEvOpened(s, evId)) throw new GameError("evidence_not_opened", "열람하지 않은 증거는 제시할 수 없습니다.");
  const rule = pack.objections.find((o) => o.statement === st.id && o.evidence.includes(evId));
  const speaker = st.speaker;
  if (!rule) {
    chat(s, speaker, "system", "그 증거로는 이 진술을 반박할 수 없습니다.");
    events.push({ kind: "objection", statementId: st.id, evidenceId: evId, success: false });
    return;
  }
  if (s.objections.some((o) => o.statementId === st.id && o.evidenceId === evId)) return; // 같은 짝 반복은 무시
  s.objections.push({ statementId: st.id, evidenceId: evId, crack: rule.crack });
  (s.brokenBy[st.id] = s.brokenBy[st.id] || []).push(evId);
  (s.stmtNotes[st.id] = s.stmtNotes[st.id] || []).push(rule.note);
  addFlag(s, `broken:${st.id}`, events);
  addFlag(s, `crack:${rule.crack}`, events);
  events.push({ kind: "objection", statementId: st.id, evidenceId: evId, success: true, note: rule.note });
  const p = PEOPLE[speaker];
  if (p && s.place === "interrogation" && personLoc(s, p).present) {
    const line = (p.cracks || {})[rule.crack];
    if (line) chat(s, speaker, "npc", line, { source: "rule" });
  }
}

// ── 접촉 기록: 증거→인물(talk 첨부), 증거↔증거(combine), 인물↔인물(confront)을 모두 남긴다. 누가 무엇을 언제 맞댔는지가 분석 데이터다.
function logContact(s, kind, a, b, ok, ref) {
  (s.contacts = s.contacts || []).push({ kind, a, b, ok: !!ok, ref: ref || null, ts: now() });
  if (s.contacts.length > 400) s.contacts.shift();
}
const pairKey = (x, y) => [x, y].sort().join("+");

function doCombine(s, a, events) {
  const { pack, EVIDENCE } = K(s);
  const x = String(a.a || ""), y = String(a.b || "");
  if (!EVIDENCE[x] || !EVIDENCE[y]) throw new GameError("evidence_unknown", "알 수 없는 증거입니다.");
  if (x === y) throw new GameError("same_evidence", "서로 다른 두 증거를 맞대십시오.");
  if (!getEvOpened(s, x) || !getEvOpened(s, y)) throw new GameError("evidence_not_opened", "열람한 증거끼리만 맞댈 수 있습니다.");
  const key = pairKey(x, y);
  const rule = (pack.combos || []).find((c) => pairKey(c.a, c.b) === key);
  s.insights = s.insights || [];
  if (!rule) {
    logContact(s, "combine", x, y, false);
    events.push({ kind: "combo", success: false, a: x, b: y });
    return;
  }
  const fresh = !s.insights.some((i) => i.id === rule.id);
  logContact(s, "combine", x, y, true, rule.id);
  if (fresh) {
    s.insights.push({ id: rule.id, kind: "combine", a: rule.a, b: rule.b, ts: now() });
    addFlag(s, `cmb:${rule.id}`, events);
  }
  events.push({ kind: "combo", success: true, id: rule.id, fresh, a: x, b: y });
}

function doConfront(s, a, events) {
  const { pack, PEOPLE, STATEMENTS } = K(s);
  const x = String(a.a || ""), y = String(a.b || "");
  if (!PEOPLE[x] || !PEOPLE[y]) throw new GameError("person_unknown", "알 수 없는 인물입니다.");
  if (x === y) throw new GameError("same_person", "서로 다른 두 인물을 맞대십시오.");
  const vis = visiblePids(s);
  if (!vis.includes(x) || !vis.includes(y)) throw new GameError("person_hidden", "아직 만날 수 없는 인물입니다.");
  const key = pairKey(x, y);
  const rule = (pack.confronts || []).find((c) => pairKey(c.a, c.b) === key);
  s.insights = s.insights || [];
  if (!rule) {
    logContact(s, "confront", x, y, false);
    events.push({ kind: "confront", success: false, a: x, b: y, reason: "none" });
    return;
  }
  if (!allMet(s, rule.requires)) {
    // 맞댈 거리는 있지만 아직 한쪽(또는 양쪽)의 말을 듣지 못했다
    logContact(s, "confront", x, y, false, rule.id);
    events.push({ kind: "confront", success: false, a: x, b: y, reason: "unheard" });
    return;
  }
  const fresh = !s.insights.some((i) => i.id === rule.id);
  logContact(s, "confront", x, y, true, rule.id);
  if (fresh) {
    s.insights.push({ id: rule.id, kind: "confront", a: rule.a, b: rule.b, ts: now() });
    addFlag(s, `cf:${rule.id}`, events);
    const br = rule.breaks;
    if (br && STATEMENTS[br.statement] && has(s, `heard:${br.statement}`) && !has(s, `broken:${br.statement}`)) {
      s.objections.push({ statementId: br.statement, evidenceId: `CF:${rule.id}`, crack: br.crack });
      (s.brokenBy[br.statement] = s.brokenBy[br.statement] || []).push(`CF:${rule.id}`);
      (s.stmtNotes[br.statement] = s.stmtNotes[br.statement] || []).push(`대질: ${rule.note}`);
      addFlag(s, `broken:${br.statement}`, events);
      addFlag(s, `crack:${br.crack}`, events);
      events.push({ kind: "objection", statementId: br.statement, evidenceId: null, success: true, note: rule.note, via: "confront" });
    }
  }
  events.push({ kind: "confront", success: true, id: rule.id, fresh, a: x, b: y });
}

function doSummon(s, a, events) {
  const { pack, PEOPLE } = K(s);
  const p = PEOPLE[a.pid];
  const rule = pack.summons[a.pid];
  if (!p || !rule) throw new GameError("summon_invalid", "소환할 수 없는 인물입니다.");
  if (s.place !== "interrogation") throw new GameError("not_in_interrogation", "소환 신청은 심문실에서만 할 수 있습니다.");
  if (!visiblePids(s).includes(p.pid)) throw new GameError("person_hidden", "아직 만날 수 없는 인물입니다.");
  if (has(s, `summoned:${p.pid}`)) throw new GameError("already_summoned", "이미 출석한 인물입니다.");
  const ids = checkAttachments(s, a.evidenceIds || []);
  let ok = true;
  let reason = rule.approve;
  if (rule.needMet && !has(s, `met:${p.pid}`)) {
    ok = false;
    reason = "먼저 현장에서 면담을 시도해 거절 여부를 확인하십시오";
  } else {
    const groupsOk = rule.groups.every((g) => g.ids.some((id) => ids.includes(id)));
    const altOk = (rule.altFlags || []).some((f) => has(s, f));
    if (!(groupsOk || altOk) || !allMet(s, rule.requires)) {
      ok = false;
      reason = rule.deny;
    }
  }
  s.judge.push({ pid: p.pid, verdict: ok ? "approved" : "denied", reason, evidenceIds: ids, ts: now() });
  events.push({ kind: "judge", pid: p.pid, verdict: ok ? "approved" : "denied", reason });
  if (ok) {
    addFlag(s, `summoned:${p.pid}`, events);
    chat(s, p.pid, "system", rule.arrive || "판사 승인으로 심문실에 출석했습니다");
    events.push({ kind: "person_appeared", pid: p.pid, name: p.name });
  }
}

function doNote(s, a) {
  if (typeof a.text !== "string") throw new GameError("bad_text", "메모 형식이 올바르지 않습니다.");
  s.notes = a.text.slice(0, 2000);
}

function doSubmit(s, a, events) {
  const { pack, EVIDENCE } = K(s);
  if (s.submitted) throw new GameError("already_submitted", "결론은 첫 제출만 유효합니다. 이미 제출했습니다.", 409);
  const culprit = String(a.culprit || "");
  const allowed = new Set([...pack.suspects.map((x) => x.pid), ...pack.people.map((p) => p.pid)]);
  if (!allowed.has(culprit)) throw new GameError("culprit_unknown", "범인으로 지목할 인물을 선택해 주십시오.");
  const field = { method: typeof a.method === "string" ? a.method.slice(0, 1000) : "", motive: typeof a.motive === "string" ? a.motive.slice(0, 1000) : "", reasoning: typeof a.reasoning === "string" ? a.reasoning.slice(0, 3000) : "" };
  field.all = `${field.method}\n${field.motive}\n${field.reasoning}`;
  const sc = pack.scoring;
  const pick = (list, max) => {
    const ids = [...new Set((Array.isArray(list) ? list : []).map(String))].filter((id) => EVIDENCE[id] && getEvOpened(s, id));
    return max ? ids.slice(0, max) : ids;
  };
  const evIds = pick(a.evidenceIds, sc.evidence.max);
  const breakdown = [];
  breakdown.push({ label: sc.culprit.label || "범인 지목", got: sc.culprit.pids.includes(culprit) ? sc.culprit.points : 0, max: sc.culprit.points });
  if (sc.confession) {
    const got = sc.culprit.pids.includes(culprit) && has(s, `confessed:${culprit}`);
    breakdown.push({ label: sc.confession.label || "자백 확보", got: got ? sc.confession.points : 0, max: sc.confession.points });
  }
  for (const it of sc.items) {
    const said = it.re.test(field[it.field] || "");
    const backed = !it.needs || it.needs.some((f) => has(s, f)); // needs가 있으면 그중 하나는 확인한 적이 있어야 한다
    breakdown.push({ label: said && !backed ? `${it.label} (화면에서 확인한 근거 없음)` : it.label, got: said && backed ? it.points : 0, max: it.points });
  }
  for (const g of sc.evidence.groups) {
    breakdown.push({ label: `근거 증거 - ${g.label}`, got: g.ids.some((id) => evIds.includes(id)) ? sc.evidence.perGroup : 0, max: sc.evidence.perGroup });
  }
  // 다른 용의자 배제(사건 팩에 있을 때만): 용의자마다 고른 증거가 각 근거 묶음을 하나씩 짚어야 한다.
  const exInput = {};
  if (sc.exclusions) {
    const given = a.exclusions && typeof a.exclusions === "object" ? a.exclusions : {};
    for (const x of sc.exclusions.suspects) {
      const ids = x.pid === culprit ? [] : pick(given[x.pid], sc.exclusions.max);
      exInput[x.pid] = ids;
      for (const g of x.groups) breakdown.push({ label: `배제 - ${x.name}: ${g.label}`, got: g.ids.some((id) => ids.includes(id)) ? sc.exclusions.perGroup : 0, max: sc.exclusions.perGroup });
    }
  }
  const score = breakdown.reduce((n, b) => n + b.got, 0);
  const max = breakdown.reduce((n, b) => n + b.max, 0);
  s.submitted = {
    score,
    max,
    breakdown,
    // notes(증거별 해석·한계)·exclusions(용의자 배제 근거)는 사건 팩에 있을 때만 싣는다
    answer: { summary: pack.answer.summary, culpritName: pack.answer.culpritName, timeline: pack.answer.timeline, notes: pack.answer.notes || [], exclusions: pack.answer.exclusions || [] },
    submittedAt: now(),
    input: { culprit, method: field.method, motive: field.motive, reasoning: field.reasoning, evidenceIds: evIds, exclusions: exInput },
  };
  events.push({ kind: "submitted", score });
}

async function runAction(s, a, deps) {
  const events = [];
  const beforeLocs = openLocationIds(s);
  const beforeVis = visiblePids(s);
  switch (a.type) {
    case "travel": doTravel(s, a); break;
    case "inspect": doInspect(s, a, events); break;
    case "open": doOpen(s, a, events); break;
    case "talk": await doTalk(s, a, deps, events); break;
    case "object": doObject(s, a, events); break;
    case "summon": doSummon(s, a, events); break;
    case "combine": doCombine(s, a, events); break;
    case "confront": doConfront(s, a, events); break;
    case "note": doNote(s, a); break;
    case "submit": doSubmit(s, a, events); break;
    default: throw new GameError("unknown_action", "알 수 없는 행동입니다.");
  }
  const { LOCS, PEOPLE } = K(s);
  for (const id of openLocationIds(s)) {
    if (!beforeLocs.includes(id)) events.push({ kind: "location_unlocked", locationId: id, name: LOCS[id].name });
  }
  for (const pid of visiblePids(s)) {
    if (!beforeVis.includes(pid)) events.push({ kind: "person_appeared", pid, name: PEOPLE[pid].name });
  }
  markSeen(s);
  return events;
}

const queues = new Map();
function applyAction(session, action, deps = {}) {
  const key = session.id;
  const prev = queues.get(key) || Promise.resolve();
  const run = prev.then(() => doApply(session, action || {}, deps));
  const tail = run.catch(() => {});
  queues.set(key, tail);
  tail.then(() => {
    if (queues.get(key) === tail) queues.delete(key);
  });
  return run;
}

async function doApply(session, action, deps) {
  if (!session.caseId) session.caseId = DEFAULT_CASE; // 버전 1 저장본 호환
  if (!PACKS[session.caseId]) throw new GameError("case_unknown", "이 저장본의 사건을 찾을 수 없습니다.");
  if (action.hintsOn === true && !session.submitted) session.assisted = true; // 실마리·추천을 켠 채 한 행동이 하나라도 있으면 '도움 받음'
  if (action.type === "reset") {
    const fresh = createSession(action.caseId && PACKS[action.caseId] ? action.caseId : session.caseId);
    fresh.id = session.id;
    for (const k of Object.keys(session)) delete session[k];
    Object.assign(session, fresh);
    return { events: [] };
  }
  const clone = structuredClone(session);
  clone.pending = false;
  session.pending = true;
  try {
    const events = await runAction(clone, action, deps);
    for (const k of Object.keys(session)) delete session[k];
    Object.assign(session, clone);
    return { events };
  } finally {
    session.pending = false;
  }
}

// 지도: 잠긴 장소는 이름·id 없이 좌표만(안개), 길은 좌표 선분으로만 보낸다.
function mapView(pack, open) {
  const L = Object.fromEntries(pack.locations.map((l) => [l.id, l]));
  return {
    zones: pack.map.zones || {},
    decor: pack.map.decor || [],
    fog: pack.locations.filter((l) => l.kind !== "interrogation" && !open.includes(l.id)).map((l) => ({ x: l.x, y: l.y })),
    roads: (pack.map.edges || []).filter(([a, b]) => L[a] && L[b]).map(([a, b, dashed]) => ({
      x1: L[a].x, y1: L[a].y, x2: L[b].x, y2: L[b].y, dashed: !!dashed, open: open.includes(a) && open.includes(b),
    })),
  };
}

// 접촉으로 얻은 착안·대질: 얻은 것만 본문을 싣는다(얻지 않은 규칙은 개수도 보내지 않는다).
function insightsView(s) {
  const { pack, EVIDENCE, PEOPLE } = K(s);
  return (s.insights || []).map((i) => {
    if (i.kind === "combine") {
      const r = (pack.combos || []).find((c) => c.id === i.id);
      if (!r) return null;
      return { id: r.id, kind: "combine", a: r.a, b: r.b, aTitle: EVIDENCE[r.a].title, bTitle: EVIDENCE[r.b].title, title: r.title, text: r.text, ask: r.ask, talkTo: r.talkTo || null, ts: i.ts };
    }
    const r = (pack.confronts || []).find((c) => c.id === i.id);
    if (!r) return null;
    return { id: r.id, kind: "confront", a: r.a, b: r.b, aTitle: PEOPLE[r.a].name, bTitle: PEOPLE[r.b].name, title: r.title, note: r.note,
      lines: r.lines.map(([pid, text]) => ({ pid, name: PEOPLE[pid].name, text })), breaks: r.breaks ? r.breaks.statement : null, ts: i.ts };
  }).filter(Boolean);
}
function contactStats(s) {
  const list = s.contacts || [];
  const by = (k) => list.filter((c) => c.kind === k);
  const pack = (k) => ({ tries: by(k).length, hits: by(k).filter((c) => c.ok).length });
  return { present: pack("present"), combine: pack("combine"), confront: pack("confront"), recent: list.slice(-12).map((c) => ({ ...c })) };
}

// ── 공개 상태 (잠긴 정보 없음)
function publicState(s) {
  if (!s.caseId) s.caseId = DEFAULT_CASE;
  const { pack, PEOPLE } = K(s);
  const artBase = (pack.art && pack.art.base) || "/art/";
  const open = openLocationIds(s);
  const vis = visiblePids(s);
  const spots = visibleSpots(s);
  const locations = pack.locations.filter((l) => open.includes(l.id)).map((l) => ({
    id: l.id,
    name: l.name,
    kind: l.kind,
    x: l.x,
    y: l.y,
    shape: l.shape || null,
    unlocked: true,
    current: s.locationId === l.id,
    hasNew: !l.start && s.locationId !== l.id && !s.visited.includes(l.id),
    hints: hintsFor(s, l.hints).slice(0, 2),
    art: l.art ? `${artBase}${l.art}.png` : null,
  }));
  const people = vis.map((pid) => {
    const p = PEOPLE[pid];
    const loc = personLoc(s, p);
    const entry = {
      pid,
      name: p.name,
      role: p.role,
      stance: stanceOf(s, p),
      locationId: loc.locationId,
      present: loc.present,
      canTalk: loc.present,
      portrait: p.portrait ? `${artBase}${p.portrait}` : null,
      initials: p.name.trim()[0],
      // 추천 질문: 진행도에 맞는 것 최대 3개. fill이면 보내지 않고 입력창에 채워 플레이어가 끝맺게 한다.
      prompts: ((pack.prompts || {})[pid] || []).filter((x) => hintLive(s, x)).slice(0, 3).map((x) => ({ q: x.q, fill: !!x.fill })),
      where: loc.present ? null : whereToMeet(pack, p, s),
      // 수사 노트: 들은 이야기 수, 지금 조건으로 더 물어볼 거리 수(주제는 보내지 않는다)
      heard: pack.nodes.filter((n) => n.pid === pid && !n.deduction && has(s, `k:${n.id}`)).length,
      topicsLeft: p.stance === "refusing" && !has(s, `summoned:${pid}`) ? null : pack.nodes.filter((n) => n.pid === pid && !n.deduction && !n.accuse && !has(s, `k:${n.id}`) && allMet(s, n.requires)).length,
      // 36번: 신뢰·압박(만난 뒤에만 보인다)
      meters: (s.chats[pid] || []).some((m) => m.from === "player") && meterOf(s, pid) ? { ...meterOf(s, pid) } : null,
    };
    if (p.stance === "refusing" && !has(s, `summoned:${pid}`) && has(s, `met:${pid}`)) entry.refusal = pack.refusals[pid].text;
    return entry;
  });
  const chats = {};
  for (const pid of vis) chats[pid] = (s.chats[pid] || []).map((m) => ({ ...m }));
  const statements = pack.statements.filter((x) => has(s, `heard:${x.id}`)).map((x) => ({
    id: x.id,
    speaker: x.speaker,
    speakerName: x.speakerName,
    text: x.text,
    status: has(s, `broken:${x.id}`) ? "broken" : "standing",
    brokenBy: [...(s.brokenBy[x.id] || [])],
    notes: [...(s.stmtNotes[x.id] || [])],
  }));
  const evidence = s.discovered.map((id) => {
    const e = K(s).EVIDENCE[id];
    const opened = getEvOpened(s, id);
    const o = { id, title: e.title, typeKo: e.typeKo, where: e.where, opened };
    if (opened) { o.text = e.text; o.look = e.look || null; o.use = e.use || null; o.type = e.type || null; }
    return o;
  });
  return {
    version: 2,
    caseId: pack.id,
    title: pack.title,
    source: pack.source || "",
    sessionId: s.id,
    place: s.place,
    locationId: s.locationId,
    brief: pack.brief,
    map: mapView(pack, open),
    locations,
    lead: s.submitted ? null : leadOf(s),
    assisted: !!s.assisted,
    usage: s.usage || { calls: 0, inTok: 0, outTok: 0, usd: 0, priced: true, ms: 0 },
    roomHints: hintsFor(s, pack.roomHints).slice(0, 2),
    spots: spots.map((sp) => ({ id: sp.id, locationId: sp.locationId, label: sp.label, done: s.spotsDone.includes(sp.id) })),
    evidence,
    statements,
    people,
    suspects: pack.suspects.map((x) => ({ ...x })),
    culpritQuestion: pack.scoring.culprit.label || "범인 지목",
    // 결론 양식 정보. 배제 대상이 누구인지는 보내지 않는다(범인이 드러나므로): 화면은 고른 범인을 뺀 후보 전원에게 배제 칸을 낸다.
    form: { evidenceMax: pack.scoring.evidence.max || 0, exclusionMax: pack.scoring.exclusions ? pack.scoring.exclusions.max : 0, confessionPoints: pack.scoring.confession ? pack.scoring.confession.points : 0 },
    chats,
    knowledge: s.knowledge.map((k) => ({ ...k })),
    judge: s.judge.map((j) => ({ ...j })),
    timeline: s.timeline.map((t) => ({ ...t })),
    insights: insightsView(s),
    contactStats: contactStats(s),
    notes: s.notes,
    pending: !!s.pending,
    submitted: s.submitted ? { score: s.submitted.score, max: s.submitted.max, breakdown: s.submitted.breakdown, answer: s.submitted.answer, submittedAt: s.submitted.submittedAt } : null,
    stats: {
      evidenceFound: s.discovered.length,
      evidenceTotal: pack.evidence.length,
      statementsBroken: statements.filter((x) => x.status === "broken").length,
      statementsTotal: pack.statements.length,
      deductions: pack.nodes.filter((n) => n.deduction && has(s, `k:${n.id}`)).length,
      deductionsTotal: pack.nodes.filter((n) => n.deduction).length,
      startedAt: s.createdAt,
    },
  };
}

module.exports = { createSession, applyAction, publicState, listCases, GameError, PACKS };
