// 36번: 신뢰·압박 계기판(키트 state_model)이 해금 조건에 실제로 쓰이는지. 규칙 모드(모델 없음)로 돌린다.
process.env.ABBEY_CASES = "boscombe";
const test = require("node:test");
const assert = require("node:assert/strict");
const E = require("../engine.cjs");

const deps = { evaluate: async () => ({ ok: false }), speak: async () => ({ ok: false }) };
const talk = (s, pid, text, attachments = []) => E.applyAction(s, { type: "talk", pid, text, attachments }, deps);
const known = (s, id) => s.flags.includes(`k:${id}`);
async function atPrison() {
  const s = E.createSession("boscombe");
  await talk(s, "P6", "제임스를 직접 만나고 싶습니다. 감옥 면회 허가가 있습니까?");
  await E.applyAction(s, { type: "travel", locationId: "prison" }, deps);
  return s;
}

test("초기값은 키트 initial_state, 공개 상태에는 만난 뒤에만 보인다", async () => {
  const s = E.createSession("boscombe");
  let p3 = E.publicState(s).people.find((p) => p.pid === "P3");
  assert.equal(p3.meters, null);
  await talk(s, "P3", "와 주셔서 감사합니다. 제임스는 어떤 사람입니까?");
  p3 = E.publicState(s).people.find((p) => p.pid === "P3");
  assert.deepEqual(p3.meters, { trust: 62, pressure: 20 }); // 60 + 정중함 2
});

test("앨리스를 증거 없이 몰아세우면 신뢰가 떨어져 빅토리아 시절 이야기(A_T2)가 닫히고, 위로하면 다시 열린다", async () => {
  const s = E.createSession("boscombe");
  await talk(s, "P3", "당신이 거짓말을 하고 있잖아요. 숨기지 말고 사실대로 말하세요.");
  assert.ok(E.publicState(s).people.find((p) => p.pid === "P3").meters.trust < 60);
  await talk(s, "P3", "아버님과 매카시 씨는 어떤 사이였나요? 옛날 호주 시절은요?");
  assert.ok(!known(s, "A_T2"), "신뢰 60 미만인데 A_T2가 열림");
  for (let i = 0; i < 2; i++) await talk(s, "P3", "괜찮아요, 걱정 마세요. 천천히 말씀하셔도 됩니다."); // 50 → 62
  await talk(s, "P3", "아버님과 매카시 씨는 어떤 사이였나요? 옛날 호주 시절은요?");
  assert.ok(known(s, "A_T2"), "위로로 신뢰를 되찾았는데 A_T2가 안 열림");
});

test("제임스: 비밀 보장 약속이 없고 신뢰도 낮으면 브리스톨 비밀(J_T2)을 말하지 않는다", async () => {
  const s2 = await atPrison();
  // 앨리스 전언 없이 신뢰 경로로 J_T1: 위로 3번(30 → 48)
  for (let i = 0; i < 3; i++) await talk(s2, "P1", "괜찮습니다. 걱정 마시고 천천히 말씀하세요.");
  await talk(s2, "P1", "아버지와 다툰 이유가 뭐였습니까?");
  assert.ok(known(s2, "J_T1"), "신뢰 45 이상인데 J_T1이 안 열림(키트의 신뢰 갈래)");
  await talk(s2, "P1", "브리스톨에서 사흘 동안 누구와 있었습니까?");
  assert.ok(!known(s2, "J_T2"), "약속도 신뢰 65도 없는데 J_T2가 열림");
  await talk(s2, "P1", "브리스톨에서 사흘 동안 누구와 있었습니까? 비밀은 꼭 지키겠습니다.");
  assert.ok(known(s2, "J_T2"), "비밀 보장 약속 뒤에도 J_T2가 안 열림");
  assert.ok(s2.flags.includes("promise:P1"));
});

test("페이션스: 겁을 주어 압박이 50을 넘으면 그 뒤의 일(P_T1)을 말하지 않는다", async () => {
  const s = E.createSession("boscombe");
  await E.applyAction(s, { type: "travel", locationId: "lodge" }, deps);
  await talk(s, "P4", "그날 숲 가장자리에서 무엇을 봤니?");
  assert.ok(known(s, "P_see"));
  for (let i = 0; i < 2; i++) await talk(s, "P4", "바른대로 말 안 하면 교수형감이야, 각오해.");
  const v = E.publicState(s).people.find((p) => p.pid === "P4").meters;
  assert.ok(v.pressure > 50, `압박 ${v.pressure}`);
  await talk(s, "P4", "괜찮아, 천천히 말해도 돼. 도망친 뒤에는 어떻게 됐니?");
  assert.ok(!known(s, "P_T1"), "압박이 50을 넘었는데 P_T1이 열림");
});

test("계기판 기록(meterLog)에 말투·적용 규칙·전후 값이 남는다", async () => {
  const s = E.createSession("boscombe");
  await talk(s, "P6", "사건 개요를 알려 주시겠습니까?");
  const rec = s.meterLog.at(-1);
  assert.equal(rec.pid, "P6");
  assert.equal(rec.tone, "polite");
  assert.deepEqual(rec.rules, ["tone:polite"]);
  assert.equal(rec.after.trust, rec.before.trust + 2);
});
