// 모든 사건 팩: 정적 점검(check-pack) + golden.json 정답 경로를 규칙 모드로 끝까지 재생.
process.env.ABBEY_CASES = "all"; // 모든 사건 팩 점검·재생
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const E = require("../engine.cjs");
const { checkPack } = require("../scripts/check-pack.cjs");

const deps = { evaluate: async () => ({ ok: false }), speak: async () => ({ ok: false }) };
const casesDir = path.join(__dirname, "..", "cases");

for (const id of fs.readdirSync(casesDir)) {
  const packFile = path.join(casesDir, id, "pack.cjs");
  if (!fs.existsSync(packFile)) continue;
  test(`[${id}] 사건 팩 정적 점검`, () => {
    const r = checkPack(require(packFile));
    assert.deepEqual(r.errs, []);
  });
  const goldenFile = path.join(casesDir, id, "golden.json");
  if (!fs.existsSync(goldenFile)) continue;
  test(`[${id}] 정답 경로 재생 → 자백·만점`, async () => {
    const golden = JSON.parse(fs.readFileSync(goldenFile, "utf8"));
    const s = E.createSession(id);
    for (const [i, a] of golden.actions.entries()) {
      try {
        await E.applyAction(s, a, deps);
      } catch (e) {
        assert.fail(`${i}번째 행동 ${JSON.stringify(a)} 실패: ${e.code || ""} ${e.message}`);
      }
    }
    for (const pid of golden.expect.confessed || []) assert.ok(s.flags.includes(`confessed:${pid}`), `${pid} 자백 안 됨`);
    const st = E.publicState(s);
    assert.ok(st.submitted, "제출 안 됨");
    assert.equal(st.submitted.score, golden.expect.score, JSON.stringify(st.submitted.breakdown));
    // 공개 상태에 정답 해설이 제출 전에는 없어야 한다는 점은 engine.test에서 확인
  });
}

// 2026-11-17: 추천 멘트가 어디선 나오고 어디선 안 나오던 문제. 보스콤 정답 경로 내내 '다음 실마리'가 비지 않고,
// 처음 도착한 장소마다 안내가 한 줄 이상 있어야 한다.
test("[boscombe] 정답 경로 내내 다음 실마리·도착 장소 안내가 비지 않음", async () => {
  const golden = JSON.parse(fs.readFileSync(path.join(casesDir, "boscombe", "golden.json"), "utf8"));
  const s = E.createSession("boscombe");
  const leads = new Set();
  const noHint = [];
  for (const a of golden.actions) {
    if (a.type === "submit") break;
    await E.applyAction(s, a, deps);
    const st = E.publicState(s);
    assert.ok(st.lead && st.lead.text, `행동 ${JSON.stringify(a)} 뒤 다음 실마리가 비었음`);
    leads.add(st.lead.text);
    if (a.type === "travel" && a.locationId !== "interrogation") {
      const cur = st.locations.find((l) => l.current);
      if (!cur.hints.length) noHint.push(a.locationId);
    }
  }
  assert.deepEqual(noHint, []);
  assert.ok(leads.size >= 8, `실마리가 진행에 따라 바뀌어야 함(${leads.size}종)`);
});

// 2026-11-17: 대화창 추천 질문이 인물마다 들쭉날쭉하던 문제. 정답 경로에서 처음 말을 거는 순간 그 인물의 추천 질문이 있어야 한다.
test("[boscombe] 처음 말 거는 인물마다 추천 질문이 있음", async () => {
  const golden = JSON.parse(fs.readFileSync(path.join(casesDir, "boscombe", "golden.json"), "utf8"));
  const s = E.createSession("boscombe");
  const first = new Set();
  const missing = [];
  for (const a of golden.actions) {
    if (a.type === "submit") break;
    if (a.type === "talk" && !first.has(a.pid)) {
      first.add(a.pid);
      const p = E.publicState(s).people.find((x) => x.pid === a.pid);
      if (p.canTalk && !(p.prompts || []).length) missing.push(a.pid);
    }
    await E.applyAction(s, a, deps);
  }
  assert.deepEqual(missing, []);
  const st = E.publicState(s);
  assert.ok(st.people.find((x) => x.pid === "P2").prompts.length >= 1, "자백 뒤 터너 추천 질문(협박 내용) 없음");
});

// 2026-11-17: 스트리밍 계약. 판정 알림이 대사보다 먼저 오고, 흘려보낸 조각은 모두 최종 대사의 앞부분이며, 호출이 사용량에 잡힌다.
test("[boscombe] 스트리밍: judged → text 조각(최종 대사의 앞부분) → 사용량 기록", async () => {
  const s = E.createSession("boscombe");
  const seen = [];
  const reply = "마차는 준비해 뒀소. 따라오시오. 사실만 보시오.";
  const sdeps = {
    evaluate: async () => ({ ok: false, latency_ms: 5, usage: { input_tokens: 10, output_tokens: 2 }, cost_usd: 0.000002 }),
    speak: async (ctx, onText) => {
      for (let i = 1; i <= reply.length; i++) onText && onText(reply.slice(0, i));
      return { ok: true, text: reply, latency_ms: 7, usage: { input_tokens: 20, output_tokens: 8 }, cost_usd: 0.000006 };
    },
    progress: (o) => seen.push(o),
  };
  await E.applyAction(s, { type: "talk", pid: "P6", text: "현장을 보고 싶습니다. 연못으로 안내해 주시죠.", attachments: [] }, sdeps);
  assert.equal(seen[0].phase, "judged");
  assert.ok(seen[0].unlocks.length >= 1, "현장 안내는 장소 해금을 미리 알려야 함");
  const texts = seen.filter((o) => o.phase === "text").map((o) => o.text);
  assert.ok(texts.length >= 2, "문장 단위로 여러 번 흘려보내야 함");
  const st = E.publicState(s);
  const last = st.chats.P6[st.chats.P6.length - 1];
  for (const t of texts) assert.ok(last.text.startsWith(t), `조각이 최종 대사의 앞부분이 아님: ${t}`);
  assert.equal(st.usage.calls, 2);
  assert.ok(st.usage.usd > 0 && st.usage.priced);
});

// 2026-11-19(36번): 규칙 대체 대사가 '~이다' 메모체로 나가던 문제. 정답 경로의 모든 인물 답이 그 노드의 말투 대사(say)여야 하고,
// 말투 대사는 사실 문장의 숫자·고유명사를 빠뜨리지 않아야 한다(말투만 바꾸고 사실은 같게).
test("[boscombe] 규칙 모드 답은 인물 말투 대사이고, 사실 문장의 숫자·고유명사를 담는다", async () => {
  const pack = require(path.join(casesDir, "boscombe", "pack.cjs"));
  const lost = [];
  for (const n of pack.nodes.filter((x) => !x.deduction)) {
    assert.ok(n.say && n.say !== n.text, `${n.id} 말투 대사 없음`);
    const marks = (n.text.match(/\d+|'[^']+'|Cooee|BALLARAT|Ballarat|리젠트|버뮤다|윌로스|브리스톨|빅토리아|발라랏|멜버른|해덜리|헤리퍼드/g) || []);
    const ALIAS = { 14: "열네", 60: "예순" }; // 말투상 숫자를 우리말로 읽은 곳
    for (const m of marks) if (!n.say.includes(m.replace(/^'|'$/g, "").split(/[,(]/)[0]) && !(ALIAS[m] && n.say.includes(ALIAS[m]))) lost.push(`${n.id}: ${m}`);
  }
  assert.deepEqual(lost, []);
  const golden = JSON.parse(fs.readFileSync(path.join(casesDir, "boscombe", "golden.json"), "utf8"));
  const s = E.createSession("boscombe");
  const says = new Set(pack.nodes.map((n) => n.say).filter(Boolean));
  let voiced = 0;
  for (const a of golden.actions) {
    if (a.type === "submit") break;
    const before = (s.chats[a.pid] || []).length;
    await E.applyAction(s, a, deps);
    if (a.type !== "talk") continue;
    const msg = (s.chats[a.pid] || []).slice(before).find((m) => m.from === "npc");
    if (msg && [...says].some((x) => msg.text.includes(x.slice(0, 20)))) voiced++;
    assert.ok(!msg || !/[가-힣]다\.$/.test(msg.text) || /니다\.$|[소오요]\.$/.test(msg.text) || pack.nodes.some((n) => n.deduction && n.text === msg.text), `메모체 답: ${msg && msg.text.slice(0, 60)}`);
  }
  assert.ok(voiced >= 10, `말투 대사로 나간 답이 너무 적음(${voiced})`);
});
