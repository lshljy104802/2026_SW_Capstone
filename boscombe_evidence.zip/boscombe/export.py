"""게임·페르소나 파트 전달용 파일 만들기
  → handoff/boscombe_case.json : 게임에서 읽는 데이터(공개 증거 + 채점용 정답)
  → handoff/증거목록.md        : 사람이 읽는 증거 목록과 페르소나 ID 대응표
"""
import json

from solver import ROOT, judge, load
from validate import closure, minimal_set, valid_set

PERSONA_INV = {  # 페르소나 파트 조사 행동(INV_*) → 이 데이터의 증거
    "INV_COUNTY_PAPER": ["EV_SURGEON_REPORT"],
    "INV_HATHERLEY_BOOTS": ["EV_BOOTS_HATHERLEY"],
    "INV_POOL_GROUND": ["EV_TRACKS_POOL", "EV_TIPTOE_TRACKS"],
    "INV_BEECH_TREE": ["EV_BEECH_CIGAR", "EV_STONE_WEAPON"],
    "INV_WIRE_MAP": ["EV_VICTORIA_MAP"],
}
STAGE = {1: "사건 기록", 2: "현장 조사", 3: "추가 조사"}


def exclusion_basis(case, evidence, pid):
    """후보 pid를 배제하는 데 필요한 최소 증거"""
    ev_by = {e["id"]: e for e in evidence}
    ids = {e["id"] for e in evidence}
    for e in sorted(evidence, key=lambda x: (-x["stage"], x["id"])):
        t = ids - {e["id"]}
        if valid_set(ev_by, t) and judge(case, evidence, t)["후보"][pid]["배제"]:
            ids = t
    return sorted(ids, key=lambda i: (ev_by[i]["stage"], i))


def main():
    case, evidence = load("case_boscombe.json"), load("evidence_boscombe.json")["evidence"]
    names = {p["id"]: p["name"] for p in case["persons"]}
    culprit = case["truth"]["culprit"]
    final = judge(case, evidence, {e["id"] for e in evidence})
    ms = minimal_set(case, evidence)
    excl = {p: {"reason": "범인 특징과 어긋남: " + ", ".join(v["어긋난 특징"]), "evidence": exclusion_basis(case, evidence, p)}
            for p, v in final["후보"].items() if p != culprit}

    pub_fields = ["id", "stage", "type", "location", "object", "title", "text", "requires", "gate_flags"]
    out = {
        "case_id": case["case_id"], "title": case["title"], "source": case["source"],
        "persons": [{k: p[k] for k in ("id", "name", "role")} | {"suspect": p.get("suspect", False)} for p in case["persons"]],
        "locations": case["locations"],
        "stages": {str(k): v for k, v in STAGE.items()},
        "evidence": [{k: e[k] for k in pub_fields} for e in evidence],
        "answer": {  # 채점용(플레이어에게 보이지 않게)
            "culprit": culprit, "weapon": case["truth"]["weapon"], "motive": case["truth"]["motive"],
            "minimum_evidence": ms, "exclusions": excl,
            "evidence_notes": {e["id"]: {"proves": e["proves"], "limits": e["limits"]} for e in evidence},
        },
        "persona_alignment": {"same_ids": sorted(e["id"] for e in evidence if "같은 ID" in (e.get("persona_ref") or "")),
                              "investigations": PERSONA_INV,
                              "new_evidence": sorted(e["id"] for e in evidence if (e.get("persona_ref") or "").startswith("(새 증거)"))},
    }
    hd = ROOT / "handoff"
    hd.mkdir(exist_ok=True)
    (hd / "boscombe_case.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")

    locs = {l["id"]: l["name"] for l in case["locations"]}
    L = [f"# {case['title']} 증거 목록", "", f"원작: {case['source']}", "",
         f"증거 {len(evidence)}개 · 단계별 " + " / ".join(f"{s} {STAGE[s]} {sum(1 for e in evidence if e['stage'] == s)}개" for s in STAGE), "",
         "- **text**: 플레이어에게 보이는 관찰 내용(해석 없음) / **해석**: 이 증거로 알 수 있는 것(정답 화면·힌트용) / **한계**: 이 증거만으로 알 수 없는 것",
         "- **선행**: 먼저 열어야 하는 증거 / **진행 조건**: 페르소나 대화로 켜지는 조건(scene_access_granted = 경감의 현장 안내, victoria_known = 빅토리아 이야기를 들음)", ""]
    for s in STAGE:
        L += [f"## {s}단계 · {STAGE[s]}", ""]
        for e in [x for x in evidence if x["stage"] == s]:
            L += [f"### {e['id']} — {e['title']}",
                  f"- 위치: {locs[e['location']]} / 조사 대상: {e['object']} / 종류: {e['type']}",
                  f"- 선행: {', '.join(e['requires']) or '없음'} / 진행 조건: {', '.join(e['gate_flags']) or '없음'}",
                  f"- 원작 단서: {', '.join(e['original_clues']) or '-'}" + (f" / 각색: {e['adaptation']}" if e.get("adaptation") else ""),
                  "", f"> {e['text']}", "", f"- 해석: {e['proves']}", f"- 한계: {e['limits']}", ""]
    L += ["## 정답과 근거 (채점용)", "",
          f"- 범인: **{names[culprit]}** / 흉기: 돌 / 동기: {case['truth']['motive']}",
          f"- 최소 근거 증거({len(ms)}개): {', '.join(ms)}", ""]
    for p, x in excl.items():
        L.append(f"- {names[p]} 배제: {x['reason']} ← {', '.join(x['evidence'])}")
    L += ["", "### 단계별 추리 흐름", ""] + [f"- {l}" for l in case["truth"]["logic"]]
    L += ["", "## 페르소나 파트와의 ID 대응", "", "| 페르소나 조사 행동 | 얻는 증거 |", "|---|---|"]
    L += [f"| {k} | {', '.join(v)} |" for k, v in PERSONA_INV.items()]
    L += ["", "| 증거 | 페르소나 파일과의 관계 |", "|---|---|"]
    L += [f"| {e['id']} | {e.get('persona_ref') or '-'} |" for e in evidence]
    (hd / "증거목록.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("handoff 작성:", [p.name for p in hd.iterdir()])
    print("최소 근거:", ms)
    for p, x in excl.items():
        print(names[p], "배제:", x)


if __name__ == "__main__":
    main()
