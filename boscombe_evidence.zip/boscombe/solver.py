"""보스콤 밸리 판정기: 공개된 증거만 읽고 범인을 특정할 수 있는지 규칙으로 판정한다.

요소(Abbey Grange와 같은 프로파일형)
- 관계: 피해자와의 관계·갈등 기록이 있는가
- 능력: 현장 단서가 보여 주는 범인 특징(perp_trait)과 인물 특징(trait) 대조.
        알려진 특징이 하나라도 어긋나면 배제, 2개 이상 일치하고 그중 신체 특징(다리·키·주로 쓰는 손)이 있으면 확인
- 기회: 사건 장소 근처에 있었거나 연못과 맞닿은 곳에 사는가
특정 = 배제되지 않은 후보가 한 명뿐이고, 그 사람의 관계·능력·기회가 모두 확인됨
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent
NEAR = {"boscombe_pool", "pool_woods", "hatherley_path", "great_beech"}
ABILITY = ["lame", "tall", "australian", "left_handed", "local"]
DISTINCT = {"lame", "tall", "left_handed"}   # 현장에서만 나오는 신체 특징(능력 확인에 1개 이상 필요)


def load(name):
    return json.loads((ROOT / "data" / name).read_text(encoding="utf-8"))


def perp_traits(facts):
    """증거 사실에서 범인 특징을 모은다. 두 증거를 합쳐야 나오는 특징은 규칙으로 도출."""
    t = {f["trait"] for f in facts if f["kind"] == "perp_trait"}
    if any(f["kind"] == "injury" and f.get("side") == "left" and f.get("position") == "rear" for f in facts):
        t.add("left_handed")          # 뒤에서 친 일격이 왼쪽에 맞음
    if any(f["kind"] == "dying_words" and f.get("heard") == "a rat" for f in facts) and \
       any(f["kind"] == "place_name" and f.get("name") == "Ballarat" for f in facts):
        t.add("australian")           # 'a rat' = (Bal)larat
    return t


def person_traits(facts, pid):
    out = {f["trait"]: f["value"] for f in facts if f["kind"] == "trait" and f["person"] == pid}
    # 자기 장화로 확인된 발자국이 있고 그 발자국에 절뚝임이 없으면 다리를 절지 않는다(원작 탐정의 추론)
    if any(f["kind"] == "tracks" and f.get("person") == pid and not any(w in str(f.get("pattern", "")) for w in ("lame", "limp")) for f in facts):
        out.setdefault("lame", False)
    if any(f["kind"] == "residence" and f["person"] == pid for f in facts):
        out.setdefault("local", True)
    return out


def judge(case, evidence, ids):
    """ids: 공개된 증거 ID 집합 → 후보별 판정과 특정 여부"""
    facts = [f for e in evidence if e["id"] in ids for f in e["facts"]]
    victim = next(p["id"] for p in case["persons"] if p["role"].startswith("피해자"))
    pt = perp_traits(facts)
    res = {}
    for p in case["persons"]:
        if not p.get("suspect"):
            continue
        pid = p["id"]
        tr = person_traits(facts, pid)
        clash = sorted(t for t in pt if tr.get(t) is False)
        match = sorted(t for t in pt if t in ABILITY and tr.get(t) is True)
        rel = any(f["kind"] in ("relation", "conflict") and f.get("person") == pid and f.get("target") == victim for f in facts)
        opp = any((f["kind"] == "presence" and f["person"] == pid and f["location"] in NEAR) or
                  (f["kind"] == "residence" and f["person"] == pid and f.get("adjacent_to") == "boscombe_pool") for f in facts)
        res[pid] = {"관계": "확인" if rel else "미정",
                    "능력": "배제" if clash else ("확인" if len(match) >= 2 and DISTINCT & set(match) else "미정"),
                    "기회": "확인" if opp else "미정",
                    "배제": bool(clash), "어긋난 특징": clash, "일치한 특징": match}
    alive = [k for k, v in res.items() if not v["배제"]]
    strong = [k for k, v in res.items() if not v["배제"] and v["관계"] == v["능력"] == v["기회"] == "확인"]
    solved = None
    if len(alive) == 1:
        v = res[alive[0]]
        if v["관계"] == v["능력"] == v["기회"] == "확인":
            solved = alive[0]
    likely = strong[0] if len(strong) == 1 else None   # 완화 기준: 관계·능력·기회가 모두 확인된 후보가 한 명
    return {"범인 특징": sorted(pt), "후보": res, "남은 후보": alive, "특정": solved, "유력": likely, "확인된 후보": strong}


def stage_ids(evidence, stage):
    return {e["id"] for e in evidence if e["stage"] <= stage}


if __name__ == "__main__":
    case, ev = load("case_boscombe.json"), load("evidence_boscombe.json")["evidence"]
    names = {p["id"]: p["name"] for p in case["persons"]}
    for s in (1, 2, 3):
        r = judge(case, ev, stage_ids(ev, s))
        print(f"[{s}단계] 범인 특징={r['범인 특징']}")
        for pid, v in r["후보"].items():
            print(f"   {names[pid]:8s} 관계={v['관계']} 능력={v['능력']} 기회={v['기회']} 어긋남={v['어긋난 특징']} 일치={v['일치한 특징']}")
        print(f"   남은 후보: {[names[x] for x in r['남은 후보']]} → 특정: {names.get(r['특정'], '불가')}")
