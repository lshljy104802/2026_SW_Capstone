"""채점 도구 자체를 시험한다 → report/trust.md

A. 사실 분류기(원장 대조) 변이 시험: 정답 사실은 모두 '참', 값을 하나씩 틀리게 바꾼 사실은 '틀림'으로 잡는가
B. 최종 제작 채점기 결함 주입: 정답 세트에 결함을 하나씩 넣으면 필수 조건에서 떨어지고, 원인 항목이 맞게 표시되는가
C. 별칭 처리: 한국어 지명·임종의 말 표기를 같은 사실로 받는가(모델에게 불리하지 않은가)

python trust_tests.py
"""
import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "gen"))
from solver import load  # noqa: E402
from score_models import accepted_truths, classify  # noqa: E402
import score_production as SP  # noqa: E402

case, clues = load("case_boscombe.json"), load("original_clues.json")
gold = load("evidence_boscombe.json")["evidence"]
story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
persona = json.loads(SP.PERSONA.read_text(encoding="utf-8")) if SP.PERSONA.exists() else None
truths = accepted_truths(case)
quotes = {c["id"]: c["quote"] for c in clues["clues"]}


def gold_copy():
    g = copy.deepcopy(gold)
    for e in g:
        e["quote"] = " / ".join(quotes[c] for c in e.get("original_clues", []) if c in quotes)
    return g


L = ["# 채점 도구 신뢰 시험", "", "`python trust_tests.py`로 다시 만들 수 있다.", ""]

# ---------------- A
allf = [(e["id"], f) for e in gold for f in e["facts"]]
okc = sum(1 for _, f in allf if classify(f, truths)[0] == "ok")
MUT = [
    ("injury", "side", "right"), ("injury", "position", "front"), ("weapon", "item", "gun"),
    ("crime_scene", "location", "turner_hall"), ("dying_words", "heard", "a cat"), ("appointment", "time", "16:00"),
]
rows, caught, n = [], 0, 0
for eid, f in allf:
    variants = []
    for kind, key, val in MUT:
        if f["kind"] == kind and f.get(key) != val:
            variants.append((f"{key}: {f.get(key)} → {val}", {**f, key: val}))
    if f["kind"] == "trait":
        variants.append((f"value: {f['value']} → {not f['value']}", {**f, "value": not f["value"]}))
    if f["kind"] == "perp_trait":
        variants.append((f"trait: {f['trait']} → short", {**f, "trait": "short"}))
    for desc, v in variants:
        n += 1
        k = classify(v, truths)[0]
        caught += k == "wrong"
        rows.append(f"| {eid} | {f['kind']} | {desc} | {'틀림' if k == 'wrong' else k} |")
L += ["## A. 사실 분류기 변이 시험", "",
      f"- 정답 세트 사실 {len(allf)}개 중 '참'으로 분류: {okc}/{len(allf)}",
      f"- 값을 틀리게 바꾼 사실 {n}개 중 '틀림'으로 잡음: {caught}/{n}", "",
      "| 증거 | 사실 종류 | 바꾼 값 | 분류 |", "|---|---|---|---|"] + rows + [""]
A_ok = okc == len(allf) and caught == n

# ---------------- B
cases = []


def inj(name, fn, expect):
    g = gold_copy()
    fn(g)
    s = SP.score(case, clues, story, persona, gold, {"evidence": g}, truths)
    failed = [k for k, v in s["checks"].items() if not v]
    extra = []
    if s["missing"]:
        extra.append("슬롯 누락")
    if s["slot_errors"]:
        extra.append("슬롯 칸 오류")
    if s["solved"] != case["truth"]["culprit"]:
        extra.append("범인 특정 실패")
    found = failed + extra
    cases.append((name, expect, found, not s["required_ok"] and all(x in found for x in expect)))


def by(g, i):
    return next(e for e in g if e["id"] == i)


inj("슬롯 하나 삭제(고용인 명부)", lambda g: g.remove(by(g, "EV_STAFF_REGISTER")), ["슬롯 누락", "B6"])
inj("조사 대상 이름을 바꿈", lambda g: by(g, "EV_BEECH_CIGAR").__setitem__("object", "벤치 아래"), ["슬롯 칸 오류"])
inj("원장과 모순되는 사실(흉기=총)", lambda g: by(g, "EV_STONE_WEAPON")["facts"].append({"kind": "weapon", "item": "gun"}), ["B1"])
inj("증거 문장에 추리 결론", lambda g: by(g, "EV_SURGEON_REPORT").__setitem__("text", by(g, "EV_SURGEON_REPORT")["text"] + " 범인은 왼손잡이다."), ["B8"])
inj("지도 문장에 지명 가리기 수법(ARAT)", lambda g: by(g, "EV_VICTORIA_MAP").__setitem__("text", by(g, "EV_VICTORIA_MAP")["text"] + " 앞부분을 손으로 가리면 ARAT만 보인다."), ["B8"])
inj("해석 칸에 범인 이름과 범행", lambda g: by(g, "EV_TIPTOE_TRACKS").__setitem__("proves", "터너가 매카시를 쳤다."), ["B9"])
inj("원작에 없는 인용", lambda g: by(g, "EV_INQUEST_RECORD").__setitem__("quote", "He said clearly that a rat had bitten him."), ["B14"])
inj("임종의 말 사실 누락", lambda g: by(g, "EV_INQUEST_RECORD").__setitem__("facts", [f for f in by(g, "EV_INQUEST_RECORD")["facts"] if f["kind"] != "dying_words"]), ["B2", "범인 특정 실패"])
inj("까치발 발자국의 범인 특징 사실 삭제", lambda g: by(g, "EV_TIPTOE_TRACKS").__setitem__("facts", [f for f in by(g, "EV_TIPTOE_TRACKS")["facts"] if f["kind"] != "perp_trait"]), ["범인 특정 실패"])
inj("출처·각색 메모 삭제", lambda g: (by(g, "EV_WOOD_PATH").__setitem__("adaptation", None), by(g, "EV_WOOD_PATH").__setitem__("facts", []), by(g, "EV_WOOD_PATH").__setitem__("quote", "")), ["B11"])
base = SP.score(case, clues, story, persona, gold, {"evidence": gold_copy()}, truths)
L += ["## B. 최종 제작 채점기 결함 주입", "",
      f"- 결함 없는 정답 세트: 필수 조건 {'통과' if base['required_ok'] else '실패'}",
      f"- 결함 {len(cases)}종 중 필수 조건에서 떨어뜨리고 원인을 맞게 표시: {sum(c[3] for c in cases)}/{len(cases)}", "",
      "| 결함 | 기대 원인 | 실제로 걸린 항목 | 탐지 |", "|---|---|---|---|"]
for name, ex, found, ok in cases:
    L.append(f"| {name} | {', '.join(ex)} | {', '.join(found) or '-'} | {'O' if ok else 'X'} |")
B_ok = base["required_ok"] and all(c[3] for c in cases)

# ---------------- C
al = [({"kind": "place_name", "name": "발라랏", "region": "빅토리아"}, "Ballarat"),
      ({"kind": "place_name", "name": "밸러랫(Ballarat)", "region": "Victoria"}, "Ballarat"),
      ({"kind": "dying_words", "person": "charles_mccarthy", "heard": "...a rat"}, "a rat"),
      ({"kind": "dying_words", "person": "charles_mccarthy", "heard": "쥐(a rat)"}, "a rat")]
L += ["", "## C. 표기 별칭", "", "| 모델 표기 | 맞춘 값 | 분류 |", "|---|---|---|"]
C_ok = True
for f, want in al:
    g = SP.alias(f)
    k = classify(g, truths)[0]
    C_ok &= k == "ok"
    L.append(f"| `{json.dumps(f, ensure_ascii=False)}` | {g.get('name') or g.get('heard')} | {k} |")

L += ["", "## 결론", "", f"- A 사실 분류기: {'통과' if A_ok else '실패'}", f"- B 결함 주입: {'통과' if B_ok else '실패'}", f"- C 별칭: {'통과' if C_ok else '실패'}"]
(ROOT / "report" / "trust.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print("\n".join(L[-4:]))
for name, ex, found, ok in cases:
    if not ok:
        print("X", name, ex, found)
