# 보스콤 밸리 사건 — 증거 데이터 (증거 생성 파트)

원작: *The Boscombe Valley Mystery* (Arthur Conan Doyle, 1891). WhoDunIt 논문 부록 A.3 단편 목록 수록작.
원문: 팀원이 제공한 sherlock-holm.es v3.1 PDF를 텍스트로 옮긴 `story/boscombe_valley.txt`.

## 파일

| 파일 | 내용 |
|---|---|
| `data/original_clues.json` | 원작 단서 20개(핵심 10개). 원문 인용, 한국어 요약, 단서를 나타내는 사실 표기 |
| `data/case_boscombe.json` | 사건 원장(정답층). 인물·특징, 장소, 이동 시간, 시간대별 실제 사건, 참 사실 41개, 정답·추론 흐름, 각색 메모 |
| `data/evidence_boscombe.json` | 증거 정답 세트 17개(1단계 6 · 2단계 8 · 3단계 3) |
| `solver.py` | 판정기(관계·능력·기회). 공개된 증거만 읽고 범인을 특정할 수 있는지 판정 |
| `validate.py` | 검증 15개 항목(B1~B15) + 결함 주입 12종 → `report/validation.md` |
| `export.py` | 전달용 파일 → `handoff/boscombe_case.json`(게임용), `handoff/증거목록.md`(사람이 읽는 목록) |

## 만든 방법

1. **원작 단서 추출:** 탐정이 실제로 쓴 단서 20개를 뽑고 원문 문장을 인용했다. 인용은 원문 텍스트와 자동 대조한다(B14). 정답 추리에 꼭 필요한 10개는 핵심 단서로 표시했다.
2. **사건 원장 작성:** 실제 사건 흐름(18개 사건), 인물 특징, 장소, 이동 시간, 참 사실 목록과 정답을 정했다. 증거의 사실은 모두 이 목록 안에 있어야 한다(B1).
3. **증거 작성:** 증거 문장(text)에는 관찰한 사실만 쓰고, 탐정의 해석은 `proves`, 그 증거만으로 알 수 없는 것은 `limits`에 따로 적었다. 증거마다 지도 위치(`location`), 조사 대상(`object`), 단계, 선행 증거, 원작 단서 번호를 붙였다.
4. **검증:** 판정기로 단계별 풀이 가능성을 확인하고, 일부러 결함을 넣은 데이터 12종이 모두 걸러지는지 확인했다.

## 추리 구조

현장 단서로 범인의 특징을 밝히고, 특징이 맞는 사람을 찾는 구조다(Abbey Grange와 같은 프로파일형).

| 단계 | 새로 알게 되는 범인 특징 | 남은 후보 |
|---|---|---|
| 1 사건 기록 | 머리 왼쪽 뒤를 맞음 → 왼손잡이 | 제임스, 터너, 크라우더, 페이션스 (4명) |
| 2 현장 조사 | 제3의 까치발 자국 → 오른쪽 다리를 절고, 보폭이 길고, 네모 장화 / 연못은 농장·영지로만 접근 | 터너, 크라우더 (2명). 제임스는 발자국이 고르고, 페이션스는 14세 소녀라 빠짐 |
| 3 추가 조사 | 지도의 BALLARAT + 임종의 말 'a rat' → 발라랏(호주) 출신 | 터너 (1명). 크라우더는 이 지방 태생이라 빠지고, 터너는 다리를 절고 거구인 호주 출신으로 확인 |

## 검증 결과

- 15개 항목 모두 통과, 결함 주입 12종 모두 탐지 (`report/validation.md`)
- 원작 핵심 단서 10개 모두 증거에 반영
- 최소 해결 증거 11개, 1~3단계 증거를 모두 써야 풀림
- 페르소나 파일(`boscombe_personas.json`)의 증거 ID 8개가 모두 이 데이터에 같은 ID로 있음(B13)

## 교수님 피드백 반영

- **정해진 진술·대조 탭 제거:** 진술 목록과 진술–물증 짝을 두지 않았다. 원작 안에 실제로 있는 문서(신문 기사, 검시 기록, 경찰 기록)만 증거로 둔다.
- **지도 기반 조사:** 모든 증거에 장소와 조사 대상 이름이 있어, 사건 지도에서 오브젝트를 눌러 여는 방식에 바로 쓸 수 있다. 지도 밖 장소(호텔, 전신국)는 `map: off_map`으로 표시했다.
- **행동 제한 없음:** 횟수 제한 없이 단계와 선행 증거로만 열린다. `gate_flags`는 페르소나 대화로 켜지는 진행 조건이며, 쓰지 않아도 데이터는 풀린다.
- **자백 없이 정답 판정 가능:** 원작은 결말의 자백으로 정답이 확정되지만, 이 데이터는 증거만으로 범인을 특정할 수 있다. 채점은 `answer.culprit`, `answer.minimum_evidence`, `answer.exclusions`로 하면 된다.

## 페르소나 파트와 맞출 것

- **같은 ID:** EV_INQUEST_RECORD, EV_SURGEON_REPORT, EV_BOOTS_HATHERLEY, EV_TRACKS_POOL, EV_TIPTOE_TRACKS, EV_BEECH_CIGAR, EV_STONE_WEAPON, EV_VICTORIA_MAP
- **문장 변경:** 페르소나 파일의 증거 설명에 섞여 있던 추리 표현(시가 홀더, 무딘 주머니칼, '상처와 들어맞고', 'A RAT')은 증거 문장에서 빼고 `proves`로 옮겼다. 증거 문장은 이 데이터를 쓰는 것으로 통일하자.
- **새 증거:** 신문 기사, 마부 증언, 페이션스 증언, 체포 발언, 연못 지형, 임대 기록, 숲길, 터너의 걸음걸이, 고용인 명부. 조사 행동(INV_*)과의 대응은 `handoff/증거목록.md`에 있다.
- **설정 추가 필요:** 크라우더가 이 지방 태생이라는 설정(EV_STAFF_REGISTER)을 크라우더 페르소나에 넣어야 한다. 숲지기 모런이 터너의 걸음걸이를 이야기하는 설정(EV_TURNER_GAIT)도 맞춰야 한다.
- **진행 조건 이름:** `scene_access_granted`, `victoria_known`은 페르소나 파일의 플래그 이름을 그대로 썼다.

## 각색 메모 (원작에 없는 부분)

`data/case_boscombe.json`의 `adaptation_notes`와 증거별 `adaptation`에 모두 적었다. 주요 내용:

- 정확한 시각, 사망 추정 시각대(15:10~15:30), 이동 시간은 게임용 설정
- 터너가 다리를 저는 모습(원작 결말)을 숲지기의 증언으로 옮김
- 크라우더의 이력(이 지방 태생)은 원작에 없는 설정
- 제임스 발자국의 양발 깊이가 고르다는 것, 14세 소녀의 보폭이 짧다는 것은 판정용 설정
- 임대료 면제(원작에서 경감이 전하는 정보)를 임대 서류로 옮김

## 실행

```bash
python solver.py                                   # 단계별 판정
python validate.py --persona boscombe_personas.json   # 검증(페르소나 파일은 선택)
python export.py                                   # 전달용 파일 생성
```

## 모델 비교 (`gen/`)

같은 프롬프트(`gen/prompt_template.md` + 원문)를 여러 모델에 주고 증거를 만들게 한 뒤, 정답 세트와 같은 기준으로 채점한다. 결과는 `report/model_compare.md`.

| 파일 | 내용 |
|---|---|
| `gen/prompt_template.md` | 모든 모델에 똑같이 주는 프롬프트(원문 자리 `{story}`) |
| `gen/claude_runs/` | Claude Opus·Sonnet·Haiku 5.5가 2회씩 만든 증거(각 모델은 프롬프트 파일 하나만 읽고 독립적으로 생성) |
| `gen/run_models.py` | 다른 모델 실행기(Ollama 로컬 모델, Gemini 무료 키, OpenRouter·Groq 무료 모델, 유료 API) → `gen/runs/` |
| `gen/score_models.py` | 두 폴더의 결과를 모두 채점해 비교표 작성 |

채점 기준: 핵심 단서 반영, 사실 정확도(원장과 모순 여부), 진술형 증거 수, 원문 인용 일치, 검증 11개 항목, 판정기의 범인 특정(엄격·완화)

```bash
python gen/run_models.py --models "ollama:qwen2.5:7b,ollama:gemma3:12b" --repeats 2   # PC의 무료 로컬 모델
python gen/score_models.py                                                          # 모두 다시 채점
```

## 최종 제작(게임 슬롯 17개) — 2026-11-16

게임에 바로 넣을 수 있게 슬롯(ID·단계·장소·조사 대상·선행 증거·진행 조건)을 고정하고 내용만 쓰게 한 비교.

| 파일 | 내용 |
|---|---|
| `gen/prompt_production.md` | 모든 모델에 준 프롬프트(슬롯 표, 각색 설정 6개) |
| `gen/claude_prod/` | Claude Opus·Sonnet·Haiku 5.5, Fable 5.1 각 2회 결과 |
| `gen/runs_prod/` | Ollama 등 run_models.py 결과(`--prompt prompt_production.md --out runs_prod`) |
| `gen/score_production.py` | 채점기(선정 기준 포함) → `report/production_compare.md` |
| `review/` | 블라인드 원문 대조 프롬프트·라벨 → `report/review.md` |
| `trust_tests.py` | 채점 도구 자체 시험 → `report/trust.md` |

결론: 웹페이지에는 정답 세트를 쓴다(모델 결과 8회 모두 지도 증거에 'ARAT' 추리 수법을 적어 B8 실패). 다음 스토리 제작에는 Claude Opus 5.5를 권한다.
