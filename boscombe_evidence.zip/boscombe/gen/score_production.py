"""최종 제작(게임 슬롯 17개) 결과를 채점한다 → report/production_compare.md, report/production_scores.json

읽는 곳
  gen/claude_prod/*.json   Claude 모델 결과(증거 JSON 그대로), meta.json에 모델·시간
  gen/runs_prod/*.json     run_models.py 결과(Ollama 등, 응답 원문 포함)
기준
  data/case_boscombe.json(사건 원장), data/original_clues.json(원작 단서), story/(원문),
  validate.py 검증 항목, solver.py 판정기, 게임 페르소나 파일(B13)

선정 기준은 결과를 보기 전에 정해 이 파일에 적어 둔다(SELECTION).
"""
import copy
import json
import re
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from solver import judge, load, stage_ids  # noqa: E402
from validate import CHECKS, norm, run_checks, sub  # noqa: E402
from score_models import FREE, accepted_truths, classify, parse  # noqa: E402

PERSONA = Path("/home/claude/boscombe_game/data/boscombe_personas.json")
SLOT_FIELDS = ["stage", "type", "location", "object", "requires", "gate_flags"]
# 한국어로 적은 같은 값(채점 전에 원장 표기로 맞춘다). 모델에게 불리하지 않게 넓게 받는다
ALIASES = {
    "place_name.name": {"ballarat": ["발라랏", "발라랫", "밸러랫", "발라라트", "ballarat"]},
}
SELECTION = """
[필수 조건] 하나라도 어기면 게임에 넣지 않는다
 1. JSON을 읽을 수 있고, 17개 슬롯이 모두 있으며 슬롯 칸(단계·종류·장소·조사 대상·선행 증거·진행 조건)을 그대로 지켰다
 2. 원장과 모순되는 사실이 0건이다(B1)
 3. 적용 가능한 검증 항목 B2~B14를 모두 통과한다
 4. 판정기가 3단계에서 범인을 엄격 기준으로 특정한다(1·2단계에서는 특정하지 못한다)
[순위] 필수 조건을 통과한 데이터끼리
 1. 정답 세트 사실 회수율(슬롯별)이 높은 것
 2. 원장으로 판단할 수 없는 사실이 적은 것(검수 부담)
 3. 원문 인용 일치율이 높은 것
 4. 독립 검토(원문 대조)에서 근거 없는 문장이 적은 것
"""


def alias(f):
    f = dict(f)
    if f.get("kind") == "place_name" and isinstance(f.get("name"), str):
        n = f["name"].strip().lower()
        for canon, al in ALIASES["place_name.name"].items():
            if any(a in n for a in al):
                f["name"] = "Ballarat"
    if f.get("kind") == "dying_words" and isinstance(f.get("heard"), str):
        h = f["heard"].lower()
        if "rat" in h or "랫" in h or "쥐" in h:
            f["heard"] = "a rat"
    return f


def korean_ratio(s):
    letters = [c for c in s if c.isalpha()]
    return round(sum(1 for c in letters if "가" <= c <= "힣") / len(letters), 2) if letters else 0.0


def score(case, clues, story, persona, gold, obj, truths):
    out = {"parsed": obj is not None}
    if not obj:
        return out
    gold_by = {e["id"]: e for e in gold}
    ev_in = [e for e in obj.get("evidence", []) if isinstance(e, dict)]
    by = {}
    for e in ev_in:
        if e.get("id") in gold_by and e["id"] not in by:
            by[e["id"]] = e
    out["n"] = len(ev_in)
    out["missing"] = [i for i in gold_by if i not in by]
    out["extra"] = [e.get("id") for e in ev_in if e.get("id") not in gold_by]
    slot_err = []
    total = ok = wrong = unknown = 0
    bad, unk = [], []
    norm_ev = []
    for gid, g in gold_by.items():
        e = copy.deepcopy(by.get(gid, {}))
        for k in SLOT_FIELDS:
            v = e.get(k)
            if k in ("requires", "gate_flags"):
                v = sorted(v or [])
                if v != sorted(g[k]):
                    slot_err.append(f"{gid}.{k}")
            elif v != g[k]:
                slot_err.append(f"{gid}.{k}")
            e[k] = g[k]           # 게임 슬롯은 정답 칸으로 고정해 내용만 비교한다
        e["id"] = gid
        for k in ("title", "text", "proves", "limits", "quote"):
            e[k] = e.get(k) or ""
        e["adaptation"] = e.get("adaptation") or None
        facts = []
        for f in e.get("facts") or []:
            total += 1
            f2 = alias(f) if isinstance(f, dict) else f
            kind, val = classify(f2, truths)
            if kind == "ok":
                ok += 1
                facts.append(val)
            elif kind == "wrong":
                wrong += 1
                bad.append(f"{gid}: {json.dumps(f, ensure_ascii=False)[:110]} ({val})")
            else:
                unknown += 1
                unk.append(f"{gid}: {json.dumps(f, ensure_ascii=False)[:110]}")
        e["facts"] = facts
        e["original_clues"] = [c["id"] for c in clues["clues"] if c["signature"] and
                               all(any(sub(s, f) for f in facts) for s in c["signature"])]
        if not e["original_clues"] and e.get("quote"):
            e["original_clues"] = ["(원문 인용)"]
        norm_ev.append(e)
    out["slot_errors"] = slot_err
    out["fact_total"], out["fact_ok"], out["fact_wrong"], out["fact_unknown"] = total, ok, wrong, unknown
    out["fact_acc"] = round(ok / (ok + wrong), 3) if ok + wrong else 0.0
    out["bad_facts"], out["unknown_facts"] = bad, unk
    # 정답 세트 사실 회수율: 같은 슬롯에 정답 세트의 사실이 들어 있는가(덜 구체적인 표기는 인정)
    hit = tot = 0
    per_slot = {}
    for e in norm_ev:
        # 정답 사실도 같은 방식으로 정규화하고, 설명용 칸(진술 요약어·경로 등 FREE)은 비교하지 않는다
        core = lambda f: {k: v for k, v in f.items() if k not in FREE.get(f["kind"], set())}
        gf = [core(classify(alias(f), truths)[1]) for f in gold_by[e["id"]]["facts"]]
        mf = [core(x) for x in e["facts"]]
        h = sum(1 for f in gf if any(sub(x, f) or sub(f, x) for x in mf))
        per_slot[e["id"]] = (h, len(gf))
        hit, tot = hit + h, tot + len(gf)
    out["gold_recall"] = round(hit / tot, 3) if tot else 0.0
    out["per_slot"] = per_slot
    allf = [f for e in norm_ev for f in e["facts"]]
    key = [c for c in clues["clues"] if c["key"]]
    hitc = lambda c: all(any(sub(s, f) for f in allf) for s in c["signature"])
    out["key_hit"] = [c["id"] for c in key if hitc(c)]
    out["all_recall"] = round(sum(hitc(c) for c in clues["clues"]) / len(clues["clues"]), 2)
    qs = [q for e in norm_ev for q in (e.get("quote") or "").split(" / ") if q.strip()]
    st = norm(story)
    out["quote_n"] = len(qs)
    out["quote_match"] = round(sum(1 for q in qs if norm(q) in st) / len(qs), 2) if qs else None
    out["bad_quotes"] = [q[:60] for q in qs if norm(q) not in st]
    texts = [e["text"] for e in norm_ev]
    out["text_len"] = round(statistics.mean(len(t) for t in texts)) if texts else 0
    out["empty_text"] = [e["id"] for e in norm_ev if len(e["text"]) < 20]
    out["korean"] = korean_ratio(" ".join(texts + [e["title"] for e in norm_ev]))
    out["no_limits"] = [e["id"] for e in norm_ev if not e["limits"].strip()]
    out["no_proves"] = [e["id"] for e in norm_ev if not e["proves"].strip()]
    out["adaptations"] = sum(1 for e in norm_ev if e.get("adaptation"))
    R, why, stages, ms = run_checks(case, clues, norm_ev, story=story, persona=persona)
    R["B1"], why["B1"] = wrong == 0, bad[:5]
    # B14는 원작 단서 파일의 인용을 보는 항목이라 모델 인용으로 다시 본다
    R["B14"], why["B14"] = out["quote_match"] == 1.0, out["bad_quotes"][:5]
    out["checks"] = {k: R[k] for k in CHECKS if k != "B15"}
    out["why"] = {k: why[k] for k in out["checks"] if not R[k]}
    out["stage_solve"] = [stages[s]["특정"] for s in (1, 2, 3)]
    out["solved"] = stages[3]["특정"]
    out["remaining"] = stages[3]["남은 후보"]
    out["min_set"] = len(ms)
    out["evidence"] = norm_ev
    culprit = case["truth"]["culprit"]
    out["required_ok"] = (not out["missing"] and not slot_err and wrong == 0 and all(out["checks"].values())
                          and out["solved"] == culprit and not any(out["stage_solve"][:2]))
    return out


def main():
    case, clues = load("case_boscombe.json"), load("original_clues.json")
    gold = load("evidence_boscombe.json")["evidence"]
    story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
    persona = json.loads(PERSONA.read_text(encoding="utf-8")) if PERSONA.exists() else None
    truths = accepted_truths(case)
    names = {p["id"]: p["name"] for p in case["persons"]}
    rows = []
    g = copy.deepcopy(gold)
    g_quotes = {c["id"]: c["quote"] for c in clues["clues"]}
    for e in g:   # 정답 세트는 인용을 원작 단서 파일에 두었으므로 그 인용을 붙여 같은 기준으로 본다
        e["quote"] = " / ".join(g_quotes[c] for c in e.get("original_clues", []) if c in g_quotes)
    rows.append(("정답 세트(원장 기반)", "-", None, score(case, clues, story, persona, gold, {"evidence": g}, truths)))
    meta = {}
    mp = HERE / "claude_prod" / "meta.json"
    if mp.exists():
        meta = json.loads(mp.read_text(encoding="utf-8"))
    files = sorted(list((HERE / "claude_prod").glob("*.json")) + list((HERE / "runs_prod").glob("*.json")))
    for p in files:
        if p.name == "meta.json":
            continue
        raw = json.loads(p.read_text(encoding="utf-8"))
        obj, err = parse(raw)
        if obj is None and isinstance(raw, dict) and raw.get("response"):
            obj, err = parse({"response": re.sub(r"<think>.*?</think>", "", raw["response"], flags=re.S)})
        s = score(case, clues, story, persona, gold, obj, truths)
        s["error"] = err
        m = meta.get(p.stem, {})
        s["file"] = p.name
        rows.append((m.get("model") or raw.get("model", p.stem), m.get("run") or raw.get("run", "?"),
                     m.get("seconds") or raw.get("seconds"), s))
    json.dump([{"model": m, "run": r, "seconds": sec, **{k: v for k, v in s.items() if k != "evidence"}} for m, r, sec, s in rows],
              open(ROOT / "report" / "production_scores.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # 선정된 데이터(필수 조건 통과 + 순위 1위)를 파일로 남긴다
    cand = [(m, r, s) for m, r, sec, s in rows[1:] if s.get("parsed") and s.get("required_ok")]
    cand.sort(key=lambda x: (-x[2]["gold_recall"], x[2]["fact_unknown"], -(x[2]["quote_match"] or 0)))
    f = lambda v: "-" if v is None else v
    ck_keys = [k for k in CHECKS if k != "B15"]
    L = ["# 보스콤 밸리 증거 최종 제작: 모델 비교", "",
         "- 모든 모델에 같은 프롬프트(`gen/prompt_production.md` + 원문)를 주었다. 게임 슬롯 17개(ID·단계·장소·조사 대상·선행 증거·진행 조건)는 고정하고 내용만 쓰게 했다.",
         "- 정답 세트는 사건 원장을 보고 만든 기준 데이터다. 채점 기준(원장)과 출처가 같으므로 비교의 상한선으로만 본다.",
         "- 사실 정확도: 원장으로 참·거짓을 가릴 수 있는 사실 중 참인 비율. 판단 불가: 원장에 없어 사람이 확인해야 하는 사실 수.",
         "- 정답 사실 회수율: 정답 세트가 각 슬롯에 담은 사실 중 모델이 같은 슬롯에 담은 비율.",
         "- 범인 특정: 판정기가 1·2·3단계 증거로 각각 범인을 특정하는지(엄격 기준). 정상은 '불가·불가·존 터너'.", "",
         "## 선정 기준(결과를 보기 전에 정함)", "", "```", SELECTION.strip(), "```", "",
         "## 1. 요약", "",
         "| 데이터 | 회차 | 슬롯 17개 | 슬롯 칸 오류 | 사실 정확도 | 틀린 사실 | 판단 불가 | 정답 사실 회수율 | 핵심 단서 | 인용 일치 | 검증 통과 | 단계별 특정 | 필수 조건 | 시간(초) |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m, r, sec, s in rows:
        if not s.get("parsed"):
            L.append(f"| {m} | {r} | 읽기 실패 | - | - | - | - | - | - | - | - | - | X | {f(sec)} |")
            continue
        ck = s["checks"]
        L.append(f"| {m} | {r} | {17 - len(s['missing'])}/17 | {len(s['slot_errors'])} | {s['fact_acc']} | {s['fact_wrong']} | {s['fact_unknown']} | "
                 f"{s['gold_recall']} | {len(s['key_hit'])}/10 | {f(s['quote_match'])} | {sum(ck.values())}/{len(ck)} | "
                 f"{' · '.join(names.get(x, '불가') for x in s['stage_solve'])} | {'O' if s['required_ok'] else 'X'} | {f(sec)} |")
    by = {}
    for m, r, sec, s in rows[1:]:
        by.setdefault(m, []).append((sec, s))
    L += ["", "### 모델별", "", "| 모델 | 회차 | 필수 조건 통과 | 사실 정확도(평균) | 정답 사실 회수율(평균) | 판단 불가(평균) | 인용 일치(평균) | 평균 시간(초) |", "|---|---|---|---|---|---|---|---|"]
    for m, v in by.items():
        okv = [s for _, s in v if s.get("parsed")]
        mean = lambda fn: round(statistics.mean([fn(x) for x in okv]), 3) if okv else "-"
        secs = [x for x, _ in v if x]
        L.append(f"| {m} | {len(v)} | {sum(1 for _, s in v if s.get('required_ok'))}/{len(v)} | {mean(lambda x: x['fact_acc'])} | {mean(lambda x: x['gold_recall'])} | "
                 f"{mean(lambda x: x['fact_unknown'])} | {mean(lambda x: x['quote_match'] or 0)} | {round(statistics.mean(secs), 1) if secs else '-'} |")
    cols = ["정답 세트" if r == "-" else f"{m.replace('Claude ', '').replace('ollama:', '')} #{r}" for m, r, _, _ in rows]
    L += ["", "## 2. 검증 항목", "", "| 항목 | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    for k in ck_keys:
        L.append(f"| {k} {CHECKS[k].split(' (')[0]} | " + " | ".join("-" if not s.get("checks") else ("O" if s["checks"][k] else "X") for *_, s in rows) + " |")
    L += ["", "## 3. 슬롯별 정답 사실 회수", "", "| 슬롯 | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    for gid in [e["id"] for e in gold]:
        L.append(f"| {gid} | " + " | ".join("-" if not s.get("per_slot") else f"{s['per_slot'][gid][0]}/{s['per_slot'][gid][1]}" for *_, s in rows) + " |")
    L += ["", "## 4. 회차별 문제", ""]
    for m, r, sec, s in rows[1:]:
        L.append(f"### {m} #{r}")
        if not s.get("parsed"):
            L += [f"- {s.get('error')}", ""]
            continue
        if s["missing"]:
            L.append(f"- 빠진 슬롯: {', '.join(s['missing'])}")
        if s["extra"]:
            L.append(f"- 슬롯 밖 증거: {', '.join(map(str, s['extra']))}")
        if s["slot_errors"]:
            L.append(f"- 슬롯 칸을 바꿈: {', '.join(s['slot_errors'][:12])}")
        L.append(f"- 단계별 특정: {' · '.join(names.get(x, '불가') for x in s['stage_solve'])} / 3단계 남은 후보 {[names[x] for x in s['remaining']]}")
        for k, w in s["why"].items():
            L.append(f"- {k} 실패: {'; '.join(map(str, w))[:300]}")
        if s["bad_facts"]:
            L.append(f"- 원장과 모순되는 사실 {len(s['bad_facts'])}건:")
            L += [f"  - `{b}`" for b in s["bad_facts"][:8]]
        if s["unknown_facts"]:
            L.append(f"- 원장으로 판단할 수 없는 사실 {len(s['unknown_facts'])}건(최대 6건): " + "; ".join(f"`{u}`" for u in s["unknown_facts"][:6]))
        if s["empty_text"]:
            L.append(f"- 증거 문장이 비었거나 너무 짧음: {', '.join(s['empty_text'])}")
        L.append(f"- 증거 문장 평균 {s['text_len']}자, 한국어 비율 {s['korean']}")
        L.append("")
    L += ["## 5. 필수 조건 통과 데이터의 순위", ""]
    if cand:
        L += ["| 순위 | 데이터 | 정답 사실 회수율 | 판단 불가 | 인용 일치 |", "|---|---|---|---|---|"]
        for i, (m, r, s) in enumerate(cand, 1):
            L.append(f"| {i} | {m} #{r} | {s['gold_recall']} | {s['fact_unknown']} | {s['quote_match']} |")
    else:
        L.append("필수 조건을 모두 통과한 모델 데이터가 없다.")
    out = ROOT / "report" / "production_compare.md"
    out.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L[:len(rows) + 30]))
    print("저장:", out)


if __name__ == "__main__":
    main()
