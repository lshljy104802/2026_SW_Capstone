[원작]
{story}

[과제]
위 원작 소설(The Boscombe Valley Mystery)을 추리 게임에서 플레이어가 조사할 수 있는 '증거 목록'으로 바꾸세요. 반드시 한국어로 쓰세요(quote만 영어 원문).

[게임 설정]
- 플레이어는 사건 지도에서 장소를 고르고, 그 장소의 조사 대상(물건, 흔적, 서류)을 눌러 증거를 엽니다.
- 정해진 진술 목록은 없습니다. 증거는 원작 안에 실제로 있는 문서(신문 기사, 검시 기록 등), 현장 물증, 흔적, 기록입니다.
- 증거는 3단계로 공개됩니다: 1 = 사건 기록(처음부터 열람), 2 = 현장 조사, 3 = 추가 조사(외부 기록, 탐문).
- 플레이어는 증거만으로 범인을 특정할 수 있어야 하고, 1·2단계만으로는 특정할 수 없어야 합니다.

[규칙]
1. 원작에서 탐정이나 경찰이 확인한 단서를 빠짐없이 증거로 만듭니다. 증거 하나에는 단서 하나를 담습니다(빠짐없이 담으면 보통 15개 이상).
2. text에는 관찰한 사실만 씁니다. 탐정의 추리나 결론(예: 왼손잡이, 다리를 전다, 범인은 누구)은 text에 쓰지 말고 proves에 씁니다.
3. 어떤 증거에도 범인의 이름을 범행과 함께 쓰지 마세요. '범인', '범행', '살해', '자백' 같은 표현을 text와 title에 쓰지 마세요.
4. 원작에 없는 내용을 만들었다면 adaptation에 무엇을 왜 만들었는지 적고, 원작 내용이면 null로 둡니다.
5. quote에는 그 증거의 근거가 되는 원작 영어 문장을 그대로(25단어 이하) 적습니다. 원작에 없는 증거면 빈 문자열.
6. requires에는 먼저 열어야 하는 증거 id를 적습니다(같거나 앞 단계 증거만). gate_flags에는 진행 조건을 적을 수 있습니다: "scene_access_granted"(경감이 현장을 안내함), "victoria_known"(빅토리아 이야기를 들음). 없으면 빈 목록.

[인물 id]
- charles_mccarthy: 피해자, 해덜리 농장 임차인
- james_mccarthy: 피해자의 아들, 체포된 피의자 (용의자)
- john_turner: 이 지역 최대 지주 (용의자)
- william_crowder: 사냥터지기, 목격자 (용의자)
- patience_moran: 숲지기의 딸(14세), 목격자 (용의자)
- alice_turner: 터너의 딸, 의뢰인
- inspector_lestrade: 경감
- moran: 숲지기 / john_cobb: 매카시 집 마부

[장소 id]
ross_hotel(로스의 호텔), ross_telegraph(로스 전신국), hatherley_farm(해덜리 농장), hatherley_path(농장에서 연못 가는 길), boscombe_pool(연못가 풀밭), pool_woods(연못 주변 숲), great_beech(큰 너도밤나무), wood_path(숲길), moran_lodge(숲지기 집), turner_hall(터너 저택), bristol(브리스톨), hereford_gaol(헤리퍼드 감옥)

[facts 표기] 증거가 입증하는 사실만 적습니다. facts의 각 항목은 문장이 아니라 아래 형식의 JSON 객체여야 합니다(해당하는 것만).
- {"kind":"presence","person":인물id,"location":장소id}  어떤 인물이 그 장소에 있었다
- {"kind":"crime_scene","location":장소id}
- {"kind":"injury","person":인물id,"part":"head","side":"left|right","position":"front|rear","cause":"blunt"}
- {"kind":"item_at","item":"james_gun","location":장소id}
- {"kind":"relation","person":인물id,"target":인물id,"type":"colonial_acquaintance|landlord_rent_free|father_son|..."}
- {"kind":"conflict","person":인물id,"target":인물id,"type":"quarrel"}
- {"kind":"trait","person":인물id,"trait":"lame|tall|australian|left_handed|local","value":true|false}  인물의 특징
- {"kind":"appointment","person":인물id,"time":"HH:MM"}
- {"kind":"signal","person":인물id,"word":"cooee","before_seeing":인물id}
- {"kind":"absence","person":인물id,"location":장소id,"known_to_victim":true|false}
- {"kind":"dying_words","person":인물id,"heard":"들린 말"}
- {"kind":"object_seen","item":"grey_cloth","location":장소id,"then":"gone"}
- {"kind":"remark","person":인물id,"content":"짧은 요약어"}
- {"kind":"reference_boots","persons":[인물id,...]}
- {"kind":"tracks","person":인물id,"pattern":"walk2_run1|pacing|..."}
- {"kind":"third_party","location":장소id}  부자 외의 제3자가 그 장소에 있었다
- {"kind":"perp_trait","trait":"lame|tall|square_boots|returned_for_item|cigar_indian|cigar_holder|blunt_knife|local|left_handed|australian"}  현장 단서가 보여 주는 범인의 특징
- {"kind":"weapon","item":"stone|gun|..."}
- {"kind":"access","location":장소id,"via":[장소id,...]}
- {"kind":"residence","person":인물id,"location":장소id,"adjacent_to":장소id}
- {"kind":"trail_end","location":"highroad"}
- {"kind":"place_name","name":"지명","region":"지역"}

[출력] 아래 JSON 하나만 출력하세요(설명 문장 없이).
{"evidence":[{"id":"EV01","stage":1,"type":"document|physical|trace|observation|testimony_record","location":장소id,"object":"지도에서 누를 조사 대상 이름","title":"","text":"","facts":[...],"requires":[],"gate_flags":[],"quote":"","proves":"","limits":"","adaptation":null}]}
