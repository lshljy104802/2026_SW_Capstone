"""모델이 만든 증거를 정답 세트와 같은 기준으로 채점한다 → report/model_compare.md

읽는 곳: gen/runs/*.json (run_models.py 결과, 응답 원문 포함), gen/claude_runs/*.json (증거 JSON 그대로)
기준: data/ 의 사건 원장·원작 단서, validate.py의 검증 항목, solver.py의 판정기
"""
import copy
import json
import re
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
from solver import judge, load, stage_ids  # noqa: E402
from validate import CHECKS, norm, run_checks, sub  # noqa: E402

USED_CHECKS = ["B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", "B11", "B12"]
FREE = {  # 값이 달라도 되는 설명용 칸
    "remark": {"content"}, "conflict": {"type"}, "object_seen": {"location", "then"}, "access": {"via", "location"},
    "residence": {"location"}, "tracks": {"pattern"}, "place_name": {"region"}, "reference_boots": {"persons"},
    "signal": {"before_seeing"}, "injury": {"part", "cause"},
}
SYMMETRIC = {"relation", "conflict"}
TRUE_PERP = {"lame", "tall", "square_boots", "returned_for_item", "cigar_indian", "cigar_holder", "blunt_knife", "local",
             "left_handed", "australian"}
IGNORE = {"time", "day", "note", "source", "detail", "description", "when", "evidence"}


def accepted_truths(case):
    """증거 수준의 참 사실 + 원장에서 참인 사실(인물 특징, 범인 특징 도출값 등)"""
    T = list(case["truth_facts"])
    for p in case["persons"]:
        for t, v in (p.get("traits") or {}).items():
            if v is not None:
                T.append({"kind": "trait", "person": p["id"], "trait": t, "value": v})
    T += [{"kind": "perp_trait", "trait": "left_handed"}, {"kind": "perp_trait", "trait": "australian"},
          {"kind": "relation", "person": "james_mccarthy", "target": "charles_mccarthy", "type": "father_son"},
          {"kind": "relation", "person": "charles_mccarthy", "target": "james_mccarthy", "type": "father_son"},
          {"kind": "presence", "person": "john_turner", "location": "boscombe_pool"},
          {"kind": "presence", "person": "john_turner", "location": "great_beech"},
          {"kind": "presence", "person": "charles_mccarthy", "location": "hatherley_path"},
          {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_path"},
          {"kind": "presence", "person": "patience_moran", "location": "moran_lodge"},
          {"kind": "presence", "person": "james_mccarthy", "location": "moran_lodge"},
          {"kind": "item_at", "item": "stone", "location": "great_beech"},
          {"kind": "third_party", "location": "pool_woods"},
          {"kind": "residence", "person": "charles_mccarthy", "location": "hatherley_farm", "adjacent_to": "boscombe_pool"}]
    return T


def low(v):
    if isinstance(v, str):
        return v.strip().lower()
    if isinstance(v, list):
        return sorted(low(x) for x in v)
    return v


def classify(f, truths):
    """모델 사실 → ("ok", 정규화 사실) | ("wrong", 이유) | ("unknown", None)
    ok: 원장의 참 사실과 맞음(덜 구체적이어도 됨) / wrong: 원장과 모순 / unknown: 원장에 없어 판단 불가"""
    if not isinstance(f, dict) or "kind" not in f:
        return "wrong", "형식 오류(객체가 아님)"
    g = {k: low(v) for k, v in f.items() if k not in IGNORE}
    k0 = g["kind"]
    # 약속 시각은 'time' 칸에 있으므로 무시 목록에서 빼기 전에 따로 본다(3시 = 15:00, 표기 차이는 인정)
    if k0 == "appointment" and f.get("time") not in (None, ""):
        t = re.sub(r"\s+", "", str(f["time"]).lower())
        if not re.fullmatch(r"(15:00|15:00:00|3:00|3:00pm|3pm|15시|3시|오후3시|오후3:00|3시경|3시쯤|오후3시경|오후3시쯤)", t):
            return "wrong", "약속 시각이 원장과 다름"
    if k0 == "dying_words" and isinstance(g.get("heard"), str) and "rat" in g["heard"]:
        g["heard"] = "a rat"
    free = FREE.get(k0, set())
    for t in truths:
        if t["kind"] != k0:
            continue
        tl = {k: low(v) for k, v in t.items()}
        for cand in ([g, {**g, "person": g.get("target"), "target": g.get("person")}] if k0 in SYMMETRIC else [g]):
            if any(k not in tl for k in cand):
                continue
            if all(k not in cand or k in free or cand[k] == tl[k] for k in tl if k != "kind"):
                # 맞은 칸은 원장의 표기(대소문자 등)로, 설명용 칸은 모델 값 그대로
                return "ok", {k: (t[k] if k in t and k not in free else v) for k, v in cand.items()}
    if k0 == "trait" and any(t["kind"] == "trait" and t["person"] == g.get("person") and t["trait"] == g.get("trait") for t in truths):
        return "wrong", "인물 특징 값이 원장과 반대"
    if k0 == "perp_trait" and g.get("trait") not in TRUE_PERP:
        return "wrong", "원장에 없는 범인 특징"
    if k0 == "weapon" and g.get("item") != "stone":
        return "wrong", "흉기가 원장과 다름"
    if k0 == "crime_scene" and g.get("location") != "boscombe_pool":
        return "wrong", "사건 장소가 원장과 다름"
    if k0 == "injury" and (g.get("side", "left") != "left" or g.get("position", "rear") != "rear"):
        return "wrong", "상처 위치가 원장과 다름"
    if k0 == "dying_words" and g.get("heard") != "a rat":
        return "wrong", "임종의 말이 원장과 다름"
    if k0 == "appointment" and g.get("time") not in (None, "15:00"):
        return "wrong", "약속 시각이 원장과 다름"
    return "unknown", None


def parse(raw):
    if isinstance(raw, dict) and "evidence" in raw:
        return raw, None
    text = raw.get("response") if isinstance(raw, dict) else None
    if not text:
        return None, (raw.get("error") if isinstance(raw, dict) else None) or "응답 없음"
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M)
    m = re.search(r"\{.*\}", text, re.S)
    try:
        return json.loads(m.group(0) if m else text), None
    except Exception as ex:
        return None, f"JSON 파싱 실패: {ex}"


def score(case, clues, story, obj, truths):
    out = {"parsed": obj is not None}
    if not obj:
        return out
    ev = [e for e in obj.get("evidence", []) if isinstance(e, dict)]
    out["n"] = len(ev)
    out["stages"] = "/".join(str(sum(1 for e in ev if e.get("stage") == s)) for s in (1, 2, 3))
    total = ok = wrong = unknown = 0
    bad = []
    norm_ev = []
    for i, e in enumerate(ev):
        e = copy.deepcopy(e)
        e.setdefault("id", f"EV{i + 1:02d}")
        for k, d in [("stage", 1), ("requires", []), ("gate_flags", []), ("title", ""), ("text", ""), ("proves", ""),
                     ("location", ""), ("object", ""), ("adaptation", None), ("quote", "")]:
            if e.get(k) is None and d is not None:
                e[k] = d
        if not isinstance(e["stage"], int):
            try:
                e["stage"] = int(e["stage"])
            except Exception:
                e["stage"] = 1
        facts = []
        for f in e.get("facts") or []:
            total += 1
            kind, val = classify(f, truths)
            if kind == "ok":
                ok += 1
                facts.append(val)
            elif kind == "wrong":
                wrong += 1
                bad.append(f"{e['id']}: {json.dumps(f, ensure_ascii=False)[:110]} ({val})")
            else:
                unknown += 1
        e["facts"] = facts
        e["original_clues"] = [c["id"] for c in clues["clues"] if c["signature"] and
                               all(any(sub(s, f) for f in facts) for s in c["signature"])]
        if not e["original_clues"] and e.get("quote"):
            e["original_clues"] = ["(원문 인용)"]
        norm_ev.append(e)
    out["fact_total"], out["fact_unknown"] = total, unknown
    out["fact_acc"] = round(ok / (ok + wrong), 3) if ok + wrong else 0.0
    out["bad_facts"] = bad
    allf = [f for e in norm_ev for f in e["facts"]]
    key = [c for c in clues["clues"] if c["key"]]
    hit = lambda c: all(any(sub(s, f) for f in allf) for s in c["signature"])
    out["key_hit"] = [c["id"] for c in key if hit(c)]
    out["key_recall"] = round(len(out["key_hit"]) / len(key), 2)
    out["all_recall"] = round(sum(hit(c) for c in clues["clues"]) / len(clues["clues"]), 2)
    qs = [e["quote"] for e in norm_ev if e.get("quote")]
    st = norm(story)
    out["quote_match"] = round(sum(1 for q in qs if all(norm(p) in st for p in q.split(" / "))) / len(qs), 2) if qs else None
    out["adaptations"] = sum(1 for e in norm_ev if e.get("adaptation"))
    out["testimony"] = sum(1 for e in norm_ev if str(e.get("type", "")).startswith("testimony") or
                           any(w in e.get("title", "") + e.get("object", "") for w in ("진술", "증언", "면담", "의 말")))
    try:
        R, why, stages, ms = run_checks(case, clues, norm_ev, story=None, persona=None)
        out["checks"] = {k: R[k] for k in USED_CHECKS}
        out["why"] = {k: why[k] for k in USED_CHECKS if not R[k]}
        out["solved"] = stages[3]["특정"]
        out["likely"] = stages[3]["유력"]
        out["strong"] = stages[3]["확인된 후보"]
        out["remaining"] = stages[3]["남은 후보"]
        out["min_set"] = len(ms)
    except Exception as ex:
        out["check_error"] = f"{type(ex).__name__}: {ex}"
    return out


def main():
    case, clues = load("case_boscombe.json"), load("original_clues.json")
    story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
    truths = accepted_truths(case)
    names = {p["id"]: p["name"] for p in case["persons"]}
    rows = []
    gold = load("evidence_boscombe.json")
    g = copy.deepcopy(gold)
    for e in g["evidence"]:
        e["quote"] = ""
    rows.append(("정답 세트 (Claude Opus 5.5, 원장 보고 작성)", "-", None, score(case, clues, story, g, truths)))
    files = sorted(list((HERE / "claude_runs").glob("*.json")) + list((HERE / "runs").glob("*.json")))
    meta = json.loads((HERE / "claude_runs" / "meta.json").read_text(encoding="utf-8")) if (HERE / "claude_runs" / "meta.json").exists() else {}
    for p in files:
        if p.name == "meta.json":
            continue
        raw = json.loads(p.read_text(encoding="utf-8"))
        obj, err = parse(raw)
        s = score(case, clues, story, obj, truths)
        s["error"] = err
        m = meta.get(p.stem, {})
        rows.append((m.get("model") or raw.get("model", p.stem), m.get("run") or raw.get("run", "?"),
                     m.get("seconds") or raw.get("seconds"), s))

    f = lambda v: "-" if v is None else v
    L = ["# 보스콤 밸리 증거 생성: 모델 비교", "",
         "- 모든 모델에 같은 프롬프트(`gen/prompt_template.md` + 원문)를 주고 증거를 만들게 했다. 정답 세트는 원장을 보고 만든 기준 데이터라 비교의 상한선이다.",
         "- 사실 정확도: 원장으로 참·거짓을 가릴 수 있는 사실 중 참인 비율. 괄호 안은 원장에 없어 판단할 수 없는 사실 수(틀린 것은 아님). 진술형 증거: 인물의 말을 옮긴 증거 수(교수님 피드백상 대화로 얻어야 할 내용). 핵심 단서: 원작 핵심 단서 10개 중 증거에 담긴 수.",
         "- 범인 특정(엄격): 다른 후보가 모두 증거로 배제되고 범인의 관계·능력·기회가 확인됨(정답 세트 기준). 유력 후보(완화): 관계·능력·기회가 모두 확인된 후보가 한 명뿐임(다른 후보의 배제 근거는 없어도 됨).",
         f"- 검증: 정답 세트용 15개 항목 중 모델 결과에 적용할 수 있는 {len(USED_CHECKS)}개({', '.join(USED_CHECKS)}). 판정기로 범인 특정 여부도 함께 본다.", "",
         "## 1. 요약", "",
         "| 데이터 | 회차 | 증거 수 (1/2/3단계) | 핵심 단서 | 전체 단서 | 사실 정확도 (원장 밖 사실) | 진술형 증거 | 인용 일치 | 각색 표시 | 검증 통과 | 범인 특정(엄격) | 유력 후보(완화) | 시간(초) |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for m, r, sec, s in rows:
        if not s.get("parsed"):
            L.append(f"| {m} | {r} | 파싱 실패 | - | - | - | - | - | - | - | - | - | {f(sec)} |")
            continue
        ck = s.get("checks")
        L.append(f"| {m} | {r} | {s['n']} ({s['stages']}) | {len(s['key_hit'])}/10 | {s['all_recall']} | {s['fact_acc']} ({s['fact_unknown']}) | {s['testimony']} | "
                 f"{f(s['quote_match'])} | {s['adaptations']} | {sum(ck.values()) if ck else '오류'}/{len(USED_CHECKS)} | "
                 f"{names.get(s.get('solved'), 'X')} | {names.get(s.get('likely'), 'X')} | {f(sec)} |")

    by = {}
    for m, r, sec, s in rows[1:]:
        by.setdefault(m, []).append(s)
    L += ["", "### 모델별 평균", "", "| 모델 | 회차 수 | 핵심 단서(평균) | 사실 정확도(평균) | 검증 통과(평균) | 범인 특정(엄격) | 유력 후보(완화) |", "|---|---|---|---|---|---|---|"]
    for m, v in by.items():
        ok = [x for x in v if x.get("parsed")]
        mean = lambda fn: round(statistics.mean([fn(x) for x in ok]), 2) if ok else "-"
        L.append(f"| {m} | {len(v)} | {mean(lambda x: len(x['key_hit']))} | {mean(lambda x: x['fact_acc'])} | "
                 f"{mean(lambda x: sum(x['checks'].values()) if x.get('checks') else 0)} | {sum(1 for x in ok if x.get('solved') == case['truth']['culprit'])}/{len(v)} | "
                 f"{sum(1 for x in ok if x.get('likely') == case['truth']['culprit'])}/{len(v)} |")

    key = [c for c in clues["clues"] if c["key"]]
    cols = ["정답 세트" if r == "-" else f"{m.replace('Claude ', '').split(' ')[0]} #{r}" for m, r, _, _ in rows]
    L += ["", "## 2. 핵심 단서 반영", "", "| 단서 | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    for c in key:
        L.append(f"| {c['id']} {c['topic']} | " + " | ".join("-" if not s.get("parsed") else ("O" if c["id"] in s["key_hit"] else "X") for *_, s in rows) + " |")
    L += ["", "## 3. 검증 항목", "", "| 항목 | " + " | ".join(cols) + " |", "|---" * (len(cols) + 1) + "|"]
    for k in USED_CHECKS:
        L.append(f"| {k} {CHECKS[k]} | " + " | ".join("-" if not s.get("checks") else ("O" if s["checks"][k] else "X") for *_, s in rows) + " |")
    L += ["", "## 4. 회차별 문제", ""]
    for m, r, sec, s in rows[1:]:
        L.append(f"### {m} #{r}")
        if not s.get("parsed"):
            L += [f"- {s.get('error')}", ""]
            continue
        L.append(f"- 놓친 핵심 단서: {', '.join(c['id'] + ' ' + c['topic'] for c in key if c['id'] not in s['key_hit']) or '없음'}")
        L.append(f"- 판정 결과: 배제되지 않은 후보 {[names[x] for x in s.get('remaining', [])]} / 관계·능력·기회가 모두 확인된 후보 {[names[x] for x in s.get('strong', [])]}")
        for k, w in (s.get("why") or {}).items():
            L.append(f"- {k} 실패: {'; '.join(map(str, w))[:300]}")
        if s.get("bad_facts"):
            L.append(f"- 원장과 모순되는 사실 {len(s['bad_facts'])}건(최대 8건 표시):")
            L += [f"  - `{b}`" for b in s["bad_facts"][:8]]
        L.append("")
    out = ROOT / "report" / "model_compare.md"
    out.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L[:len(rows) + 12]))
    print("저장:", out)


if __name__ == "__main__":
    main()
