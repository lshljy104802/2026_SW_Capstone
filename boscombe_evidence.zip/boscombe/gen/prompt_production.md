[원작]
{story}

[과제]
위 원작 소설(The Boscombe Valley Mystery)로 만든 추리 게임에 실제로 들어갈 '증거 데이터'를 작성하세요. 게임의 화면·대화 인물(페르소나)·진행 조건은 이미 만들어져 있고, 아래 [게임 슬롯]의 17개 자리에 들어갈 내용을 쓰면 됩니다. 반드시 한국어로 쓰세요(quote만 영어 원문).

[게임 설정]
- 플레이어는 사건 지도에서 장소를 고르고, 그 장소의 조사 대상을 눌러 증거를 엽니다. 증거는 3단계로 열립니다: 1 = 사건 기록(처음부터), 2 = 현장 조사, 3 = 추가 조사.
- 플레이어는 증거만으로(자백 없이) 범인을 특정할 수 있어야 하고, 1·2단계만으로는 특정할 수 없어야 합니다. 범인이 아닌 용의자(제임스, 크라우더, 페이션스)는 각각 증거로 배제할 수 있어야 합니다.
- 인물의 대화는 별도의 AI 인물이 맡습니다. 증거에는 원작 안에 실제로 있는 문서·물증·흔적·기록과, 아래 각색 설정만 씁니다.

[게임 슬롯] (id, 단계, 종류, 장소, 조사 대상, requires, gate_flags는 그대로 복사하세요)
| id | 단계 | 종류 | 장소 | 조사 대상(지도에서 누르는 이름) | 무엇을 담는 자리인가 | requires | gate_flags |
|---|---|---|---|---|---|---|---|
| EV_NEWS_REPORT | 1 | document | ross_hotel | 지역 신문 다발 | 사건을 처음 보도한 지역 신문 기사 | - | - |
| EV_GROOM_APPOINTMENT | 1 | document | ross_hotel | 신문 기사 중 마부의 증언 | 신문에 실린 매카시 집 마부의 말(사건 당일 아침의 일) | - | - |
| EV_PATIENCE_DEPOSITION | 1 | document | ross_hotel | 신문 기사 중 목격자 증언 | 신문에 실린 목격자 소녀 페이션스 모런의 증언 | - | - |
| EV_INQUEST_RECORD | 1 | document | ross_hotel | 검시 심리 기록 | 검시 심리에서 아들 제임스가 한 진술과 문답 | - | - |
| EV_ARREST_REMARK | 1 | document | ross_hotel | 경찰 기록 | 제임스를 체포할 때 그가 한 말을 적은 경찰 기록 | - | - |
| EV_SURGEON_REPORT | 1 | document | ross_hotel | 주간 지역 신문(검시 기록 전문) | 주간 지역 신문에 실린 검시 기록 전문 중 외과의 소견 | - | - |
| EV_POOL_LAYOUT | 2 | observation | boscombe_pool | 연못 전경 | 보스콤 연못 주변의 지형과 연못으로 들어오는 길 | - | scene_access_granted |
| EV_BOOTS_HATHERLEY | 2 | physical | hatherley_farm | 현관의 장화 | 해덜리 농장 현관에 있는 부자의 장화 | - | scene_access_granted |
| EV_RENT_RECORD | 2 | document | hatherley_farm | 농장 임대 서류 | 해덜리 농장의 임대 서류 | - | scene_access_granted |
| EV_TRACKS_POOL | 2 | trace | boscombe_pool | 시신이 있던 풀밭 | 시신이 있던 풀밭과 그 주변의 부자 발자국 | EV_BOOTS_HATHERLEY | scene_access_granted |
| EV_TIPTOE_TRACKS | 2 | trace | boscombe_pool | 풀밭 가장자리의 낯선 발자국 | 풀밭 가장자리에 남은 부자 외의 발자국 | EV_TRACKS_POOL | scene_access_granted |
| EV_BEECH_CIGAR | 2 | physical | great_beech | 너도밤나무 뒤의 낙엽 | 큰 너도밤나무 뒤 낙엽 속에 남은 것 | EV_TIPTOE_TRACKS | scene_access_granted |
| EV_STONE_WEAPON | 2 | physical | great_beech | 이끼 사이의 돌 | 너도밤나무 근처 이끼 사이에서 주운 돌 | EV_TIPTOE_TRACKS | scene_access_granted |
| EV_WOOD_PATH | 2 | trace | wood_path | 숲길 | 너도밤나무에서 이어지는 숲길의 흔적 | EV_TIPTOE_TRACKS | scene_access_granted |
| EV_VICTORIA_MAP | 3 | document | ross_telegraph | 전보로 받은 지도 | 브리스톨에 전보를 쳐서 받은 빅토리아 식민지 지도 | EV_INQUEST_RECORD | victoria_known |
| EV_TURNER_GAIT | 3 | testimony_record | moran_lodge | 숲지기 모런 | 숲지기 모런이 말하는 존 터너의 모습 | EV_WOOD_PATH | - |
| EV_STAFF_REGISTER | 3 | document | moran_lodge | 영지 고용인 명부 | 터너 영지의 고용인 명부 | EV_WOOD_PATH | - |

[각색 설정] 원작에 없거나 원작과 다른 곳에 나오지만 게임에 꼭 필요해 이미 정해 둔 설정입니다. 해당 슬롯에 반영하고 adaptation에 적으세요.
1. 사건 당일의 정확한 시각과 이동 시간은 게임용 설정입니다. 원작 표현(3시쯤 등)을 그대로 써도 됩니다.
2. EV_PATIENCE_DEPOSITION: 페이션스 모런은 14세 소녀로 체구가 작고 보폭이 짧습니다(판정용 설정).
3. EV_RENT_RECORD: 원작에서 레스트레이드가 전하는 '매카시는 터너에게서 해덜리 농장을 임대료 없이 빌려 쓴다'는 정보를 농장의 임대 서류로 옮깁니다.
4. EV_TRACKS_POOL: 제임스의 발자국은 양발 깊이가 고릅니다(판정용 설정).
5. EV_TURNER_GAIT: 원작 결말에서 터너가 나타날 때의 모습(키가 큰 거구, 다리를 저는 걸음)을 숲지기 모런의 증언으로 미리 확인할 수 있게 옮깁니다.
6. EV_STAFF_REGISTER: 사냥터지기 윌리엄 크라우더는 이 지방에서 나고 자란 사람으로 해외에 나간 적이 없습니다(후보 배제용 설정, 고용인 명부에 기록).

[규칙]
1. 슬롯 하나에 그 조사 대상에서 관찰할 수 있는 단서를 담습니다. 원작에서 탐정이나 경찰이 확인한 단서가 17개 슬롯 어딘가에 빠짐없이 들어가야 합니다.
2. text에는 관찰한 사실만 씁니다. 탐정의 추리나 결론(예: 왼손잡이, 다리를 전다는 결론, 범인은 누구)은 text와 title에 쓰지 말고 proves에 씁니다. 단, EV_TURNER_GAIT처럼 증인이 직접 본 모습을 말하는 것은 관찰입니다.
3. 어떤 증거에도 범인의 이름을 범행과 함께 쓰지 마세요. '범인', '범행', '살해', '자백' 같은 표현을 text와 title에 쓰지 마세요.
4. limits에는 그 증거만으로는 알 수 없는 것을 씁니다.
5. 원작에 없는 내용을 만들었다면 adaptation에 무엇을 왜 만들었는지 적고, 원작 내용이면 null로 둡니다.
6. quote에는 그 증거의 근거가 되는 원작 영어 문장을 그대로(25단어 이하) 적습니다. 여러 곳이면 ' / '로 이어 적습니다. 원작에 없는 증거면 빈 문자열.

[인물 id]
- charles_mccarthy: 피해자, 해덜리 농장 임차인
- james_mccarthy: 피해자의 아들, 체포된 피의자 (용의자)
- john_turner: 이 지역 최대 지주 (용의자)
- william_crowder: 사냥터지기, 목격자 (용의자)
- patience_moran: 숲지기의 딸(14세), 목격자 (용의자)
- alice_turner: 터너의 딸, 의뢰인
- inspector_lestrade: 경감
- moran: 숲지기 / john_cobb: 매카시 집 마부

[장소 id]
ross_hotel(로스의 호텔), ross_telegraph(로스 전신국), hatherley_farm(해덜리 농장), hatherley_path(농장에서 연못 가는 길), boscombe_pool(연못가 풀밭), pool_woods(연못 주변 숲), great_beech(큰 너도밤나무), wood_path(숲길), moran_lodge(숲지기 집), turner_hall(터너 저택), bristol(브리스톨), hereford_gaol(헤리퍼드 감옥)

[facts 표기] 증거가 입증하는 사실만 적습니다. facts의 각 항목은 문장이 아니라 아래 형식의 JSON 객체여야 합니다(해당하는 것만).
- {"kind":"presence","person":인물id,"location":장소id}  어떤 인물이 그 장소에 있었다
- {"kind":"crime_scene","location":장소id}
- {"kind":"injury","person":인물id,"part":"head","side":"left|right","position":"front|rear","cause":"blunt"}
- {"kind":"item_at","item":"james_gun","location":장소id}
- {"kind":"relation","person":인물id,"target":인물id,"type":"colonial_acquaintance|landlord_rent_free|father_son|..."}
- {"kind":"conflict","person":인물id,"target":인물id,"type":"quarrel"}
- {"kind":"trait","person":인물id,"trait":"lame|tall|australian|left_handed|local","value":true|false}  인물의 특징
- {"kind":"appointment","person":인물id,"time":"HH:MM"}
- {"kind":"signal","person":인물id,"word":"cooee","before_seeing":인물id}
- {"kind":"absence","person":인물id,"location":장소id,"known_to_victim":true|false}
- {"kind":"dying_words","person":인물id,"heard":"들린 말"}
- {"kind":"object_seen","item":"grey_cloth","location":장소id,"then":"gone"}
- {"kind":"remark","person":인물id,"content":"짧은 요약어"}
- {"kind":"reference_boots","persons":[인물id,...]}
- {"kind":"tracks","person":인물id,"pattern":"walk2_run1|pacing|..."}
- {"kind":"third_party","location":장소id}  부자 외의 제3자가 그 장소에 있었다
- {"kind":"perp_trait","trait":"lame|tall|square_boots|returned_for_item|cigar_indian|cigar_holder|blunt_knife|local|left_handed|australian"}  현장 단서가 보여 주는 범인의 특징
- {"kind":"weapon","item":"stone|gun|..."}
- {"kind":"access","location":장소id,"via":[장소id,...]}
- {"kind":"residence","person":인물id,"location":장소id,"adjacent_to":장소id}
- {"kind":"trail_end","location":"highroad"}
- {"kind":"place_name","name":"지명","region":"지역"}

[출력] 아래 JSON 하나만 출력하세요(설명 문장 없이). evidence에는 17개 슬롯이 표의 순서대로 모두 있어야 합니다.
{"evidence":[{"id":"EV_NEWS_REPORT","stage":1,"type":"document","location":"ross_hotel","object":"지역 신문 다발","title":"","text":"","facts":[...],"requires":[],"gate_flags":[],"quote":"","proves":"","limits":"","adaptation":null}]}
