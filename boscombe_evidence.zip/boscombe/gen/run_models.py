"""여러 모델로 보스콤 밸리 증거를 생성한다 (같은 프롬프트, 같은 원문)

결과는 gen/runs/<모델표기>_<시각>_<회차>.json 에 저장되고, score_models.py가 모두 모아 채점한다.

사용 예 (키는 환경변수로만)
  python gen/run_models.py --models "ollama:qwen2.5:7b,ollama:gemma3:12b" --repeats 2
  set GEMINI_API_KEY=...      (Google AI Studio 무료 키)
  python gen/run_models.py --models "gemini:gemini-2.5-flash-lite" --repeats 2
  python gen/run_models.py --models "openrouter:meta-llama/llama-3.3-70b-instruct:free"   (OPENROUTER_API_KEY)
  python gen/run_models.py --models "anthropic:claude-haiku-5-5,openai:gpt-6-luna"        (유료 키)

제공사: ollama | gemini | openrouter | groq | cerebras | mistral | nvidia | github | cohere | openai | deepseek | anthropic
환경변수: OLLAMA_URL(기본 http://localhost:11434), OLLAMA_NUM_CTX(기본 32768), LLM_TIMEOUT(초, 기본 1800),
          OLLAMA_THINK(생각 모드가 있는 모델에서 false로 두면 생각 단계를 끈다)

최종 제작(게임 슬롯 17개 채우기):
  python gen/run_models.py --prompt prompt_production.md --out runs_prod --models "ollama:qwen2.5:7b" --repeats 2
"""
import argparse
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parent
TIMEOUT = int(os.environ.get("LLM_TIMEOUT", "1800"))
OPENAI_COMPAT = {
    "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1", "OPENROUTER_API_KEY"),
    "groq": ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "deepseek": ("https://api.deepseek.com", "DEEPSEEK_API_KEY"),
    # 무료 등급이 있는 곳 (모델 이름은 각 사이트의 모델 목록에서 확인)
    "cerebras": ("https://api.cerebras.ai/v1", "CEREBRAS_API_KEY"),
    "mistral": ("https://api.mistral.ai/v1", "MISTRAL_API_KEY"),
    "nvidia": ("https://integrate.api.nvidia.com/v1", "NVIDIA_API_KEY"),
    "github": ("https://models.github.ai/inference", "GITHUB_TOKEN"),
    "cohere": ("https://api.cohere.ai/compatibility/v1", "COHERE_API_KEY"),
}
SYSTEM = "당신은 추리 소설을 게임용 증거 데이터로 바꾸는 작가입니다. 지시한 JSON 형식만 출력합니다."


def post(url, body, headers):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode('utf-8', 'replace')[:400]}") from None


def call(provider, model, prompt, temperature):
    if provider == "ollama":
        url = os.environ.get("OLLAMA_URL", "http://localhost:11434")
        body = {"model": model, "stream": False, "format": "json",
                "options": {"temperature": temperature, "num_ctx": int(os.environ.get("OLLAMA_NUM_CTX", "32768")),
                            "num_predict": int(os.environ.get("OLLAMA_NUM_PREDICT", "16384"))},
                "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}]}
        if os.environ.get("OLLAMA_THINK", "").lower() in ("false", "0", "no"):
            body["think"] = False
        r = post(url + "/api/chat", body, {})
        return r["message"]["content"], {k: r.get(k) for k in ("prompt_eval_count", "eval_count", "eval_duration", "total_duration")}
    if provider == "anthropic":
        key = os.environ.get("ANTHROPIC_API_KEY") or exit("ANTHROPIC_API_KEY 환경변수에 키를 넣어 주세요.")
        body = {"model": model, "max_tokens": 16000, "temperature": temperature, "system": SYSTEM,
                "messages": [{"role": "user", "content": prompt}]}
        r = post("https://api.anthropic.com/v1/messages", body, {"x-api-key": key, "anthropic-version": "2023-06-01"})
        return "".join(c.get("text", "") for c in r["content"] if c.get("type") == "text"), r.get("usage")
    base, key_env = OPENAI_COMPAT[provider]
    key = os.environ.get(key_env) or exit(f"{key_env} 환경변수에 키를 넣어 주세요.")
    body = {"model": model, "temperature": temperature, "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}]}
    try:
        r = post(base + "/chat/completions", body, {"Authorization": "Bearer " + key})
    except RuntimeError as e:   # temperature·json 모드를 받지 않는 모델 대비
        if "temperature" in str(e) or "response_format" in str(e):
            body.pop("temperature", None)
            body.pop("response_format", None)
            r = post(base + "/chat/completions", body, {"Authorization": "Bearer " + key})
        else:
            raise
    return r["choices"][0]["message"]["content"], r.get("usage")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", required=True, help="제공사:모델, 쉼표 구분")
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--prompt", default="prompt_template.md", help="gen/ 안의 프롬프트 파일(최종 제작은 prompt_production.md)")
    ap.add_argument("--out", default="runs", help="결과를 저장할 gen/ 안의 폴더(최종 제작은 runs_prod)")
    a = ap.parse_args()
    story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
    prompt = (HERE / a.prompt).read_text(encoding="utf-8").replace("{story}", story)
    out = HERE / a.out
    out.mkdir(exist_ok=True)
    for spec in [s.strip() for s in a.models.split(",") if s.strip()]:
        provider, model = spec.split(":", 1)
        for r in range(a.repeats):
            t0, text, err, usage = time.time(), None, None, None
            try:
                text, usage = call(provider, model, prompt, a.temperature)
            except Exception as ex:
                err = f"호출 실패: {ex}"
                print(f"  ! {spec} {r + 1}회차 {err}")
            sec = round(time.time() - t0, 1)
            name = re.sub(r"[^A-Za-z0-9._-]+", "_", spec) + time.strftime("_%m%d-%H%M%S") + f"_{r + 1}.json"
            (out / name).write_text(json.dumps({"model": spec, "run": r + 1, "seconds": sec, "error": err, "usage": usage,
                                                "prompt": a.prompt, "temperature": a.temperature, "response": text},
                                               ensure_ascii=False, indent=1), encoding="utf-8")
            print(f"{spec} {r + 1}회차: {sec}초, 응답 {len(text or '')}자 → gen/{a.out}/{name}")


if __name__ == "__main__":
    main()
