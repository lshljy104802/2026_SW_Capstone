"""독립 검토(원문 대조)용 프롬프트를 만든다. 데이터 이름은 가린다(검토자는 누가 만들었는지 모른다).

python review/make_review.py <라벨> <증거 JSON 경로>  → review/<라벨>_prompt.md, review/<라벨>_key.json
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
label, path = sys.argv[1], Path(sys.argv[2])
raw = json.loads(path.read_text(encoding="utf-8"))
ev = raw["evidence"] if "evidence" in raw else raw
story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
prod = (ROOT / "gen" / "prompt_production.md").read_text(encoding="utf-8")
adapt = prod[prod.index("[각색 설정]"):prod.index("[규칙]")].strip()
sents, key = [], []
for e in ev:
    for fld in ("title", "text"):
        for s in re.split(r"(?<=[.!?])\s+", (e.get(fld) or "").strip()):
            if s.strip():
                sid = f"S{len(sents) + 1:03d}"
                sents.append(f"{sid} [{e.get('id')}·{'제목' if fld == 'title' else '본문'}] {s.strip()}")
                key.append({"sid": sid, "evidence": e.get("id"), "field": fld, "sentence": s.strip()})
prompt = f"""[원작]
{story}

[게임용 각색 설정] 아래 내용은 게임 제작자가 일부러 정한 설정이므로 원작에 없어도 '각색'으로 인정한다.
{adapt}

[과제]
너는 추리 게임 증거 데이터의 사실 검수자다. 아래 문장들은 위 원작으로 만든 게임 증거의 제목과 본문이다.
문장마다 원작(또는 각색 설정)에 근거가 있는지 판정하라. 누가 만든 데이터인지는 알려 주지 않는다.

판정(label)
- original: 원작에 근거가 있다(번역·요약·말 바꾸기는 인정. 원작이 확인해 준 사실과 같은 뜻이면 된다)
- adaptation: 원작에는 없지만 위 각색 설정에 근거가 있다
- unsupported: 원작에도 각색 설정에도 근거가 없는 내용이 들어 있다(사소한 꾸밈말은 제외, 사실 주장만)
- contradicted: 원작이나 각색 설정과 어긋나는 내용이 있다
문장 하나에 여러 사실이 있으면 가장 나쁜 판정을 준다(contradicted > unsupported > adaptation > original).

[문장 목록]
{chr(10).join(sents)}

[출력] 아래 JSON 하나만 출력하라.
{{"items":[{{"sid":"S001","label":"original","quote":"근거가 된 원작 영어 구절(20단어 이하, 없으면 빈 문자열)","note":"unsupported·contradicted일 때 무엇이 문제인지 한국어로 짧게"}}]}}
문장 목록의 모든 sid를 빠짐없이 순서대로 넣어라.
"""
out = ROOT / "review"
(out / f"{label}_prompt.md").write_text(prompt, encoding="utf-8")
(out / f"{label}_key.json").write_text(json.dumps({"source": str(path), "sentences": key}, ensure_ascii=False, indent=1), encoding="utf-8")
print(label, len(sents), "문장")
