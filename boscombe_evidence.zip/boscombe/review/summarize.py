"""독립 검토 결과 정리 → report/review.md, report/review.json"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path("/tmp/claude-0/-home-claude/4dcdd97f-c8b0-5eca-9636-9642664ed9d6/scratchpad/review_out")
LM = json.loads((ROOT / "review" / "label_map.json").read_text())
LM["K"] = "gold"
NAME = {"gold": "정답 세트(원장 기반)", "fable_1": "Fable 5.1 #1", "fable_2": "Fable 5.1 #2", "haiku_2": "Haiku 5.5 #2",
        "opus_2": "Opus 5.5 #2", "sonnet_1": "Sonnet 5.5 #1", "sonnet_2": "Sonnet 5.5 #2",
        "qwen25_1": "qwen2.5:7b #1", "qwen25_2": "qwen2.5:7b #2", "qwen35_1": "qwen3.5:9b #1", "qwen35_2": "qwen3.5:9b #2"}
BAD = {"unsupported", "contradicted"}
rank = {"original": 0, "adaptation": 1, "unsupported": 2, "contradicted": 3}
rows, detail, agree_all = [], {}, []
for L, src in sorted(LM.items(), key=lambda x: list(NAME).index(x[1])):
    key = json.loads((ROOT / "review" / f"{L}_key.json").read_text())["sentences"]
    R = {}
    for rv in ("fable", "sonnet"):
        p = OUT / f"{L}_{rv}.json"
        if p.exists():
            R[rv] = {x["sid"]: x for x in json.loads(p.read_text())["items"]}
    if len(R) < 2:
        continue
    n = len(key)
    cnt = {rv: {k: sum(1 for x in R[rv].values() if x["label"] == k) for k in rank} for rv in R}
    same = sum(1 for s in key if R["fable"].get(s["sid"], {}).get("label") == R["sonnet"].get(s["sid"], {}).get("label"))
    a = [R["fable"].get(s["sid"], {}).get("label") in BAD for s in key]
    b = [R["sonnet"].get(s["sid"], {}).get("label") in BAD for s in key]
    agree_all += list(zip(a, b))
    either = [s for s, x, y in zip(key, a, b) if x or y]
    both = [s for s, x, y in zip(key, a, b) if x and y]
    rows.append((src, n, cnt, same, len(both), len(either)))
    detail[src] = [{"sentence": s["sentence"], "evidence": s["evidence"],
                    "fable": R["fable"][s["sid"]]["label"], "sonnet": R["sonnet"][s["sid"]]["label"],
                    "note": (R["fable"][s["sid"]].get("note") or "") + " / " + (R["sonnet"][s["sid"]].get("note") or "")}
                   for s in either]
# 이진 판정(문제 있음/없음) 일치도와 카파
po = sum(1 for x, y in agree_all if x == y) / len(agree_all)
px, py = sum(x for x, _ in agree_all) / len(agree_all), sum(y for _, y in agree_all) / len(agree_all)
pe = px * py + (1 - px) * (1 - py)
kappa = (po - pe) / (1 - pe) if pe < 1 else 1.0
L = ["# 독립 검토(원문 대조) 결과", "",
     "- 검토자 2명(Claude Fable 5.1, Claude Sonnet 5.5)이 데이터 이름을 모른 채 증거의 제목·본문 문장을 원문·각색 설정과 대조했다.",
     "- Ollama 결과(qwen2.5:7b, qwen3.5:9b)는 나중에 받아 같은 프롬프트로 검토했다. 이때 Fable 검토자는 Claude Fable 5.2였다.",
     "- 문제 문장: unsupported(근거 없음) 또는 contradicted(모순). '둘 다'는 두 검토자가 모두 문제로 본 문장, '한 명 이상'은 어느 한쪽이라도 문제로 본 문장.",
     f"- 검토자 간 일치: 문제 여부 일치율 {po:.3f}, 카파 {kappa:.2f} (문장 {len(agree_all)}개)", "",
     "| 데이터 | 문장 수 | Fable 판정(원문/각색/근거 없음/모순) | Sonnet 판정 | 라벨 일치율 | 문제 문장(둘 다) | 문제 문장(한 명 이상) | 문제 비율(한 명 이상) |",
     "|---|---|---|---|---|---|---|---|"]
for src, n, cnt, same, both, either in rows:
    f = lambda c: "/".join(str(c[k]) for k in rank)
    L.append(f"| {NAME[src]} | {n} | {f(cnt['fable'])} | {f(cnt['sonnet'])} | {same / n:.2f} | {both} | {either} | {either / n:.3f} |")
L += ["", "## 문제로 본 문장", ""]
for src, items in detail.items():
    L.append(f"### {NAME[src]}")
    if not items:
        L += ["- 없음", ""]
        continue
    for it in items:
        L.append(f"- [{it['evidence']}] {it['sentence']} — Fable: {it['fable']}, Sonnet: {it['sonnet']}. {it['note'].strip(' /')}")
    L.append("")
(ROOT / "report" / "review.md").write_text("\n".join(L) + "\n", encoding="utf-8")
json.dump({"rows": [{"source": r[0], "n": r[1], "counts": r[2], "same": r[3], "both": r[4], "either": r[5]} for r in rows],
           "po": po, "kappa": kappa, "detail": detail}, open(ROOT / "report" / "review.json", "w"), ensure_ascii=False, indent=1)
print("\n".join(L[:14]))
