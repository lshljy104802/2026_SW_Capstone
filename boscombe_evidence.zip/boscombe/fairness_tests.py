"""정답 세트·판정기 공정성 검사 → report/fairness.md

T1 이름 바꾸기: 증거의 인물 id를 서로 바꾸면 판정 결과도 그 사람으로 바뀌는가(특정 인물을 하드코딩하지 않음)
T2 순서 바꾸기: 증거 순서를 무작위로 50번 섞어도 결과가 같은가
T3 규칙 제거: 판정 규칙을 하나씩 끄면 정답 세트가 어떻게 되는가(어떤 규칙에 기대는지)
T4 각색 의존도: 원작에 없는 '배제용 설정' 사실을 빼면 정답 세트가 풀리는가
T5 모델 결과 보정: 모델 결과에 그 배제용 설정 3개만 넣어 주면 엄격 판정이 풀리는가(기준이 정답 세트에 유리한지)
T6 규칙 근거: 판정 규칙마다 원문 근거 문장이 원문에 실제로 있는가
T7 판정 불가 사실: 모델 결과에서 원장으로 판단할 수 없었던 사실 목록(사람이 원문과 대조할 대상)
"""
import copy
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "gen"))
import solver  # noqa: E402
from solver import judge, load, stage_ids  # noqa: E402
from score_models import accepted_truths, classify, parse  # noqa: E402

case, gold = load("case_boscombe.json"), load("evidence_boscombe.json")["evidence"]
story = (ROOT / "story" / "boscombe_valley.txt").read_text(encoding="utf-8")
names = {p["id"]: p["name"] for p in case["persons"]}
N = lambda x: names.get(x, "불가") if x else "불가"
L = ["# 정답 세트·판정기 공정성 검사", "", "`python fairness_tests.py`로 다시 만들 수 있다.", ""]


def solve(ev, stage=3):
    r = judge(case, ev, stage_ids(ev, stage))
    return r["특정"], r["유력"], r["남은 후보"]


def swap(ev, a, b):
    ev = copy.deepcopy(ev)
    for e in ev:
        for f in e["facts"]:
            for k in ("person", "target"):
                if f.get(k) == a:
                    f[k] = b
                elif f.get(k) == b:
                    f[k] = a
    return ev


# T1
L += ["## T1 이름 바꾸기", "", "| 바꾼 두 사람 | 기대 결과 | 1단계 | 2단계 | 3단계 | 통과 |", "|---|---|---|---|---|---|"]
t1 = []
for a, b in [("john_turner", "william_crowder"), ("john_turner", "james_mccarthy"), ("john_turner", "patience_moran")]:
    ev = swap(gold, a, b)
    res = [solve(ev, s)[0] for s in (1, 2, 3)]
    ok = res == [None, None, b]
    t1.append(ok)
    L.append(f"| {names[a]} ↔ {names[b]} | {names[b]} | {N(res[0])} | {N(res[1])} | {N(res[2])} | {'O' if ok else 'X'} |")

# T2
random.seed(0)
base = [solve(gold, s) for s in (1, 2, 3)]
same = 0
for _ in range(50):
    ev = copy.deepcopy(gold)
    random.shuffle(ev)
    same += [solve(ev, s) for s in (1, 2, 3)] == base
L += ["", "## T2 순서 바꾸기", "", f"증거 순서를 무작위로 50번 섞음 → 단계별 결과가 같은 경우 {same}/50", ""]

# T3
orig_pt, orig_pp, orig_distinct = solver.perp_traits, solver.person_traits, solver.DISTINCT


def no_left(facts):
    t = orig_pt(facts)
    t.discard("left_handed")
    return t


def no_aus(facts):
    t = orig_pt(facts)
    t.discard("australian")
    return t


def no_tracks(facts, pid):
    out = {f["trait"]: f["value"] for f in facts if f["kind"] == "trait" and f["person"] == pid}
    if any(f["kind"] == "residence" and f["person"] == pid for f in facts):
        out.setdefault("local", True)
    return out


def no_resid(facts, pid):
    out = orig_pp(facts, pid)
    if not any(f["kind"] == "trait" and f["person"] == pid and f["trait"] == "local" for f in facts):
        out.pop("local", None)
    return out


ablations = [
    ("왼쪽 뒤 상처 → 왼손잡이", "perp_traits", no_left),
    ("'a rat' + Ballarat → 호주 출신", "perp_traits", no_aus),
    ("절뚝임 없는 본인 발자국 → 다리를 절지 않음", "person_traits", no_tracks),
    ("연못 옆 거주 → 이 지방 사람", "person_traits", no_resid),
    ("능력 확인에 신체 특징 1개 필요(DISTINCT)", "DISTINCT", set(solver.ABILITY)),
]
L += ["## T3 규칙 하나씩 끄기 (정답 세트)", "", "| 끈 규칙 | 2단계 특정 | 3단계 특정 | 3단계 남은 후보 | 해석 |", "|---|---|---|---|---|"]
for label, attr, repl in ablations:
    setattr(solver, attr, repl)
    s2, s3 = solve(gold, 2), solve(gold, 3)
    setattr(solver, "perp_traits", orig_pt)
    setattr(solver, "person_traits", orig_pp)
    setattr(solver, "DISTINCT", orig_distinct)
    note = "결과 같음(이 데이터에서는 필수 아님)" if (s2[0], s3[0]) == (None, "john_turner") else (
        "너무 일찍 풀림" if s2[0] else "풀리지 않음(필수 규칙)")
    L.append(f"| {label} | {N(s2[0])} | {N(s3[0])} | {', '.join(N(x) for x in s3[2])} | {note} |")

# T4
ADAPT = [("EV_PATIENCE_DEPOSITION", "patience_moran", "tall", "페이션스 보폭이 짧음"),
         ("EV_TRACKS_POOL", "james_mccarthy", "lame", "제임스 양발 깊이가 고름"),
         ("EV_STAFF_REGISTER", "william_crowder", "australian", "크라우더는 이 지방 태생")]


def drop_adapt(ev, which):
    ev = copy.deepcopy(ev)
    for e in ev:
        for eid, pid, tr, _ in which:
            if e["id"] == eid:
                e["facts"] = [f for f in e["facts"] if not (f["kind"] == "trait" and f.get("person") == pid and f.get("trait") == tr)]
    return ev


L += ["", "## T4 각색 의존도 (정답 세트)", "", "원작에 없는 '배제용 설정' 사실을 빼고 다시 판정했다.", "",
      "| 뺀 설정 | 3단계 특정 | 유력 후보 | 남은 후보 |", "|---|---|---|---|"]
for item in ADAPT + [None]:
    which = ADAPT if item is None else [item]
    s = solve(drop_adapt(gold, which))
    L.append(f"| {'세 가지 모두' if item is None else item[3]} | {N(s[0])} | {N(s[1])} | {', '.join(N(x) for x in s[2])} |")
# 제임스: 판정용 설정 없이 원작의 발자국만으로도 배제되는가(발자국 규칙)
ev = drop_adapt(gold, [ADAPT[1]])
jt = judge(case, ev, stage_ids(ev, 3))["후보"]["james_mccarthy"]
L += ["", f"제임스의 '다리를 절지 않음' 설정을 빼도 발자국 규칙으로 배제되는가: {'예' if jt['배제'] else '아니오'} (어긋난 특징 {jt['어긋난 특징']})"]

# T5
truths = accepted_truths(case)
gold_by_id = {e["id"]: e for e in gold}
patch = [{"kind": "trait", "person": pid, "trait": tr, "value": False} for _, pid, tr, _ in ADAPT]
L += ["", "## T5 모델 결과에 배제용 설정 3개만 넣어 주기", "",
      "모델 결과의 사실을 채점기와 같은 방식으로 정규화한 뒤, 3단계 증거 하나(위 세 설정 사실만 담음)를 더해 다시 판정했다.", "",
      "| 실행 | 원래 엄격 | 원래 유력 | 보정 후 엄격 | 보정 후 남은 후보 |", "|---|---|---|---|---|"]
meta = json.loads((ROOT / "gen" / "claude_runs" / "meta.json").read_text(encoding="utf-8"))
unknown = {}
for p in sorted((ROOT / "gen" / "claude_runs").glob("*.json")):
    if p.name == "meta.json":
        continue
    obj, err = parse(json.loads(p.read_text(encoding="utf-8")))
    ev = []
    for i, e in enumerate(obj["evidence"]):
        facts = []
        for f in e.get("facts") or []:
            k, v = classify(f, truths)
            if k == "ok":
                facts.append(v)
            elif k == "unknown":
                key = json.dumps({a: b for a, b in f.items() if a not in ("note",)}, ensure_ascii=False, sort_keys=True)
                unknown.setdefault(key, set()).add(p.stem)
        try:
            st = int(e.get("stage", 1))
        except Exception:
            st = 1
        ev.append({"id": e.get("id", f"EV{i}"), "stage": st, "facts": facts})
    before = solve(ev)
    after = solve(ev + [{"id": "PATCH", "stage": 3, "facts": patch}])
    L.append(f"| {p.stem} | {N(before[0])} | {N(before[1])} | {N(after[0])} | {', '.join(N(x) for x in after[2])} |")

# T6
RULE_QUOTES = [
    ("왼쪽 뒤 상처 → 왼손잡이", ["struck from immediately behind, and yet was upon the left side"]),
    ("발자국 → 다리를 절고 키가 큼", ["limps with the right leg", "tall man"]),
    ("임종의 말 + 지명 → 호주 발라랏 출신", ["a rat", "ARAT", "BALLARAT"]),
    ("네모 장화", ["Square, too, quite unusual boots"]),
    ("시가·홀더·칼", ["Indian cigar", "cigar-holder", "blunt pen-knife"]),
]
low = " ".join(story.split()).lower()
L += ["", "## T6 판정 규칙의 원문 근거", "", "| 규칙 | 찾은 원문 표현 | 원문에 있음 |", "|---|---|---|"]
for rule, qs in RULE_QUOTES:
    found = [q for q in qs if q.lower() in low]
    L.append(f"| {rule} | {' / '.join(qs)} | {len(found)}/{len(qs)} |")

# T7
L += ["", "## T7 원장으로 판정할 수 없었던 모델 사실", "", f"서로 다른 사실 {len(unknown)}개. 여러 실행에서 나온 것부터 원문과 대조한다.", "",
      "| 사실 | 나온 실행 수 |", "|---|---|"]
for k, v in sorted(unknown.items(), key=lambda x: -len(x[1])):
    L.append(f"| `{k}` | {len(v)} |")

(ROOT / "report").mkdir(exist_ok=True)
(ROOT / "report" / "fairness.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print("\n".join(L))
