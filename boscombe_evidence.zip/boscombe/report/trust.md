# 채점 도구 신뢰 시험

`python trust_tests.py`로 다시 만들 수 있다.

## A. 사실 분류기 변이 시험

- 정답 세트 사실 44개 중 '참'으로 분류: 44/44
- 값을 틀리게 바꾼 사실 20개 중 '틀림'으로 잡음: 20/20

| 증거 | 사실 종류 | 바꾼 값 | 분류 |
|---|---|---|---|
| EV_NEWS_REPORT | crime_scene | location: boscombe_pool → turner_hall | 틀림 |
| EV_NEWS_REPORT | trait | value: True → False | 틀림 |
| EV_GROOM_APPOINTMENT | appointment | time: 15:00 → 16:00 | 틀림 |
| EV_PATIENCE_DEPOSITION | trait | value: False → True | 틀림 |
| EV_INQUEST_RECORD | dying_words | heard: a rat → a cat | 틀림 |
| EV_SURGEON_REPORT | injury | side: left → right | 틀림 |
| EV_SURGEON_REPORT | injury | position: rear → front | 틀림 |
| EV_POOL_LAYOUT | perp_trait | trait: local → short | 틀림 |
| EV_TRACKS_POOL | trait | value: False → True | 틀림 |
| EV_TIPTOE_TRACKS | perp_trait | trait: lame → short | 틀림 |
| EV_TIPTOE_TRACKS | perp_trait | trait: tall → short | 틀림 |
| EV_TIPTOE_TRACKS | perp_trait | trait: square_boots → short | 틀림 |
| EV_TIPTOE_TRACKS | perp_trait | trait: returned_for_item → short | 틀림 |
| EV_BEECH_CIGAR | perp_trait | trait: cigar_indian → short | 틀림 |
| EV_BEECH_CIGAR | perp_trait | trait: cigar_holder → short | 틀림 |
| EV_BEECH_CIGAR | perp_trait | trait: blunt_knife → short | 틀림 |
| EV_STONE_WEAPON | weapon | item: stone → gun | 틀림 |
| EV_TURNER_GAIT | trait | value: True → False | 틀림 |
| EV_TURNER_GAIT | trait | value: True → False | 틀림 |
| EV_STAFF_REGISTER | trait | value: False → True | 틀림 |

## B. 최종 제작 채점기 결함 주입

- 결함 없는 정답 세트: 필수 조건 통과
- 결함 10종 중 필수 조건에서 떨어뜨리고 원인을 맞게 표시: 10/10

| 결함 | 기대 원인 | 실제로 걸린 항목 | 탐지 |
|---|---|---|---|
| 슬롯 하나 삭제(고용인 명부) | 슬롯 누락, B6 | B3, B6, B11, 슬롯 누락, 슬롯 칸 오류, 범인 특정 실패 | O |
| 조사 대상 이름을 바꿈 | 슬롯 칸 오류 | 슬롯 칸 오류 | O |
| 원장과 모순되는 사실(흉기=총) | B1 | B1 | O |
| 증거 문장에 추리 결론 | B8 | B8 | O |
| 지도 문장에 지명 가리기 수법(ARAT) | B8 | B8 | O |
| 해석 칸에 범인 이름과 범행 | B9 | B9 | O |
| 원작에 없는 인용 | B14 | B14 | O |
| 임종의 말 사실 누락 | B2, 범인 특정 실패 | B2, B3, B6, 범인 특정 실패 | O |
| 까치발 발자국의 범인 특징 사실 삭제 | 범인 특정 실패 | B2, B3, B6, 범인 특정 실패 | O |
| 출처·각색 메모 삭제 | B11 | B11 | O |

## C. 표기 별칭

| 모델 표기 | 맞춘 값 | 분류 |
|---|---|---|
| `{"kind": "place_name", "name": "발라랏", "region": "빅토리아"}` | Ballarat | ok |
| `{"kind": "place_name", "name": "밸러랫(Ballarat)", "region": "Victoria"}` | Ballarat | ok |
| `{"kind": "dying_words", "person": "charles_mccarthy", "heard": "...a rat"}` | a rat | ok |
| `{"kind": "dying_words", "person": "charles_mccarthy", "heard": "쥐(a rat)"}` | a rat | ok |

## 결론

- A 사실 분류기: 통과
- B 결함 주입: 통과
- C 별칭: 통과
