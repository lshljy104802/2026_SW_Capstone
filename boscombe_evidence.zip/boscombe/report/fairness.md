# 정답 세트·판정기 공정성 검사

`python fairness_tests.py`로 다시 만들 수 있다.

## T1 이름 바꾸기

| 바꾼 두 사람 | 기대 결과 | 1단계 | 2단계 | 3단계 | 통과 |
|---|---|---|---|---|---|
| 존 터너 ↔ 윌리엄 크라우더 | 윌리엄 크라우더 | 불가 | 불가 | 윌리엄 크라우더 | O |
| 존 터너 ↔ 제임스 매카시 | 제임스 매카시 | 불가 | 불가 | 제임스 매카시 | O |
| 존 터너 ↔ 페이션스 모런 | 페이션스 모런 | 불가 | 불가 | 페이션스 모런 | O |

## T2 순서 바꾸기

증거 순서를 무작위로 50번 섞음 → 단계별 결과가 같은 경우 50/50

## T3 규칙 하나씩 끄기 (정답 세트)

| 끈 규칙 | 2단계 특정 | 3단계 특정 | 3단계 남은 후보 | 해석 |
|---|---|---|---|---|
| 왼쪽 뒤 상처 → 왼손잡이 | 불가 | 존 터너 | 존 터너 | 결과 같음(이 데이터에서는 필수 아님) |
| 'a rat' + Ballarat → 호주 출신 | 불가 | 불가 | 존 터너, 윌리엄 크라우더 | 풀리지 않음(필수 규칙) |
| 절뚝임 없는 본인 발자국 → 다리를 절지 않음 | 불가 | 존 터너 | 존 터너 | 결과 같음(이 데이터에서는 필수 아님) |
| 연못 옆 거주 → 이 지방 사람 | 불가 | 존 터너 | 존 터너 | 결과 같음(이 데이터에서는 필수 아님) |
| 능력 확인에 신체 특징 1개 필요(DISTINCT) | 불가 | 존 터너 | 존 터너 | 결과 같음(이 데이터에서는 필수 아님) |

## T4 각색 의존도 (정답 세트)

원작에 없는 '배제용 설정' 사실을 빼고 다시 판정했다.

| 뺀 설정 | 3단계 특정 | 유력 후보 | 남은 후보 |
|---|---|---|---|
| 페이션스 보폭이 짧음 | 불가 | 존 터너 | 존 터너, 페이션스 모런 |
| 제임스 양발 깊이가 고름 | 존 터너 | 존 터너 | 존 터너 |
| 크라우더는 이 지방 태생 | 불가 | 존 터너 | 존 터너, 윌리엄 크라우더 |
| 세 가지 모두 | 불가 | 존 터너 | 존 터너, 윌리엄 크라우더, 페이션스 모런 |

제임스의 '다리를 절지 않음' 설정을 빼도 발자국 규칙으로 배제되는가: 예 (어긋난 특징 ['lame'])

## T5 모델 결과에 배제용 설정 3개만 넣어 주기

모델 결과의 사실을 채점기와 같은 방식으로 정규화한 뒤, 3단계 증거 하나(위 세 설정 사실만 담음)를 더해 다시 판정했다.

| 실행 | 원래 엄격 | 원래 유력 | 보정 후 엄격 | 보정 후 남은 후보 |
|---|---|---|---|---|
| haiku_1 | 불가 | 불가 | 불가 | 존 터너 |
| haiku_2 | 불가 | 불가 | 불가 | 존 터너, 윌리엄 크라우더 |
| opus_1 | 불가 | 존 터너 | 존 터너 | 존 터너 |
| opus_2 | 불가 | 존 터너 | 존 터너 | 존 터너 |
| sonnet_1 | 불가 | 존 터너 | 존 터너 | 존 터너 |
| sonnet_2 | 불가 | 존 터너 | 존 터너 | 존 터너 |

## T6 판정 규칙의 원문 근거

| 규칙 | 찾은 원문 표현 | 원문에 있음 |
|---|---|---|
| 왼쪽 뒤 상처 → 왼손잡이 | struck from immediately behind, and yet was upon the left side | 1/1 |
| 발자국 → 다리를 절고 키가 큼 | limps with the right leg / tall man | 2/2 |
| 임종의 말 + 지명 → 호주 발라랏 출신 | a rat / ARAT / BALLARAT | 3/3 |
| 네모 장화 | Square, too, quite unusual boots | 1/1 |
| 시가·홀더·칼 | Indian cigar / cigar-holder / blunt pen-knife | 3/3 |

## T7 원장으로 판정할 수 없었던 모델 사실

서로 다른 사실 32개. 여러 실행에서 나온 것부터 원문과 대조한다.

| 사실 | 나온 실행 수 |
|---|---|
| `{"content": "opposed_marriage", "kind": "remark", "person": "john_turner"}` | 3 |
| `{"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}` | 3 |
| `{"item": "james_gun", "kind": "item_at", "location": "hatherley_path"}` | 2 |
| `{"kind": "presence", "location": "hatherley_farm", "person": "charles_mccarthy"}` | 2 |
| `{"kind": "presence", "location": "bristol", "person": "james_mccarthy"}` | 2 |
| `{"kind": "presence", "location": "ross_hotel", "person": "john_turner"}` | 2 |
| `{"kind": "presence", "location": "boscombe_pool", "person": "inspector_lestrade"}` | 2 |
| `{"content": "혼담에 반대", "kind": "remark", "person": "john_turner"}` | 2 |
| `{"kind": "presence", "location": "pool_woods", "person": "charles_mccarthy"}` | 1 |
| `{"kind": "presence", "location": "pool_woods", "person": "james_mccarthy"}` | 1 |
| `{"kind": "conflict", "person": "john_turner", "target": "charles_mccarthy", "type": "long_standing_pressure"}` | 1 |
| `{"kind": "place_name", "name": "빅토리아 식민지", "region": "호주"}` | 1 |
| `{"content": "결혼 반대", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"kind": "place_name", "name": "발라랏", "region": "빅토리아 식민지"}` | 1 |
| `{"kind": "conflict", "person": "john_turner", "target": "charles_mccarthy", "type": "threat"}` | 1 |
| `{"kind": "tracks", "pattern": "into_pool", "person": "inspector_lestrade"}` | 1 |
| `{"kind": "tracks", "pattern": "trampled_around_body", "person": "moran"}` | 1 |
| `{"content": "quarrel_about_marriage", "kind": "remark", "person": "alice_turner"}` | 1 |
| `{"kind": "place_name", "name": "Victoria", "region": "Australia"}` | 1 |
| `{"kind": "tracks", "pattern": "inward_twist_left_into_pool", "person": "inspector_lestrade"}` | 1 |
| `{"kind": "tracks", "pattern": "trampled_6_8ft_around_body", "person": "moran"}` | 1 |
| `{"content": "pressed_son_to_marry_alice", "kind": "remark", "person": "charles_mccarthy"}` | 1 |
| `{"kind": "relation", "person": "charles_mccarthy", "target": "john_turner", "type": "tenant"}` | 1 |
| `{"content": "gravely_ill_about_sixty", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"kind": "place_name", "name": "Boscombe Valley", "region": "Herefordshire"}` | 1 |
| `{"kind": "presence", "location": "pool_woods", "person": "john_turner"}` | 1 |
| `{"content": "인도산 시가 소지", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"content": "시가 홀더 소지", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"content": "무딘 주머니칼 소지", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"content": "회색 외투 소지", "kind": "remark", "person": "john_turner"}` | 1 |
| `{"content": "매카시가 결혼을 몹시 원함", "kind": "remark", "person": "alice_turner"}` | 1 |
| `{"adjacent_to": "turner_hall", "kind": "residence", "location": "hatherley_farm", "person": "charles_mccarthy"}` | 1 |
