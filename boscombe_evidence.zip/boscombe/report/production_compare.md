# 보스콤 밸리 증거 최종 제작: 모델 비교

- 모든 모델에 같은 프롬프트(`gen/prompt_production.md` + 원문)를 주었다. 게임 슬롯 17개(ID·단계·장소·조사 대상·선행 증거·진행 조건)는 고정하고 내용만 쓰게 했다.
- 정답 세트는 사건 원장을 보고 만든 기준 데이터다. 채점 기준(원장)과 출처가 같으므로 비교의 상한선으로만 본다.
- 사실 정확도: 원장으로 참·거짓을 가릴 수 있는 사실 중 참인 비율. 판단 불가: 원장에 없어 사람이 확인해야 하는 사실 수.
- 정답 사실 회수율: 정답 세트가 각 슬롯에 담은 사실 중 모델이 같은 슬롯에 담은 비율.
- 범인 특정: 판정기가 1·2·3단계 증거로 각각 범인을 특정하는지(엄격 기준). 정상은 '불가·불가·존 터너'.

## 선정 기준(결과를 보기 전에 정함)

```
[필수 조건] 하나라도 어기면 게임에 넣지 않는다
 1. JSON을 읽을 수 있고, 17개 슬롯이 모두 있으며 슬롯 칸(단계·종류·장소·조사 대상·선행 증거·진행 조건)을 그대로 지켰다
 2. 원장과 모순되는 사실이 0건이다(B1)
 3. 적용 가능한 검증 항목 B2~B14를 모두 통과한다
 4. 판정기가 3단계에서 범인을 엄격 기준으로 특정한다(1·2단계에서는 특정하지 못한다)
[순위] 필수 조건을 통과한 데이터끼리
 1. 정답 세트 사실 회수율(슬롯별)이 높은 것
 2. 원장으로 판단할 수 없는 사실이 적은 것(검수 부담)
 3. 원문 인용 일치율이 높은 것
 4. 독립 검토(원문 대조)에서 근거 없는 문장이 적은 것
```

## 1. 요약

| 데이터 | 회차 | 슬롯 17개 | 슬롯 칸 오류 | 사실 정확도 | 틀린 사실 | 판단 불가 | 정답 사실 회수율 | 핵심 단서 | 인용 일치 | 검증 통과 | 단계별 특정 | 필수 조건 | 시간(초) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 정답 세트(원장 기반) | - | 17/17 | 0 | 1.0 | 0 | 0 | 1.0 | 10/10 | 1.0 | 14/14 | 불가 · 불가 · 존 터너 | O | - |
| Claude Fable 5.1 | 1 | 17/17 | 0 | 1.0 | 0 | 10 | 0.886 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 189.4 |
| Claude Fable 5.1 | 2 | 17/17 | 0 | 1.0 | 0 | 8 | 0.932 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 202.5 |
| Claude Haiku 5.5 | 1 | 17/17 | 0 | 1.0 | 0 | 6 | 0.795 | 9/10 | 0.94 | 10/14 | 불가 · 불가 · 불가 | X | 216.2 |
| Claude Haiku 5.5 | 2 | 17/17 | 0 | 1.0 | 0 | 3 | 0.818 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 224.6 |
| Claude Opus 5.5 | 1 | 17/17 | 0 | 1.0 | 0 | 5 | 0.932 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 330.6 |
| Claude Opus 5.5 | 2 | 17/17 | 0 | 1.0 | 0 | 5 | 0.932 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 211.8 |
| Claude Sonnet 5.5 | 1 | 17/17 | 0 | 1.0 | 0 | 2 | 0.841 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 222.8 |
| Claude Sonnet 5.5 | 2 | 17/17 | 0 | 1.0 | 0 | 3 | 0.909 | 10/10 | 1.0 | 13/14 | 불가 · 불가 · 존 터너 | X | 242.4 |
| ollama:qwen2.5:7b | 1 | 17/17 | 21 | 0.955 | 1 | 16 | 0.205 | 3/10 | 0.71 | 8/14 | 불가 · 불가 · 불가 | X | 384.1 |
| ollama:qwen2.5:7b | 2 | 7/17 | 67 | 0.75 | 1 | 2 | 0.045 | 1/10 | 1.0 | 9/14 | 불가 · 불가 · 불가 | X | 56.5 |
| ollama:qwen3.5:9b | 1 | 17/17 | 2 | 1.0 | 0 | 6 | 0.364 | 7/10 | 0.91 | 8/14 | 불가 · 불가 · 불가 | X | 197.9 |
| ollama:qwen3.5:9b | 2 | 17/17 | 1 | 1.0 | 0 | 10 | 0.455 | 6/10 | - | 9/14 | 불가 · 불가 · 불가 | X | 111.0 |

### 모델별

| 모델 | 회차 | 필수 조건 통과 | 사실 정확도(평균) | 정답 사실 회수율(평균) | 판단 불가(평균) | 인용 일치(평균) | 평균 시간(초) |
|---|---|---|---|---|---|---|---|
| Claude Fable 5.1 | 2 | 0/2 | 1.0 | 0.909 | 9 | 1.0 | 195.9 |
| Claude Haiku 5.5 | 2 | 0/2 | 1.0 | 0.806 | 4.5 | 0.97 | 220.4 |
| Claude Opus 5.5 | 2 | 0/2 | 1.0 | 0.932 | 5 | 1.0 | 271.2 |
| Claude Sonnet 5.5 | 2 | 0/2 | 1.0 | 0.875 | 2.5 | 1.0 | 232.6 |
| ollama:qwen2.5:7b | 2 | 0/2 | 0.853 | 0.125 | 9 | 0.855 | 220.3 |
| ollama:qwen3.5:9b | 2 | 0/2 | 1.0 | 0.409 | 8 | 0.455 | 154.4 |

## 2. 검증 항목

| 항목 | 정답 세트 | Fable 5.1 #1 | Fable 5.1 #2 | Haiku 5.5 #1 | Haiku 5.5 #2 | Opus 5.5 #1 | Opus 5.5 #2 | Sonnet 5.5 #1 | Sonnet 5.5 #2 | qwen2.5:7b #1 | qwen2.5:7b #2 | qwen3.5:9b #1 | qwen3.5:9b #2 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| B1 증거-원장 정합성 | O | O | O | O | O | O | O | O | O | X | X | O | O |
| B2 원작 핵심 단서 반영 | O | O | O | X | O | O | O | O | O | X | X | X | X |
| B3 최종 단계 해결 가능 | O | O | O | X | O | O | O | O | O | X | X | X | X |
| B4 조기 해결 불가 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B5 단일 증거로 범인 특정 불가 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B6 범인이 아닌 후보마다 배제 근거 존재 | O | O | O | O | O | O | O | O | O | X | X | X | X |
| B7 다단계 추론 필요 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B8 관찰 사실만 기술 | O | X | X | X | X | X | X | X | X | X | O | X | O |
| B9 정답 누출 없음 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B10 단계·선행 조건 정상 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B11 출처 표시 | O | O | O | O | O | O | O | O | O | O | X | X | X |
| B12 지도 배치 정보 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B13 페르소나 파트 증거 ID와 정합 | O | O | O | O | O | O | O | O | O | O | O | O | O |
| B14 원작 인용 확인 | O | O | O | X | O | O | O | O | O | X | O | X | X |

## 3. 슬롯별 정답 사실 회수

| 슬롯 | 정답 세트 | Fable 5.1 #1 | Fable 5.1 #2 | Haiku 5.5 #1 | Haiku 5.5 #2 | Opus 5.5 #1 | Opus 5.5 #2 | Sonnet 5.5 #1 | Sonnet 5.5 #2 | qwen2.5:7b #1 | qwen2.5:7b #2 | qwen3.5:9b #1 | qwen3.5:9b #2 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| EV_NEWS_REPORT | 7/7 | 6/7 | 5/7 | 1/7 | 4/7 | 5/7 | 5/7 | 4/7 | 7/7 | 0/7 | 0/7 | 0/7 | 2/7 |
| EV_GROOM_APPOINTMENT | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 0/1 | 1/1 | 1/1 |
| EV_PATIENCE_DEPOSITION | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 0/3 | 0/3 | 1/3 | 1/3 |
| EV_INQUEST_RECORD | 6/6 | 4/6 | 6/6 | 6/6 | 5/6 | 6/6 | 6/6 | 6/6 | 5/6 | 0/6 | 1/6 | 2/6 | 2/6 |
| EV_ARREST_REMARK | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 |
| EV_SURGEON_REPORT | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 1/1 |
| EV_POOL_LAYOUT | 4/4 | 3/4 | 3/4 | 2/4 | 2/4 | 3/4 | 3/4 | 3/4 | 3/4 | 0/4 | 0/4 | 1/4 | 1/4 |
| EV_BOOTS_HATHERLEY | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 1/1 |
| EV_RENT_RECORD | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 1/1 |
| EV_TRACKS_POOL | 4/4 | 3/4 | 4/4 | 3/4 | 2/4 | 4/4 | 4/4 | 3/4 | 3/4 | 0/4 | 0/4 | 2/4 | 3/4 |
| EV_TIPTOE_TRACKS | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 | 3/5 | 5/5 | 1/5 | 0/5 | 0/5 | 1/5 |
| EV_BEECH_CIGAR | 4/4 | 4/4 | 4/4 | 4/4 | 4/4 | 4/4 | 4/4 | 4/4 | 3/4 | 0/4 | 0/4 | 0/4 | 0/4 |
| EV_STONE_WEAPON | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 1/1 |
| EV_WOOD_PATH | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 1/1 | 1/1 |
| EV_VICTORIA_MAP | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 0/1 | 1/1 | 1/1 |
| EV_TURNER_GAIT | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 0/2 | 2/2 | 2/2 |
| EV_STAFF_REGISTER | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 0/1 | 0/1 | 0/1 | 0/1 |

## 4. 회차별 문제

### Claude Fable 5.1 #1
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 10건(최대 6건): `EV_NEWS_REPORT: {"kind": "relation", "person": "john_turner", "target": "alice_turner", "type": "father_daughter"}`; `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_GROOM_APPOINTMENT: {"kind": "presence", "person": "john_cobb", "location": "hatherley_farm"}`; `EV_INQUEST_RECORD: {"kind": "absence", "person": "james_mccarthy", "location": "hatherley_farm", "known_to_victim": false}`; `EV_INQUEST_RECORD: {"kind": "presence", "person": "james_mccarthy", "location": "bristol"}`; `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`
- 증거 문장 평균 285자, 한국어 비율 0.99

### Claude Fable 5.1 #2
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 8건(최대 6건): `EV_NEWS_REPORT: {"kind": "relation", "person": "john_turner", "target": "alice_turner", "type": "father_daughter"}`; `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_GROOM_APPOINTMENT: {"kind": "presence", "person": "john_cobb", "location": "hatherley_farm"}`; `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`; `EV_WOOD_PATH: {"kind": "third_party", "location": "wood_path"}`; `EV_WOOD_PATH: {"kind": "residence", "person": "moran", "location": "moran_lodge", "adjacent_to": "wood_path"}`
- 증거 문장 평균 308자, 한국어 비율 0.99

### Claude Haiku 5.5 #1
- 단계별 특정: 불가 · 불가 · 불가 / 3단계 남은 후보 ['존 터너']
- B2 실패: C14
- B3 실패: 특정 결과: None; 남은 후보: ['john_turner']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/
- B14 실패: There is no sign of a place whence it had been taken.; This is a map of the Colony of Victoria.
- 원장으로 판단할 수 없는 사실 6건(최대 6건): `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_NEWS_REPORT: {"kind": "relation", "person": "william_crowder", "target": "john_turner", "type": "employee"}`; `EV_GROOM_APPOINTMENT: {"kind": "relation", "person": "john_cobb", "target": "charles_mccarthy", "type": "employee"}`; `EV_PATIENCE_DEPOSITION: {"kind": "presence", "person": "charles_mccarthy", "location": "pool_woods"}`; `EV_PATIENCE_DEPOSITION: {"kind": "presence", "person": "james_mccarthy", "location": "pool_woods"}`; `EV_STAFF_REGISTER: {"kind": "relation", "person": "william_crowder", "target": "john_turner", "type": "employee"}`
- 증거 문장 평균 150자, 한국어 비율 0.98

### Claude Haiku 5.5 #2
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 3건(최대 6건): `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_NEWS_REPORT: {"kind": "place_name", "name": "Ross", "region": "Herefordshire"}`; `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`
- 증거 문장 평균 158자, 한국어 비율 0.99

### Claude Opus 5.5 #1
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_STONE_WEAPON: '상처와 들어맞'; EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/
- 원장으로 판단할 수 없는 사실 5건(최대 6건): `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_NEWS_REPORT: {"kind": "relation", "person": "john_turner", "target": "charles_mccarthy", "type": "landlord"}`; `EV_TRACKS_POOL: {"kind": "tracks", "person": "inspector_lestrade", "pattern": "inward_twist_into_reeds"}`; `EV_STAFF_REGISTER: {"kind": "relation", "person": "william_crowder", "target": "john_turner", "type": "employee"}`; `EV_STAFF_REGISTER: {"kind": "relation", "person": "moran", "target": "patience_moran", "type": "father_daughter"}`
- 증거 문장 평균 237자, 한국어 비율 0.99

### Claude Opus 5.5 #2
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 5건(최대 6건): `EV_NEWS_REPORT: {"kind": "trait", "person": "charles_mccarthy", "trait": "australian", "value": true}`; `EV_GROOM_APPOINTMENT: {"kind": "presence", "person": "charles_mccarthy", "location": "hatherley_farm"}`; `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`; `EV_WOOD_PATH: {"kind": "third_party", "location": "wood_path"}`; `EV_STAFF_REGISTER: {"kind": "residence", "person": "moran", "location": "moran_lodge", "adjacent_to": "wood_path"}`
- 증거 문장 평균 239자, 한국어 비율 0.99

### Claude Sonnet 5.5 #1
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 2건(최대 6건): `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`; `EV_WOOD_PATH: {"kind": "residence", "person": "moran", "location": "moran_lodge", "adjacent_to": "wood_path"}`
- 증거 문장 평균 213자, 한국어 비율 0.99

### Claude Sonnet 5.5 #2
- 단계별 특정: 불가 · 불가 · 존 터너 / 3단계 남은 후보 ['존 터너']
- B8 실패: EV_VICTORIA_MAP: /(?<![A-Za-z])ARAT(?![A-Za-z])/; EV_VICTORIA_MAP: /앞부분을 (손으로 )?가리/
- 원장으로 판단할 수 없는 사실 3건(최대 6건): `EV_INQUEST_RECORD: {"kind": "absence", "person": "james_mccarthy", "location": "hatherley_farm", "known_to_victim": false}`; `EV_ARREST_REMARK: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`; `EV_STAFF_REGISTER: {"kind": "residence", "person": "patience_moran", "location": "moran_lodge", "adjacent_to": "boscombe_pool"}`
- 증거 문장 평균 240자, 한국어 비율 0.99

### ollama:qwen2.5:7b #1
- 슬롯 칸을 바꿈: EV_GROOM_APPOINTMENT.object, EV_GROOM_APPOINTMENT.requires, EV_GROOM_APPOINTMENT.gate_flags, EV_PATIENCE_DEPOSITION.object, EV_PATIENCE_DEPOSITION.requires, EV_PATIENCE_DEPOSITION.gate_flags, EV_INQUEST_RECORD.requires, EV_INQUEST_RECORD.gate_flags, EV_ARREST_REMARK.requires, EV_ARREST_REMARK.gate_flags, EV_SURGEON_REPORT.requires, EV_SURGEON_REPORT.gate_flags
- 단계별 특정: 불가 · 불가 · 불가 / 3단계 남은 후보 ['제임스 매카시', '존 터너', '윌리엄 크라우더', '페이션스 모런']
- B1 실패: EV_BEECH_CIGAR: {"kind": "weapon", "item": "cigar_indian"} (흉기가 원장과 다름)
- B2 실패: C01; C02; C03; C04; C08; C13; C14
- B3 실패: 특정 결과: None; 남은 후보: ['james_mccarthy', 'john_turner', 'william_crowder', 'patience_moran']
- B6 실패: 제임스 매카시; 윌리엄 크라우더; 페이션스 모런
- B8 실패: EV_NEWS_REPORT: '범행'; EV_ARREST_REMARK: '자백'
- B14 실패: I saw the latter raise up his hand as if to strike his fathe; I was not surprised to hear it, and that it was no more than; It was the butt-end of the gun as the son stood listening.; He had a very fine carriage, and a large and very strong man; He had never been abroad, and was a native of the dist
- 원장과 모순되는 사실 1건:
  - `EV_BEECH_CIGAR: {"kind": "weapon", "item": "cigar_indian"} (흉기가 원장과 다름)`
- 원장으로 판단할 수 없는 사실 16건(최대 6건): `EV_NEWS_REPORT: {"kind": "appointment", "person": "john_turner", "time": "15:00"}`; `EV_NEWS_REPORT: {"kind": "signal", "person": "john_turner", "word": "Cooee", "before_seeing": "james_mccarthy"}`; `EV_GROOM_APPOINTMENT: {"kind": "appointment", "person": "john_turner", "time": "15:00"}`; `EV_GROOM_APPOINTMENT: {"kind": "relation", "person": "john_cobb", "target": "charles_mccarthy", "type": "groom"}`; `EV_PATIENCE_DEPOSITION: {"kind": "signal", "person": "john_turner", "word": "Cooee", "before_seeing": "james_mccarthy"}`; `EV_PATIENCE_DEPOSITION: {"kind": "conflict", "person": "john_turner", "target": "james_mccarthy", "type": "quarrel"}`
- 증거 문장이 비었거나 너무 짧음: EV_STONE_WEAPON, EV_WOOD_PATH
- 증거 문장 평균 30자, 한국어 비율 1.0

### ollama:qwen2.5:7b #2
- 빠진 슬롯: EV_BOOTS_HATHERLEY, EV_RENT_RECORD, EV_TRACKS_POOL, EV_TIPTOE_TRACKS, EV_BEECH_CIGAR, EV_STONE_WEAPON, EV_WOOD_PATH, EV_VICTORIA_MAP, EV_TURNER_GAIT, EV_STAFF_REGISTER
- 슬롯 칸을 바꿈: EV_GROOM_APPOINTMENT.requires, EV_GROOM_APPOINTMENT.gate_flags, EV_PATIENCE_DEPOSITION.requires, EV_PATIENCE_DEPOSITION.gate_flags, EV_INQUEST_RECORD.requires, EV_INQUEST_RECORD.gate_flags, EV_ARREST_REMARK.requires, EV_ARREST_REMARK.gate_flags, EV_SURGEON_REPORT.requires, EV_SURGEON_REPORT.gate_flags, EV_POOL_LAYOUT.gate_flags, EV_BOOTS_HATHERLEY.stage
- 단계별 특정: 불가 · 불가 · 불가 / 3단계 남은 후보 ['제임스 매카시', '존 터너', '윌리엄 크라우더', '페이션스 모런']
- B1 실패: EV_SURGEON_REPORT: {"kind": "injury", "person": "charles_mccarthy", "part": "head", "side": "left", "position": "front", "cause": (상처 위치가 원장과 다름)
- B2 실패: C02; C03; C04; C05; C07; C08; C13; C14; C16
- B3 실패: 특정 결과: None; 남은 후보: ['james_mccarthy', 'john_turner', 'william_crowder', 'patience_moran']
- B6 실패: 제임스 매카시; 윌리엄 크라우더; 페이션스 모런
- B11 실패: EV_POOL_LAYOUT; EV_BOOTS_HATHERLEY; EV_RENT_RECORD; EV_TRACKS_POOL; EV_TIPTOE_TRACKS; EV_BEECH_CIGAR; EV_STONE_WEAPON; EV_WOOD_PATH; EV_VICTORIA_MAP; EV_TURNER_GAIT; EV_STAFF_REGISTER
- 원장과 모순되는 사실 1건:
  - `EV_SURGEON_REPORT: {"kind": "injury", "person": "charles_mccarthy", "part": "head", "side": "left", "position": "front", "cause": (상처 위치가 원장과 다름)`
- 원장으로 판단할 수 없는 사실 2건(최대 6건): `EV_GROOM_APPOINTMENT: {"kind": "track", "person": "john_turner", "pattern": "walk1"}`; `EV_PATIENCE_DEPOSITION: {"kind": "track", "person": "patience_moran", "pattern": "tiptoe1"}`
- 증거 문장이 비었거나 너무 짧음: EV_BOOTS_HATHERLEY, EV_RENT_RECORD, EV_TRACKS_POOL, EV_TIPTOE_TRACKS, EV_BEECH_CIGAR, EV_STONE_WEAPON, EV_WOOD_PATH, EV_VICTORIA_MAP, EV_TURNER_GAIT, EV_STAFF_REGISTER
- 증거 문장 평균 31자, 한국어 비율 0.85

### ollama:qwen3.5:9b #1
- 슬롯 칸을 바꿈: EV_SURGEON_REPORT.object, EV_STONE_WEAPON.location
- 단계별 특정: 불가 · 불가 · 불가 / 3단계 남은 후보 ['제임스 매카시', '존 터너', '윌리엄 크라우더', '페이션스 모런']
- B2 실패: C04; C07; C08
- B3 실패: 특정 결과: None; 남은 후보: ['james_mccarthy', 'john_turner', 'william_crowder', 'patience_moran']
- B6 실패: 제임스 매카시; 윌리엄 크라우더; 페이션스 모런
- B8 실패: EV_BEECH_CIGAR: '시가 홀더'
- B11 실패: EV_NEWS_REPORT; EV_TIPTOE_TRACKS; EV_BEECH_CIGAR
- B14 실패: I heard Mr. McCarthy the elder using very strong language to
- 원장으로 판단할 수 없는 사실 6건(최대 6건): `EV_PATIENCE_DEPOSITION: {"kind": "presence", "person": "patience_moran", "location": "boscombe_pool"}`; `EV_PATIENCE_DEPOSITION: {"kind": "remark", "person": "patience_moran", "content": "두 사람이 싸우고 있었고 아들이 아버지를 때릴 듯했다 / 아버지가 죽은 후 그 옷을 보지 못`; `EV_INQUEST_RECORD: {"kind": "absence", "person": "james_mccarthy", "location": "boscombe_pool", "known_to_victim": true}`; `EV_TIPTOE_TRACKS: {"kind": "tracks", "person": "john_turner", "pattern": "tiptoe_return"}`; `EV_BEECH_CIGAR: {"kind": "item_at", "item": "cigar_ash", "location": "great_beech"}`; `EV_STAFF_REGISTER: {"kind": "presence", "person": "william_crowder", "location": "hatherley_farm"}`
- 증거 문장이 비었거나 너무 짧음: EV_NEWS_REPORT, EV_GROOM_APPOINTMENT, EV_PATIENCE_DEPOSITION, EV_INQUEST_RECORD, EV_ARREST_REMARK, EV_SURGEON_REPORT
- 증거 문장 평균 39자, 한국어 비율 0.98

### ollama:qwen3.5:9b #2
- 슬롯 칸을 바꿈: EV_SURGEON_REPORT.object
- 단계별 특정: 불가 · 불가 · 불가 / 3단계 남은 후보 ['제임스 매카시', '존 터너', '윌리엄 크라우더', '페이션스 모런']
- B2 실패: C04; C07; C08; C14
- B3 실패: 특정 결과: None; 남은 후보: ['james_mccarthy', 'john_turner', 'william_crowder', 'patience_moran']
- B6 실패: 제임스 매카시; 윌리엄 크라우더; 페이션스 모런
- B11 실패: EV_NEWS_REPORT; EV_TIPTOE_TRACKS; EV_BEECH_CIGAR; EV_WOOD_PATH
- B14 실패: 
- 원장으로 판단할 수 없는 사실 10건(최대 6건): `EV_GROOM_APPOINTMENT: {"kind": "presence", "person": "moran", "location": "hatherley_farm"}`; `EV_PATIENCE_DEPOSITION: {"kind": "trait", "person": "patience_moran", "trait": "small", "value": true}`; `EV_INQUEST_RECORD: {"kind": "presence", "person": "james_mccarthy", "location": "hatherley_farm"}`; `EV_INQUEST_RECORD: {"kind": "presence", "person": "moran", "location": "hatherley_farm"}`; `EV_POOL_LAYOUT: {"kind": "trait", "person": "charles_mccarthy", "trait": "local", "value": true}`; `EV_TIPTOE_TRACKS: {"kind": "trait", "person": "unknown_perpetrator", "trait": "left_handed", "value": true}`
- 증거 문장 평균 71자, 한국어 비율 1.0

## 5. 필수 조건 통과 데이터의 순위

필수 조건을 모두 통과한 모델 데이터가 없다.
