"""보스콤 밸리 증거 데이터 검증: 15개 항목(B1~B15) + 결함 주입 테스트

  python validate.py                          # 검증 + 결함 주입 → report/validation.md
  python validate.py --persona boscombe_personas.json   # 페르소나 파일 ID 정합성(B13)까지
"""
import argparse
import copy
import json
import re
import sys
from pathlib import Path

from solver import ROOT, judge, load, stage_ids

CHECKS = {
    "B1": "증거-원장 정합성 (증거의 모든 사실이 원장의 참 사실 목록에 있음)",
    "B2": "원작 핵심 단서 반영 (핵심 단서마다 그 사실을 담은 증거가 있음)",
    "B3": "최종 단계 해결 가능 (공개 증거만으로 범인 유일 특정, 관계·능력·기회 모두 확인)",
    "B4": "조기 해결 불가 (1·2단계에서는 특정 불가)",
    "B5": "단일 증거로 범인 특정 불가 (선행 증거 포함)",
    "B6": "범인이 아닌 후보마다 배제 근거 존재",
    "B7": "다단계 추론 필요 (최소 해결 증거 5개 이상·3단계 모두 사용, 증거 결합이 필요한 배제 존재)",
    "B8": "관찰 사실만 기술 (증거 문장·제목에 추리 표현 없음)",
    "B9": "정답 누출 없음 (범인 이름과 범행 표현이 함께 나오지 않음)",
    "B10": "단계·선행 조건 정상 (참조 존재, 선행 증거가 같거나 앞 단계, 순환 없음, 진행 조건 이름 정상)",
    "B11": "출처 표시 (원작 단서 번호 또는 각색 메모가 모든 증거에 있음)",
    "B12": "지도 배치 정보 (모든 증거에 원장의 장소와 조사 대상 이름이 있음)",
    "B13": "페르소나 파트 증거 ID와 정합 (--persona 지정 시)",
    "B14": "원작 인용 확인 (모든 단서 인용이 원문에 있음)",
    "B15": "원장 내부 정합성 (범행 시각이 사망 추정 시각대 안, 인물 특징과 사실 일치, 범인은 후보)",
}
INFERENCE_WORDS = ["범인", "범행", "살인자", "살해", "왼손잡이", "시가 홀더", "주머니칼", "Black Jack", "발라랏 갱", "발라랫 갱", "자백",
                   "A RAT", "끝 두 음절", "상처와 들어맞"]
# 낱말 목록으로 못 잡는 추리 표현(정규식). 지명 앞을 가려 'ARAT'을 보여 주는 것은 탐정의 추리 과정이다
INFERENCE_RE = [r"(?<![A-Za-z])ARAT(?![A-Za-z])", r"앞부분을 (손으로 )?가리", r"아랫.{0,12}발라랫|발라랫.{0,12}아랫", r"발 아랫"]
CRIME_WORDS = ["쳤", "죽였", "살해", "범인", "범행", "흉기를 휘둘"]
GATES = {"scene_access_granted", "victoria_known"}


def sub(sig, f):
    return all(f.get(k) == v for k, v in sig.items())


def norm(s):
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"').replace("—", "-")
    return re.sub(r"\s+", " ", s).strip().lower()


def closure(ev_by, eid):
    out, stack = set(), [eid]
    while stack:
        x = stack.pop()
        if x in out or x not in ev_by:
            continue
        out.add(x)
        stack += ev_by[x]["requires"]
    return out


def valid_set(ev_by, ids):
    return all(r in ids for i in ids for r in ev_by[i]["requires"])


def minimal_set(case, evidence):
    ev_by = {e["id"]: e for e in evidence}
    ids = {e["id"] for e in evidence}
    for e in sorted(evidence, key=lambda x: (-x["stage"], x["id"])):
        trial = ids - {e["id"]}
        if valid_set(ev_by, trial) and judge(case, evidence, trial)["특정"] == case["truth"]["culprit"]:
            ids = trial
    return sorted(ids, key=lambda i: (ev_by[i]["stage"], i))


def run_checks(case, clues, evidence, story=None, persona=None):
    R, why = {}, {}
    ev_by = {e["id"]: e for e in evidence}
    culprit = case["truth"]["culprit"]
    truth = case["truth_facts"]
    names = {p["id"]: p["name"] for p in case["persons"]}

    bad = [f"{e['id']}: {json.dumps(f, ensure_ascii=False)}" for e in evidence for f in e["facts"] if f not in truth]
    R["B1"], why["B1"] = not bad, bad[:5]

    allf = [f for e in evidence for f in e["facts"]]
    miss = [c["id"] for c in clues["clues"] if c["key"] and not all(any(sub(s, f) for f in allf) for s in c["signature"])]
    R["B2"], why["B2"] = not miss, miss

    stages = {s: judge(case, evidence, stage_ids(evidence, s)) for s in (1, 2, 3)}
    R["B3"], why["B3"] = stages[3]["특정"] == culprit, [f"특정 결과: {stages[3]['특정']}", f"남은 후보: {stages[3]['남은 후보']}"]
    early = [s for s in (1, 2) if stages[s]["특정"]]
    R["B4"], why["B4"] = not early, [f"{s}단계에서 특정됨" for s in early]

    singles = [e["id"] for e in evidence if judge(case, evidence, closure(ev_by, e["id"]))["특정"]]
    R["B5"], why["B5"] = not singles, singles

    final = stages[3]["후보"]
    noex = [names[p] for p, v in final.items() if p != culprit and not v["배제"]]
    R["B6"], why["B6"] = not noex, noex

    ms = minimal_set(case, evidence)
    ms_stages = {ev_by[i]["stage"] for i in ms}
    combo = []
    for p in final:
        if p == culprit:
            continue
        if not any(judge(case, evidence, closure(ev_by, e["id"]))["후보"][p]["배제"] for e in evidence):
            combo.append(names[p])
    ok7 = len(ms) >= 5 and ms_stages == {1, 2, 3} and bool(combo)
    R["B7"], why["B7"] = ok7, [f"최소 해결 증거 {len(ms)}개(단계 {sorted(ms_stages)})", f"결합해야 배제되는 후보: {combo}"]

    hits = [f"{e['id']}: '{w}'" for e in evidence for w in INFERENCE_WORDS if w in e["text"] or w in e["title"]]
    hits += [f"{e['id']}: /{r}/" for e in evidence for r in INFERENCE_RE if re.search(r, e["text"] + " " + e["title"])]
    R["B8"], why["B8"] = not hits, hits

    cn = names[culprit].split()[-1]
    leak = [e["id"] for e in evidence for fld in ("text", "title", "proves")
            for sent in re.split(r"[.!?]\s", e[fld]) if cn in sent and any(w in sent for w in CRIME_WORDS)]
    R["B9"], why["B9"] = not leak, sorted(set(leak))

    probs = []
    for e in evidence:
        for r in e["requires"]:
            if r not in ev_by:
                probs.append(f"{e['id']} → 없는 증거 {r}")
            elif ev_by[r]["stage"] > e["stage"]:
                probs.append(f"{e['id']}({e['stage']}단계) → {r}({ev_by[r]['stage']}단계)")
        if e["id"] in closure({k: v for k, v in ev_by.items()}, e["id"]) - {e["id"]} or \
           any(e["id"] in closure(ev_by, r) for r in e["requires"] if r in ev_by):
            probs.append(f"{e['id']} 순환")
        probs += [f"{e['id']} 알 수 없는 진행 조건 {g}" for g in e["gate_flags"] if g not in GATES]
    R["B10"], why["B10"] = not probs, probs

    nosrc = [e["id"] for e in evidence if not e["original_clues"] and not e.get("adaptation")]
    R["B11"], why["B11"] = not nosrc, nosrc

    locs = {l["id"] for l in case["locations"]}
    noloc = [e["id"] for e in evidence if e["location"] not in locs or not e.get("object")]
    R["B12"], why["B12"] = not noloc, noloc

    if persona:
        pids = {x["id"] for x in persona.get("evidence_items", [])}
        miss13 = sorted(pids - set(ev_by))
        R["B13"], why["B13"] = not miss13, miss13
    else:
        R["B13"], why["B13"] = True, ["페르소나 파일 미지정(건너뜀)"]

    if story:
        st = norm(story)
        badq = [f"{c['id']}: {q[:40]}" for c in clues["clues"] for q in c["quote"].split(" / ") if norm(q) not in st]
        R["B14"], why["B14"] = not badq, badq
    else:
        R["B14"], why["B14"] = False, ["원문 텍스트 없음"]

    p15 = []
    dw = case["death_window"]
    blow = next(ev for ev in case["events"] if ev["id"] == "T11")
    if not (dw["start"] <= blow["time"] <= dw["end"]):
        p15.append("범행 시각이 사망 추정 시각대 밖")
    for p in case["persons"]:
        for t, v in (p.get("traits") or {}).items():
            for f in truth:
                if f["kind"] == "trait" and f["person"] == p["id"] and f["trait"] == t and f["value"] != v:
                    p15.append(f"{p['id']}.{t}: 인물 설정 {v} ≠ 사실 {f['value']}")
    if not next(p for p in case["persons"] if p["id"] == culprit).get("suspect"):
        p15.append("범인이 후보 목록에 없음")
    R["B15"], why["B15"] = not p15, p15
    return R, why, stages, ms


# ---------------------------------------------------------------- 결함 주입
def mutations(evidence, clues):
    E = lambda: copy.deepcopy(evidence)
    C = lambda: copy.deepcopy(clues)
    out = []

    def m(mid, desc, expect, ev=None, cl=None):
        out.append((mid, desc, expect, ev if ev is not None else E(), cl if cl is not None else C()))

    ev = [e for e in E() if e["id"] not in ("EV_TIPTOE_TRACKS", "EV_BEECH_CIGAR", "EV_STONE_WEAPON", "EV_WOOD_PATH", "EV_TURNER_GAIT", "EV_STAFF_REGISTER")]
    m("M1", "까치발 발자국 증거(와 이어진 증거) 삭제", ["B2", "B3"], ev)
    ev = E()
    for e in ev:
        if e["stage"] == 3:
            e["stage"] = 2
    m("M2", "3단계 증거를 모두 2단계로 앞당김", ["B4"], ev)
    ev = E()
    ev[0]["facts"].append({"kind": "presence", "person": "william_crowder", "location": "boscombe_pool"})
    m("M3", "원장에 없는 사실 추가(크라우더가 연못가에 있었다)", ["B1"], ev)
    ev = E()
    next(e for e in ev if e["id"] == "EV_SURGEON_REPORT")["text"] += " 범인은 왼손잡이다."
    m("M4", "증거 문장에 추리 결론을 씀", ["B8"], ev)
    ev = E()
    e = next(e for e in ev if e["id"] == "EV_WOOD_PATH")
    e["original_clues"], e["adaptation"] = [], None
    m("M5", "출처와 각색 메모를 모두 지움", ["B11"], ev)
    ev = E()
    next(e for e in ev if e["id"] == "EV_TRACKS_POOL")["requires"].append("EV_VICTORIA_MAP")
    m("M6", "2단계 증거가 3단계 증거를 선행 조건으로 요구", ["B10"], ev)
    m("M7", "고용인 명부 삭제(크라우더 배제 근거 없음)", ["B3", "B6"], [e for e in E() if e["id"] != "EV_STAFF_REGISTER"])
    ev = E()
    e = next(e for e in ev if e["id"] == "EV_INQUEST_RECORD")
    e["facts"] = [f for f in e["facts"] if f["kind"] != "dying_words"]
    m("M8", "임종의 말 'a rat' 사실 누락", ["B2", "B3"], ev)
    ev = E()
    next(e for e in ev if e["id"] == "EV_STONE_WEAPON")["location"] = "secret_cellar"
    m("M9", "원장에 없는 장소에 증거 배치", ["B12"], ev)
    cl = C()
    cl["clues"][2]["quote"] = "He said clearly that a rat had bitten him."
    m("M10", "원작에 없는 인용으로 바꿈", ["B14"], cl=cl)
    ev = E()
    next(e for e in ev if e["id"] == "EV_TIPTOE_TRACKS")["proves"] += " 터너가 돌아와서 망토를 챙긴 뒤 매카시를 쳤다."
    m("M11", "해석 칸에 범인 이름과 범행을 함께 씀", ["B9"], ev)
    ev = E()
    g = next(e for e in ev if e["id"] == "EV_TURNER_GAIT")
    g["facts"] += [{"kind": "trait", "person": "william_crowder", "trait": "australian", "value": False},
                   {"kind": "trait", "person": "james_mccarthy", "trait": "lame", "value": False},
                   {"kind": "trait", "person": "patience_moran", "trait": "tall", "value": False},
                   {"kind": "perp_trait", "trait": "lame"}, {"kind": "perp_trait", "trait": "tall"},
                   {"kind": "relation", "person": "john_turner", "target": "charles_mccarthy", "type": "colonial_acquaintance"},
                   {"kind": "residence", "person": "john_turner", "location": "turner_hall", "adjacent_to": "boscombe_pool"},
                   {"kind": "dying_words", "person": "charles_mccarthy", "heard": "a rat"},
                   {"kind": "place_name", "name": "Ballarat", "region": "Victoria"}]
    m("M12", "증거 하나에 결정적 사실을 몰아넣음", ["B5"], ev)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--persona", help="페르소나 파일(boscombe_personas.json) 경로")
    a = ap.parse_args()
    case, clues, evidence = load("case_boscombe.json"), load("original_clues.json"), load("evidence_boscombe.json")["evidence"]
    sp = ROOT / "story" / "boscombe_valley.txt"
    story = sp.read_text(encoding="utf-8") if sp.exists() else None
    persona = json.loads(Path(a.persona).read_text(encoding="utf-8")) if a.persona else None

    R, why, stages, ms = run_checks(case, clues, evidence, story, persona)
    names = {p["id"]: p["name"] for p in case["persons"]}
    L = ["# 보스콤 밸리 증거 데이터 검증 결과", "",
         f"- 증거 {len(evidence)}개 (단계별 " + "/".join(str(sum(1 for e in evidence if e['stage'] == s)) for s in (1, 2, 3)) + f"), 원작 단서 {len(clues['clues'])}개(핵심 {sum(c['key'] for c in clues['clues'])}개)",
         f"- 통과 {sum(R.values())}/{len(R)}", "", "## 검증 항목", "", "| 항목 | 내용 | 결과 | 비고 |", "|---|---|---|---|"]
    for k, d in CHECKS.items():
        L.append(f"| {k} | {d} | {'통과' if R[k] else '실패'} | {'; '.join(why[k])} |")
    L += ["", "## 단계별 판정", "", "| 단계 | 범인 특징 | 남은 후보 | 특정 |", "|---|---|---|---|"]
    for s, r in stages.items():
        L.append(f"| {s} | {', '.join(r['범인 특징'])} | {', '.join(names[x] for x in r['남은 후보'])} | {names.get(r['특정'], '불가')} |")
    L += ["", "### 최종 단계 후보별 판정", "", "| 후보 | 관계 | 능력 | 기회 | 어긋난 특징 | 일치한 특징 |", "|---|---|---|---|---|---|"]
    for p, v in stages[3]["후보"].items():
        L.append(f"| {names[p]} | {v['관계']} | {v['능력']} | {v['기회']} | {', '.join(v['어긋난 특징']) or '-'} | {', '.join(v['일치한 특징']) or '-'} |")
    L += ["", f"### 최소 해결 증거 ({len(ms)}개)", "", ", ".join(ms), ""]

    L += ["## 결함 주입 테스트", "", "| 결함 | 내용 | 기대 항목 | 실제 실패 항목 | 탐지 |", "|---|---|---|---|---|"]
    caught = 0
    for mid, desc, expect, ev, cl in mutations(evidence, clues):
        r, *_ = run_checks(case, cl, ev, story, persona)
        failed = [k for k, v in r.items() if not v]
        ok = all(x in failed for x in expect)
        caught += ok
        L.append(f"| {mid} | {desc} | {', '.join(expect)} | {', '.join(failed) or '-'} | {'O' if ok else 'X'} |")
    L.insert(4, f"- 결함 주입 {caught}/{len(mutations(evidence, clues))}종 탐지")
    out = ROOT / "report" / "validation.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L))
    return 0 if all(R.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
