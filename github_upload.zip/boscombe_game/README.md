# 보스콤 밸리 사건 — 게임 서버판

배포자 PC 한 대에서 게임 서버와 Ollama를 돌리고, 플레이어는 브라우저로 접속만 한다.
플레이어 쪽에는 설치할 것도, 내려받을 모델도 없다.

```
플레이어 브라우저 ──(인터넷/와이파이)──▶ 배포자 PC: server.py ──(이 PC 안에서만)──▶ Ollama
```

## 배포자: 처음 한 번 준비

1. Python 3.9 이상, Ollama를 설치한다.
2. 대화용 모델을 받는다: `ollama pull exaone3.5:7.8b`
3. 압축을 푼 폴더에서 `start_server.bat`(Windows)을 더블클릭한다. macOS·Linux는 `./start_server.sh`를 실행한다.
4. 창에 뜨는 주소로 접속해 머리글에 **'AI 대화 · exaone3.5:7.8b'** 표시가 나오는지 확인한다.

```
보스콤 밸리 게임 서버 실행 중 (끄려면 Ctrl+C)
  이 PC에서:        http://localhost:8000
  같은 와이파이에서: http://192.168.x.x:8000
```

Windows 방화벽 허용 창이 뜨면 '허용'을 누른다. 같은 와이파이의 다른 기기에서 접속하려면 허용이 필요하다.

## API 키로 다른 모델 쓰기(선택)

기본은 이 PC의 Ollama(EXAONE)다. API 키가 있으면 같은 게임을 API 모델로도 돌릴 수 있다.

1. `start_server_api.bat`(macOS·Linux는 `./start_server_api.sh`)을 실행한다.
2. 처음 한 번 제공처(HAI-GPT API Gateway, Anthropic, Gemini, Groq, OpenRouter, OpenAI, 직접 지정), 키, 모델 이름을 묻는다. 키는 화면에 보이지 않게 입력받고, 키가 맞으면 쓸 수 있는 모델 이름 일부를 보여 준다.
3. 쓰는 방식을 고른다: **대사·판정 모두 API** 또는 **채점·판정만 API(대사는 Ollama)**.
4. 답은 폴더의 `.env`에 저장되고, 다음부터는 묻지 않고 바로 켜진다. 다시 정하려면 `python server/server.py --setup`.

**HAI-GPT API Gateway(통합 키):** 키 하나로 Claude·GPT·Gemini를 모델 이름만 바꿔 부른다(OpenAI 호환, 주소 `https://factchat-cloud.mindlogic.ai/v1/gateway`). 설정에서 1번을 고르면 된다.

```bash
python server/server.py --provider hai --list-models                                    # 키로 쓸 수 있는 모델 이름 보기
python server/server.py --provider hai --api-model claude-haiku-5-5 --api-rate-model claude-sonnet-5-5
```

- 추천: 대사·판정 `claude-haiku-5-5`, 개발자 검증 채점 `claude-sonnet-5-5`(대사 모델과 다른 모델로 채점).
- 게이트웨이 한도는 60초에 120회다. 한 턴에 2~3회(판정, 대사, 변형 C의 속생각)를 부르므로 동시에 여러 명이 하면 한도에 닿을 수 있다. 서버는 429가 오면 잠깐 쉬고 두 번까지 다시 시도한다.
- 크레딧은 모델 카드의 단가로 차감된다. 단가는 콘솔이나 `GET /v1/gateway/models/`의 `pricing`에서 확인한다.

```bash
python server/server.py --provider gemini --api-model <모델명>                 # 대사·판정 모두 API
python server/server.py --model exaone3.5:7.8b --judge-provider gemini --api-model <모델명>   # 대사는 EXAONE, 판정·채점은 API
python server/server.py --api-daily-limit 500                                  # 하루 API 호출 상한(기본 1500)
```

- 키는 `.env` 또는 환경 변수(`BOSCOMBE_API_KEY`, `GEMINI_API_KEY`, `ANTHROPIC_API_KEY` 등)에서만 읽는다. 브라우저로 보내지 않고, 로그와 오류 문구에서는 가린다.
- **`.env`는 절대 공유·업로드하지 않는다.** 압축해서 넘길 때도 빼고, `.gitignore`에 들어 있다. 키를 채팅이나 문서에 붙여 넣지 않는다.
- 무료 키는 제공처마다 분당·하루 한도가 다르다. 한도가 더 낮으면 `--api-daily-limit`을 그 값으로 낮춘다.
- 머리글의 상태 표시에 지금 쓰는 모델 종류가 나온다.

## 플레이어에게 주소 알려 주기

| 상황 | 방법 |
|---|---|
| 같은 와이파이(강의실, 집) | 서버 창의 `http://192.168.x.x:8000` 주소를 공유 |
| 다른 곳에서 인터넷으로 | 아래 cloudflared 임시 주소를 공유 |

cloudflared를 쓰는 방법(무료, 계정 없이 임시 주소 발급):

1. cloudflared를 설치한다. Windows는 `winget install --id Cloudflare.cloudflared`.
2. 서버를 켠 상태에서 새 창을 열고 `cloudflared tunnel --url http://localhost:8000`을 실행한다.
3. 출력된 `https://….trycloudflare.com` 주소를 공유한다. 이 주소는 터널을 다시 켤 때마다 바뀐다.

배포자 PC와 서버, 터널이 켜져 있는 동안만 플레이할 수 있다.

## 옵션

```bash
python server/server.py --model gemma3:12b                         # 대화 모델 바꾸기
python server/server.py --model exaone3.5:7.8b --judge-model qwen2.5:3b  # 질문 판정은 작은 모델로(더 빠름)
python server/server.py --port 8080 --parallel 2                   # 포트, Ollama 동시 호출 수
python server/server.py --persona B                                # 페르소나 변형 기본값(A/B/C, 기본 C)
```

플레이어 한 명이 질문하면 Ollama를 두 번 부른다(질문 판정 1회, 대답 1회). 결론을 제출하면 채점 1회, 터너의 반응 1회를 더 부른다.
여러 명이 동시에 하면 차례로 처리하므로 대답이 늦어질 수 있다.
PC 사양이 넉넉하면 `--parallel`을 올리고, 판정에는 작은 모델을 쓰면 빨라진다.

## 한 턴의 처리 순서

1. **질문 판정(Ollama):** 플레이어의 말을 주제·말투·언급한 증거로 정리한다. 키워드에 없는 표현도 뜻으로 알아듣는다. 플레이어가 추리의 결론을 말했는지도 함께 판정한다.
2. **규칙 엔진(브라우저):** 페르소나 키트의 조건식대로 신뢰·긴장을 바꾸고 해금 여부를 정한다. 무엇을 털어놓고 무엇을 피할지도 여기서 정한다.
3. **심리 판정(브라우저, `src/psych.js`):** 이번 턴에 작동할 방어기제, 중요한 턴인지(첫 만남·증거 제시·추궁·새로 털어놓음 등), 기운 변화를 정한다.
4. **속생각(Ollama, 변형 C의 중요한 턴만):** 대답하기 전에 인물의 속생각을 세 줄(기분·받아들임·속셈)로 만든다. 플레이어에게는 보이지 않는다.
5. **대답 생성(Ollama):** 서버가 프롬프트를 만든다. 변형 B·C는 Big Five, 방어기제, 말투 규칙, 말투 예시 2쌍(RoleLLM), 세계 밖 질문 규칙, 기운, 속생각을 함께 넣고, 생성 직전 위치에 페르소나 재고정 문장(Li et al.)을 붙인다. 넣는 것은 지금 열린 지식, 이번에 털어놓을 내용, 회피 방식, 제시된 증거, 최근 대화다. 대본에 없는 질문에도 보유 지식 안에서 자유롭게 대답한다.
6. **누출 검사(서버와 브라우저 양쪽):** 잠긴 단계의 정보가 섞이면 한 번 다시 만든다. 그래도 섞이면 대본 대사로 대신한다.

## 추리, 힌트, 결론

- **추리:** 따로 고르는 화면이 없다. 증거가 가리키는 결론(예: 범인의 손, 다리, 매카시의 마지막 말)을 레스트레이드 경감에게 보고하거나, 터너와 대면할 때 말하거나, 결론 글에 적으면 성립하고 수사 기록 탭의 '탐정의 추리'에 남는다. 다른 인물에게 말한 추리는 기록하지 않는다.
- **터너 만나기:** 경감은 추리를 비웃으면서도 수첩에 적어 둔다. 근거 있는 추리가 쌓이면(페르소나 키트의 쪽지 조건) 마지못해 숲지기 편에 터너에게 쪽지를 보내 준다. 플레이어가 숲지기 집에서 직접 쪽지를 보내지는 않는다. 그 추리를 뒷받침할 증거나 진술을 아직 얻지 못했으면 성립하지 않고, 알림도 없다. 판정은 AI 판정기와 키워드(`src/script.js`의 `deductionVoice`)를 함께 쓴다.
- **힌트:** 머리글의 💡 힌트 버튼을 누르면 지금 해 볼 만한 행동이나 질문을 하나 보여 준다. '더 구체적으로'를 누르면 자세한 힌트가 나온다. 사용 횟수는 결과표에 남는다.
- **결론:** 범인을 고르고, 동기는 직접 글로 쓴다. 채점관(AI)이 진상과 대조해 세 요소(협박, 결혼 요구, 딸을 지키려 함)를 몇 개 짚었는지 매기고 한두 문장으로 평한다. AI를 쓸 수 없으면 핵심 표현으로 채점한다. 터너를 범인으로 지목하면 터너가 자백 여부에 맞게 직접 반응한다(인정하거나 부인).

## 가드레일·추리 진행 점검(점검 모드)

- 게임 주소 뒤에 `?qa=1`을 붙여 열면(예: `http://localhost:8000/?qa=1`) 왼쪽 아래에 '🔧 점검' 버튼이 생긴다. 질문 세트(`test/qa_questions.json`, 73문항)를 정해진 상태에서 하나씩 보내고 자동 판정과 대답을 표로 보여 준다. 'CSV 저장'으로 결과를 받는다.
- 분류: A 세계관 이탈·엉뚱한 질문, B 지시 무시·프롬프트 주입, C 잠긴 정보 직접 질문, D 인물이 모르는 정보·창작 유도, E 거짓 전제·근거 없는 추궁, F 추리 진행·해금 조건, G 입력 형식·보안.
- 자동 판정: 잠긴 단계 누출, 세계관 이탈 단어, 한국어 여부, 금지 표현, 단계·플래그·추리 변화. 말투나 사실 창작은 '기대 동작'을 보고 사람이 확인한다.
- AI 모드에서는 AI 대답이 누출 검사에 걸려 대본으로 바뀐 경우를 '주의'로 표시한다. 서버의 요청 한도(1분 30회) 때문에 문항 사이에 간격을 둔다.
- 실행 전 저장된 진행 상황은 보관했다가 끝나면 되돌린다.
- 터미널에서 한 번에: `node test/qa_run.js http://localhost:8000/ 결과.json` (Node와 Playwright가 필요하다).

## 임시: Claude 연결판(claude.ai 아티팩트)

Ollama 서버를 켜기 전에도 AI 대화를 확인할 수 있도록, 같은 게임을 claude.ai 아티팩트로 올렸다.
`dist/boscombe_valley_artifact.html`이 그 파일이다.

- **대답하는 모델:** 보는 사람의 Claude 계정으로 Claude Haiku 5.5가 질문을 판정하고 인물의 대답을 만든다. Ollama가 하던 역할을 그대로 대신한다.
- **프롬프트와 규칙:** 프롬프트는 서버와 같은 구성(`src/prompts.js`)이고, 해금과 누출 검사도 그대로 적용된다.
- **처음 질문할 때:** Claude 사용 허용 창이 뜬다. 허용하지 않으면 대본 모드로 진행한다.
- **우선순위:** 연결 순서는 Claude(아티팩트 안) → 게임 서버(Ollama) → 대본 모드다.

## 서버에 연결되지 않을 때

`dist/boscombe_valley_local.html` 파일을 그냥 열거나 서버가 꺼지면 **대본 모드**로 자동 전환된다.
대본 모드는 키워드로 주제를 판정하고 정해 둔 대사로 대답한다. 머리글의 상태 표시를 누르면 연결 상태를 볼 수 있다.

## 보안

- **바깥에 여는 것:** Ollama는 이 PC 안에서만 호출한다. 바깥에는 게임 페이지와 `/api/judge`, `/api/speak`, `/api/grade`만 열린다. 검증용 채점 `/api/rate`와 거르기 전 원문(`_audit`)은 이 PC(localhost)에서만 쓸 수 있다.
- **API 키:** `.env`에만 둔다. 브라우저·로그로 나가지 않는다. 하루 호출 상한으로 키가 새도 피해를 줄인다.
- **요청 처리:** 요청 본문 크기·연결 시간(30초)을 제한하고, 이 PC가 아닌 곳에서 오는 요청은 IP당 분당 횟수를 제한한다.
- **서버가 정하는 것:** 프롬프트와 인물 설정은 서버가 데이터 파일로 직접 만든다. 플레이어가 고칠 수 있는 것은 자기 질문뿐이다. 질문 길이와 IP당 요청 수(1분 30회)도 제한한다.
- **임시 주소:** cloudflared 주소를 아는 사람은 누구나 접속할 수 있다. 시연이 끝나면 터널을 끈다.
- **브라우저 조작:** 게임 진행 상태는 브라우저에 저장된다. 개발자 도구로 상태를 조작하면 스포일러를 볼 수 있다. 시연·수업용으로는 문제없는 수준이다.

## 심리 기반 페르소나(PersonaForge 구조)

팀원이 조사한 논문 PersonaForge(Tong & Zou, ACL 2026 Findings)의 3층 성격 구조와 선택적 이중처리를 이 게임에 옮겼다.

| 층 | 이 게임에서 | 위치 |
|---|---|---|
| 1층 핵심 특성 | Big Five(0~1) + 주 방어기제와 발동 규칙(추궁·증거 제시·주제·긴장 등) | `data/persona_psych.json` |
| 2층 말투 행렬 | 문장 길이, 어미, 말줄임표 빈도, 입버릇, 행동 묘사 | 같은 파일 |
| 3층 동적 상태 | 엔진의 신뢰·긴장 + 기운(긍정 +10, 부정 −15, 그 밖 −2) | `src/psych.js` |
| 선택적 이중처리 | 중요한 턴에만 속생각 → 대답(논문은 약 40% 턴에서 작동) | `server/psych.py`, `src/prompts.js` |

- **변형:** A = 기존 페르소나, B = A + 위 3층, C = B + 속생각. 플레이어 화면에는 고르는 곳이 없다. 개발자가 검증 도구로 비교해 하나를 고르고, 서버의 `--persona`(기본 C)로 정한다. Claude 연결판은 `src/ui.js`의 `DEFAULT_VARIANT`를 쓴다.
- **개발용 보기:** 주소 끝에 `?research=1`을 붙이면 말풍선 아래에 그 턴의 방어기제와 속생각이 보인다(스포일러 주의).
- **수치는 초안이다.** 원작 근거로 먼저 채웠다. 팀원 2~3명이 각자 라벨링해 일치도(κ)를 내고, 합의값으로 `data/persona_psych.json`을 고친 뒤 `python build.py`.
- **속도:** 변형 C는 중요한 턴에서 Ollama를 한 번 더 부른다(짧은 출력, 최대 160토큰). 느리면 B로 바꾼다.

### 비교 실험

```bash
python server/server.py --model exaone3.5:7.8b          # 서버를 켠 상태에서
node test/persona_eval.js http://localhost:8000 eval_out  # 인물 6명 × 변형 A·B·C × 14턴
node test/persona_eval.js http://localhost:8000 eval_out --chars john_turner --turns 8   # 일부만
```

인물마다 같은 질문 14개(화제 전환·근거 없는 추궁·위협·공감 같은 교란 포함)를 변형별로 따로 대화시킨다.

| 파일 | 내용 |
|---|---|
| `summary.csv` | 변형·인물별 말투 준수(SA: 문장 길이·어미·입버릇·말줄임표), 누설 수, 응답 시간, 중요한 턴 비율 |
| `turns.csv` | 턴별 질문, 대답, 속생각, 방어기제, 기운, 지표 |
| `blind_pairs.md` | 같은 질문에 대한 A와 C의 대답을 순서를 섞어 나란히 둔 것. 성격에 더 맞는 쪽을 고른다(PC 쌍대 비교) |
| `answer_key.json` | blind_pairs의 정답. 채점이 끝난 뒤에 연다 |
| `defense_turns.csv` | 방어기제가 발동한 턴. 의도한 방어가 대답에 드러났는지 1/0으로 표시한다(DMA) |

### 페르소나 검증 도구(개발자 전용)

성격이 보존되는지, 정보가 새지 않는지를 확인하는 시험 6가지. 게임 화면에는 없고, 서버를 켠 PC에서 따로 돌린다(Node.js 18 이상).

**가장 쉬운 방법:** 서버를 켠 뒤 `tools\run_verify.bat`을 더블클릭하고 번호를 고른다. 자세한 사용법은 `tools/VERIFY_GUIDE.md`.

```bash
node tools/persona_verify.js --dry                       # 예상 호출 수만
node tools/persona_verify.js                             # 터너·제임스, A/B/C, T1~T6, 1회
node tools/persona_verify.js --chars all --reps 2        # 6명 전체, 2회
node tools/persona_verify.js --variants B,C --tests T5   # 일부만
node tools/persona_verify.js --no-judge                  # 채점 모델 없이 규칙 지표만
node tools/persona_verify.js --questions                 # 질문 세트(Markdown)만 다시 만들기
node tools/persona_verify.js --merge verify_out           # 결과들을 모델·변형별 비교표로
node tools/persona_verify.js --rerate verify_out/<결과>.json  # 대답은 그대로, 채점만 다시
```

| 시험 | 보는 것 | 근거 |
|---|---|---|
| T1 | Big Five 10문항 인터뷰 → 목표값과의 오차 | InCharacter |
| T2 | 말투 준수(문장 길이·어미·입버릇), 한국어 유지 | PersonaForge, PersonaGym |
| T3 | 14턴 장기 대화의 설정 이탈·모순·인물 유지 | PersonaForge, Abdulhai et al. |
| T4 | 의도한 방어기제가 대답에 드러나는가 | PersonaForge |
| T5 | 잠긴 정보 누출, 프롬프트 추출, 역할 이탈, 세계 밖 질문 | TimeChara, Zhang et al., RoleBreak |
| T6 | 증거 없이/있이 같은 질문 → 범인의 회피·인정 변화 | SUE |

- 문항 원본은 `data/verify_suite.json`, 사람이 읽는 질문 세트는 `tools/persona_question_set.md`.
- 채점(`/api/rate`)은 서버 PC(localhost)에서만 열린다. 채점 모델은 대사 모델과 다르게 두는 것을 권한다(예: 대사 EXAONE, 채점 API).
- 결과는 `verify_out/`에 남는다. .md 맨 위에 합격 기준 대조표(✔/✘), 보고서용 요약 표, 해석 초안이 있고, .csv는 문항별 원자료, .json은 전체 기록이다.

## 화면(팀 UI 틀)

팀원 ③ 개선판의 틀을 따른다: 표지(봉랍) → 수사 안내서, 탭 안내 띠, '다음 실마리' 띠, 증거 책상 비교, 노트 카드, 수사 기록·메모, 종이 쪽지 말풍선. 지도와 장소 그림, 인물 그림은 이 게임의 것(`src/scenes.js`, `src/art.js`)을 쓰고, 페르소나는 이 게임의 PersonaForge 구조를 쓴다. 맞대기 보드(증거→인물 내밀기, 증거↔증거 착안, 인물↔인물 대질)는 `data/contact_board.json` 규칙표로 옮겼다. 팀원 판의 '이의 제기'와 심문실 이동은 옮기지 않았다. 색과 배치는 `src/style.css`에 있다. 주소 끝에 `#intro`를 붙이면 표지를 다시 볼 수 있다.

- **설정:** 난이도(쉬움: 예시 질문 3개, 핵심 질문 포함 / 보통: 기본 질문만 최대 2개 / 어려움: 예시 질문 없음)와 AI 대화 켜기·끄기. 난이도는 결과 화면에 남는다.
- **다음 실마리:** 모든 탭의 탭 바로 아래 띠 하나로 통합했다(머리줄의 실마리 버튼은 없앴다).
- **말풍선:** 기울기와 그림자 필터를 빼서 글자 번짐을 없앴다.

## 폴더

| 경로 | 내용 |
|---|---|
| `start_server.bat`, `start_server.sh` | 서버 실행(Ollama) |
| `start_server_api.bat`, `start_server_api.sh` | API 키로 서버 실행(처음 한 번 설정) |
| `server/providers.py` | 모델 연결(Ollama, Anthropic, OpenAI 호환) |
| `server/server.py` | 게임 서버(표준 라이브러리만 사용) |
| `dist/boscombe_valley_local.html` | 게임 화면(서버가 이 파일을 내보냄) |
| `data/` | 증거 데이터(handoff), 페르소나 키트 원본, 심리 계층(`persona_psych.json`) |
| `server/psych.py` | 심리 계층 프롬프트(서버) |
| `src/` | 화면·엔진·대본 소스. 고친 뒤 `python build.py` |
| `data/verify_suite.json` | 페르소나 검증 문항(T1~T6)과 채점 프롬프트 |
| `tools/persona_verify.js`, `tools/persona_question_set.md` | 페르소나 검증 도구와 질문 세트(개발자 전용) |
| `test/` | 엔진 시험, 화면 시험, 가짜 Ollama, 가짜 API |

## 수정과 시험

```bash
python build.py                 # src/ + data/ → dist/
node test/playthrough.js        # 처음부터 진엔딩까지 + 대본 누출 검사 + 예시 질문 판정
node test/scenarios.js out.json # 풀이 시나리오 10가지 재생
node test/scenario_board.js out.json [스크린샷 폴더]  # 맞대기 보드 풀이를 실제 화면에서 재생(Playwright)
python test/mock_ollama.py 18435 &          # Ollama 없이 서버 시험
python server/server.py --ollama http://127.0.0.1:18435 --model mock:1b
```

## 교수님 피드백 반영

- **화면:** 왼쪽 2/3에 지도·증거·수사 기록·결론 탭, 오른쪽 1/3에 카카오톡 형식 대화창과 인물 초상
- **추리:** 보기에서 고르는 추리 노트를 없앴다. 플레이어가 직접 말한 추리만 인정하고, 막히면 힌트 버튼으로 한 단계씩 안내한다
- **결론:** 동기는 객관식 대신 서술형으로 받고, AI 채점관과 터너가 확인한다
- **지도:** 번호 핀 대신 장면 위의 물건(장화, 발자국, 시가, 돌, 명부 등)을 눌러 조사
- **대화:** 정해진 진술·대조 탭이 없고, 증거만 가지고 자유롭게 질문한다. 예시 질문은 입력창에 하나만 보인다
- **가드레일:** 근거 없는 추궁은 거부한다. 조건을 채울 때마다 한 단계씩 털어놓고, 결정적 증거와 추리를 갖춰야 범인이 자백한다
- **거짓 자백처럼 들리는 말:** 제임스를 근거 없이 몰아세우면 '받아 마땅한 벌'이라며 자책한다
- **행동 횟수 제한 없음**

## 페르소나 데이터와 다르게 처리한 점

- **한 턴에 한 단계만 해금:** 앞 단계에서 물은 주제는 다음 단계 조건에 다시 쓰지 않는다. 점진적으로 공개하기 위해서다.
- **레스트레이드:** 면회·현장 안내·소문이 순서와 관계없이 열린다.
- **'앨리스의 전언' 주제:** 앨리스에게 전언을 받은 뒤에만 성립한다.
- **추리 DD_LOCAL_PERSON:** 증거 데이터의 '연못 지형'으로도 성립한다.
- **크라우더의 고향 대사:** 크라우더가 이 지방 태생이라는 대사(증거 데이터의 각색)를 넣었다. 페르소나 키트에도 반영이 필요하다.
- **배제·대조 추리 4개(DX_*):** 증거 데이터의 배제 근거를 옮겼다. 결과 표에만 쓰고 엔딩 판정에는 쓰지 않는다.
- **쪽지(ACT_SEND_NOTE):** 조건식은 그대로 쓰되, 숲지기 집에서 직접 보내는 대신 조건을 채운 뒤 레스트레이드와 대화하면 경감이 보낸다.
- **추리 성립 방식:** 페르소나 키트는 추리 카드 선택을 전제로 하지만, 이 판은 플레이어가 말로 밝힌 추리를 판정한다(조건식 `deduction_made`는 그대로 쓴다).
- **동기 채점:** 페르소나 키트의 엔딩 판정에는 동기가 들어가지 않는다. 동기 점수는 결과표에만 쓴다.
- **현지화 덧씌우기(`data/localization_ko.json`):** 임종의 말 'a rat'을 '…아랫…'으로, 지명 표기 '발라랏'을 '발라랫'으로 바꾼다. 페르소나 키트 원본은 고치지 않고 빌드(`build.py`)와 서버(`server.py`)가 불러올 때 순서대로 치환한다. 내부 사실 값(`heard: "a rat"`, `name: "Ballarat"`)은 그대로다. 페르소나 키트에 정식 반영할지는 페르소나 담당과 정해야 한다.
