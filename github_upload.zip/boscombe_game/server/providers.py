"""모델 호출 — Ollama(기본) 또는 API(키를 넣은 경우).

종류
  ollama     배포자 PC의 Ollama (기본, 비용 없음)
  anthropic  Claude API (Anthropic). 키: ANTHROPIC_API_KEY
  openai     OpenAI 호환 API. 기본 주소를 바꿔 Gemini·Groq·OpenRouter·OpenAI 등에 쓴다. 키: BOSCOMBE_API_KEY 등
             HAI-GPT API Gateway(BAZE, preset 'hai')도 이 형식이다. 키 하나로 Claude·GPT·Gemini 모델을 이름만 바꿔 부른다.

API 키는 이 PC의 환경 변수나 프로젝트 폴더의 .env 파일에서만 읽는다.
화면(브라우저)으로는 절대 보내지 않고, 로그에도 찍지 않는다.
표준 라이브러리만 쓴다.
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT / ".env"

# OpenAI 호환 API의 기본 주소(모델 이름은 서비스마다 다르고 자주 바뀌므로 실행할 때 확인해 넣는다)
PRESETS = {
    # HAI-GPT API Gateway(BAZE, mindlogic): OpenAI 호환. 주소 끝 '/'까지 문서 그대로 쓴다. 모델 목록은 GET /models/
    "hai": {"kind": "openai", "base": "https://factchat-cloud.mindlogic.ai/v1/gateway", "path": "/chat/completions/", "models_path": "/models/?type=llm",
            "key_env": ["HAI_API_KEY", "BAZE_API_KEY", "BOSCOMBE_API_KEY"], "model": "claude-haiku-5-5", "label": "HAI-GPT API Gateway"},
    "anthropic": {"kind": "anthropic", "base": "https://api.anthropic.com/v1", "key_env": ["ANTHROPIC_API_KEY", "BOSCOMBE_API_KEY"], "model": "claude-haiku-5-5", "label": "Anthropic(Claude)"},
    "gemini": {"kind": "openai", "base": "https://generativelanguage.googleapis.com/v1beta/openai", "key_env": ["GEMINI_API_KEY", "GOOGLE_API_KEY", "BOSCOMBE_API_KEY"], "model": "", "label": "Google Gemini"},
    "groq": {"kind": "openai", "base": "https://api.groq.com/openai/v1", "key_env": ["GROQ_API_KEY", "BOSCOMBE_API_KEY"], "model": "", "label": "Groq"},
    "openrouter": {"kind": "openai", "base": "https://openrouter.ai/api/v1", "key_env": ["OPENROUTER_API_KEY", "BOSCOMBE_API_KEY"], "model": "", "label": "OpenRouter"},
    "openai": {"kind": "openai", "base": "https://api.openai.com/v1", "key_env": ["OPENAI_API_KEY", "BOSCOMBE_API_KEY"], "model": "", "label": "OpenAI"},
    "custom": {"kind": "openai", "base": "", "key_env": ["BOSCOMBE_API_KEY"], "model": "", "label": "OpenAI 호환(직접 지정)"},
}


def load_env(path=ENV_FILE):
    """KEY=VALUE 형식의 .env를 읽는다(이미 있는 환경 변수가 우선)."""
    out = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip().strip('"').strip("'")
    except FileNotFoundError:
        pass
    for k, v in out.items():
        os.environ.setdefault(k, v)
    return out


def mask(key):
    return "(없음)" if not key else f"…{key[-4:]} ({len(key)}자)"


class Backend:
    """한 역할(대사 또는 판정)에 쓰는 모델."""

    def __init__(self, provider="ollama", model="", base="", key="", ollama="http://localhost:11434", timeout=120, daily_limit=0):
        self.provider = provider
        if provider == "ollama":
            self.kind, self.base, self.key = "ollama", ollama.rstrip("/"), ""
        else:
            pre = PRESETS.get(provider, PRESETS["custom"])
            self.kind = pre["kind"]
            self.base = (base or pre["base"]).rstrip("/")
            self.key = key or next((os.environ.get(k) for k in pre["key_env"] if os.environ.get(k)), "")
            self.path = pre.get("path", "/chat/completions")
            self.models_path = pre.get("models_path", "/models")
            model = model or pre["model"]
        self.model = model
        self.timeout = timeout
        self.lock = threading.Semaphore(1) if self.kind == "ollama" else threading.Semaphore(4)
        self.daily_limit = daily_limit           # 하루 API 호출 상한(0이면 무제한). 키가 외부에 노출된 서버에서 낭비를 막는다
        self.calls = {"day": time.strftime("%Y-%m-%d"), "n": 0}
        self.think_ok = {}
        self.json_ok = True                       # response_format(json_object)를 받아 주는지. 한 번 400이 나면 다음부터 빼고 보낸다
        self._status = None

    @property
    def label(self):
        if self.kind == "ollama":
            return f"Ollama {self.model}"
        return f"{PRESETS.get(self.provider, PRESETS['custom'])['label']} {self.model}"

    def describe(self):
        return {"provider": self.provider, "model": self.model}

    # ---------------------------------------------------------- 호출
    def chat(self, messages, json_mode=False, temperature=0.7, num_predict=320):
        if self.kind != "ollama":
            day = time.strftime("%Y-%m-%d")
            if self.calls["day"] != day:
                self.calls = {"day": day, "n": 0}
            if self.daily_limit and self.calls["n"] >= self.daily_limit:
                raise RuntimeError("오늘의 API 호출 상한에 도달했습니다")
            self.calls["n"] += 1
        with self.lock:
            t0 = time.time()
            if self.kind == "ollama":
                text, pe, ev = self._ollama(messages, json_mode, temperature, num_predict)
            elif self.kind == "anthropic":
                text, pe, ev = self._anthropic(messages, json_mode, temperature, num_predict)
            else:
                text, pe, ev = self._openai(messages, json_mode, temperature, num_predict)
        print(f"    {self.label} {'판정' if json_mode else '대사'} {time.time() - t0:.1f}초 (입력 {pe}토큰, 출력 {ev}토큰)")
        return text.strip()

    def _post(self, url, body, headers):
        # API는 분당 호출 한도(예: HAI 게이트웨이 60초에 120회)에 걸리면 429를 준다 → 잠깐 쉬고 두 번까지 다시 시도
        for wait in ((1.5, 4.0) if self.kind != "ollama" else ()):
            try:
                return self._post_once(url, body, headers)
            except RuntimeError as e:
                code = str(e)[5:8]
                if code not in ("429", "500", "502", "503", "504", "529"):
                    raise
                time.sleep(wait)
        return self._post_once(url, body, headers)

    def _get(self, url, headers):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"HTTP {e.code}") from None

    def list_models(self):
        """OpenAI 호환 API의 모델 이름 목록(키 확인 겸)."""
        if self.kind != "openai":
            return []
        data = self._get(self.base + self.models_path, {"Authorization": "Bearer " + self.key})
        return [m.get("id") for m in (data.get("data") or data.get("models") or []) if isinstance(m, dict) and m.get("id")]

    def _post_once(self, url, body, headers):
        req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=dict({"Content-Type": "application/json"}, **headers))
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = e.read().decode("utf-8", "replace")[:300]
            except Exception:
                pass
            # 키가 오류 메시지에 섞여 돌아오는 경우를 대비해 지운다
            if self.key:
                detail = detail.replace(self.key, "***")
            raise RuntimeError(f"HTTP {e.code} {detail}") from None

    def _ollama(self, messages, json_mode, temperature, num_predict):
        body = {"model": self.model, "messages": messages, "stream": False, "keep_alive": "60m",
                "options": {"temperature": temperature, "num_predict": num_predict, "num_ctx": 8192}}
        if json_mode:
            body["format"] = "json"
        else:
            body["options"]["repeat_penalty"] = 1.15   # 같은 말을 되풀이하는 고장을 줄인다
        if self.think_ok.get(self.model, True):
            body["think"] = False                      # qwen3 같은 '생각하는' 모델이 긴 추론을 먼저 쓰지 않게 한다
        try:
            data = self._post(self.base + "/api/chat", body, {})
        except RuntimeError as e:
            if str(e).startswith("HTTP 400") and "think" in body:
                self.think_ok[self.model] = False
                body.pop("think")
                data = self._post(self.base + "/api/chat", body, {})
            else:
                raise
        return (data.get("message") or {}).get("content", ""), data.get("prompt_eval_count") or 0, data.get("eval_count") or 0

    @staticmethod
    def _split_system(messages):
        system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
        rest = []
        for m in messages:
            if m["role"] == "system":
                continue
            role = "assistant" if m["role"] == "assistant" else "user"
            if rest and rest[-1]["role"] == role:
                rest[-1]["content"] += "\n\n" + m["content"]
            else:
                rest.append({"role": role, "content": m["content"]})
        if not rest or rest[0]["role"] != "user":
            rest.insert(0, {"role": "user", "content": "(대화를 시작한다)"})
        return system, rest

    def _anthropic(self, messages, json_mode, temperature, num_predict):
        system, rest = self._split_system(messages)
        if json_mode:
            rest[-1]["content"] += "\n\n반드시 JSON 객체 하나만 출력한다. 설명이나 코드 블록 표시는 쓰지 않는다."
        body = {"model": self.model, "max_tokens": max(64, num_predict), "temperature": temperature, "messages": rest}
        if system:
            body["system"] = system
        data = self._post(self.base + "/messages", body, {"x-api-key": self.key, "anthropic-version": "2023-06-01"})
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        u = data.get("usage") or {}
        return text, u.get("input_tokens", 0), u.get("output_tokens", 0)

    def _openai(self, messages, json_mode, temperature, num_predict):
        body = {"model": self.model, "messages": messages, "temperature": temperature, "max_tokens": max(64, num_predict)}
        plain_json = messages[:-1] + [{"role": messages[-1]["role"], "content": messages[-1]["content"] + "\n\n반드시 JSON 객체 하나만 출력한다. 설명이나 코드 블록 표시는 쓰지 않는다."}]
        if json_mode:
            if self.json_ok:
                body["response_format"] = {"type": "json_object"}
            else:
                body["messages"] = plain_json
        headers = {"Authorization": "Bearer " + self.key}
        url = self.base + self.path
        try:
            data = self._post(url, body, headers)
        except RuntimeError as e:
            if json_mode and self.json_ok and str(e).startswith(("HTTP 400", "HTTP 422")):   # json 형식 옵션을 모르는 서비스·모델이면 빼고 다시
                self.json_ok = False
                body.pop("response_format", None)
                body["messages"] = plain_json
                data = self._post(url, body, headers)
            else:
                raise
        ch = (data.get("choices") or [{}])[0]
        text = (ch.get("message") or {}).get("content") or ""
        u = data.get("usage") or {}
        return text, u.get("prompt_tokens", 0), u.get("completion_tokens", 0)

    # ---------------------------------------------------------- 상태
    def status(self):
        """(ok, 이유). API는 한 번 짧게 호출해 보고 10분 동안 결과를 기억한다(호출 비용을 아끼려고)."""
        if self.kind == "ollama":
            try:
                with urllib.request.urlopen(self.base + "/api/tags", timeout=5) as r:
                    models = [m["name"] for m in json.loads(r.read()).get("models", [])]
                ok = self.model in models or any(m.split(":")[0] == self.model for m in models)
                return ok, None if ok else f"Ollama에 '{self.model}' 모델이 없습니다"
            except Exception as e:
                return False, f"Ollama에 연결할 수 없습니다: {e}"
        if not self.key:
            return False, f"{self.label}: API 키가 없습니다(.env 또는 환경 변수에 넣으세요)"
        if not self.model:
            return False, f"{self.provider}: 모델 이름이 없습니다(--api-model로 지정하세요)"
        if self._status and time.time() - self._status[0] < 600:
            return self._status[1], self._status[2]
        try:
            out = self.chat([{"role": "user", "content": "한 단어로 대답: 안녕"}], temperature=0, num_predict=16)
            ok, why = bool(out), None if out else "빈 응답"
        except Exception as e:
            ok, why = False, f"{self.label} 호출 실패: {e}"
        self._status = (time.time(), ok, why)
        return ok, why


def setup_interactive():
    """키 입력 도우미: API 종류·키·모델을 물어 .env에 저장한다(키는 화면에 보이지 않게 입력)."""
    import getpass
    names = ["hai", "anthropic", "gemini", "groq", "openrouter", "openai", "custom"]
    print("\n어떤 API 키인가요?")
    for i, n in enumerate(names, 1):
        print(f"  {i}. {PRESETS[n]['label']}")
    sel = input("번호 [1]: ").strip() or "1"
    try:
        prov = names[int(sel) - 1]
    except (ValueError, IndexError):
        prov = "hai"
    pre = PRESETS[prov]
    base = ""
    if prov == "custom":
        base = input("API 기본 주소(예: https://example.com/v1): ").strip()
    key = getpass.getpass("API 키(입력해도 화면에 보이지 않습니다): ").strip()
    if pre["kind"] == "openai" and (pre["base"] or base):
        try:
            b = Backend(prov, model="x", base=base, key=key)
            ids = b.list_models()
            if ids:
                shown = [i for i in ids if any(w in i for w in ("claude", "gpt", "gemini"))][:24] or ids[:24]
                print(f"키 확인됨. 쓸 수 있는 모델 {len(ids)}개 중 일부: {', '.join(shown)}")
        except Exception as e:
            print(f"(모델 목록을 가져오지 못했습니다: {str(e)[:60]}. 키나 주소를 확인하세요.)")
    hint = pre["model"] or "서비스 콘솔에서 쓸 수 있는 모델 이름을 확인해 넣으세요"
    if prov == "hai":
        print("추천: 대사·판정 claude-haiku-5-5(빠르고 저렴), 검증 채점 claude-sonnet-5-5(대사 모델과 다르게)")
    model = input(f"대사·판정 모델 이름 [{hint}]: ").strip() or pre["model"]
    rate_default = "claude-sonnet-5-5" if prov == "hai" else model
    rate = input(f"페르소나 검증 채점 모델 이름 [{rate_default}]: ").strip() or rate_default
    print("\n이 API를 어디에 쓸까요?")
    print("  1. 인물 대사와 질문 판정 모두 (Ollama를 쓰지 않음)")
    print("  2. 질문 판정·채점만 API, 인물 대사는 Ollama(exaone 등) 그대로")
    use = input("번호 [1]: ").strip() or "1"
    lines = [f"BOSCOMBE_PROVIDER={prov if use == '1' else 'ollama'}", f"BOSCOMBE_JUDGE_PROVIDER={prov}",
             f"BOSCOMBE_API_PROVIDER={prov}", f"BOSCOMBE_API_MODEL={model}", f"BOSCOMBE_API_RATE_MODEL={rate}", f"BOSCOMBE_API_KEY={key}"]
    if base:
        lines.append(f"BOSCOMBE_API_BASE={base}")
    old = []
    try:
        old = [l for l in ENV_FILE.read_text(encoding="utf-8").splitlines() if not l.startswith("BOSCOMBE_")]
    except FileNotFoundError:
        pass
    ENV_FILE.write_text("\n".join(old + ["# 보스콤 밸리 서버 설정(이 파일은 다른 사람과 공유하지 마세요)"] + lines) + "\n", encoding="utf-8")
    try:
        os.chmod(ENV_FILE, 0o600)
    except OSError:
        pass
    print(f"\n.env에 저장했습니다: {PRESETS[prov]['label']} · 모델 {model or '(미지정)'} · 키 {mask(key)}")
    print("이 파일(.env)은 압축해서 남에게 보내거나 깃에 올리지 마세요.\n")
