"""심리 기반 페르소나 계층 — 프롬프트 조각(src/psych.js와 같은 문장).

턴 판정(방어기제·중요한 턴·기운 갱신)은 브라우저의 src/psych.js가 하고,
서버는 받은 값(variant, defense, energy, critical)을 검증한 뒤 프롬프트를 만든다.
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PSY = json.loads((ROOT / "data" / "persona_psych.json").read_text(encoding="utf-8"))
D = PSY["dynamic_state"]["energy"]
ORDER = ["O", "C", "E", "A", "N"]
ELLIPSIS = {"high": "말줄임표(…)로 말을 자주 끊는다", "mid": "가끔 말줄임표(…)를 쓴다", "low": "말줄임표는 거의 쓰지 않고 또박또박 말한다"}
VARIANTS = {"A", "B", "C"}


def level(v):
    return "high" if v >= 0.65 else "low" if v <= 0.35 else None


def clean_psych(req_psych, default_variant):
    """브라우저가 보낸 심리 판정 값을 검증한다."""
    ps = req_psych if isinstance(req_psych, dict) else {}
    v = ps.get("variant") if ps.get("variant") in VARIANTS else default_variant
    d = ps.get("defense") if ps.get("defense") in PSY["defenses"] else None
    try:
        e = max(0, min(D["max"], float(ps.get("energy", 80))))
    except (TypeError, ValueError):
        e = 80
    return {"variant": v, "defense": d, "energy": e, "critical": bool(ps.get("critical"))}


def system_block(cid, energy):
    c = PSY["characters"].get(cid)
    if not c:
        return []
    T, L = PSY["trait_text"], ["", "## 성격 특성(Big Five, 0~1)"]
    for k in ORDER:
        v = c["big_five"][k]
        lv = level(v)
        L.append(f"- {T[k]['name']} {v:.2f}" + ((" 높음: " if lv == "high" else " 낮음: ") + T[k][lv] if lv else " 보통"))
    d = PSY["defenses"][c["defense"]["primary"]]
    L += ["", "## 방어기제(스트레스를 받을 때 생각이 비틀리는 방식)", f"- 주 방어기제: {d['ko']} — {d['how']}"]
    s = c["style"]
    L += ["", "## 말투 규칙",
          f"- 한 문장은 대체로 {s['sentence_chars'][0]}~{s['sentence_chars'][1]}자.",
          f"- 어미: {s['register']} (예: {', '.join('~' + x for x in s['endings'])})",
          f"- {ELLIPSIS.get(s['ellipsis'], ELLIPSIS['mid'])}",
          f"- 입버릇(필요할 때 한 답변에 많아야 하나): {', '.join(chr(39) + x + chr(39) for x in s['catchphrases'])}",
          f"- 행동 묘사 예: {' '.join(s['tone_markers'])}"]
    if c.get("voice_examples"):
        L += ["", "## 말투 예시(말투만 참고하고, 내용을 그대로 되풀이하지 않는다)"]
        for q, a in c["voice_examples"]:
            L += [f"탐정: {q}", f"나: {a}"]
    if c.get("core_facts"):
        L += ["", "## 바뀌지 않는 내 신상(속생각에서도 벗어나지 않는다)"] + [f"- {x}" for x in c["core_facts"]]
    if PSY.get("world_boundary"):
        L += ["", "## 세계 밖 질문", "- " + PSY["world_boundary"]]
    e = round(c["energy_start"] if energy is None else energy)
    L += ["", f"## 기운 {e}/100"]
    if e <= D["low"]:
        L.append("- 기운이 거의 없다. 1~2문장으로 짧게 말하고, 말끝을 흐린다.")
    elif e >= 80:
        L.append("- 기운이 있다. 성격대로 충분히 말한다.")
    return L


def turn_lines(defense):
    d = PSY["defenses"].get(defense or "")
    if not d:
        return []
    return [f"이번 턴에는 방어기제 '{d['ko']}'가 작동한다: {d['how']} 이 방식으로 반응하되, 보유 지식 밖의 사실을 지어내지 않는다."]


def anchor_line(cid):
    """페르소나 재고정(생성 직전 위치)."""
    c = PSY["characters"].get(cid)
    if not c:
        return []
    T = PSY["trait_text"]
    traits = [f"{T[k]['name']} {'높음' if level(c['big_five'][k]) == 'high' else '낮음'}" for k in ORDER if level(c["big_five"][k])]
    core = (" " + " ".join(c["core_facts"])) if c.get("core_facts") else ""
    return [f"다시 기억할 것: 너는 위의 인물이다. 성격({', '.join(traits)}), 말투({c['style']['register']}).{core} 보유 지식 밖의 사실은 말하지 않고, 세계 밖 질문에는 인물로서 어리둥절해한다."]


def monologue_task(cid, defense, energy, text, directives):
    c = PSY["characters"][cid]
    b, Dfs = c["big_five"], PSY["defenses"]
    tips = []
    if b["N"] >= 0.65:
        tips.append("신경성이 높아 위협과 의심에 먼저 눈이 간다")
    if b["A"] <= 0.35:
        tips.append("친화성이 낮아 상대를 깎아내리고 싶어 한다")
    if b["E"] >= 0.65:
        tips.append("외향성이 높아 먼저 말을 꺼내고 싶어 한다")
    if b["E"] <= 0.35:
        tips.append("외향성이 낮아 되도록 짧게 끝내고 싶어 한다")
    if energy <= D["low"]:
        tips.append("기운이 없어 생각도 짧다")
    dn = (f"{Dfs[defense]['ko']}({Dfs[defense]['how']})" if defense in Dfs
          else f"{Dfs[c['defense']['primary']]['ko']}(평소의 방어 방식)")
    t = (text or "")[:400] or "(탐정이 말없이 증거를 내민다)"
    dir_txt = ("\n## 이번 턴 지침\n" + "\n".join(f"- {x}" for x in directives) + "\n") if directives else ""
    return (f"탐정: {t}\n{dir_txt}\n## 지금 할 일: 대답하기 전의 속생각\n"
            "너는 아직 말하지 않는다. 이 인물의 머릿속 생각만 아래 세 줄로 쓴다. 탐정에게는 보이지 않는다.\n"
            "기분: (지금 느끼는 감정 한 줄)\n"
            f"받아들임: (방어기제 {dn}가 탐정의 말을 어떻게 받아들이게 하는지 한 줄)\n"
            "속셈: (하고 싶은 말과, 보유 지식·허용 표현 안에서 실제로 해도 되는 말 한 줄)\n"
            + (f"참고: {', '.join(tips)}.\n" if tips else "")
            + (f"- 바뀌지 않는 신상: {' '.join(c['core_facts'])}\n" if c.get("core_facts") else "")
            + "- 보유 지식에 없는 사실, 아직 털어놓지 않은 비밀은 속생각에도 쓰지 않는다. 없는 가족이나 사건을 지어내지 않는다.\n- 한국어로 세 줄만 쓴다.")


def with_monologue(inner):
    return f"너의 속생각(그대로 말하지 말고 태도와 말의 방향에만 반영하라): {inner}"


def clean_inner(t):
    t = (t or "").replace("\r", "").strip()
    lines = [x.strip() for x in t.split("\n") if re.match(r"^(기분|받아들임|속셈)\s*[:：]", x.strip())][:3]
    out = " / ".join(lines) if lines else " / ".join(t.split("\n")[:3])
    return out[:320].strip()


def persona_card(cid, name, role):
    """채점자에게 주는 인물 설정 요약(src/psych.js personaCard와 같은 문장)."""
    c = PSY["characters"][cid]
    T, D = PSY["trait_text"], PSY["defenses"]
    b5 = ", ".join(f"{T[k]['name']} {c['big_five'][k]:.2f}" + (f"({'높음' if level(c['big_five'][k]) == 'high' else '낮음'})" if level(c["big_five"][k]) else "") for k in ORDER)
    s = c["style"]
    alts = []
    for r in c["defense"]["rules"]:
        if r["name"] != c["defense"]["primary"] and D[r["name"]]["ko"] not in alts:
            alts.append(D[r["name"]]["ko"])
    lines = [f"이름: {name} ({role})", f"성격(Big Five 0~1): {b5}",
             f"주 방어기제: {D[c['defense']['primary']]['ko']} — {D[c['defense']['primary']]['how']}"]
    if alts:
        lines.append(f"상황에 따라 쓰는 방어기제: {', '.join(alts)}")
    lines.append(f"말투: {s['register']}; 문장 {s['sentence_chars'][0]}~{s['sentence_chars'][1]}자; {ELLIPSIS.get(s['ellipsis'], ELLIPSIS['mid'])}; 입버릇 {', '.join(s['catchphrases'])}; 행동 묘사 예 {' '.join(s['tone_markers'])}")
    return "\n".join(lines)


def defense_defs():
    return "\n".join(f"- {k}({v['ko']}): {v['how']}" for k, v in PSY["defenses"].items())
