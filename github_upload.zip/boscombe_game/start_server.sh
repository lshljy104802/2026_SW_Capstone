#!/bin/sh
# 보스콤 밸리 게임 서버 실행 (배포자 PC, Ollama)
cd "$(dirname "$0")" && python3 server/server.py --provider ollama --judge-provider ollama --model exaone3.5:7.8b "$@"
