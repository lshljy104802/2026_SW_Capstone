#!/bin/sh
# 보스콤 밸리 게임 서버 실행 (API 키 사용). 처음 한 번 키를 묻고 .env에 저장한다.
cd "$(dirname "$0")" || exit 1
[ -f .env ] || python3 server/server.py --setup
python3 server/server.py --model exaone3.5:7.8b "$@"
