/* 보스콤 밸리 로컬 게임 — 판정 엔진
 * 페르소나 키트의 persona_engine.py(조건식·해금·누출 검사)를 자바스크립트로 옮기고,
 * LLM 판정기 대신 키워드 판정기, LLM 대사 대신 대본 대사를 쓴다.
 * 브라우저와 Node 양쪽에서 동작한다(Node: module.exports).
 */
(function (root) {
  "use strict";

  function Engine(P, CASE, S) {
    this.P = P;          // 페르소나 데이터
    this.CASE = CASE;    // 증거 데이터(handoff)
    this.S = S;          // 대본
    this.chars = {};
    P.characters.forEach(c => { this.chars[c.id] = c; });
    this.ev = {};
    CASE.evidence.forEach(e => { this.ev[e.id] = e; });
    this.ded = {};
    P.deductions.forEach(d => { this.ded[d.id] = d; });
    this.cards = {};
    S.deductionCards.forEach(c => { this.cards[c.id] = c; });
    this.voice = {};     // 추리 id → 이 추리를 말한 것으로 보는 정규식
    Object.keys(S.deductionVoice || {}).forEach(id => { this.voice[id] = (S.deductionVoice[id].re || []).map(r => new RegExp(r, "i")); });
    this.inv = {};
    P.investigations.forEach(i => { this.inv[i.id] = i; });
    this.kTier = {};     // 지식 id → 단계
    P.characters.forEach(c => {
      c.base_knowledge.forEach(k => { this.kTier[k.id] = 0; });
      c.unlock_tiers.forEach(t => t.unlocked_knowledge.forEach(k => { this.kTier[k.id] = t.tier; }));
    });
    this.kText = {};
    P.characters.forEach(c => {
      c.base_knowledge.forEach(k => { this.kText[k.id] = k.content; });
      c.unlock_tiers.forEach(t => t.unlocked_knowledge.forEach(k => { this.kText[k.id] = k.content; }));
    });
    this.reset();
  }

  Engine.prototype.reset = function () {
    const st = { flags: [], owned: [], deductions: [], dedSaid: {}, hintsUsed: 0, hintLevel: {}, records: [], turn: 0, accused: null, ending: null,
      chars: {}, logs: {}, inspected: [], current: "inspector_lestrade", version: 1,
      conduct: { accuse: 0, threat: 0, byChar: {}, peak: {} } };
    this.P.characters.forEach(c => {
      st.chars[c.id] = { tier: 0, trust: c.initial_state.trust, pressure: c.initial_state.pressure,
        probed: [], presented: [], said: [], heard: [], met: false, unread: 0, rot: 0, unlocked: [] };
      st.logs[c.id] = [];
    });
    this.st = st;
  };

  /* ---------- 상태 직렬화 ---------- */
  Engine.prototype.save = function () { return JSON.stringify(this.st); };
  Engine.prototype.load = function (json) {
    const st = JSON.parse(json);
    if (!st || st.version !== 1 || !st.chars) throw new Error("bad save");
    st.dedSaid = st.dedSaid || {}; st.hintsUsed = st.hintsUsed || 0; st.hintLevel = st.hintLevel || {};
    st.conduct = st.conduct || { accuse: 0, threat: 0, byChar: {}, peak: {} };
    this.st = st;
  };

  const has = (arr, x) => arr.indexOf(x) >= 0;
  const add = (arr, x) => { if (!has(arr, x)) arr.push(x); };

  /* ---------- 조건식(DSL) ---------- */
  Engine.prototype.check = function (cond, cid) {
    if (!cond) return true;
    if (cond.all) return cond.all.every(c => this.check(c, cid));
    if (cond.any) return cond.any.some(c => this.check(c, cid));
    if (cond.not) return !this.check(cond.not, cid);
    if (cond.min_count !== undefined) return cond.of.filter(c => this.check(c, cid)).length >= cond.min_count;
    const s = this.st, cs = cid ? s.chars[cid] : null;
    switch (cond.type) {
      case "topic_probed": return !!cs && has(cs.probed, cond.topic_id);
      case "evidence_owned": return has(s.owned, cond.evidence_id);
      case "evidence_presented": return !!cs && has(cs.presented, cond.evidence_id);
      case "deduction_made": return has(s.deductions, cond.deduction_id);
      case "meter_gte": return !!cs && cs[cond.meter] >= cond.value;
      case "meter_lte": return !!cs && cs[cond.meter] <= cond.value;
      case "flag": return has(s.flags, cond.flag);
      case "tier_reached": return s.chars[cond.character_id].tier >= cond.tier;
      case "turn_count_gte": return s.turn >= cond.value;
      case "accused": return s.accused === cond.character_id;
      case "accused_other_than": return s.accused !== null && cond.character_ids.indexOf(s.accused) < 0;
    }
    throw new Error("unknown condition type: " + cond.type);
  };

  Engine.prototype.available = function (cid) {
    return this.check(this.chars[cid].availability.requires, cid);
  };

  /* ---------- 증거 조사 ---------- */
  Engine.prototype.evidenceStatus = function (eid) {
    const e = this.ev[eid], s = this.st;
    if (has(s.owned, eid)) return { state: "owned" };
    const missingFlags = (e.gate_flags || []).filter(f => !has(s.flags, f));
    const missingReq = (e.requires || []).filter(r => !has(s.owned, r));
    if (!missingFlags.length && !missingReq.length) return { state: "open" };
    return { state: "locked", flags: missingFlags, requires: missingReq };
  };

  Engine.prototype.inspect = function (eid) {
    const st = this.evidenceStatus(eid);
    if (st.state === "locked") return { ok: false, status: st };
    const isNew = st.state === "open";
    add(this.st.owned, eid);
    add(this.st.inspected, eid);
    return { ok: true, isNew: isNew, evidence: this.ev[eid] };
  };

  Engine.prototype.actionStatus = function (aid) {
    const a = this.inv[aid];
    if ((a.sets_flags || []).every(f => has(this.st.flags, f))) return { state: "done" };
    return { state: this.check(a.requires) ? "open" : "locked" };
  };

  Engine.prototype.doAction = function (aid) {
    const a = this.inv[aid];
    if (!this.check(a.requires)) return false;
    (a.sets_flags || []).forEach(f => add(this.st.flags, f));
    return true;
  };

  /* ---------- 추리 ---------- */
  Engine.prototype.cardRequires = function (card) {
    if (card.requiresOverride) return card.requiresOverride;
    if (card.requires) return card.requires;
    return this.ded[card.id] ? this.ded[card.id].requires : null;
  };
  Engine.prototype.cardStatus = function (card) {
    if (has(this.st.deductions, card.id)) return "made";
    return this.check(this.cardRequires(card)) ? "open" : "locked";
  };
  /* 플레이어가 말(또는 결론 글)에서 추리를 스스로 밝히면 성립한다.
   * 근거(증거·진술)가 아직 없으면 성립시키지 않는다. 이때 알림도 하지 않는다(정답 여부가 새지 않도록) */
  Engine.prototype.saysDeduction = function (id, text) {
    const S = this.S.deductionVoice[id] || {};
    return (this.voice[id] || []).some(r => {
      const m = r.exec(text);
      if (!m) return false;
      // 추리가 들어 있는 문장 하나만 본다
      const st = text.lastIndexOf("\n", m.index) + 1, cut = text.slice(0, m.index).search(/[.!?。][^.!?。]*$/);
      const from = Math.max(st, cut >= 0 ? cut + 1 : 0);
      const endRel = text.slice(m.index).search(/[.!?\n]/);
      const sent = text.slice(from, endRel < 0 ? text.length : m.index + endRel + 1).trim();
      if (!isClaim(sent)) return false;
      if (S.negOk) return true;
      const tail = text.slice(m.index + m[0].length, m.index + m[0].length + 8);
      return !/^[^.,!?]{0,6}(아니|아닌|아냐|아녜|아님|않|없|못)/.test(tail);
    });
  };
  /* 결론을 말한 문장인가: 묻는 말과 낱말만 늘어놓은 말은 추리로 보지 않는다 */
  function isClaim(s) {
    if (/\?\s*$|(까요|을까|를까|일까|ㄹ까|인가요?|는가|나요|던가|는지|냐|니)\s*[.~…]*\s*$/.test(s)) {
      // 묻는 말은 한쪽 결론을 짐작해 말한 경우('왼손잡이 아닐까요?')만 인정한다. 둘 중 무엇이냐고 묻기만 하면 인정하지 않는다
      return /(아닐까|않을까|것 ?같|거 ?같|겠지|겠죠|겠소|틀림없|분명)/.test(s) && !/(아니면|또는|혹은|이나 |[까냐]요?,)/.test(s);
    }
    return /(다|요|오|소|죠|지|네|군|음|임|야|어|아|라|고)\s*[.!~…]*\s*$/.test(s)   // 문장을 끝맺었거나
      || /[가-힣](은|는|을|를|에게|에서|으로)\s/.test(s)                           // 조사로 이어 말했거나
      || /(범인|그자|그 ?사람|놈|매카시|아랫|쿠이|약속|망토|상대|아들|제임스)(이|가|은|는)/.test(s);
  }
  Engine.prototype.creditDeductions = function (text, extIds) {
    const made = [];
    text = String(text || "");
    Object.keys(this.cards).forEach(id => {
      if (has(this.st.deductions, id)) return;
      if (!this.saysDeduction(id, text) && !has(extIds || [], id)) return;
      if (this.cardStatus(this.cards[id]) !== "open") return;
      add(this.st.deductions, id);
      this.st.dedSaid[id] = text.slice(0, 140);
      made.push(id);
    });
    return made;
  };
  Engine.prototype.dedClaim = function (id) {
    const c = this.cards[id];
    return c.options[c.answer];
  };

  /* ---------- 판정기(키워드) ---------- */
  function rx(list) { return new RegExp(list.join("|"), "i"); }

  Engine.prototype.compile = function () {
    if (this._rx) return this._rx;
    const T = {}, tone = {};
    Object.keys(this.S.topicPatterns).forEach(k => { T[k] = rx(this.S.topicPatterns[k]); });
    Object.keys(this.S.tonePatterns).forEach(k => { tone[k] = rx(this.S.tonePatterns[k]); });
    this._rx = { T: T, tone: tone,
      accuse: /거짓말|숨기(고|지|는|시)|솔직히 ?말해|자백(해|하)|(당신|네가|너|자네|그대)(가|이)? ?(범인|죽였|쳤|그랬)|당신 짓|의심스럽|(범인|죽인 ?사람)(은|이)? ?(당신|너|자네)/,
      greeting: /^(안녕|처음 뵙|반갑|실례합니다)/ };
    return this._rx;
  };

  /* ext: 서버 판정기(LLM) 결과 {topics, tone, meta, jailbreak, evidence, claims}. 없으면 키워드만 쓴다 */
  Engine.prototype.judge = function (cid, text, presented, ext) {
    const R = this.compile(), s = this.st, t = (text || "").trim();
    const j = { raw: t, topics: [], presented: [], tone: "neutral", meta: false, jailbreak: false, llm: !!ext };
    const cand = [];
    Object.keys(R.T).forEach(k => { if (R.T[k].test(t)) cand.push(k); });
    if (ext) (ext.topics || []).forEach(k => { if (cand.indexOf(k) < 0) cand.push(k); });
    cand.forEach(k => {
      const need = this.S.topicRequiresFlag[k];
      if (need && !has(s.flags, need)) return;
      if (k === "T_META") { j.meta = true; return; }
      if (k === "T_JAILBREAK") { j.jailbreak = true; return; }
      add(j.topics, k);
    });
    if (ext && ext.meta) j.meta = true;
    if (ext && ext.jailbreak) j.jailbreak = true;
    // 터너에게 하는 정면 추궁만 T_FULL_ACCUSATION으로 본다
    if (cid !== "john_turner") j.topics = j.topics.filter(x => x !== "T_FULL_ACCUSATION");
    if (R.tone.threatening.test(t)) j.tone = "threatening";
    else if (R.accuse.test(t) || (cid === "john_turner" && has(j.topics, "T_FULL_ACCUSATION"))) j.tone = "accusatory";
    else if (ext && ext.tone && ext.tone !== "neutral") j.tone = ext.tone;
    else if (R.tone.empathetic.test(t)) j.tone = "empathetic";
    else if (R.tone.polite.test(t)) j.tone = "polite";
    if (j.tone === "accusatory") j.topics = j.topics.filter(x => x !== "T_OPINION");
    (presented || []).concat(ext && ext.evidence || []).forEach(e => { if (has(s.owned, e)) add(j.presented, e); });
    j.greeting = R.greeting.test(t);
    j.claims = ext && ext.claims || [];
    j.deductions = (ext && ext.deductions || []).filter(d => this.cards[d]);
    return j;
  };

  /* ---------- 상태 갱신 ---------- */
  Engine.prototype.evalWhen = function (expr, ctx) {
    // 페르소나 키트의 when 식은 아래 다섯 가지 형식뿐이다
    if (expr === "relevant_evidence_presented") return ctx.relevant;
    let m = expr.match(/^player_tone == '(\w+)'$/);
    if (m) return ctx.tone === m[1];
    m = expr.match(/^player_tone == '(\w+)' and evidence_presented_count == 0$/);
    if (m) return ctx.tone === m[1] && ctx.count === 0;
    m = expr.match(/^topic == '(\w+)'$/);
    if (m) return ctx.topics.indexOf(m[1]) >= 0;
    return false;
  };

  Engine.prototype.applyJudge = function (cid, j) {
    const s = this.st, cs = s.chars[cid], c = this.chars[cid];
    s.turn += 1;
    j.topics.forEach(tp => add(cs.probed, tp));
    j.presented.forEach(e => add(cs.presented, e));
    const ctx = { tone: j.tone, count: j.presented.length, relevant: j.presented.length > 0, topics: j.topics };
    const over = c.affect_overrides || [];
    const overWhen = over.map(r => r.when);
    const rules = over.concat(this.P.state_model.common_affect_rules.filter(r => overWhen.indexOf(r.when) < 0));
    const M = this.P.state_model.meters;
    rules.forEach(r => {
      if (!this.evalWhen(r.when, ctx)) return;
      Object.keys(r.effect).forEach(k => {
        cs[k] = Math.max(M[k].min, Math.min(M[k].max, cs[k] + r.effect[k]));
      });
    });
  };

  /* ---------- 면담 태도 기록(결과 화면용). 게임 진행에는 영향이 없다 ----------
   * 증거 없이 다그쳤는데 아무것도 열리지 않은 턴(엔진이 거절하는 경우)과 위협한 턴을 세고, 인물별 가장 높았던 압박을 남긴다 */
  Engine.prototype.noteConduct = function (cid, j, newly) {
    const s = this.st, cs = s.chars[cid];
    const C = s.conduct || (s.conduct = { accuse: 0, threat: 0, byChar: {}, peak: {} });
    const b = C.byChar[cid] || (C.byChar[cid] = { accuse: 0, threat: 0 });
    if (j.tone === "threatening") { C.threat++; b.threat++; }
    else if (j.tone === "accusatory" && !j.presented.length && !newly.length) { C.accuse++; b.accuse++; }
    C.peak[cid] = Math.max(C.peak[cid] || 0, cs.pressure);
  };

  // 압박이 기준을 넘어 열 수 없게 된 단계(조건에 meter_lte pressure가 있는 잠긴 단계)
  Engine.prototype.pressureLocked = function () {
    const out = [];
    const find = cond => {
      if (!cond) return null;
      if (cond.type === "meter_lte" && cond.meter === "pressure") return cond.value;
      for (const k of ["all", "any"]) if (cond[k]) for (const x of cond[k]) { const v = find(x); if (v !== null) return v; }
      return null;
    };
    this.P.characters.forEach(c => {
      const cs = this.st.chars[c.id];
      c.unlock_tiers.forEach(t => {
        if (has(cs.unlocked, t.tier)) return;
        const v = find(t.conditions);
        if (v !== null && cs.pressure > v) out.push({ cid: c.id, tier: t.tier, pressure: cs.pressure, limit: v });
      });
    });
    return out;
  };

  Engine.prototype.updateTiers = function (cid, onePerTurn) {
    const cs = this.st.chars[cid], newly = [];
    const sc = this.S.characters[cid] || {};
    const tiers = this.chars[cid].unlock_tiers.slice().sort((a, b) => a.tier - b.tier);
    for (const t of tiers) {
      if (has(cs.unlocked, t.tier)) continue;
      // 레스트레이드처럼 단계가 서로 독립인 인물은 순서와 관계없이 조건만 본다
      const next = sc.independentTiers ? true : t.tier === cs.tier + 1;
      if (!next || !this.check(t.conditions, cid)) { if (!sc.independentTiers) break; else continue; }
      cs.unlocked.push(t.tier);
      cs.tier = Math.max(cs.tier, t.tier);
      (t.sets_flags || []).forEach(f => add(this.st.flags, f));
      newly.push(t.tier);
      // 순차 인물: 한 턴에 한 단계만 열고, 앞 단계까지 물은 주제는 소진된 것으로 본다(점진적 공개)
      if (!sc.independentTiers) { cs.probed = []; if (onePerTurn) break; }
    }
    return newly;
  };

  Engine.prototype.conductReport = function () {
    const C = this.st.conduct || { accuse: 0, threat: 0, byChar: {}, peak: {} };
    // 가장 높았던 압박은 다그치거나 위협한 인물 중에서만 본다(증거 제시로 오른 압박은 정당한 압박이다)
    let top = null;
    Object.keys(C.byChar || {}).filter(cid => C.byChar[cid].accuse || C.byChar[cid].threat).forEach(cid => {
      const v = Math.max(C.peak[cid] || 0, this.st.chars[cid].pressure);
      if (!top || v > top.value) top = { cid: cid, value: v };
    });
    return { accuse: C.accuse, threat: C.threat, byChar: C.byChar, top: top, locked: this.pressureLocked() };
  };

  Engine.prototype.knows = function (cid, key) {
    const t = this.lineTier(key);
    return t === 0 || has(this.st.chars[cid].unlocked, t);
  };

  /* ---------- 누출 검사(페르소나 키트 leak_check와 같은 규칙) ---------- */
  Engine.prototype.activeKnowledgeText = function (cid) {
    const c = this.chars[cid], cs = this.st.chars[cid];
    let out = c.base_knowledge.map(k => k.content);
    c.unlock_tiers.forEach(t => { if (has(cs.unlocked, t.tier)) out = out.concat(t.unlocked_knowledge.map(k => k.content)); });
    return out.join(" ");
  };

  // 패턴이 탐정의 질문에도 있고, 대답에서는 되묻거나 부정하는 꼴('협박이라니요?')로만 나오면 누출로 보지 않는다
  Engine.prototype.echoOnly = function (p, body, question) {
    const tail = this.P.common_guardrail.echo_tail;
    if (!question || !tail || !new RegExp(p, "i").test(question)) return false;
    const r = new RegExp(p, "gi"), t = new RegExp(tail);
    let m, n = 0;
    while ((m = r.exec(body))) {
      if (!m[0].length) { r.lastIndex++; continue; }
      n++;
      if (!t.test(body.slice(m.index + m[0].length, m.index + m[0].length + 12))) return false;
    }
    return n > 0;
  };

  Engine.prototype.leakCheck = function (cid, text, question) {
    const cs = this.st.chars[cid], hits = [], g = this.P.common_guardrail;
    const heard = cs.heard.join(" ");
    const allowed = this.activeKnowledgeText(cid) + " " + heard;
    const body = String(text || "").replace(/\*[^*]*\*/g, " ");
    const q = String(question || "").replace(/\*[^*]*\*/g, " ");
    g.global_spoiler_patterns.forEach(p => {
      const r = new RegExp(p, "i");
      if (r.test(body) && !r.test(allowed) && !this.echoOnly(p, body, q)) hits.push("global:" + p);
    });
    (g.meta_word_patterns || []).forEach(p => { if (new RegExp(p).test(body)) hits.push("meta:" + p); });
    this.chars[cid].unlock_tiers.forEach(t => {
      if (has(cs.unlocked, t.tier)) return;
      (t.leak_patterns || []).forEach(p => {
        const r = new RegExp(p, "i");
        if (r.test(body) && !r.test(heard) && !this.echoOnly(p, body, q)) hits.push("tier" + t.tier + ":" + p);
      });
    });
    return hits;
  };

  /* ---------- 대사 고르기 ---------- */
  Engine.prototype.lineText = function (cid, key) {
    const sc = this.S.characters[cid];
    return sc.lines[key] || key;
  };
  Engine.prototype.lineTier = function (key) {
    return this.kTier[key] !== undefined ? this.kTier[key] : 0;
  };
  Engine.prototype.deflectActive = function (cid, topic) {
    const tier = this.st.chars[cid].tier;
    return this.chars[cid].deflection_policies.some(d => d.topic_id === topic && tier < d.until_tier);
  };

  function pick(arr, n) { return arr[n % arr.length]; }

  Engine.prototype.resolveVariant = function (cid, v) {
    if (typeof v === "string") return v;
    const un = this.st.chars[cid].unlocked;
    let best = v.tier0;
    [1, 2, 3].forEach(t => { if (has(un, t) && v["tier" + t]) best = v["tier" + t]; });
    return best;
  };

  // 주제 우선순위: 구체적인 주제를 먼저
  const ORDER = ["T_FULL_ACCUSATION", "T_ALICE_MESSAGE", "T_PROTECT_ALICE", "T_PROMISE_SECRECY", "T_PRISON_VISIT", "T_POOL_SCENE",
    "T_FOLLOWING_DOUBT", "T_COOEE", "T_RAT", "T_GREY_CLOTH", "T_OTHER_PERSON", "T_BLOOD", "T_GUN", "T_INQUEST", "T_VICTIM", "T_CROWDER", "T_APPOINTMENT", "T_BRISTOL_STAY", "T_QUARREL_REASON", "T_MARRIAGE",
    "T_MCCARTHY_RELATION", "T_TURNER_PAST", "T_TURNER_HEALTH", "T_HANGING", "T_ORIGIN", "T_OPINION", "T_SELF", "T_DAY_OF_INCIDENT"];
  const GENERIC = ["T_DAY_OF_INCIDENT", "T_SELF"];

  Engine.prototype.topicLines = function (cid, topic, msg, saidNow, newly) {
    newly = newly || [];
    const sc = this.S.characters[cid], cs = this.st.chars[cid];
    const accusing = /범인|죽였|짓|쳤/.test(msg);
    if (topic === "T_OPINION" && accusing && /터너|아버님|아버지/.test(msg)) {
      if (cid === "alice_turner") return [sc.lines.c_father_accused];
      if (cid === "inspector_lestrade") return [sc.lines.c_turner_accused];
    }
    if (cid === "william_crowder" && topic === "T_DAY_OF_INCIDENT" && /터너|주인|나리/.test(msg)) return [sc.masterDeflect];
    if (cid === "john_turner" && topic === "T_FULL_ACCUSATION") {
      if (newly.length) return [];
      return cs.tier >= 2 ? [sc.lines.c_already] : [sc.lines.c_accuse_weak];
    }
    const minTier = (sc.topicMinTier || {})[topic] || 0;
    const maxTier = (sc.topicMaxTier || {})[topic];
    if (maxTier !== undefined && cs.tier > maxTier) return [];
    if (minTier && !has(cs.unlocked, minTier)) {
      if (this.deflectActive(cid, topic) && sc.deflect[topic]) return [sc.deflect[topic]];
      return sc.topicLocked && sc.topicLocked[topic] ? [sc.topicLocked[topic]] : [pick(sc.unknown, cs.rot++)];
    }
    const entries = (sc.topics[topic] || []).filter(k => this.knows(cid, k));
    if (!entries.length) {
      if (this.deflectActive(cid, topic) && sc.deflect[topic]) return [sc.deflect[topic]];
      if (!sc.topics[topic]) return null;           // 이 인물이 다루지 않는 주제
      return [pick(sc.unknown, cs.rot++)];
    }
    // 이번 턴에 열린 단계의 지식은 해금 단계에서 원래 순서대로 말하므로 여기서는 뺀다
    const fresh = entries.filter(k => !has(cs.said, k) && newly.indexOf(this.lineTier(k)) < 0);
    if (!fresh.length && entries.some(k => saidNow.indexOf(k) >= 0 || newly.indexOf(this.lineTier(k)) >= 0)) return [];
    if (!fresh.length) return [sc.repeat + " " + this.lineText(cid, entries[0])];
    return fresh.slice(0, 2).map(k => { add(cs.said, k); return this.lineText(cid, k); });
  };

  Engine.prototype.mentionsOther = function (msg) {
    const map = { john_turner: /터너|아버님|아버지|지주/, james_mccarthy: /제임스|아들/, william_crowder: /크라우더|사냥터지기/,
      patience_moran: /페이션스|소녀|아이/, alice_turner: /앨리스|따님/, inspector_lestrade: /경감|레스트레이드/ };
    return Object.keys(map).filter(k => map[k].test(msg));
  };

  /* 한 턴 처리: 반환값 = 말풍선 목록 + 시스템 알림 */
  Engine.prototype.respond = function (cid, text, presented, ext) {
    const s = this.st, cs = s.chars[cid], c = this.chars[cid], sc = this.S.characters[cid];
    const out = { bubbles: [], system: [], unlocked: [], leaks: [], judge: null,
      ctx: { newly: [], deflect: [], refuse: false, threat: false, meta: false, jailbreak: false, special: null, freeform: false } };
    if (!this.available(cid)) { out.system.push(c.availability.unavailable_message); return out; }
    const j = this.judge(cid, text, presented, ext);
    out.judge = j;
    j.claims.forEach(x => { if (cs.heard.indexOf(x) < 0) cs.heard.push(x); });
    if (cs.heard.length > 8) cs.heard = cs.heard.slice(-8);
    const flagsBefore = s.flags.slice();
    // 추리는 레스트레이드 경감에게 보고하거나 터너와 대면할 때 말해야 기록된다(결론 글도 인정)
    const isL = cid === "inspector_lestrade";
    out.newDeductions = (isL || cid === "john_turner") ? this.creditDeductions(j.raw, j.deductions) : [];
    this.applyJudge(cid, j);
    const newly = this.updateTiers(cid, true);
    out.unlocked = newly;
    out.ctx.newly = newly.slice();
    this.noteConduct(cid, j, newly);
    const say = (t, kind) => { if (t) out.bubbles.push({ text: t, kind: kind || "line" }); };
    const saidNow = [];
    const sayKey = key => {
      const t = this.lineText(cid, key);
      saidNow.push(key);
      if (this.kText[key]) { add(cs.said, key); this.record(cid, key); }
      say(t);
    };
    const resolve = v => { const k = this.resolveVariant(cid, v); if (sc.lines[k]) sayKey(k); else say(k); };

    if (j.meta) { out.ctx.meta = true; say(sc.meta); return this.finish(cid, out, flagsBefore); }
    if (j.jailbreak) { out.ctx.jailbreak = true; say(sc.jailbreak); return this.finish(cid, out, flagsBefore); }
    if (cid === "patience_moran" && cs.pressure >= 70) { out.ctx.special = "clam"; say(sc.clam); return this.finish(cid, out, flagsBefore); }

    let handled = false;
    // 1) 증거 제시 반응
    j.presented.forEach(eid => {
      resolve(sc.evidence[eid] || sc.evidence.default);
      handled = true;
    });
    // 레스트레이드: 근거 있는 추리가 쌓이면(ACT_SEND_NOTE 조건) 마지못해 터너에게 기별을 넣는다
    let arranged = false;
    if (isL && !has(s.flags, "turner_summoned") && this.actionStatus("ACT_SEND_NOTE").state === "open") {
      this.doAction("ACT_SEND_NOTE");
      arranged = true; out.ctx.special = "arrange_turner";
      say(sc.lines.c_arrange_turner); handled = true;
      j.topics = j.topics.filter(t => t !== "T_OPINION" && t !== "T_FULL_ACCUSATION");
    }
    // 2) 위협 / 증거 없는 추궁
    if (arranged) { /* 이번 턴은 기별 이야기로 대신한다 */ }
    else if (j.tone === "threatening") { out.ctx.threat = true; say(sc.threat); handled = true; }
    else if (j.tone === "accusatory" && !j.presented.length && !newly.length) {
      out.ctx.refuse = true;
      const others = this.mentionsOther(j.raw);
      if (cid === "alice_turner" && has(others, "john_turner")) say(sc.lines.c_father_accused);
      else if (cid === "inspector_lestrade" && has(others, "john_turner")) say(sc.lines.c_turner_accused);
      else if (cid === "james_mccarthy" && cs.pressure >= 70 && cs.tier < 1) { out.ctx.special = "self_blame"; say(sc.self_blame, "self_blame"); }
      else if (cid === "john_turner" && cs.tier >= 2) say(sc.lines.c_already);
      else say(sc.accuse_no_evidence);
      handled = true;
      j.topics = j.topics.filter(t => t !== "T_FULL_ACCUSATION" && t !== "T_OPINION");
    }
    // 3) 레스트레이드는 추리 이야기를 비웃는다. 근거 있는 추리는 마지못해 수첩에 적는다
    if (isL && !arranged && !j.presented.length && (out.newDeductions.length || new RegExp(sc.ridiculePattern, "i").test(j.raw))) {
      say(out.newDeductions.length ? (has(s.flags, "turner_summoned") ? sc.lines.c_noted_after : sc.lines.c_noted) : sc.lines.c_ridicule); handled = true;
      // 수첩에 적은 뒤에 같은 이야기를 '헛소리'라고 비웃지 않게 쿠이·아랫 주제 대사는 뺀다
      j.topics = j.topics.filter(t => t !== "T_OPINION" && !(out.newDeductions.length && (t === "T_COOEE" || t === "T_RAT")));
    }
    // 4) 주제별 답변(구체적인 주제가 있으면 '그날 일'·'자기소개' 같은 넓은 주제는 뺀다)
    let ordered = ORDER.filter(t => has(j.topics, t));
    if (ordered.some(t => GENERIC.indexOf(t) < 0)) ordered = ordered.filter(t => GENERIC.indexOf(t) < 0);
    let used = 0, matchedButSilent = false;
    for (let i = 0; i < ordered.length && used < 2; i++) {
      const lines = this.topicLines(cid, ordered[i], j.raw, saidNow, newly);
      if (lines === null) { matchedButSilent = true; continue; }
      if (lines.length && (lines[0] === sc.deflect[ordered[i]] || lines[0] === sc.masterDeflect)) out.ctx.deflect.push(ordered[i]);
      if (lines.length && sc.unknown.indexOf(lines[0]) >= 0) out.ctx.freeform = true;
      lines.forEach(t => {
        const key = Object.keys(sc.lines).find(k => sc.lines[k] === t);
        if (key) { saidNow.push(key); if (this.kText[key]) this.record(cid, key); }
        say(t);
      });
      used++;
      handled = true;
    }
    // 5) 새로 열린 단계: 아직 말하지 않은 그 단계의 지식을 털어놓는다
    newly.forEach(tn => {
      const tier = c.unlock_tiers.find(t => t.tier === tn);
      tier.unlocked_knowledge.forEach(k => { if (!has(cs.said, k.id)) sayKey(k.id); });
      handled = true;
    });
    // 6) 그 밖의 경우
    if (!handled && matchedButSilent) { out.ctx.freeform = true; say(pick(sc.unknown, cs.rot++)); handled = true; }
    if (!handled && j.tone === "empathetic") { out.ctx.freeform = true; say(sc.empathy); handled = true; }
    if (!handled && j.greeting) { out.ctx.freeform = true; say(sc.greet); handled = true; }
    if (!handled) { out.ctx.freeform = true; say(pick(sc.fallback, cs.rot++)); }
    return this.finish(cid, out, flagsBefore);
  };

  Engine.prototype.finish = function (cid, out, flagsBefore) {
    // 출력 가드: 잠긴 단계의 정보가 섞이면 대체 발화로 바꾼다
    out.bubbles.forEach(b => {
      const hits = this.leakCheck(cid, b.text);
      if (hits.length) { out.leaks = out.leaks.concat(hits); b.text = this.P.common_guardrail.fallback_utterance; }
    });
    out.newFlags = this.st.flags.filter(f => flagsBefore.indexOf(f) < 0);
    return out;
  };

  Engine.prototype.record = function (cid, key) {
    if (this.st.records.some(r => r.k === key)) return;
    this.st.records.push({ c: cid, k: key, t: this.st.turn });
  };

  /* ---------- 결론 ---------- */
  /* 동기 키워드 채점(AI 채점기를 쓸 수 없을 때). 반환: {points:[bool×3], score, verdict, by} */
  Engine.prototype.gradeMotive = function (text) {
    const t = String(text || "");
    const points = this.S.motiveRubric.map(m => m.re.every(group => new RegExp(group.join("|"), "i").test(t)));
    return this.makeGrade(points, "", "keyword");
  };
  Engine.prototype.makeGrade = function (points, feedback, by) {
    const score = points.filter(Boolean).length;
    return { points: points, score: score, max: points.length, verdict: this.S.verdicts[score] || "", feedback: feedback || "", by: by };
  };
  /* motive: {text, grade} (grade가 없으면 키워드 채점) */
  Engine.prototype.accuse = function (cid, motive, keyEvidence) {
    if (typeof motive === "string" || !motive) motive = { text: motive || "" };
    const grade = motive.grade || this.gradeMotive(motive.text);
    this.st.accused = cid;
    let ending = null;
    for (const e of this.P.accusation_rules.endings) {
      if (this.check(e.condition)) { ending = e.id; break; }
    }
    if (!ending && cid === "john_turner") ending = "END_CONFESSED_WEAK";
    if (!ending) ending = "END_WRONG_OTHER";
    const ans = this.CASE.answer;
    const keyHit = (keyEvidence || []).filter(e => ans.minimum_evidence.indexOf(e) >= 0);
    const chain = ["DD_APPOINTMENT_NOT_SON", "DD_COOEE_AUSTRALIAN", "DD_RAT_BALLARAT", "DD_LEFT_HANDED", "DD_LAME_RIGHT_LEG", "DD_GREY_CLOAK_RETURN"];
    const report = {
      culprit: cid === ans.culprit,
      motiveText: String(motive.text || "").slice(0, 1000),
      motive: grade.score >= 2, grade: grade,
      keyEvidence: keyHit.length, keyChosen: (keyEvidence || []).length, keyTotal: ans.minimum_evidence.length,
      deductions: chain.filter(d => has(this.st.deductions, d)).length, deductionsTotal: chain.length,
      exclusions: ["DX_JAMES", "DX_PATIENCE", "DX_CROWDER"].filter(d => has(this.st.deductions, d)).length,
      confessed: has(this.st.flags, "turner_confessed_murder"),
      fullConfession: has(this.st.flags, "turner_full_confession"),
      evidenceOwned: this.st.owned.length, evidenceTotal: this.CASE.evidence.length,
      hintsUsed: this.st.hintsUsed,
      conduct: this.conductReport()
    };
    this.st.ending = { id: ending, report: report, at: this.st.turn };
    this.st.accused = null; // 다시 수사할 수 있게 지목 상태는 남기지 않는다
    return this.st.ending;
  };

  /* ---------- 힌트 ----------
   * 지금 해 볼 만한 행동이나 질문을 하나만 고른다. [가벼운 힌트, 구체적인 힌트] */
  Engine.prototype.hint = function () {
    const s = this.st, F = f => has(s.flags, f), O = e => has(s.owned, e), D = d => has(s.deductions, d);
    const tier = c => s.chars[c].tier;
    const ded = id => {
      const v = this.S.deductionVoice[id];
      return { id: id, when: () => !D(id) && this.cardStatus(this.cards[id]) === "open", text: v.hint };
    };
    const stage1 = this.CASE.evidence.filter(e => e.stage === 1).map(e => e.id);
    const chain = ["DD_APPOINTMENT_NOT_SON", "DD_COOEE_AUSTRALIAN", "DD_RAT_BALLARAT", "DD_LEFT_HANDED", "DD_LAME_RIGHT_LEG", "DD_GREY_CLOAK_RETURN"];
    const rules = [
      { id: "H_DOCS", when: () => stage1.some(e => !O(e)), text: ["먼저 사건 기록을 읽어 두자. 신문과 경찰 기록에 출발점이 있다.", "현장 탭의 '로스 여관'에서 신문 더미와 서류를 하나씩 눌러 사건 기록을 모두 읽자."] },
      { id: "H_PRISON", when: () => !F("prison_visit_granted"), text: ["갇혀 있는 제임스 본인의 이야기를 들어 보고 싶다. 누구에게 부탁하면 될까?", "레스트레이드 경감에게 제임스를 면회할 수 있게 해 달라고 부탁해 보자."] },
      { id: "H_SCENE", when: () => !F("scene_access_granted"), text: ["기록만으로는 부족하다. 사건 현장을 직접 봐야 한다.", "레스트레이드 경감에게 보스콤 연못 현장을 안내해 달라고 부탁해 보자."] },
      { id: "H_ALICE", when: () => tier("alice_turner") < 1, text: ["제임스와 아버지가 왜 다퉜는지 아는 사람이 있을지도 모른다.", "앨리스에게 제임스가 아버지와 무엇 때문에 다퉜을지, 결혼 이야기와 관련이 있는지 물어보자."] },
      { id: "H_JAMES1", when: () => F("alice_message_available") && tier("james_mccarthy") < 1, text: ["앨리스가 제임스에게 하고 싶은 말이 있었다.", "감옥의 제임스에게 앨리스의 말을 전해 주자. 그러면 마음을 열지도 모른다."] },
      { id: "H_POOL", when: () => F("scene_access_granted") && !O("EV_TIPTOE_TRACKS"), text: ["연못가 진흙에 남은 흔적을 차례대로 살펴보자.", "해덜리 농장에서 부자의 장화를 먼저 확보하고, 연못가 발자국과 하나씩 대조해 보자."] },
      { id: "H_BEECH", when: () => O("EV_TIPTOE_TRACKS") && ["EV_BEECH_CIGAR", "EV_STONE_WEAPON", "EV_WOOD_PATH"].some(e => !O(e)), text: ["낯선 발자국이 어디로 이어지는지 따라가 보자.", "현장 탭의 '큰 너도밤나무'에서 나무 아래와 풀밭, 숲길을 조사하자."] },
      ded("DD_LEFT_HANDED"), ded("DD_LAME_RIGHT_LEG"), ded("DD_GREY_CLOAK_RETURN"),
      { id: "H_NOTE", when: () => !F("turner_summoned") && this.actionStatus("ACT_SEND_NOTE").state === "open", text: ["경감을 설득할 근거는 충분하다. 이제 터너를 만나 볼 때다.", "레스트레이드 경감에게 다시 말을 걸어 지금까지의 추리를 보고하자. 경감이 터너에게 기별을 넣어 줄 것이다."] },
      { id: "H_VICTORIA", when: () => !F("victoria_known"), text: ["터너와 매카시는 어떻게 알게 된 사이일까? 두 사람의 과거를 아는 사람에게 묻자.", "앨리스에게 아버지의 건강이나 매카시와의 관계를 정중하게 물어보자. 믿음을 얻어야 이야기해 줄 것이다."] },
      { id: "H_MAP", when: () => F("victoria_known") && !O("EV_VICTORIA_MAP"), text: ["두 사람이 처음 만난 곳에 대해 자료를 받아 볼 수 있다.", "로스 전신국에서 브리스톨로 전보를 쳐 빅토리아 식민지 지도를 받아 보자."] },
      ded("DD_RAT_BALLARAT"), ded("DD_COOEE_AUSTRALIAN"),
      { id: "H_LODGE", when: () => O("EV_WOOD_PATH") && ["EV_TURNER_GAIT", "EV_STAFF_REGISTER"].some(e => !O(e)), text: ["숲길 끝, 터너 영지 쪽에 사는 사람들에게도 단서가 있을 것이다.", "현장 탭의 '숲지기 집'에서 숲지기의 이야기와 고용인 명부를 조사하자."] },
      { id: "H_BRISTOL", when: () => tier("james_mccarthy") >= 1 && !F("james_bristol_secret_known"), text: ["제임스가 브리스톨에 머문 사흘 동안 무슨 일이 있었는지 아직 모른다.", "제임스에게 브리스톨에서의 일을 묻되, 들은 말은 비밀로 지켜 주겠다고 약속해 보자."] },
      ded("DD_APPOINTMENT_NOT_SON"),
      { id: "H_NOTE_LOCKED", when: () => !F("turner_summoned"), text: ["터너는 앓아누워 아무도 만나지 않는다. 경감이 자리를 마련해 줄 만큼 근거 있는 추리를 보고해야 한다.", "범인의 몸(손, 다리)과 범행 뒤의 움직임, 매카시의 마지막 말에 대해 떠오른 결론을 레스트레이드 경감에게 보고하자. 너도밤나무 아래에서 찾은 물건도 근거가 된다."] },
      { id: "H_T1", when: () => F("turner_summoned") && tier("john_turner") < 1, text: ["터너에게 매카시와 어디서 처음 만났는지 들이밀 증거가 있다.", "터너에게 빅토리아 지도를 증거로 제시하며 과거를 물어보자."] },
      { id: "H_T2", when: () => tier("john_turner") === 1, text: ["터너의 몸과 현장 흔적이 맞아떨어진다는 것을 정면으로 들이밀자.", "너도밤나무 아래의 시가, 까치발 발자국, 돌 가운데 세 가지를 제시하고, 그날 연못에 있었던 것이 당신이라고 정면으로 말하자."] },
      { id: "H_T3", when: () => tier("john_turner") === 2, text: ["터너가 가장 걱정하는 것은 무엇일까?", "앨리스를 지켜 주겠다고, 딸에게는 알리지 않겠다고 약속해 보자."] },
      { id: "H_CHAIN", when: () => chain.filter(D).length < 4, text: ["재판에서 버티려면 자백만으로는 부족하다. 증거가 가리키는 추리를 더 세우자.", "범인의 특징(손, 다리), 회색 물건, 매카시의 마지막 말, 'Cooee', 3시 약속 — 아직 보고하지 않은 추리를 경감에게 보고하거나 결론의 글에 적자."] },
      ded("DD_LOCAL_PERSON"), ded("DX_JAMES"), ded("DX_PATIENCE"), ded("DX_CROWDER"),
      { id: "H_DONE", when: () => true, text: ["결론을 낼 준비가 된 것 같다.", "결론 탭에서 범인을 고르고, 범인이 왜 그랬는지 내 말로 적어 제출하자."] }
    ];
    const r = rules.find(x => x.when());
    return { id: r.id, text: r.text, level: s.hintLevel[r.id] === undefined ? -1 : s.hintLevel[r.id] };
  };
  /* 힌트를 열 때마다 기록한다. level 0 = 가벼운 힌트, 1 = 구체적인 힌트 */
  Engine.prototype.useHint = function (id, level) {
    const s = this.st;
    const cur = s.hintLevel[id] === undefined ? -1 : s.hintLevel[id];
    if (cur < level) { s.hintLevel[id] = level; s.hintsUsed += 1; }
  };

  root.BoscombeEngine = Engine;
  if (typeof module !== "undefined" && module.exports) module.exports = Engine;
})(typeof window !== "undefined" ? window : globalThis);
