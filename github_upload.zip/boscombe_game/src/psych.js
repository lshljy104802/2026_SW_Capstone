/* 보스콤 밸리 — 심리 기반 페르소나 계층(PersonaForge 3층 구조 + 선택적 이중처리)
 *
 * 데이터: data/persona_psych.json
 *   1층 핵심 특성: Big Five(0~1) + 방어기제(발동 규칙)
 *   2층 말투 행렬: 문장 길이, 어미, 말줄임표, 입버릇, 행동 묘사
 *   3층 동적 상태: 엔진의 신뢰·긴장 + 기운(에너지)
 * 변형: A = 기존 페르소나, B = A + 위 3층, C = B + 중요한 턴에 속생각(내적 독백)을 먼저 만든 뒤 대답
 *
 * 턴 판정(방어기제·중요한 턴·기운)은 이 파일에서만 한다. 서버(server/psych.py)는 받은 결과로 프롬프트만 만든다.
 */
(function (root) {
  "use strict";
  const LEVEL = v => (v >= 0.65 ? "high" : v <= 0.35 ? "low" : null);
  const ELLIPSIS = { high: "말줄임표(…)로 말을 자주 끊는다", mid: "가끔 말줄임표(…)를 쓴다", low: "말줄임표는 거의 쓰지 않고 또박또박 말한다" };
  const ORDER = ["O", "C", "E", "A", "N"];

  function Psych(PSY) {
    this.PSY = PSY;
    this.D = PSY.dynamic_state.energy;
  }

  Psych.prototype.has = function (cid) { return !!this.PSY.characters[cid]; };

  /* 인물별 기운 상태(엔진 저장 데이터 안에 함께 저장된다) */
  Psych.prototype.state = function (st, cid) {
    st.psy = st.psy || {};
    if (!st.psy[cid]) {
      const c = this.PSY.characters[cid];
      st.psy[cid] = { energy: c ? c.energy_start : 80, last: null };
    }
    return st.psy[cid];
  };

  /* when 조건(모두 맞아야 함) */
  Psych.prototype.match = function (w, t) {
    if (w.tone && w.tone.indexOf(t.tone) < 0) return false;
    if (w.presented && !t.presented) return false;
    if (w.topics && !w.topics.some(x => t.topics.indexOf(x) >= 0)) return false;
    if (w.tier_min !== undefined && t.tier < w.tier_min) return false;
    if (w.tier_max !== undefined && t.tier > w.tier_max) return false;
    if (w.pressure_min !== undefined && t.pressure < w.pressure_min) return false;
    if (w.ctx && !w.ctx.some(k => (k === "deflect" ? (t.ctx.deflect || []).length > 0 : !!t.ctx[k]))) return false;
    return true;
  };

  /* 한 턴 판정. t = {tone, topics, presented(개수), ctx, tier, trust0, trust1, pressure0, pressure1, first}
   * 반환: {defense, critical, reasons, energy, mood} */
  Psych.prototype.turn = function (st, cid, t) {
    const c = this.PSY.characters[cid], ps = this.state(st, cid);
    if (!c) return { defense: null, critical: false, reasons: [], energy: ps.energy, mood: "보통" };
    t.topics = t.topics || []; t.ctx = t.ctx || {};
    // 3층: 기운 갱신(논문의 +10 / -15 / -2 규칙)
    const neg = t.pressure1 > t.pressure0 || t.tone === "accusatory" || t.tone === "threatening";
    const pos = !neg && (t.trust1 > t.trust0 || t.tone === "empathetic" || t.tone === "polite");
    const delta = neg ? this.D.negative : pos ? this.D.positive : this.D.neutral;
    ps.energy = Math.max(0, Math.min(this.D.max, ps.energy + delta));
    // 1층: 방어기제(첫 번째로 맞는 규칙)
    const rule = (c.defense.rules || []).find(r => this.match(r.when, t));
    const defense = rule ? rule.name : null;
    // 중요한 턴(속생각을 만들 턴)
    const reasons = [];
    if (t.first) reasons.push("첫 만남");
    if (t.presented) reasons.push("증거 제시");
    if ((t.ctx.newly || []).length) reasons.push("새로 털어놓음");
    if (t.ctx.threat || t.ctx.refuse || t.tone === "accusatory" || t.tone === "threatening") reasons.push("추궁·위협");
    if (defense) reasons.push("방어기제 발동");
    if (Math.abs((t.trust1 || 0) - (t.trust0 || 0)) >= 5) reasons.push("신뢰 변화");
    const mood = neg ? "긴장" : pos ? "누그러짐" : "보통";
    ps.last = { defense: defense, critical: reasons.length > 0, reasons: reasons, energy: ps.energy, mood: mood, delta: delta };
    return ps.last;
  };

  /* ---------- 프롬프트 조각(server/psych.py와 같은 문장) ---------- */
  Psych.prototype.systemBlock = function (cid, energy) {
    const c = this.PSY.characters[cid];
    if (!c) return [];
    const T = this.PSY.trait_text, L = ["", "## 성격 특성(Big Five, 0~1)"];
    ORDER.forEach(k => {
      const v = c.big_five[k], lv = LEVEL(v);
      L.push(`- ${T[k].name} ${v.toFixed(2)}${lv ? (lv === "high" ? " 높음: " : " 낮음: ") + T[k][lv] : " 보통"}`);
    });
    const d = this.PSY.defenses[c.defense.primary];
    L.push("", "## 방어기제(스트레스를 받을 때 생각이 비틀리는 방식)", `- 주 방어기제: ${d.ko} — ${d.how}`);
    const s = c.style;
    L.push("", "## 말투 규칙",
      `- 한 문장은 대체로 ${s.sentence_chars[0]}~${s.sentence_chars[1]}자.`,
      `- 어미: ${s.register} (예: ${s.endings.map(x => "~" + x).join(", ")})`,
      `- ${ELLIPSIS[s.ellipsis] || ELLIPSIS.mid}`,
      `- 입버릇(필요할 때 한 답변에 많아야 하나): ${s.catchphrases.map(x => "'" + x + "'").join(", ")}`,
      `- 행동 묘사 예: ${s.tone_markers.join(" ")}`);
    if (c.voice_examples && c.voice_examples.length) {
      L.push("", "## 말투 예시(말투만 참고하고, 내용을 그대로 되풀이하지 않는다)");
      c.voice_examples.forEach(([q, a]) => L.push(`탐정: ${q}`, `나: ${a}`));
    }
    if (c.core_facts && c.core_facts.length) { L.push("", "## 바뀌지 않는 내 신상(속생각에서도 벗어나지 않는다)"); c.core_facts.forEach(x => L.push("- " + x)); }
    if (this.PSY.world_boundary) L.push("", "## 세계 밖 질문", "- " + this.PSY.world_boundary);
    const e = Math.round(energy === undefined ? c.energy_start : energy);
    L.push("", `## 기운 ${e}/100`);
    if (e <= this.D.low) L.push("- 기운이 거의 없다. 1~2문장으로 짧게 말하고, 말끝을 흐린다.");
    else if (e >= 80) L.push("- 기운이 있다. 성격대로 충분히 말한다.");
    return L;
  };

  Psych.prototype.turnLines = function (cid, defense) {
    if (!defense || !this.PSY.defenses[defense]) return [];
    const d = this.PSY.defenses[defense];
    return [`이번 턴에는 방어기제 '${d.ko}'가 작동한다: ${d.how} 이 방식으로 반응하되, 보유 지식 밖의 사실을 지어내지 않는다.`];
  };

  /* 페르소나 재고정: 생성 직전 위치에 짧게 다시 알린다(대화가 길어질수록 시스템 프롬프트에서 멀어지는 이탈을 줄임) */
  Psych.prototype.anchorLine = function (cid) {
    const c = this.PSY.characters[cid];
    if (!c) return [];
    const T = this.PSY.trait_text;
    const traits = ORDER.map(k => [k, LEVEL(c.big_five[k])]).filter(x => x[1]).map(([k, lv]) => `${T[k].name} ${lv === "high" ? "높음" : "낮음"}`);
    const core = c.core_facts && c.core_facts.length ? " " + c.core_facts.join(" ") : "";
    return [`다시 기억할 것: 너는 위의 인물이다. 성격(${traits.join(", ")}), 말투(${c.style.register}).${core} 보유 지식 밖의 사실은 말하지 않고, 세계 밖 질문에는 인물로서 어리둥절해한다.`];
  };

  /* 속생각(1단계) 지시. 시스템 프롬프트(인물 설정) 뒤에 user 턴으로 붙인다 */
  Psych.prototype.monologueTask = function (cid, defense, energy, text, directives) {
    const c = this.PSY.characters[cid], b = c.big_five, D = this.PSY.defenses;
    const tips = [];
    if (b.N >= 0.65) tips.push("신경성이 높아 위협과 의심에 먼저 눈이 간다");
    if (b.A <= 0.35) tips.push("친화성이 낮아 상대를 깎아내리고 싶어 한다");
    if (b.E >= 0.65) tips.push("외향성이 높아 먼저 말을 꺼내고 싶어 한다");
    if (b.E <= 0.35) tips.push("외향성이 낮아 되도록 짧게 끝내고 싶어 한다");
    if (energy <= this.D.low) tips.push("기운이 없어 생각도 짧다");
    const dn = defense && D[defense] ? `${D[defense].ko}(${D[defense].how})` : `${D[c.defense.primary].ko}(평소의 방어 방식)`;
    return `탐정: ${String(text || "").slice(0, 400) || "(탐정이 말없이 증거를 내민다)"}
${directives.length ? "\n## 이번 턴 지침\n" + directives.map(x => "- " + x).join("\n") + "\n" : ""}
## 지금 할 일: 대답하기 전의 속생각
너는 아직 말하지 않는다. 이 인물의 머릿속 생각만 아래 세 줄로 쓴다. 탐정에게는 보이지 않는다.
기분: (지금 느끼는 감정 한 줄)
받아들임: (방어기제 ${dn}가 탐정의 말을 어떻게 받아들이게 하는지 한 줄)
속셈: (하고 싶은 말과, 보유 지식·허용 표현 안에서 실제로 해도 되는 말 한 줄)
${tips.length ? "참고: " + tips.join(", ") + ".\n" : ""}${c.core_facts && c.core_facts.length ? "- 바뀌지 않는 신상: " + c.core_facts.join(" ") + "\n" : ""}- 보유 지식에 없는 사실, 아직 털어놓지 않은 비밀은 속생각에도 쓰지 않는다. 없는 가족이나 사건을 지어내지 않는다.
- 한국어로 세 줄만 쓴다.`;
  };

  Psych.prototype.withMonologue = function (inner) {
    return `너의 속생각(그대로 말하지 말고 태도와 말의 방향에만 반영하라): ${inner}`;
  };

  /* 속생각 정리: 세 줄만, 길이 제한 */
  Psych.prototype.cleanInner = function (t) {
    t = String(t || "").replace(/\r/g, "").trim();
    const lines = t.split("\n").map(x => x.trim()).filter(x => /^(기분|받아들임|속셈)\s*[:：]/.test(x)).slice(0, 3);
    const out = (lines.length ? lines.join(" / ") : t.split("\n").slice(0, 3).join(" / ")).slice(0, 320);
    return out.trim();
  };

  /* 채점자에게 주는 인물 설정 요약(server/psych.py persona_card와 같은 문장) */
  Psych.prototype.personaCard = function (cid, name, role) {
    const c = this.PSY.characters[cid], T = this.PSY.trait_text, D = this.PSY.defenses;
    const b5 = ORDER.map(k => `${T[k].name} ${c.big_five[k].toFixed(2)}` + (LEVEL(c.big_five[k]) ? `(${LEVEL(c.big_five[k]) === "high" ? "높음" : "낮음"})` : "")).join(", ");
    const s = c.style, alts = [];
    c.defense.rules.forEach(r => { if (r.name !== c.defense.primary && alts.indexOf(D[r.name].ko) < 0) alts.push(D[r.name].ko); });
    const L = [`이름: ${name} (${role})`, `성격(Big Five 0~1): ${b5}`, `주 방어기제: ${D[c.defense.primary].ko} — ${D[c.defense.primary].how}`];
    if (alts.length) L.push(`상황에 따라 쓰는 방어기제: ${alts.join(", ")}`);
    L.push(`말투: ${s.register}; 문장 ${s.sentence_chars[0]}~${s.sentence_chars[1]}자; ${ELLIPSIS[s.ellipsis] || ELLIPSIS.mid}; 입버릇 ${s.catchphrases.join(", ")}; 행동 묘사 예 ${s.tone_markers.join(" ")}`);
    return L.join("\n");
  };
  Psych.prototype.defenseDefs = function () {
    return Object.keys(this.PSY.defenses).map(k => `- ${k}(${this.PSY.defenses[k].ko}): ${this.PSY.defenses[k].how}`).join("\n");
  };

  root.BVPsych = Psych;
  if (typeof module !== "undefined" && module.exports) module.exports = Psych;
})(typeof window !== "undefined" ? window : globalThis);
