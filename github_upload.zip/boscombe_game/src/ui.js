/* 보스콤 밸리 로컬 게임 — 화면
 * 화면 틀은 팀원 36번(경쟁판-2) UI를 따른다: 짙은 머리줄, 기울어진 탭, 탭 안내 띠, 다음 실마리, 노트·수사 기록 탭,
 * 수사 안내서, 증거 카드·대조 책상·자세히, 오른쪽 인물 패널과 종이 쪽지 대사.
 * 지도·장소 그림·인물 그림은 이 게임의 것(art.js, scenes.js), 판정은 engine.js, 페르소나는 psych.js·prompts.js.
 */
(function () {
  "use strict";
  const G = window.GAME, S = window.SCRIPT, Art = window.BVArt;
  const E = new window.BoscombeEngine(G.personas, G.case, S);
  const SAVE_KEY = "boscombe_local_v1", SET_KEY = "boscombe_local_settings", MEMO_KEY = "boscombe_memo", UI_KEY = "boscombe_ui";
  const NAMES = {}; G.personas.characters.forEach(c => { NAMES[c.id] = c.name; });
  const CHAR_ORDER = ["inspector_lestrade", "alice_turner", "patience_moran", "william_crowder", "james_mccarthy", "john_turner"];
  const SHORT = { inspector_lestrade: "경감", alice_turner: "앨리스", patience_moran: "페이션스", william_crowder: "크라우더", james_mccarthy: "제임스", john_turner: "터너" };
  const LOCNAME = {}; G.case.locations.forEach(l => { LOCNAME[l.id] = l.name; });
  const LOCDESC = {
    ross_hotel: "탐정이 묵는 로스의 여관. 사건 기사와 검시 기록이 실린 지역 신문, 경찰 기록을 여기서 읽을 수 있다.",
    ross_telegraph: "로스의 전신국. 브리스톨로 전보를 쳐서 자료를 받아 볼 수 있다.",
    hereford_gaol: "제임스 매카시가 갇혀 있는 감옥. 면회 허가가 있어야 들어갈 수 있다.",
    hatherley_farm: "매카시 부자가 살던 농장. 터너 소유의 땅이다.",
    hatherley_path: "농장에서 보스콤 연못으로 이어지는 길. 사냥터지기 크라우더가 부자를 본 길이다.",
    boscombe_pool: "해덜리 농장과 터너 영지 사이의 작은 연못. 둘레가 질척한 풀밭이다.",
    pool_woods: "연못을 둘러싼 숲.",
    great_beech: "숲 가장자리에 선 큰 너도밤나무.",
    wood_path: "숲을 지나 큰길로 이어지는 길.",
    moran_lodge: "터너 영지의 숲지기 모런 가족이 사는 집. 사건 직후 제임스가 도움을 청하러 달려온 곳이다.",
    turner_hall: "이 지역 최대 지주 존 터너의 저택. 터너는 몸져누워 있어 의사가 면회를 막고 있다."
  };
  const CHAR_LOC = { inspector_lestrade: "ross_hotel", alice_turner: "ross_hotel", james_mccarthy: "hereford_gaol", patience_moran: "moran_lodge", william_crowder: "hatherley_path", john_turner: "turner_hall" };
  const FLAG_MSG = {
    prison_visit_granted: "레스트레이드 경감이 면회 허가증을 내주었다. 이제 감옥의 제임스와 이야기할 수 있다.",
    scene_access_granted: "경감이 현장으로 안내했다. 지도의 연못·농장·숲을 조사할 수 있다.",
    victoria_known: "터너와 매카시가 빅토리아 금광에서 알게 되었다는 것을 알았다. 로스 전신국에서 지도를 요청할 수 있다.",
    alice_message_available: "앨리스의 전언을 받았다. 제임스에게 전할 수 있다.",
    james_quarrel_reason_known: "제임스가 말다툼의 이유를 털어놓았다.",
    james_bristol_secret_known: "제임스가 브리스톨의 비밀을 털어놓았다.",
    patience_opened_up: "페이션스가 마음을 열었다.",
    crowder_testimony_weakened: "크라우더가 '따라갔다'는 말이 짐작이었다고 인정했다.",
    turner_rent_free_known: "터너가 매카시에게 땅을 공짜로 빌려주었다는 소문을 들었다.",
    turner_blackmail_admitted: "터너가 매카시에게 협박당해 왔다고 인정했다.",
    turner_confessed_murder: "터너가 연못에서의 일을 자백했다.",
    turner_full_confession: "터너가 모든 것을 털어놓고 자백서 서명에 동의했다.",
    turner_summoned: "레스트레이드 경감이 숲지기 모런 편에 터너에게 쪽지를 보냈다. 이제 터너와 대화할 수 있다."
  };
  const FLAG_HINT = { scene_access_granted: "레스트레이드 경감에게 현장 안내를 부탁해야 한다.", victoria_known: "터너와 매카시가 호주 어디에서 알게 되었는지 알아야 전보를 칠 수 있다." };
  const UNAVAIL_HINT = { james_mccarthy: () => "레스트레이드 경감에게 면회를 부탁해 보자.", john_turner: () => noteHint() };
  /* 터너를 만나는 길: 레스트레이드에게 근거 있는 추리를 보고하면(ACT_SEND_NOTE 조건) 경감이 기별을 넣는다.
   * 무엇이 몇 개 필요한지는 직접 알려 주지 않는다 */
  function noteHint() {
    if (E.actionStatus("ACT_SEND_NOTE").state === "open") return "터너는 앓아누워 손님을 받지 않는다. 레스트레이드 경감에게 지금까지의 추리를 보고하면 자리를 마련해 줄지도 모른다.";
    return "터너는 앓아누워 손님을 받지 않는다. 경감이 자리를 마련해 줄 만큼 근거 있는 추리를 보고해야 한다. 막히면 탭 바로 아래의 「다음 실마리」를 열어 보자.";
  }
  const EV_TYPE = { document: "기록", physical: "현장 물품", trace: "현장 흔적", observation: "현장 관찰", testimony_record: "증언 기록" };
  const STAGE = { 1: "사건 기록", 2: "현장 조사", 3: "추가 조사" };

  let settings = { level: "normal", ai: { enabled: true } };
  // 페르소나 변형은 플레이어가 고르지 않는다. 서버판은 서버 설정(--persona), Claude판은 아래 기본값을 쓴다.
  // A/B/C 비교와 속생각 보기는 개발자 검증 도구(tools/persona_verify.js)의 일이다. 주소에 ?research=1을 붙이면 개발용으로 속생각을 보인다.
  const DEFAULT_VARIANT = "C";
  const DEV_RESEARCH = /[?&]research=1\b/.test(location.search || "");
  const LEVELS = {
    easy: { name: "쉬움", note: "예시 질문 3개. 해금·추리로 바로 이어지는 핵심 질문까지 보여 준다." },
    normal: { name: "보통", note: "예시 질문 최대 2개. 사건 경위처럼 누구나 먼저 물어볼 기본 질문만 보여 주고, 핵심 질문은 직접 떠올려야 한다." },
    hard: { name: "어려움", note: "예시 질문을 보여 주지 않는다. 모든 질문을 직접 생각해 내야 한다." }
  };
  const PS = new window.BVPsych(G.psych);
  let ui = { tab: "map", loc: "ross_hotel", evFilter: 0, attach: [], busy: false, picked: { culprit: null, motive: "", ev: [] }, evpop: false, grading: false,
    ai: { state: "checking", model: "", reason: "" }, aiWarned: false, desk: [], guideOff: false, leadOff: false, fold: {} };

  /* ---------- 저장 ---------- */
  function trySet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* 저장소를 쓸 수 없는 환경 */ } }
  function tryGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function save() { trySet(SAVE_KEY, E.save()); }
  function saveUi() { trySet(UI_KEY, JSON.stringify({ guideOff: ui.guideOff, leadOff: ui.leadOff, fold: ui.fold, desk: ui.desk })); }
  (function load() {
    const raw = tryGet(SAVE_KEY);
    if (raw) { try { E.load(raw); } catch (e) { E.reset(); } }
    const st = tryGet(SET_KEY);
    if (st) { try { const o = JSON.parse(st); settings.level = LEVELS[o.level] ? o.level : o.hints === false ? "hard" : "normal"; if (o.ai) settings.ai.enabled = o.ai.enabled !== false; } catch (e) { /* 무시 */ } }
    const u = tryGet(UI_KEY);
    if (u) { try { const o = JSON.parse(u); ui.guideOff = !!o.guideOff; ui.leadOff = !!o.leadOff; ui.fold = o.fold || {}; ui.desk = (o.desk || []).filter(id => E.st.owned.indexOf(id) >= 0).slice(0, 2); } catch (e) { /* 무시 */ } }
  })();

  /* ---------- 도우미 ---------- */
  const $ = s => document.querySelector(s);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = t => esc(t).replace(/\*([^*]+)\*/g, '<em class="act">$1</em>');
  const now = () => { const d = new Date(); return (d.getHours() < 12 ? "오전 " : "오후 ") + ((d.getHours() % 12) || 12) + ":" + String(d.getMinutes()).padStart(2, "0"); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const evTitle = id => (E.ev[id] ? E.ev[id].title : id);
  const evIcon = id => (Art.OBJECTS.find(o => o.ev === id) || {}).icon || Art.OFFMAP_ICONS[id] || "paper";
  function toast(msg, kind) {
    let box = $("#toasts"); if (!box) { box = document.createElement("div"); box.id = "toasts"; box.className = "toasts"; document.body.appendChild(box); }
    const t = document.createElement("div"); t.className = "toast" + (kind ? " " + kind : ""); t.textContent = msg; box.appendChild(t);
    t.addEventListener("click", () => t.remove());
    setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 300); }, 2800);
  }
  function log(cid, m) { m.ts = m.ts || now(); E.st.logs[cid].push(m); }

  function evStatus(id) { const s = E.evidenceStatus(id); return s.state; }
  function lockReason(id) {
    const s = E.evidenceStatus(id);
    if (s.state !== "locked") return "";
    if (s.flags.length) return FLAG_HINT[s.flags[0]] || "아직 조사할 수 없다.";
    return "먼저 '" + s.requires.map(evTitle).join("', '") + "'을(를) 조사해야 한다.";
  }
  const told = () => E.st.records.filter(r => E.lineTier(r.k) > 0).length;
  function charStatus(c) {
    const cs = E.st.chars[c], F = f => E.st.flags.indexOf(f) >= 0;
    if (!E.available(c)) return ["refusing", c === "john_turner" ? "거절" : "만날 수 없음"];
    if (c === "john_turner" && F("turner_confessed_murder")) return ["confessed", "자백"];
    if (c === "john_turner" && F("turner_blackmail_admitted")) return ["admitted", "인정"];
    if (cs.pressure >= 70) return ["refusing", "경계"];
    if (cs.trust >= 50) return ["cooperative", "협조"];
    return ["", "조심스러움"];
  }
  function knownKeys(c) {
    const ch = E.chars[c], cs = E.st.chars[c];
    let keys = ch.base_knowledge.map(k => k.id);
    ch.unlock_tiers.forEach(t => { if (cs.unlocked.indexOf(t.tier) >= 0) keys = keys.concat(t.unlocked_knowledge.map(k => k.id)); });
    return keys;
  }
  const remaining = c => knownKeys(c).filter(k => E.st.chars[c].said.indexOf(k) < 0).length;
  const moreLocked = c => E.chars[c].unlock_tiers.some(t => E.st.chars[c].unlocked.indexOf(t.tier) < 0);
  function meterRows(c) {
    const cs = E.st.chars[c], ps = PS.state(E.st, c);
    const row = (cls, label, v, tip) => `<div class="mt-row ${cls}" title="${esc(tip)}"><span>${label}</span><span class="mt-bar"><i style="width:${Math.round(v)}%"></i></span><span class="mt-v">${Math.round(v)}</span></div>`;
    return row("trust", "신뢰", cs.trust, "신뢰가 높으면 민감한 이야기를 털어놓는다") + row("pressure", "압박", cs.pressure, "근거 없는 추궁·위협에 오른다. 너무 높으면 입을 닫는 인물도 있다") + row("energy", "기운", ps.energy, "심리 계층의 동적 상태. 떨어지면 말이 짧아진다");
  }

  /* ---------- 머리줄 ---------- */
  function renderTop() {
    $("#counters").innerHTML = `<span>증거 <b>${E.st.owned.length}/${E.CASE.evidence.length}</b></span><span>털어놓은 진술 <b>${told()}</b></span><span>세운 추리 <b>${E.st.deductions.length}</b></span><span>힌트 <b>${E.st.hintsUsed}</b></span>`;
    $("#aistat").innerHTML = aiPill();
  }

  /* ---------- 탭 ---------- */
  const TABS = [["map", "지도"], ["evidence", "증거"], ["statements", "진술"], ["notes", "노트"], ["records", "수사 기록"], ["conclude", "결론"]];
  const TAB_GUIDE = {
    map: ["장소를 눌러 옮기고 빛나는 물건을 눌러 조사합니다. 아래 맞대기 보드에서 증거·인물을 서로 맞대 봅니다.", "map"],
    evidence: ["모은 증거를 읽고 두 장까지 대조 책상에 펼쳐 견줍니다. 「대화에 첨부」로 지금 대화 상대에게 내밉니다.", "evidence"],
    statements: ["인물에게 들은 이야기가 사람별로 쌓입니다. 증거를 내밀어 새로 털어놓게 한 이야기에는 표시가 붙습니다.", "talk"],
    notes: ["사람별로 들은 이야기, 아직 남은 물어볼 거리, 내민 증거 수를 모았습니다.", "notes"],
    records: ["세운 추리, 맞대기 기록, 사건 진행, 개인 메모가 모여 있습니다.", "deduce"],
    conclude: ["범인과 동기, 결정적 증거를 골라 제출합니다. 제출 뒤에도 수사를 이어갈 수 있습니다.", "conclude"]
  };
  function renderTabs() {
    if (!TABS.some(t => t[0] === ui.tab)) ui.tab = "map";
    const n = { evidence: E.st.owned.length, statements: E.st.records.length, records: E.st.deductions.length };
    $("#tabs").innerHTML = TABS.map(([k, l]) => `<button class="tab ${n[k] === 0 ? "quiet" : ""}" role="tab" aria-selected="${ui.tab === k}" data-tab="${k}">${l}${n[k] ? `<span class="cnt">${n[k]}</span>` : ""}</button>`).join("");
  }
  function tabGuide(tab) {
    const g = TAB_GUIDE[tab];
    if (!g || ui.guideOff) return "";
    return `<div class="tab-guide"><span class="tg-mark" aria-hidden="true">?</span><span class="tg-text">${esc(g[0])}</span><button class="tg-more" data-guide="${g[1]}">자세히</button><button class="tg-hide" data-guide-hide title="안내 띠 숨기기(수사 안내에서 다시 켤 수 있음)" aria-label="탭 안내 띠 숨기기">✕</button></div>`;
  }
  function foldHead(key, title, extra) {
    const open = !ui.fold[key];
    return `<div class="foldhead"><button class="fold-btn" data-fold="${key}" aria-expanded="${open}">${open ? "▾" : "▸"} ${esc(title)}</button>${extra || ""}</div>`;
  }

  function renderMain() {
    renderTabs();
    const v = $("#view");
    const body = ui.tab === "map" ? viewMap() : ui.tab === "evidence" ? viewEvidence() : ui.tab === "statements" ? viewStatements()
      : ui.tab === "notes" ? viewNotes() : ui.tab === "records" ? viewRecords() : viewConclude();
    v.innerHTML = leadBanner() + tabGuide(ui.tab) + body;
    const memo = $("#memo"); if (memo) memo.value = tryGet(MEMO_KEY) || "";
  }

  /* ---------- 다음 실마리(힌트) ---------- */
  function leadBanner() {
    const h = E.hint();
    if (ui.leadOff) return `<div class="nextlead off"><span class="lead-k">다음 실마리</span><button class="lead-toggle" data-lead-toggle>펼치기</button></div>`;
    const lv = h.level;
    const body = lv < 0
      ? `<p class="lead-t">막혔을 때 지금 해 볼 만한 일을 하나 알려 줍니다. 여는 횟수는 결과에 힌트 사용으로 남습니다.</p><button class="lead-go" data-lead-open="0">실마리 보기</button>`
      : `<p class="lead-t">${esc(h.text[0])}${lv >= 1 ? `<br><b>${esc(h.text[1])}</b>` : ""}</p>${lv < 1 ? `<button class="lead-go" data-lead-open="1">더 구체적으로</button>` : ""}`;
    return `<div class="nextlead"><span class="lead-k">다음 실마리</span><div class="lead-body">${body}</div><button class="lead-toggle" data-lead-toggle>숨기기</button></div>`;
  }

  /* ---------- 지도 ---------- */
  function charPinInfo() {
    const o = {};
    CHAR_ORDER.forEach(c => { o[c] = { available: E.available(c), unread: E.st.chars[c].unread, hidden: c === "john_turner" && E.available(c) }; });
    return o;
  }
  const Sc = window.BVScenes;
  const SCENE_DESC = Object.assign({}, LOCDESC, {
    overview: "보스콤 밸리 전체 지도. 지도 위 장소나 아래 장소 카드를 누르면 그 장소로 간다.",
    great_beech: "연못 숲 가장자리에 선 큰 너도밤나무. 나무 뒤로 큰길까지 이어지는 숲길이 있다.",
    moran_lodge: LOCDESC.moran_lodge
  });
  const GATE_NOTE = {
    hatherley_farm: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    boscombe_pool: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    great_beech: ["scene_access_granted", "아직 현장에 들어갈 수 없다. 레스트레이드 경감에게 현장 안내를 부탁하자."],
    ross_telegraph: ["victoria_known", "전보를 칠 근거가 아직 없다. 터너와 매카시가 호주 어디에서 알게 되었는지 알아내자."],
    hereford_gaol: ["prison_visit_granted", "면회 허가가 있어야 들어갈 수 있다. 레스트레이드 경감에게 면회를 부탁하자."]
  };
  function sceneEvidence(key) { return E.CASE.evidence.filter(e => Sc.sceneOf(e.location) === key); }
  function viewMap() {
    const key = ui.loc || "ross_hotel";
    // 숲지기 집의 쪽지는 경감이 보낸 뒤에야 '완료'로 보인다(플레이어가 직접 보내지 않음)
    const status = id => (E.ev[id] ? evStatus(id) : E.actionStatus(id).state === "done" ? "done" : "locked");
    const label = id => (E.ev[id] ? E.ev[id].object : "터너에게 쪽지 보내기");
    const chars = {};
    CHAR_ORDER.forEach(c => { chars[c] = { available: E.available(c), unread: E.st.chars[c].unread, name: SHORT[c] }; });
    // 전체 지도(1000×640)를 다른 장소 장면과 같은 비율(1000×560)로 잘라 보여 준다. 위아래의 빈 들판만 잘린다
    const art = key === "overview" ? Art.mapSVG(status, charPinInfo(), null).replace('viewBox="0 0 1000 640"', 'viewBox="0 64 1000 560"') : Sc.sceneSVG(key, status, label, chars, Art.portrait);
    const gate = GATE_NOTE[key] && E.st.flags.indexOf(GATE_NOTE[key][0]) < 0 ? `<div class="scene-gate">${esc(GATE_NOTE[key][1])}</div>` : "";
    const name = key === "overview" ? "전체 지도" : Sc.SCENES[key].name;
    // 장소 카드: 누르면 그 장소, 선택된 카드를 한 번 더 누르면 전체 지도
    const cards = Sc.ORDER.filter(k => k !== "overview").map(k => {
      const evs = sceneEvidence(k);
      const own = evs.filter(e => E.st.owned.indexOf(e.id) >= 0).length;
      const open = evs.filter(e => evStatus(e.id) === "open").length;
      const faces = CHAR_ORDER.filter(c => Sc.sceneOf(charLoc(c)) === k).map(c => Art.portrait(c, { size: 22 })).join("");
      const meta = evs.length ? `증거 ${own}/${evs.length}` : "증거 없음";
      return `<button class="loccard" data-scene="${k}" aria-pressed="${key === k}" title="${key === k ? "한 번 더 누르면 전체 지도" : "이 장소로 가기"}">${Sc.thumb(k)}<span class="lc-body"><span class="lc-name">${esc(Sc.SCENES[k].name)}</span><span class="lc-meta">${meta}${open ? ` · <b>새로 조사 ${open}</b>` : ""}</span>${key === k ? `<span class="lc-back">↩ 다시 누르면 전체 지도</span>` : ""}${faces ? `<span class="lc-faces">${faces}</span>` : ""}</span></button>`;
    }).join("");
    const mapOpen = !ui.fold.map, locOpen = !ui.fold.locs;
    return `<div class="mapview"><div class="mapcol">${foldHead("map", "수사 지도 · " + name)}${mapOpen ? `<section class="sceneframe"><div class="scene-cap"><b>${esc(name)}</b><span>${esc(SCENE_DESC[key] || "")}</span></div><div class="scenescroll">${art}</div>${gate}
      <div class="maplegend"><span class="lg-open">? 조사할 수 있는 물건</span><span class="lg-locked">아직 조사할 수 없음</span><span class="lg-owned">조사 완료</span><span>인물 얼굴을 누르면 대화</span></div></section>` : ""}</div>
      <div class="locside">${foldHead("locs", "장소", `<span class="fold-note">${key === "overview" ? "지금 전체 지도" : "선택한 장소를 다시 누르면 전체 지도"}</span>`)}${locOpen ? `<div class="locgrid">${cards}</div>` : ""}</div></div>
      ${foldHead("board", "맞대기 보드", `<span class="fold-note">증거·인물을 서로 맞대 본다</span>`)}${ui.fold.board ? "" : boardHTML()}`;
  }

  /* ---------- 맞대기 보드(팀원 ③ 개선판의 틀) ----------
   * 증거 → 인물 = 내밀기(그 인물과의 대화에 첨부해 보냄), 증거 ↔ 증거 = 착안, 인물 ↔ 인물 = 대질.
   * 규칙표는 data/contact_board.json. 착안은 질문만 던지고 결론은 말하지 않는다(추리는 플레이어가 경감에게 직접 말해야 성립).
   * 대질은 두 사람에게서 이미 들은 진술만 맞대어 보여 주고, 해금·점수는 바꾸지 않는다. 성공·헛짚음은 접촉 기록으로 남는다. */
  const BOARD = G.board || { combos: [], confronts: [] };
  const pairKey = (x, y) => [x, y].sort().join("+");
  function bst() {
    E.st.insights = E.st.insights || [];
    E.st.contacts = E.st.contacts || { present: 0, combine: { tries: 0, hits: 0 }, confront: { tries: 0, hits: 0 }, log: [] };
    return E.st;
  }
  function insightView(i) {
    if (i.kind === "combine") {
      const r = BOARD.combos.find(c => c.id === i.id); if (!r) return null;
      return { id: r.id, kind: "combine", aTitle: evTitle(r.a), bTitle: evTitle(r.b), title: r.title, text: r.text, ask: r.ask, talkTo: r.talkTo || null };
    }
    const r = BOARD.confronts.find(c => c.id === i.id); if (!r) return null;
    const lines = [[r.a, r.requires[0]], [r.b, r.requires[1]]].map(([c, k]) => ({ c, t: E.lineText(c, k) }));
    return { id: r.id, kind: "confront", aTitle: NAMES[r.a], bTitle: NAMES[r.b], a: r.a, b: r.b, title: r.title, note: r.note, lines, talkTo: r.talkTo || null };
  }
  function logContact(kind, a, b, ok, ref) {
    const L = bst().contacts.log; L.push({ kind, a, b, ok: !!ok, ref: ref || null, t: E.st.turn });
    if (L.length > 300) L.shift();
  }
  function boardHTML() {
    const S0 = bst(), pk = ui.bpick, cs = S0.contacts;
    const owned = E.CASE.evidence.filter(e => E.st.owned.indexOf(e.id) >= 0);
    const pkName = pk ? (pk.kind === "ev" ? evTitle(pk.id) : NAMES[pk.id]) : "";
    const nCb = S0.insights.filter(i => i.kind === "combine").length, nCf = S0.insights.filter(i => i.kind === "confront").length;
    const miss = (cs.combine.tries - cs.combine.hits) + (cs.confront.tries - cs.confront.hits);
    const isMiss = id => ui.bmiss && ui.bmiss.indexOf(id) >= 0;
    const people = CHAR_ORDER.map(c => {
      const can = E.available(c), n = E.st.chars[c].presented.length, isPk = pk && pk.kind === "person" && pk.id === c;
      const lbl = `${NAMES[c]}${can ? "" : " (아직 만날 수 없음)"}${pk ? (pk.kind === "ev" ? "에게 집은 증거 내밀기" : isPk ? " 내려놓기" : "와(과) 대질") : " — 누르면 대화"}${n ? `, 내민 증거 ${n}건` : ""}`;
      return `<div class="ctok person${can ? "" : " away"}${E.st.current === c ? " on" : ""}${isPk ? " picked" : ""}${isMiss(c) ? " miss" : ""}${pk && !can ? " nodrop" : ""}" tabindex="0" role="button" data-bk="person" data-bid="${c}" aria-label="${esc(lbl)}">
        <span class="cmini">${Art.portrait(c, { size: 52, square: true })}</span><span class="cname">${esc(SHORT[c])}</span><span class="cstate">${can ? "대화 가능" : "만날 수 없음"}</span>${n ? `<span class="cbadge" title="이 인물에게 내민 증거">${n}</span>` : ""}
        ${can ? `<button class="cgrab" data-bgrab="${c}" aria-label="${esc(NAMES[c])}을(를) 대질할 인물로 집기" title="대질할 인물로 집기">⇄</button>` : ""}</div>`;
    }).join("");
    const evs = owned.map(e => {
      const isPk = pk && pk.kind === "ev" && pk.id === e.id;
      const linked = pk && pk.kind === "ev" && !isPk && S0.insights.some(i => i.kind === "combine" && (() => { const r = BOARD.combos.find(x => x.id === i.id); return r && pairKey(r.a, r.b) === pairKey(pk.id, e.id); })());
      const given = E.st.chars[E.st.current] && E.st.chars[E.st.current].presented.indexOf(e.id) >= 0;
      return `<div class="ctok evid${isPk ? " picked" : ""}${linked ? " linked" : ""}${isMiss(e.id) ? " miss" : ""}${pk && pk.kind === "person" ? " nodrop" : ""}" tabindex="0" role="button" aria-pressed="${!!isPk}" data-bk="ev" data-bid="${e.id}" data-type="${e.type}" title="${esc(e.object)}"
        aria-label="${esc(`증거 ${e.title}${given ? ` (${NAMES[E.st.current]}에게 내밂)` : ""}${linked ? " (이미 이은 짝)" : ""}${pk && pk.kind === "ev" && !isPk ? "에 맞대기" : " 집기"}`)}"><span class="hole" aria-hidden="true"></span><span class="cname">${esc(e.title)}</span>${given ? `<span class="cstate">내밂</span>` : ""}</div>`;
    }).join("");
    const links = S0.insights.map(insightView).filter(Boolean);
    return `<section class="contact" id="contact" aria-label="맞대기 보드">
      <div class="cb-head"><div class="cb-legend" aria-label="맞대기 규칙"><span><i class="lg e"></i>→<i class="lg p"></i> 내밀기</span><span><i class="lg e"></i>↔<i class="lg e"></i> 착안</span><span><i class="lg p"></i>↔<i class="lg p"></i> 대질</span></div></div>
      <p class="hint cb-hint${pk ? " live" : ""}" aria-live="polite">${pk ? `「${esc(pkName)}」을(를) 집었습니다. ${pk.kind === "ev" ? "인물에게 내밀거나 다른 증거에 맞대세요." : "대질할 다른 인물을 누르세요."} (같은 것을 다시 누르면 내려놓기)`
        : "토큰을 끌어다 다른 토큰 위에 놓으세요. 누르기만 해도 됩니다: 증거를 누른 뒤 대상을 누르거나, 인물의 ⇄로 대질할 사람을 집으세요."}</p>
      <div class="clabel">인물</div><div class="ctok-row" role="group" aria-label="인물">${people}</div>
      <div class="clabel">증거 (${owned.length})</div><div class="ctok-row" role="group" aria-label="모은 증거">${evs || `<div class="slim-empty">모은 증거가 없습니다. 지도에서 물건을 조사하세요.</div>`}</div>
      <div class="clabel cb-tally">이어 놓은 연결<span>착안 ${nCb} · 대질 ${nCf} · 내밀기 ${cs.present} · 헛짚음 ${miss}</span></div>
      ${links.length ? `<div class="links">${links.map(i => `<button class="link-card ${i.kind === "confront" ? "cf" : "cb"}" data-insight="${i.id}" aria-label="${i.kind === "confront" ? "대질" : "착안"}: ${esc(i.title)} 다시 보기"><span class="lk-kind">${i.kind === "confront" ? "대질" : "착안"}</span><b>${esc(i.title)}</b><span class="lk-pair">${esc(i.aTitle)} ↔ ${esc(i.bTitle)}</span></button>`).join("")}</div>`
        : `<div class="slim-empty">아직 이은 연결이 없습니다. 서로 관계가 있어 보이는 두 증거를 맞대어 보세요.</div>`}</section>`;
  }
  function refreshBoard() { const b = $("#contact"); if (!b) return; const w = document.createElement("div"); w.innerHTML = boardHTML(); b.replaceWith(w.firstElementChild); }
  function boardMiss(ids) { ui.bmiss = ids; refreshBoard(); setTimeout(() => { ui.bmiss = null; refreshBoard(); }, 700); }
  const THREAD = `<svg class="thread" viewBox="0 0 120 40" preserveAspectRatio="none" aria-hidden="true"><path class="th" d="M2 20 C30 4 50 36 60 20 S96 4 118 20" pathLength="1"/><circle class="pin" cx="2" cy="20" r="4"/><circle class="pin" cx="118" cy="20" r="4"/></svg>`;
  function showInsight(id, fresh) {
    const i = insightView(bst().insights.find(x => x.id === id) || { id, kind: BOARD.combos.some(c => c.id === id) ? "combine" : "confront" });
    if (!i) return;
    const cf = i.kind === "confront";
    const body = cf
      ? `<div class="ins-dialog">${i.lines.map(l => `<div class="ins-line"><b>${esc(NAMES[l.c])}</b><span>“${esc(l.t)}”</span></div>`).join("")}</div><p class="ins-note">${esc(i.note)}</p>`
      : `<p class="ins-text">${esc(i.text)}</p><p class="ins-ask">${esc(i.ask)}</p>`;
    const go = i.talkTo && E.available(i.talkTo) ? `<button class="primary" data-char="${i.talkTo}">${esc(NAMES[i.talkTo])}에게 말하러 가기</button>` : "";
    const tip = cf ? "대질은 해금을 일으키지 않는다. 짚인 곳을 그 사람에게 직접 다시 물어야 이야기가 달라진다."
      : i.talkTo === "inspector_lestrade" ? "답이 떠올랐다면 그 생각을 레스트레이드 경감에게 직접 말해야 추리로 성립한다." : "수사 기록 탭의 「맞대기 기록」에 남았다.";
    modal(cf ? "대질 기록" : "착안", `<div class="insight ${cf ? "cf" : "cb"}${fresh ? " fresh" : ""}"><div class="ins-kind">${cf ? "대질" : "착안"}${fresh === false ? "<span> · 이미 찾은 연결</span>" : ""}</div>
      <h3>${esc(i.title)}</h3><div class="ins-pair"><span class="ins-node ${cf ? "p" : "e"}">${esc(i.aTitle)}</span>${THREAD}<span class="ins-node ${cf ? "p" : "e"}">${esc(i.bTitle)}</span></div>${body}<p class="hint">${esc(tip)}</p></div>`,
      `<button data-modal-close>닫기</button>${go}`, "wide");
  }
  // 집어 든 것(src)을 대상(dst)에 맞댄다
  function touch(src, dst) {
    ui.bpick = null;
    if (!src || !dst || ui.busy) { refreshBoard(); return; }
    if (src.kind === "person" && dst.kind === "ev") { touch(dst, src); return; }
    if (src.kind === "ev" && dst.kind === "person") {
      if (!E.available(dst.id)) { toast(`${NAMES[dst.id]}은(는) 아직 만날 수 없다.`); refreshBoard(); return; }
      bst().contacts.present++; logContact("present", src.id, dst.id, true);
      openChar(dst.id); ui.attach = [src.id];
      send("이 증거를 보십시오: " + evTitle(src.id));
      return;
    }
    if (src.id === dst.id) { refreshBoard(); return; }
    const S0 = bst();
    if (src.kind === "ev") {
      const r = BOARD.combos.find(c => pairKey(c.a, c.b) === pairKey(src.id, dst.id));
      S0.contacts.combine.tries++;
      if (!r) { logContact("combine", src.id, dst.id, false); save(); boardMiss([src.id, dst.id]); toast("두 증거 사이에서 이어지는 점을 찾지 못했다. (헛짚음도 기록에 남는다)"); return; }
      S0.contacts.combine.hits++;
      const fresh = !S0.insights.some(i => i.id === r.id);
      if (fresh) S0.insights.push({ id: r.id, kind: "combine", t: E.st.turn });
      logContact("combine", src.id, dst.id, true, r.id); save(); refreshBoard(); renderTabs();
      showInsight(r.id, fresh); return;
    }
    const r = BOARD.confronts.find(c => pairKey(c.a, c.b) === pairKey(src.id, dst.id));
    S0.contacts.confront.tries++;
    if (!r) { logContact("confront", src.id, dst.id, false); save(); boardMiss([src.id, dst.id]); toast("두 사람의 말에서 맞부딪치는 지점을 찾지 못했다."); return; }
    const heard = k => E.st.records.some(x => x.k === k);
    if (!r.requires.every(heard)) { logContact("confront", src.id, dst.id, false, r.id); save(); boardMiss([src.id, dst.id]); toast("맞댈 거리는 있어 보인다. 두 사람에게서 먼저 그 일에 대한 말을 들어 보자."); return; }
    S0.contacts.confront.hits++;
    const fresh = !S0.insights.some(i => i.id === r.id);
    if (fresh) S0.insights.push({ id: r.id, kind: "confront", t: E.st.turn });
    logContact("confront", src.id, dst.id, true, r.id); save(); refreshBoard();
    showInsight(r.id, fresh);
  }
  function boardClick(t) {
    if (t.dataset.dragged) { delete t.dataset.dragged; return; }
    const kind = t.dataset.bk, id = t.dataset.bid, pk = ui.bpick;
    if (pk && pk.kind === kind && pk.id === id) { ui.bpick = null; refreshBoard(); return; }
    if (kind === "ev") {
      if (pk && pk.kind === "ev") { touch(pk, { kind, id }); return; }
      if (pk && pk.kind === "person") { toast("인물은 다른 인물과만 대질한다. 증거는 증거 쪽에서 인물에게 끌어 오자."); return; }
      ui.bpick = { kind, id }; refreshBoard(); return;
    }
    if (pk) { touch(pk, { kind, id }); return; }
    openChar(id);
  }
  // 끌기: 포인터 이벤트로 직접 구현해 마우스·터치 모두에서 동작한다
  function startDrag(ev, tok) {
    if (ev.button !== 0 || ui.busy || ev.target.closest(".cgrab")) return;
    const src = { kind: tok.dataset.bk, id: tok.dataset.bid };
    if (src.kind === "person" && !E.available(src.id)) return;
    const box = $("#contact"), sx = ev.clientX, sy = ev.clientY;
    let ghost = null, over = null;
    const targetAt = (x, y) => {
      const el = document.elementFromPoint(x, y), t = el && el.closest("#contact .ctok");
      if (!t || t === tok) return null;
      if (src.kind === "person" && t.dataset.bk === "ev") return null;
      return t;
    };
    const move = m => {
      if (!ghost) {
        if (Math.hypot(m.clientX - sx, m.clientY - sy) < 6) return;
        ghost = tok.cloneNode(true); ghost.classList.add("ghost"); ghost.removeAttribute("tabindex");
        ghost.style.width = tok.getBoundingClientRect().width + "px";
        document.body.appendChild(ghost); tok.classList.add("drag"); box.classList.add("dragging", "from-" + src.kind);
      }
      m.preventDefault();
      ghost.style.transform = `translate(${m.clientX + 10}px, ${m.clientY + 6}px) rotate(-4deg)`;
      const t = targetAt(m.clientX, m.clientY);
      if (t !== over) { if (over) over.classList.remove("over"); over = t; if (over) over.classList.add("over"); }
    };
    const end = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); window.removeEventListener("pointercancel", end);
      if (!ghost) return;   // 움직이지 않았으면 click으로 처리된다
      tok.dataset.dragged = "1"; setTimeout(() => { delete tok.dataset.dragged; }, 0);
      ghost.remove(); tok.classList.remove("drag"); box.classList.remove("dragging", "from-ev", "from-person");
      if (over) { over.classList.remove("over"); touch(src, { kind: over.dataset.bk, id: over.dataset.bid }); }
    };
    window.addEventListener("pointermove", move, { passive: false }); window.addEventListener("pointerup", end); window.addEventListener("pointercancel", end);
  }
  function charLoc(c) { return c === "john_turner" && E.available(c) ? "ross_hotel" : CHAR_LOC[c]; }

  /* ---------- 증거 ---------- */
  function presentedTo(id) { return CHAR_ORDER.filter(c => E.st.chars[c].presented.indexOf(id) >= 0); }
  function evHead(e) {
    return `<div class="ev-head">${Art.icon(evIcon(e.id), 22).replace("<svg ", '<svg class="ev-ico" ')}<span class="ev-type">${EV_TYPE[e.type] || "증거"}</span><span class="ev-where">${esc(LOCNAME[e.location])} · ${esc(STAGE[e.stage])}</span></div>`;
  }
  function evCard(e) {
    const used = presentedTo(e.id);
    const onDesk = ui.desk.indexOf(e.id) >= 0;
    return `<article class="paper ev-card" data-type="${e.type}">${evHead(e)}
      <h3><button class="ev-title linkish" data-evd="${e.id}">${esc(e.title)}</button></h3>
      <p class="ev-look">${esc(e.object)}</p><p class="text">${esc(e.text)}</p>
      ${used.length ? `<div class="ev-used">${used.map(c => `<span>${esc(SHORT[c])}에게 내밂</span>`).join("")}</div>` : ""}
      <div class="row"><button class="ev-more" data-evd="${e.id}">자세히</button><button data-desk="${e.id}" aria-pressed="${onDesk}">${onDesk ? "책상에서 치우기" : "책상에 펼치기"}</button><button data-present="${e.id}">대화에 첨부</button></div></article>`;
  }
  function viewEvidence() {
    const all = E.CASE.evidence, list = all.filter(e => !ui.evFilter || e.stage === ui.evFilter);
    const owned = list.filter(e => E.st.owned.indexOf(e.id) >= 0), missing = list.length - owned.length;
    const slots = [0, 1].map(i => {
      const id = ui.desk[i];
      if (!id) return `<div class="desk-slot"><div class="slim-empty">${i === 0 ? "증거 카드의 「책상에 펼치기」로 여기에 놓습니다" : "두 번째 증거를 놓으면 나란히 대조합니다"}</div></div>`;
      const e = E.ev[id];
      return `<div class="desk-slot"><div class="paper" data-type="${e.type}">${evHead(e)}<h3>${esc(e.title)}</h3><div class="body">${esc(e.text)}</div><div class="row"><button data-desk="${id}">치우기</button><button data-present="${id}">대화에 첨부</button></div></div></div>`;
    }).join("");
    const f = [[0, "전체"], [1, "사건 기록"], [2, "현장 조사"], [3, "추가 조사"]].map(([k, l]) => `<button data-evf="${k}" aria-pressed="${ui.evFilter === k}">${l}</button>`).join("");
    return `<div class="desk"><div class="desk-title">대조 책상 — 열람한 증거를 두 장까지 나란히 펼칩니다</div><div class="desk-slots">${slots}</div></div>
      <h2 class="section-title">발견한 증거<span class="st-sub">${E.st.owned.length}건 열람 · 전체 ${all.length}건</span></h2>
      <div class="filters">${f}</div>
      ${owned.length || missing ? `<div class="ev-grid">${owned.map(evCard).join("")}${missing ? `<div class="ev-card sealed"><span class="seal">?</span><span>아직 찾지 못한 증거 ${missing}건</span><span class="meta">지도의 장소와 물건을 눌러 조사하면 여기에 모입니다.</span></div>` : ""}</div>` : ""}`;
  }
  function showEvidence(id) {
    const e = E.ev[id]; if (!e) return;
    const used = presentedTo(id);
    const onDesk = ui.desk.indexOf(id) >= 0;
    modal("증거 자세히", `<div class="ev-detail" data-type="${e.type}">${evHead(e)}<div class="evd-title">${esc(e.title)}</div>
      <div class="evd-sec"><div class="evd-lbl">조사 대상</div><div class="evd-body">${esc(e.object)}</div></div>
      <div class="evd-sec"><div class="evd-lbl">관찰 기록</div><div class="evd-body">${esc(e.text)}</div></div>
      <div class="evd-sec"><div class="evd-lbl">이 증거로 한 일</div>${used.length ? `<ul class="evd-hist">${used.map(c => `<li><b>내밂</b> ${esc(NAMES[c])}</li>`).join("")}</ul>` : `<p class="evd-foot">아직 아무에게도 내밀지 않았다.</p>`}</div>
      <div class="evd-sec"><div class="evd-lbl">할 수 있는 일</div><div class="evd-acts">
        <button data-present="${id}"><b>대화에 첨부</b><span>${esc(NAMES[E.st.current])}에게 내민다</span></button>
        <button data-desk="${id}"><b>${onDesk ? "책상에서 치우기" : "책상에 펼치기"}</b><span>다른 증거와 나란히 견준다</span></button>
        <button data-bpickev="${id}"><b>맞대기 보드에서 집기</b><span>집은 채로 인물이나 다른 증거를 누른다</span></button></div></div></div>`, `<button class="primary" data-modal-close>닫기</button>`, "wide");
  }

  /* ---------- 진술(사람별로 들은 이야기) ---------- */
  function viewStatements() {
    if (!E.st.records.length) return `<div class="empty">인물에게 들은 이야기가 여기에 사람별로 쌓인다.<br>오른쪽 인물 패널에서 질문하고, 증거를 내밀어 보자.</div>`;
    const by = {};
    E.st.records.forEach(r => { (by[r.c] = by[r.c] || []).push(r); });
    return CHAR_ORDER.filter(c => by[c]).map(c => `<div class="stmt-group"><h2 class="section-title">${Art.portrait(c, { size: 30 })}${esc(NAMES[c])}의 진술<span class="st-sub">${by[c].length}건</span></h2>
      ${by[c].map(r => `<div class="paper stmt ${E.lineTier(r.k) > 0 ? "fresh" : ""}"><div class="meta">${esc(NAMES[c])}${E.lineTier(r.k) > 0 ? ` · <b class="told">새로 털어놓음</b>` : ""}</div><p class="quote">“${esc(E.lineText(c, r.k))}”</p></div>`).join("")}</div>`).join("");
  }

  /* ---------- 노트(사람별 정리) ---------- */
  function viewNotes() {
    return `<p class="hint">사람별로 정리한 수사 노트다. 「더 물어볼 거리」는 지금까지 연 조건으로 아직 듣지 못한 이야기의 수다(무엇인지는 직접 물어봐야 안다).</p>
      <div class="note-grid">${CHAR_ORDER.map(c => {
        const st = charStatus(c), cs = E.st.chars[c], recs = E.st.records.filter(r => r.c === c), av = E.available(c);
        const more = remaining(c);
        return `<article class="note-card ${E.st.current === c ? "on" : ""}"><header><span class="nc-cameo">${Art.portrait(c, { size: 52, square: true })}</span><div><h3>${esc(NAMES[c])}</h3><div class="nc-role">${esc(E.chars[c].role)}</div><span class="badge ${st[0]}">${st[1]}</span><span class="nc-where">${esc(LOCNAME[charLoc(c)] || "")}</span></div></header>
          <div class="nc-nums"><span>들은 이야기 <b>${recs.length}</b></span><span class="more">더 물어볼 거리 <b>${av ? more : "만난 뒤"}</b>${av && moreLocked(c) ? " · 숨긴 이야기 있음" : ""}</span><span>내민 증거 <b>${cs.presented.length}</b></span></div>
          <div class="meters nc-meters">${meterRows(c)}</div>
          ${recs.length ? `<ul class="nc-list">${recs.slice(-6).map(r => `<li>${esc(E.kText[r.k])}</li>`).join("")}</ul>` : `<div class="slim-empty">아직 들은 이야기가 없다.</div>`}
          <button class="nc-talk" data-char="${c}">${av ? "대화하기" : "찾아가서 묻기"}</button></article>`;
      }).join("")}</div>`;
  }

  /* ---------- 수사 기록(추리·진행·메모) ---------- */
  function viewRecords() {
    const deds = E.st.deductions;
    const flags = E.st.flags.filter(f => FLAG_MSG[f]);
    return `<div class="rec-grid"><div><h3 class="section-title">세운 추리</h3>
        ${deds.length ? `<ul class="rec-list">${deds.map(id => `<li class="approved"><span class="who">추리</span>${esc(E.dedClaim(id))}${E.st.dedSaid[id] ? `<span class="said">내가 한 말: “${esc(E.st.dedSaid[id])}”</span>` : ""}</li>`).join("")}</ul>` : `<div class="slim-empty">아직 세운 추리가 없다. 증거가 가리키는 결론을 레스트레이드 경감에게 보고하자.</div>`}
        <h3 class="section-title">맞대기 기록</h3>
        ${(() => { const ins = bst().insights.map(insightView).filter(Boolean); return ins.length ? `<ul class="rec-list">${ins.map(i => `<li><span class="who">${i.kind === "confront" ? "대질" : "착안"} · ${esc(i.aTitle)} ↔ ${esc(i.bTitle)}</span><button class="linkish" data-insight="${i.id}">${esc(i.title)}</button></li>`).join("")}</ul>` : `<div class="slim-empty">지도 탭의 맞대기 보드에서 증거끼리, 인물끼리 맞대면 여기에 남는다.</div>`; })()}
        <h3 class="section-title">사건 진행</h3>
        ${flags.length ? `<ul class="rec-list">${flags.map(f => `<li><span class="who">진행</span>${esc(FLAG_MSG[f])}</li>`).join("")}</ul>` : `<div class="slim-empty">아직 진행된 일이 없다.</div>`}</div>
      <div><h3 class="section-title">수사 현황</h3><ul class="rec-list stat">
          <li>모은 증거 <b>${E.st.owned.length}/${E.CASE.evidence.length}</b></li><li>들은 이야기 <b>${E.st.records.length}</b> (새로 털어놓은 것 ${told()})</li>
          <li>세운 추리 <b>${deds.length}</b></li><li>맞대기 <b>착안 ${bst().insights.filter(i => i.kind === "combine").length} · 대질 ${bst().insights.filter(i => i.kind === "confront").length}</b> (헛짚음 ${(bst().contacts.combine.tries - bst().contacts.combine.hits) + (bst().contacts.confront.tries - bst().contacts.confront.hits)})</li><li>힌트 사용 <b>${E.st.hintsUsed}회</b></li></ul>
        <h3 class="section-title">개인 메모</h3><textarea id="memo" rows="10" placeholder="추리 메모를 적어 두세요. 자동 저장됩니다."></textarea></div></div>`;
  }

  /* ---------- 결론 ---------- */
  function viewConclude() {
    const sus = ["james_mccarthy", "john_turner", "william_crowder", "patience_moran", "alice_turner", "inspector_lestrade"];
    const owned = E.CASE.evidence.filter(e => E.st.owned.indexOf(e.id) >= 0);
    const last = E.st.ending ? S.endings[E.st.ending.id] : null;
    return `<form class="concl-form" id="cform"><h2 class="section-title">결론 제출</h2>
      <p class="hint">언제든 제출할 수 있다. 범인으로 터너를 지목하면 터너가 직접 반응한다. ${aiOn() ? "제출하면 AI 채점관이 동기를 진상과 대조해 채점한다." : "AI에 연결되지 않아 동기는 핵심 표현으로 채점한다."} 여기 쓴 추리도 수사 기록에 반영된다.</p>
      <div class="form-row"><span class="lbl">범인</span><div class="suspects">${sus.map(c => `<button type="button" class="suspect" data-sus="${c}" aria-pressed="${ui.picked.culprit === c}">${Art.portrait(c, { size: 46, square: true })}<span>${esc(NAMES[c])}</span></button>`).join("")}</div></div>
      <div class="form-row"><label for="motiveText">동기 — 범인은 왜 그랬는가</label>
      <textarea id="motiveText" class="motive" rows="5" maxlength="1000" placeholder="무엇이 범인을 몰아붙였는지, 범인이 무엇을 지키거나 끝내려 했는지 근거와 함께 적어 보자.">${esc(ui.picked.motive)}</textarea></div>
      <div class="form-row"><span class="lbl">범인을 가리키는 결정적 증거 (여러 개 고르기)</span>${owned.length ? `<div class="check-grid">${owned.map(e => `<label><input type="checkbox" name="kev" value="${e.id}" ${ui.picked.ev.indexOf(e.id) >= 0 ? "checked" : ""}> ${esc(e.title)}</label>`).join("")}</div>` : `<div class="slim-empty">아직 모은 증거가 없다.</div>`}</div>
      <div class="concl-foot"><button class="primary" type="submit" ${ui.grading ? "disabled" : ""}>${ui.grading ? "채점 중…" : "결론 제출"}</button><span class="note">모은 증거 ${E.st.owned.length}/${E.CASE.evidence.length} · 세운 추리 ${E.st.deductions.length} · 털어놓은 진술 ${told()} · 힌트 ${E.st.hintsUsed}회${last ? ` · 지난 결론: <b>${esc(last.title)}</b>` : ""}</span></div></form>`;
  }

  /* ---------- 인물 패널 ---------- */
  function renderStrip() {
    $("#cstrip").innerHTML = CHAR_ORDER.map(c => {
      const av = E.available(c), cs = E.st.chars[c];
      return `<button class="cbtn chip ${av ? "here" : "off"}" role="tab" data-char="${c}" aria-selected="${E.st.current === c}" aria-pressed="${E.st.current === c}" title="${esc(NAMES[c])}${av ? "" : " (아직 만날 수 없음)"}"><span class="mini">${Art.portrait(c, { size: 24, square: true })}</span><span class="presence"></span><span class="nm">${esc(NAMES[c])}</span>${cs.unread ? `<span class="dot">${cs.unread}</span>` : ""}</button>`;
    }).join("");
  }
  function renderHead() {
    const c = E.st.current, p = E.chars[c];
    const loc = LOCNAME[charLoc(c)] || p.location;
    const ps = PS.state(E.st, c), st = charStatus(c);
    const def = DEV_RESEARCH && ps.last && ps.last.defense ? `<span class="badge summoned" title="지난 턴에 작동한 방어기제">${esc(G.psych.defenses[ps.last.defense].ko)}</span>` : "";
    $("#chead").innerHTML = `<button class="back" data-close-chat aria-label="수사 화면으로">←</button><div class="portrait-frame">${Art.portrait(c, { size: 150, square: true })}</div>
      <div class="pinfo"><h2>${esc(p.name)}</h2><div class="role">${esc(p.role)}</div><span class="badge ${st[0]}">${st[1]}</span>${def}<div class="where">${E.available(c) ? "지금 있는 곳" : "다른 곳"} · ${esc(loc)}</div>
      <div class="meters">${meterRows(c)}</div></div>`;
  }
  function renderMsgs(typing) {
    const c = E.st.current, logs = E.st.logs[c], nm = E.chars[c].name;
    let html = "";
    if (!E.available(c) && !logs.length) {
      html += `<div class="msg system">${esc(E.chars[c].availability.unavailable_message)}</div>`;
      if (UNAVAIL_HINT[c]) html += `<div class="msg system">${esc(UNAVAIL_HINT[c]())}</div>`;
    }
    logs.forEach(m => {
      if (m.f === "s") { html += `<div class="msg system ${m.k || ""}">${esc(m.t)}</div>`; return; }
      const me = m.f === "p";
      const att = (m.ev || []).map(id => `<span class="att">${Art.icon(evIcon(id), 16)} 증거 제시: ${esc(evTitle(id))}</span>`).join("");
      const inner = !me && DEV_RESEARCH && (m.inner || m.def) ? `<span class="innerv">${m.def ? `<b>${esc(G.psych.defenses[m.def] ? G.psych.defenses[m.def].ko : m.def)}</b>` : ""}${m.inner ? ` 속생각: ${esc(m.inner)}` : ""}</span>` : "";
      html += me ? `<div class="msg player">${m.t ? fmt(m.t) : ""}${att}</div>`
        : `<div class="msg npc"><span class="who">${esc(nm)}</span>${m.t ? fmt(m.t) : ""}${att}${inner}</div>`;
    });
    if (typing) html += `<div class="msg npc thinking"><span class="who">${esc(nm)}</span><span class="typing"><span></span><span></span><span></span></span></div>`;
    if (!logs.length && E.available(c)) html += `<div class="msg system">${esc(nm)}에게 자유롭게 물어보세요.</div>`;
    const box = $("#msgs"); box.innerHTML = html; box.scrollTop = box.scrollHeight;
    renderSuggest(typing);
  }
  // 예시 질문: 대화 기록이 아니라 입력창 바로 위에 둔다(대화가 길어져도 같은 자리)
  function renderSuggest(typing) {
    const c = E.st.current, el = $("#suggest");
    if (!el) return;
    const sg = E.available(c) && !ui.busy && !typing ? suggestions(c) : [];
    el.hidden = !sg.length;
    el.innerHTML = sg.length ? `<span class="lbl">이렇게 물어볼 수 있습니다</span><div class="sq">${sg.map(q => `<button data-q="${esc(q)}">${esc(q)}</button>`).join("")}</div>` : "";
  }
  // 난이도별 예시 질문. 보통은 누구나 먼저 물어볼 기본 질문(BASIC_TOPICS)만, 어려움은 없음.
  // 해금(현장·면회)이나 추리·자백으로 바로 이어지는 질문은 쉬움에서만 보인다.
  const BASIC_TOPICS = ["T_DAY_OF_INCIDENT", "T_MCCARTHY_RELATION", "T_TURNER_HEALTH", "tone_empathetic"];
  function suggestions(c) {
    const lv = settings.level;
    if (lv === "hard") return [];
    const cs = E.st.chars[c], sc = S.characters[c];
    const left = sc.suggest.filter(([t]) => t.indexOf("T_") !== 0 || cs.probed.indexOf(t) < 0)
      .filter(([t]) => !S.topicRequiresFlag[t] || E.st.flags.indexOf(S.topicRequiresFlag[t]) >= 0);
    if (lv === "normal") return left.filter(([t]) => BASIC_TOPICS.indexOf(t) >= 0).slice(0, 2).map(x => x[1]);
    return (left.length ? left : sc.suggest.slice(0, 1)).slice(0, 3).map(x => x[1]);
  }
  function renderComposer() {
    const c = E.st.current, av = E.available(c);
    $("#attached").innerHTML = ui.attach.map(id => `<button class="att-chip" data-unattach="${id}" aria-label="${esc(evTitle(id))} 빼기">📎 ${esc(evTitle(id))} ✕</button>`).join("");
    $("#input").disabled = !av || ui.busy;
    $("#input").placeholder = !av ? "아직 대화할 수 없습니다" : "자유롭게 질문하세요";
    $("#send").disabled = !av || ui.busy;
    $("#btnEv").disabled = !av || ui.busy || !E.st.owned.length;
    const pop = $("#evpop");
    pop.hidden = !ui.evpop;
    if (ui.evpop) pop.innerHTML = E.CASE.evidence.filter(e => E.st.owned.indexOf(e.id) >= 0).map(e => `<button data-attach="${e.id}" data-type="${e.type}">${Art.icon(evIcon(e.id), 22)}<span>${esc(e.title)}</span></button>`).join("");
  }
  function renderChat(typing) { renderHead(); renderStrip(); renderMsgs(typing); renderComposer(); }
  function renderAll() { renderTop(); renderMain(); renderChat(); }

  function openChar(c) {
    E.st.current = c;
    const cs = E.st.chars[c];
    cs.unread = 0;
    if (E.available(c) && !cs.met) { cs.met = true; log(c, { f: "c", t: S.characters[c].greet }); }
    ui.attach = []; ui.evpop = false;
    save();
    document.body.classList.add("chat-open");
    renderAll();
    setTimeout(() => { const i = $("#input"); if (i && !i.disabled && window.innerWidth > 900) i.focus(); }, 30);
  }

  /* ---------- AI 서버(배포자 PC의 Ollama 또는 API) ---------- */
  function aiBase() {
    return /^https?:/.test(location.protocol) ? location.origin : "";
  }
  function aiOn() { return settings.ai.enabled && ui.ai.state === "on"; }
  function aiPill() {
    const st = !settings.ai.enabled ? ["off", "대본 모드"] : ui.ai.state === "on" ? ["on", ui.ai.model] : ui.ai.state === "checking" ? ["", "AI 확인 중…"] : ["off", "대본 모드"];
    return `<button class="model-chip ${st[0]}" id="btnAiPill" title="${esc(ui.ai.reason || "")}">${esc(st[1])}</button>`;
  }
  async function api(path, body, ms) {
    const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), ms || 60000);
    try {
      const r = await fetch(aiBase() + path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal } : { signal: ctrl.signal });
      return await r.json();
    } finally { clearTimeout(timer); }
  }
  const PR = new window.BVPrompts(G.personas, G.case, PS);
  const CLAUDE_OPTS = { model: "claude-haiku-5-5", modelTier: "quick", cache: false };
  let sampleFn = null;
  async function checkServer() {
    if (!settings.ai.enabled) { ui.ai = { state: "off", model: "", reason: "설정에서 꺼 두었다" }; renderTop(); return; }
    ui.ai.state = "checking"; renderTop();
    // claude.ai 아티팩트 안에서 열면: 보는 사람의 Claude 계정으로 연결(배포판의 Ollama 자리를 임시로 대신함)
    if (window.claude && typeof window.claude.use === "function") {
      try { sampleFn = await window.claude.use("sample"); } catch (e) { sampleFn = null; }
      if (sampleFn) {
        ui.ai = { state: "on", provider: "claude", model: "Claude Haiku 5.5", reason: "보는 사람의 Claude 계정으로 Claude Haiku 5.5가 대사를 만든다. 배포판에서는 이 자리를 배포자 PC의 Ollama 또는 API가 맡는다." };
        renderTop(); renderComposer(); return;
      }
    }
    if (!aiBase()) { ui.ai = { state: "off", model: "", reason: "파일로 열었기 때문에 대본 모드로 동작한다. 게임 서버 주소로 접속하면 AI 대화를 쓸 수 있다." }; renderTop(); return; }
    try {
      const st = await api("/api/status", null, 8000);
      const where = st.provider && st.provider !== "ollama" ? "API(" + st.provider + ")" : "배포자 PC의 Ollama";
      if (["A", "B", "C"].indexOf(st.persona) >= 0) ui.variant = st.persona;
      ui.ai = st.ok ? { state: "on", provider: "server", model: st.model, backend: st.provider || "ollama", reason: where + "로 인물이 자유롭게 대답한다" } : { state: "off", model: "", reason: st.reason || "AI 서버를 쓸 수 없다" };
    } catch (e) { ui.ai = { state: "off", model: "", reason: "AI 서버에 연결하지 못했다" }; }
    renderTop(); renderComposer();
  }
  // 탐정이 친 HTML 태그 같은 기호는 AI 인물에게 보내지 않는다(화면에는 친 그대로 글자로 보인다)
  function aiClean(t) {
    const s = String(t || "").replace(/<[^>]{0,300}>/g, " ").replace(/\s+/g, " ").trim();
    return s || (String(t || "").trim() ? "(탐정이 알아볼 수 없는 기호를 늘어놓는다)" : "");
  }
  // 대사가 한국어인지(지문과 이야기 속 영어 고유명사는 빼고 센다)
  const LATIN_OK = /^(black|jack|of|ballarat|cooee|a|rat|arat|victoria|bristol|ross|boscombe|hatherley|mccarthy|turner|james|alice|lestrade)$/i;
  function koreanOk(t) {
    const body = t.replace(/\*[^*]*\*/g, " ");
    const hangul = (body.match(/[가-힣]/g) || []).length;
    const latin = (body.match(/[A-Za-z]+/g) || []).filter(w => !LATIN_OK.test(w)).join("").length;
    return hangul > 0 && hangul >= 2 * latin;
  }
  async function aiJudge(c, text) {
    text = aiClean(text);
    if (ui.ai.provider === "claude") return PR.cleanJudge(await sampleFn.json(PR.judgeInput(c, text, E.st.owned), CLAUDE_OPTS), E.st.owned);
    return api("/api/judge", { cid: c, text: text, owned: E.st.owned }, 45000);
  }
  async function aiSpeak(o) {
    if (ui.ai.provider === "claude") {
      const ps = o.psych || {};
      if (ps.variant === "C" && ps.critical) {
        // 1단계: 속생각(탐정에게 보이지 않음). 비었거나 잠긴 정보가 섞이면 쓰지 않는다
        try {
          const r1 = await sampleFn(PR.monologueInput(o), CLAUDE_OPTS);
          const inner = PS.cleanInner(r1.text);
          if (inner && !E.leakCheck(o.cid, inner, o.text).length) ps.inner = inner;
        } catch (e) { if (e && e.code === "rate_limited") throw e; }
      }
      for (const strict of [false, true]) {
        const r = await sampleFn(PR.speakInput(Object.assign({}, o, { strict: strict })), CLAUDE_OPTS);
        if (!r.modelApplied && r.modelTierApplied) { ui.ai.model = "Claude(" + r.modelTierApplied + ")"; }
        const t = PR.cleanReply(r.text);
        if (t && koreanOk(t) && !E.leakCheck(o.cid, t, o.text).length) return { ok: true, text: t, inner: ps.inner || null, defense: ps.defense || null, variant: ps.variant };
      }
      return { ok: false };
    }
    return api("/api/speak", o, 150000);
  }
  async function aiGrade(cid, text) {
    if (ui.ai.provider === "claude") return PR.cleanGrade(await sampleFn.json(PR.gradeInput(NAMES[cid], text, S.motiveRubric), CLAUDE_OPTS), S.motiveRubric.length);
    const r = await api("/api/grade", { cid: cid, text: text }, 90000);
    if (!r || !r.ok) throw new Error("grade failed");
    return r;
  }
  function aiError(e) {
    const code = e && e.code;
    if (ui.ai.provider === "claude") {
      if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].indexOf(code) >= 0) {
        ui.ai = { state: "off", model: "", reason: "Claude 사용이 허용되지 않아 대본 모드로 진행한다" };
        toast("Claude 사용을 허용하지 않아 대본 대사로 진행합니다."); renderTop(); return;
      }
      if (code === "rate_limited") { toast("Claude 사용량 한도에 걸려 이번 대답은 대본 대사로 했습니다. 잠시 뒤 다시 시도하세요.", "error"); return; }
      if (code === "session_expired") { toast("Claude에 다시 로그인해야 합니다. 이번 대답은 대본 대사로 했습니다.", "error"); return; }
      if (code === "cancelled") return;
      toast("Claude 응답에 문제가 있어 이번 대답은 대본 대사로 했습니다.", "error"); return;
    }
    aiFail();
  }
  function aiFail(msg) {
    ui.ai = { state: "off", model: "", reason: msg || "AI 서버 응답이 없다" };
    if (!ui.aiWarned) { toast("AI 서버 연결이 끊겨 대본 모드로 진행합니다. 잠시 뒤 다시 연결을 시도합니다.", "error"); ui.aiWarned = true; }
    setTimeout(() => { ui.aiWarned = false; checkServer(); }, 30000);
  }
  function splitBubbles(t) {
    const parts = t.split(/\n\s*\n+/).map(x => x.trim()).filter(Boolean);
    if (parts.length <= 3) return parts.length ? parts : [t];
    return [parts[0], parts[1], parts.slice(2).join(" ")];
  }

  async function send(text) {
    const c = E.st.current;
    text = (text || "").trim();
    if (ui.busy || (!text && !ui.attach.length) || !E.available(c)) return;
    const ev = ui.attach.slice();
    const cs0 = E.st.chars[c], before = { trust: cs0.trust, pressure: cs0.pressure, first: !E.st.logs[c].some(m => m.f === "p") };
    log(c, { f: "p", t: text, ev: ev });
    ui.attach = []; ui.evpop = false; ui.busy = true;
    $("#input").value = "";
    renderChat(true);
    let ext = null;
    ui.lastAI = { ai: aiOn(), judge: null, speak: null };   // 점검 모드(?qa=1)가 읽는 기록
    if (aiOn()) {
      try { ext = await aiJudge(c, text); if (!ext || !ext.ok) ext = null; }
      catch (e) { ext = null; aiError(e); }
      ui.lastAI.judge = ext;
    }
    const r = E.respond(c, text, ev, ext);
    let bubbles = r.bubbles.map(b => b.text);
    // 심리 계층: 방어기제·중요한 턴·기운 판정(대본 모드에서도 상태는 갱신된다)
    const csA = E.st.chars[c];
    const pt = r.judge ? PS.turn(E.st, c, { tone: r.judge.tone, topics: r.judge.topics, presented: r.judge.presented.length, ctx: r.ctx, tier: csA.tier,
      trust0: before.trust, trust1: csA.trust, pressure0: before.pressure, pressure1: csA.pressure, first: before.first }) : null;
    let inner = null, usedDef = null;
    if (aiOn() && bubbles.length) {
      const cs = E.st.chars[c];
      const history = E.st.logs[c].filter(m => m.f !== "s").slice(-9, -1).map(m => ({ role: m.f === "p" ? "user" : "assistant",
        content: (m.f === "p" ? aiClean(m.t) : (m.t || "")) + (m.ev && m.ev.length ? " [증거 제시: " + m.ev.map(evTitle).join(", ") + "]" : "") }));
      try {
        const psy = { variant: ui.variant || DEFAULT_VARIANT, defense: pt ? pt.defense : null, energy: PS.state(E.st, c).energy, critical: !!(pt && pt.critical) };
        const sp = await aiSpeak({ cid: c, text: aiClean(text), unlocked: cs.unlocked, trust: cs.trust, pressure: cs.pressure, heard: cs.heard,
          presented: r.judge.presented, ctx: r.ctx, draft: bubbles.join(" "), history: history, psych: psy });
        const lk = sp.ok ? E.leakCheck(c, sp.text, aiClean(text)) : [];
        ui.lastAI.speak = { ok: !!sp.ok, attempt: sp.attempt || null, reason: sp.reason || null, browserLeaks: lk, variant: sp.variant || psy.variant, defense: sp.defense || null, inner: sp.inner || null, critical: psy.critical };
        if (sp.ok && !lk.length) { bubbles = splitBubbles(sp.text); inner = sp.inner || null; usedDef = psy.variant !== "A" ? psy.defense : null; }
      } catch (e) { ui.lastAI.speak = { ok: false, reason: "error" }; aiError(e); }
    } else await sleep(450 + Math.min(900, text.length * 12));
    if (pt) { pt.inner = inner; }
    for (let i = 0; i < bubbles.length; i++) {
      const m = { f: "c", t: bubbles[i] };
      if (i === 0 && (inner || usedDef)) { m.inner = inner; m.def = usedDef; }
      log(c, m);
      renderMsgs(i < bubbles.length - 1);
      if (i < bubbles.length - 1) await sleep(520);
    }
    r.system.forEach(t => log(c, { f: "s", t: t }));
    (r.newDeductions || []).forEach(id => { log(c, { f: "s", t: "탐정의 추리를 수사 기록에 적었다: " + E.dedClaim(id), k: "ded" }); stamp("추리 성립"); });
    if ((r.newFlags || []).indexOf("turner_summoned") >= 0) E.st.chars.john_turner.unread += 1;
    if (r.unlocked.length) log(c, { f: "s", t: `${E.chars[c].name}이(가) 새로운 이야기를 털어놓았다 — 진술 탭에 추가됨`, k: "unlock" });
    (r.newFlags || []).forEach(f => { if (FLAG_MSG[f]) { log(c, { f: "s", t: FLAG_MSG[f], k: "flag" }); toast(FLAG_MSG[f]); } });
    if ((r.newFlags || []).indexOf("prison_visit_granted") >= 0) E.st.chars.james_mccarthy.unread += 1;
    ui.busy = false;
    save();
    renderAll();
    const i = $("#input"); if (i && window.innerWidth > 900) i.focus();
  }
  function stamp(word) {
    const d = document.createElement("div"); d.className = "stampfx"; d.innerHTML = `<span>${esc(word)}</span>`;
    document.body.appendChild(d); setTimeout(() => d.remove(), 1400);
  }

  /* ---------- 창 ---------- */
  function modal(title, body, buttons, cls) {
    closeModal();
    const back = document.createElement("div"); back.className = "modal-back"; back.id = "modal";
    back.innerHTML = `<div class="modal ${cls || ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><h2>${esc(title)}</h2><button class="x" data-modal-close aria-label="닫기">✕</button></header><div class="body">${body}</div>${buttons ? `<footer class="actions">${buttons}</footer>` : ""}</div>`;
    document.body.appendChild(back);
    back.addEventListener("click", e => { if (e.target === back) closeModal(); });
    const b = back.querySelector("footer button, [data-modal-close]"); if (b) b.focus();
  }
  function closeModal() { const m = $("#modal"); if (m) m.remove(); }

  function inspect(id) {
    const st = E.evidenceStatus(id);
    if (st.state === "locked") { toast(lockReason(id)); return; }
    const r = E.inspect(id);
    save(); renderAll();
    const e = r.evidence;
    modal(r.isNew ? "새 증거를 찾았다" : e.title, `<div class="ev-detail" data-type="${e.type}">${evHead(e)}<div class="evd-title">${esc(e.title)}</div><div class="evd-sec"><div class="evd-lbl">${esc(e.object)}</div><div class="evd-body">${esc(e.text)}</div></div></div>`,
      `<button data-desk="${e.id}">책상에 펼치기</button><button data-present="${e.id}">${esc(SHORT[E.st.current])}에게 내밀기</button><button class="primary" data-modal-close>확인</button>`, "wide");
  }

  function doAction(aid) {
    if (E.actionStatus(aid).state === "done") { toast("레스트레이드 경감이 숲지기 모런 편에 터너에게 보낸 쪽지다. 터너와 대화할 수 있다."); return; }
    toast(noteHint());
  }

  function showBriefing(first) {
    const b = G.personas.scenario.public_briefing.map(x => `<li>${esc(x)}</li>`).join("");
    modal("사건 개요", `<div class="brief"><ul style="margin:0;padding-left:18px">${b}</ul></div>
      <p class="hint" style="margin-top:12px">처음이라면 머리줄의 「수사 안내」에서 「처음 5분」을 읽어 보자.</p>`,
      `<button data-guide="start">수사 안내</button><button class="primary" data-modal-close>${first ? "수사 시작" : "닫기"}</button>`);
  }

  function showSettings() {
    const lv = Object.keys(LEVELS).map(k => `<label class="lvl-opt"><input type="radio" name="setLevel" value="${k}" ${settings.level === k ? "checked" : ""}><span><b>${LEVELS[k].name}</b><span class="note">${esc(LEVELS[k].note)}</span></span></label>`).join("");
    modal("설정", `<div class="field"><span><b>난이도</b> — 대화창의 예시 질문</span><div class="lvl-list">${lv}</div>
        <p class="note">다음 실마리(힌트)는 난이도와 상관없이 쓸 수 있다. 힌트를 연 횟수와 난이도는 결과에 함께 남는다.</p></div>
      <hr>
      <label class="toggle"><input type="checkbox" id="setAi" ${settings.ai.enabled ? "checked" : ""}> AI 대화 쓰기</label>
      <p class="note">켜 두면 인물이 자유 질문을 알아듣고 대답한다. 끄면 정해진 대사로만 대답하는 대본 모드가 된다. 무엇을 털어놓을지는 게임 규칙이 정하고, 잠긴 정보가 섞인 대답은 내보내지 않는다.</p>
      <div id="aiTest" class="note">현재 상태: ${esc(ui.ai.state === "on" ? "AI 대화 연결됨 (" + ui.ai.model + ") — " + ui.ai.reason : ui.ai.reason || "확인 중")}</div>`,
      `<button id="btnTest">연결 시험</button><button class="primary" id="btnSaveSet">저장</button>`);
  }

  const topicJosa = w => { const ch = String(w).charCodeAt(String(w).length - 1) - 0xac00; return ch >= 0 && ch <= 11171 && ch % 28 ? "은" : "는"; };
  // 면담 태도: 증거 없이 다그친 횟수·위협 횟수·가장 높았던 압박, 압박 때문에 잃은 진술
  function conductRows(c, row) {
    if (!c) return "";
    const clean = !c.accuse && !c.threat && !c.locked.length;
    const who = Object.keys(c.byChar || {}).filter(k => c.byChar[k].accuse || c.byChar[k].threat)
      .map(k => `${NAMES[k]} ${[c.byChar[k].accuse ? "다그침 " + c.byChar[k].accuse : "", c.byChar[k].threat ? "위협 " + c.byChar[k].threat : ""].filter(Boolean).join("·")}`);
    const top = c.top ? ` · 다그친 인물 중 가장 높은 압박 ${esc(NAMES[c.top.cid])} ${Math.round(c.top.value)}` : "";
    let html = row("면담 태도", clean ? "강압 없이 면담함" : `증거 없이 다그침 ${c.accuse}번 · 위협 ${c.threat}번${top}`, clean);
    const notes = [];
    if (who.length) notes.push("누구에게: " + esc(who.join(", ")));
    c.locked.forEach(x => notes.push(`${esc(NAMES[x.cid])}${topicJosa(NAMES[x.cid])} 압박이 ${Math.round(x.pressure)}까지 올라 남은 이야기를 하지 않았다(${x.limit}을 넘으면 마음을 열지 않는다).`));
    if (c.accuse || c.threat) notes.push("근거 없이 다그치거나 위협하면 신뢰가 떨어지고 압박이 오른다. 증거를 먼저 내밀거나 상대를 안심시키는 편이 털어놓게 만든다.");
    notes.forEach(n => { html += `<tr><td></td><td class="fb">${n}</td></tr>`; });
    return html;
  }

  function showEnding(end, reaction) {
    const en = S.endings[end.id], r = end.report, g = r.grade;
    const row = (k, v, ok) => `<tr><td>${k}</td><td class="${ok === undefined ? "" : ok ? "ok" : "no"}">${v}</td></tr>`;
    const truth = G.personas.gm_truth;
    const by = g.by === "keyword" ? "핵심 표현 채점" : g.by;
    const motiveRow = r.culprit ? `${g.score}/${g.max} · ${esc(g.verdict)} <span class="note">(${esc(by)})</span>` : "범인을 잘못 지목해 채점하지 않음";
    const good = end.id === "END_TRUE";
    modal(en.title, `<div class="verdict ${good ? "" : "failed"}"><div class="vd-top"><span>판결문</span><span>보스콤 밸리 사건</span></div>
      <div class="vd-main"><div><div class="vd-grade">${esc(en.title)}</div></div><div class="vd-stamp">${good ? "진상 규명" : r.culprit ? "범인 지목" : "오판"}</div></div>
      <div class="vd-text">${esc(en.text)}</div></div>
      ${reaction ? `<div class="reaction">${Art.portrait("john_turner", { size: 44, square: true })}<div><b>${esc(NAMES.john_turner)}</b><p>${fmt(reaction)}</p></div></div>` : ""}
      <table class="report">
        ${row("범인", r.culprit ? "맞음" : "틀림", r.culprit)}
        ${row("동기", motiveRow, r.culprit ? r.motive : undefined)}
        ${r.culprit && g.feedback ? `<tr><td></td><td class="fb">${esc(g.feedback)}</td></tr>` : ""}
        ${row("결정적 증거(정답 세트의 최소 해결 증거와 일치)", `${r.keyEvidence}/${r.keyChosen}개 선택`, r.keyEvidence >= 3)}
        ${row("범인 특징·흐름 추리", `${r.deductions}/${r.deductionsTotal}`, r.deductions >= 4)}
        ${row("다른 후보 배제", `${r.exclusions}/3`, r.exclusions === 3)}
        ${row("범인의 자백", r.fullConfession ? "전부 털어놓음" : r.confessed ? "자백" : "없음", r.confessed)}
        ${row("모은 증거", `${r.evidenceOwned}/${r.evidenceTotal}`)}
        ${conductRows(r.conduct, row)}
        ${row("힌트 사용", `${r.hintsUsed || 0}회`)}
        ${row("난이도", LEVELS[settings.level].name)}
      </table>
      <details><summary>진상 보기 (스포일러)</summary><p style="margin-top:8px">${esc(truth.motive)}</p>${r.culprit ? `<p class="note">채점 요소: ${S.motiveRubric.map((m, i) => (g.points[i] ? "✓ " : "· ") + esc(m.label)).join(" / ")}</p>` : ""}<p>${esc(truth.method)}</p><ol class="timeline">${truth.timeline.map(t => `<li><b>${esc(t.t)}</b> ${esc(t.event)}</li>`).join("")}</ol></details>`,
      `<button data-modal-close>계속 수사하기</button><button class="danger" data-reset>처음부터 다시</button>`, "wide");
  }

  /* ---------- 힌트(다음 실마리) ---------- */
  function openLead(level) {
    const h = E.hint();
    E.useHint(h.id, level);
    save(); renderTop(); if (ui.tab === "map") renderMain();
  }
  function showHint(level) {
    const h = E.hint();
    if (level === undefined) level = Math.max(0, h.level);
    E.useHint(h.id, level);
    save(); renderTop(); if (ui.tab === "map") renderMain();
    const more = level < 1 ? `<button data-hint-more>더 구체적으로</button>` : "";
    modal("다음 실마리", `<div class="nextlead"><span class="lead-k">실마리</span><div class="lead-body"><p class="lead-t">${esc(h.text[0])}${level >= 1 ? `<br><b>${esc(h.text[1])}</b>` : ""}</p></div></div>
      <p class="note">지금 해 볼 만한 것을 하나만 알려 준다. 사용 횟수는 결과에 기록된다(지금 ${E.st.hintsUsed}회).</p>`,
      `${more}<button class="primary" data-modal-close>닫기</button>`);
  }

  /* ---------- 수사 안내서 ---------- */
  const GUIDE = [
    { id: "start", t: "처음 5분", lead: "로스의 호텔(헤리퍼드 암스)에서 시작한다. 레스트레이드 경감과 앨리스 터너가 호텔에 있다.", steps: [
      ["사건부터 듣기", "오른쪽 인물 패널에서 레스트레이드 경감을 고르고 사건 개요를 물어보자. 아래 예시 질문을 눌러도 된다."],
      ["기록 읽기", "지도 탭의 로스의 호텔에서 신문과 서류를 눌러 사건 기록을 읽는다."],
      ["장소 열기", "현장(연못·농장)과 감옥은 경감에게 청해야 열린다. 앨리스에게 옛일을 물으면 전신국이 열린다."],
      ["증거를 내밀기", "증거 탭이나 대화창의 「증거 첨부」로 인물에게 증거를 내밀면 숨긴 이야기를 털어놓기도 한다."],
      ["추리를 세우고 결론 내기", "증거가 가리키는 결론을 경감에게 말하면 추리가 성립한다. 근거가 차면 터너를 만날 수 있다."]] },
    { id: "map", t: "지도와 조사", lead: "아래 장소 카드나 전체 지도 위 장소를 눌러 그곳 장면으로 간다. 선택한 카드를 다시 누르면 전체 지도로 돌아온다.", items: [
      ["빛나는 물건", "조사할 수 있는 물건이다. 누르면 증거를 얻는다."],
      ["자물쇠 표시", "아직 조사할 수 없다. 누르면 무엇이 먼저 필요한지 알려 준다."],
      ["초록 체크", "조사를 마친 물건이다."],
      ["인물 얼굴", "누르면 그 인물과 대화한다. 회색이면 아직 만날 수 없다."]] },
    { id: "lead", t: "다음 실마리", lead: "탭 바로 아래의 「다음 실마리」는 막혔을 때 지금 해 볼 일을 하나 알려 준다. 처음에는 가볍게, 「더 구체적으로」를 누르면 구체적으로 알려 준다.", items: [
      ["기록", "여는 횟수는 결과 화면에 힌트 사용으로 남는다."], ["숨기기", "띠를 접어 둘 수 있다. 「펼치기」로 다시 연다. 머리줄의 힌트 수는 그대로다."]] },
    { id: "talk", t: "대화 — 자유 심문", lead: "정해진 선택지 없이 자유롭게 묻는다. 인물은 자기가 아는 것만, 지금 마음이 허락하는 만큼만 말한다.", items: [
      ["신뢰", "공감하거나 정중하게 물으면 오른다. 높으면 민감한 이야기를 털어놓는다."],
      ["압박", "근거 없는 추궁이나 위협에 오른다. 너무 높으면 입을 닫는 인물이 있다(페이션스)."],
      ["기운", "추궁이 이어지면 떨어지고, 떨어지면 말이 짧아진다."],
      ["증거 제시", "관련 있는 증거를 내밀면 숨긴 이야기를 털어놓게 만들 수 있다."],
      ["말투", "인물마다 성격·말버릇·숨기는 방식이 다르다. 같은 질문도 누구에게 하느냐에 따라 반응이 다르다."]] },
    { id: "board", t: "맞대기 보드", lead: "지도 아래 보드에서 인물·증거 토큰을 끌어다 다른 토큰 위에 놓는다. 끌기가 불편하면 하나를 누른 뒤 대상을 눌러도 된다.", items: [
      ["증거 → 인물(내밀기)", "그 인물에게 증거를 내밀며 말을 건다. 대화창에 첨부해 보낸 것과 같다."],
      ["증거 ↔ 증거(착안)", "관계가 있는 두 증거면 둘 사이의 질문을 짚어 준다. 답은 알려 주지 않는다. 답이 떠오르면 레스트레이드 경감에게 직접 말해야 추리가 된다."],
      ["인물 ↔ 인물(대질)", "인물의 ⇄를 누르고 다른 인물을 누른다. 두 사람에게서 이미 들은 말이 서로 어긋나면 나란히 보여 준다. 아직 그 말을 듣지 못했으면 먼저 들어 보라고 알려 준다."],
      ["헛짚음", "관계없는 짝은 흔들리고 끝난다. 성공·헛짚음 모두 수사 기록에 남는다."]] },
    { id: "evidence", t: "증거 카드와 대조 책상", lead: "모은 증거는 증거 탭에 카드로 쌓인다. 카드 위 색 띠는 증거 종류다.", items: [
      ["자세히", "관찰 기록 전문과 이 증거로 한 일(누구에게 내밀었는지)을 본다."],
      ["책상에 펼치기", "두 장까지 대조 책상에 펼쳐 나란히 견준다."],
      ["대화에 첨부", "지금 대화 상대에게 내민다. 질문과 함께 보내자."]] },
    { id: "deduce", t: "추리 세우기", lead: "증거가 가리키는 결론(범인의 몸, 범행 뒤의 움직임, 마지막 말의 뜻 등)을 레스트레이드 경감에게 직접 말하면 추리가 성립한다. 성립한 추리는 수사 기록 탭에 남는다.", items: [
      ["말하는 법", "질문보다 단정이 좋다. '범인은 ~일 것이다'처럼 결론을 분명히 말한다."],
      ["결론 글", "결론 탭의 동기 글에 적은 추리도 수사 기록에 반영된다."]] },
    { id: "turner", t: "터너 만나기와 자백", lead: "터너는 앓아누워 손님을 받지 않는다. 근거 있는 추리를 경감에게 보고하면 경감이 숲지기 편에 쪽지를 보내 자리를 마련한다.", items: [
      ["추궁", "과거를 들이밀 증거, 현장 흔적과 몸이 맞아떨어진다는 증거를 내밀자."],
      ["마지막 한 걸음", "터너가 가장 걱정하는 것이 무엇인지 생각해 보자."]] },
    { id: "notes", t: "노트·진술·수사 기록", lead: "진술 탭은 사람별로 들은 이야기, 노트 탭은 사람별 요약(더 물어볼 거리, 내민 증거), 수사 기록 탭은 세운 추리·사건 진행·개인 메모다.", items: [
      ["더 물어볼 거리", "지금까지 연 조건으로 아직 듣지 못한 이야기 수다. 무엇인지는 직접 물어봐야 안다."],
      ["개인 메모", "이 브라우저에 자동 저장된다."]] },
    { id: "conclude", t: "결론과 채점", lead: "결론 탭에서 범인을 고르고 동기를 적고 결정적 증거를 골라 제출한다. 제출 뒤에도 수사를 이어갈 수 있다.", items: [
      ["채점", "범인, 동기(AI 채점관 또는 핵심 표현), 결정적 증거, 세운 추리, 후보 배제, 자백, 힌트 사용을 본다."],
      ["진엔딩", "터너의 자백과 충분한 추리가 함께 있어야 한다."]] },
    { id: "tips", t: "작은 팁", lead: "막히면 다음 실마리를 열자. 인물을 몰아붙이기보다 증거로 말하게 하자.", items: [
      ["Enter", "보내기. Shift+Enter는 줄바꿈."], ["Esc", "맨 위 창을 닫는다."], ["새 수사", "머리줄 오른쪽. 모든 진행을 지운다."]] }
  ];
  function showGuide(id) {
    const cur = GUIDE.find(g => g.id === id) || GUIDE[0], i = GUIDE.indexOf(cur);
    const nav = GUIDE.map((g, k) => `<button class="gd-tab" data-guide="${g.id}" aria-current="${g.id === cur.id}"><span class="gd-no">${String(k + 1).padStart(2, "0")}</span>${esc(g.t)}</button>`).join("");
    const body = `<div class="gd-title">${esc(cur.t)}</div><p class="gd-lead">${esc(cur.lead)}</p>
      ${cur.steps ? `<ol class="gd-steps">${cur.steps.map(s => `<li><b>${esc(s[0])}</b><span>${esc(s[1])}</span></li>`).join("")}</ol>` : ""}
      ${cur.items ? `<dl class="gd-items">${cur.items.map(s => `<dt>${esc(s[0])}</dt><dd>${esc(s[1])}</dd>`).join("")}</dl>` : ""}
      <div class="gd-pager">${i > 0 ? `<button data-guide="${GUIDE[i - 1].id}">← ${esc(GUIDE[i - 1].t)}</button>` : "<span></span>"}${i < GUIDE.length - 1 ? `<button class="primary" data-guide="${GUIDE[i + 1].id}">${esc(GUIDE[i + 1].t)} →</button>` : "<span></span>"}</div>`;
    modal("수사 안내서", `<div class="guide"><nav class="gd-nav">${nav}</nav><div class="gd-body">${body}</div></div>
      <label class="gd-toggle"><input type="checkbox" id="gdToggle" ${ui.guideOff ? "" : "checked"}> 탭마다 위쪽에 한 줄 안내 띠 보이기</label>`, "", "wide guide-modal");
  }
  function firstGuide() {
    if (tryGet("boscombe.guideSeen") === "1") return;
    trySet("boscombe.guideSeen", "1");
    if (!$("#modal")) showGuide("start");
  }

  /* ---------- 결론 제출 ---------- */
  async function submitConclusion() {
    const cid = ui.picked.culprit, text = ui.picked.motive.trim();
    if (!cid) { toast("범인을 고르자."); return; }
    if (text.length < 8) { toast("범인이 왜 그랬는지 한 문장 이상 적어 보자."); return; }
    E.creditDeductions(text);
    ui.grading = true; renderMain();
    modal("결론 검토 중", `<p>${aiOn() ? "채점관이 결론을 진상과 대조하고 있다…" : "결론을 정리하고 있다…"}</p>`);
    let grade = null;
    if (cid === E.CASE.answer.culprit && aiOn()) {
      try { const a = await aiGrade(cid, text); grade = E.makeGrade(a.points, a.feedback, ui.ai.model + " 채점"); }
      catch (e) { aiError(e); }
    }
    if (!grade) grade = E.gradeMotive(text);
    const end = E.accuse(cid, { text: text, grade: grade }, ui.picked.ev);
    let reaction = null;
    if (cid === "john_turner" && E.available("john_turner")) {
      const confessed = end.report.confessed, tv = S.turnerVerdict;
      reaction = !confessed ? tv.denied : grade.score >= 2 ? tv.confessedGood : tv.confessedPart;
      if (aiOn()) {
        const cs = E.st.chars.john_turner;
        try {
          const sp = await aiSpeak({ cid: "john_turner", text: "범인은 당신입니다. " + text, unlocked: cs.unlocked, trust: cs.trust, pressure: cs.pressure, heard: cs.heard,
            presented: [], ctx: { newly: [], deflect: [], verdict: { score: grade.score, max: grade.max, confessed: confessed } }, draft: reaction, history: [],
            psych: { variant: ui.variant || DEFAULT_VARIANT, defense: confessed ? "rationalization" : "denial", energy: PS.state(E.st, "john_turner").energy, critical: true } });
          if (sp.ok && !E.leakCheck("john_turner", sp.text, "범인은 당신입니다. " + text).length) reaction = sp.text;
        } catch (e) { aiError(e); }
      }
      if (E.leakCheck("john_turner", reaction, "범인은 당신입니다. " + text).length) reaction = tv.denied;
      log("john_turner", { f: "p", t: "범인은 당신입니다. " + text });
      log("john_turner", { f: "c", t: reaction });
    }
    ui.grading = false;
    save(); renderAll(); showEnding(end, reaction);
  }

  /* ---------- 이벤트 ---------- */
  document.addEventListener("click", async e => {
    const t = e.target.closest("button, [data-bk], [data-ev], [data-act], [data-char], [data-loc], [data-scene], g.hot, g.pin, g.maploc, g.sobj, g.spin");
    if (!t) return;
    const d = t.dataset;
    if (d.modalClose !== undefined) { closeModal(); return; }
    if (d.bgrab) { e.stopPropagation(); const pk = ui.bpick; ui.bpick = pk && pk.kind === "person" && pk.id === d.bgrab ? null : { kind: "person", id: d.bgrab }; refreshBoard(); return; }
    if (d.bk) { boardClick(t); return; }
    if (d.insight) { showInsight(d.insight); return; }
    if (d.bpickev) { ui.bpick = { kind: "ev", id: d.bpickev }; ui.tab = "map"; ui.fold.board = false; saveUi(); closeModal(); renderMain(); const b = $("#contact"); if (b) b.scrollIntoView({ block: "center" }); return; }
    if (d.tab) { ui.tab = d.tab; renderMain(); $("#view").scrollTop = 0; return; }
    if (d.guide) { showGuide(d.guide); return; }
    if (d.guideHide !== undefined) { ui.guideOff = true; saveUi(); renderMain(); toast("탭 안내 띠를 숨겼습니다. 머리줄의 「수사 안내」에서 다시 켤 수 있습니다."); return; }
    if (d.fold) { ui.fold[d.fold] = !ui.fold[d.fold]; saveUi(); renderMain(); return; }
    if (d.leadToggle !== undefined) { ui.leadOff = !ui.leadOff; saveUi(); renderMain(); return; }
    if (d.leadOpen !== undefined) { openLead(+d.leadOpen); return; }
    if (d.closeChat !== undefined) { document.body.classList.remove("chat-open"); return; }
    if (d.evd) { showEvidence(d.evd); return; }
    if (d.desk) {
      const k = ui.desk.indexOf(d.desk);
      if (k >= 0) ui.desk.splice(k, 1); else { ui.desk.push(d.desk); if (ui.desk.length > 2) ui.desk.shift(); toast("대조 책상에 펼쳤다. 증거 탭 맨 위에서 나란히 볼 수 있다."); }
      saveUi(); closeModal(); renderMain(); return;
    }
    if (d.present) { if (!E.available(E.st.current)) { toast("지금 대화 상대에게는 내밀 수 없다."); return; } if (ui.attach.indexOf(d.present) < 0) ui.attach.push(d.present); closeModal(); document.body.classList.add("chat-open"); renderComposer(); toast("증거를 첨부했다. 질문과 함께 보내자."); $("#input").focus(); return; }
    if (d.attach) { if (ui.attach.indexOf(d.attach) < 0) ui.attach.push(d.attach); ui.evpop = false; renderComposer(); $("#input").focus(); return; }
    if (d.unattach) { ui.attach = ui.attach.filter(x => x !== d.unattach); renderComposer(); return; }
    if (d.q) { send(d.q); return; }
    if (d.evf !== undefined) { ui.evFilter = +d.evf; renderMain(); return; }
    if (d.sus) { ui.picked.culprit = d.sus; renderMain(); return; }
    if (d.reset !== undefined || t.id === "btnReset") { modal("새 수사", `<p>지금까지 모은 증거, 대화, 추리를 모두 지우고 처음부터 시작한다.</p>`, `<button data-modal-close>취소</button><button class="danger" data-reset-yes>지우고 새로 시작</button>`); return; }
    if (d.resetYes !== undefined) { E.reset(); save(); ui.picked = { culprit: null, motive: "", ev: [] }; ui.tab = "map"; ui.loc = "ross_hotel"; ui.desk = []; ui.bpick = null; saveUi(); closeModal(); const c0 = E.st.current; E.st.chars[c0].met = true; log(c0, { f: "c", t: S.characters[c0].greet }); save(); renderAll(); showBriefing(true); return; }
    if (d.scene) { ui.loc = ui.loc === d.scene ? "overview" : d.scene; renderMain(); return; }
    if (t.matches && t.matches("g.hot, g.maploc")) { ui.loc = Sc.sceneOf(d.loc); renderMain(); return; }
    if (d.ev) { inspect(d.ev); return; }
    if (d.act) { doAction(d.act); return; }
    if (d.char) { closeModal(); openChar(d.char); return; }
    if (d.loc) { ui.loc = Sc.sceneOf(d.loc); renderMain(); return; }
    if (t.id === "btnBrief") { showBriefing(false); return; }
    if (t.id === "btnHelp") { showGuide("start"); return; }
    if (d.hintMore !== undefined) { showHint(1); return; }
    if (t.id === "btnSettings") { showSettings(); return; }
    if (t.id === "btnStart") { const cv = $("#cover"); if (cv) { cv.classList.add("leaving"); setTimeout(() => { cv.remove(); firstGuide(); }, 700); } return; }
    if (t.id === "btnEv") { ui.evpop = !ui.evpop; renderComposer(); return; }
    if (t.id === "send") { send($("#input").value); return; }
    if (t.id === "toChat") { openChar(E.st.current); return; }
    if (t.id === "toMain") { document.body.classList.remove("chat-open"); return; }
    if (t.id === "btnAiPill") { showSettings(); return; }
    if (t.id === "btnSaveSet") {
      const lvIn = document.querySelector("input[name=setLevel]:checked"); if (lvIn && LEVELS[lvIn.value]) settings.level = lvIn.value;
      settings.ai = { enabled: $("#setAi").checked };
      trySet(SET_KEY, JSON.stringify(settings)); closeModal(); renderAll(); toast("설정을 저장했다."); checkServer(); return;
    }
    if (t.id === "btnTest") {
      const out = $("#aiTest"); out.textContent = "시험 중…";
      try {
        const st = await api("/api/status", null, 8000);
        out.innerHTML = st.ok ? `<b class="ok">연결됨</b> — ${esc(st.provider || "ollama")} · 모델 ${esc(st.model)}` : `<b class="no">서버는 켜져 있지만 AI를 쓸 수 없다.</b> ${esc(st.reason || "")}`;
      } catch (err) { out.innerHTML = `<b class="no">게임 서버에 연결하지 못했다.</b> 서버가 켜져 있는지 확인하자. 파일로 열었다면 대본 모드로만 동작한다.`; }
      return;
    }
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") { closeModal(); ui.evpop = false; renderComposer(); }
    if (e.key === "Escape" && ui.bpick) { ui.bpick = null; refreshBoard(); }
    if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("#contact .ctok")) { e.preventDefault(); boardClick(e.target); return; }
    if ((e.key === "Enter" || e.key === " ") && e.target.matches && e.target.matches("g.hot, g.pin, g.sobj, g.spin")) { e.preventDefault(); e.target.dispatchEvent(new MouseEvent("click", { bubbles: true })); }
  });
  document.addEventListener("pointerdown", e => { const tok = e.target.closest && e.target.closest("#contact .ctok"); if (tok) startDrag(e, tok); });
  document.addEventListener("submit", e => {
    e.preventDefault();
    const f = e.target;
    if (f.id === "cform") {
      ui.picked.motive = ($("#motiveText") || {}).value || "";
      ui.picked.ev = Array.from(f.querySelectorAll("input[name=kev]:checked")).map(x => x.value);
      if (!ui.grading) submitConclusion();
    }
  });
  document.addEventListener("change", e => {
    if (e.target.name === "kev") ui.picked.ev = Array.from(document.querySelectorAll("input[name=kev]:checked")).map(x => x.value);
    if (e.target.id === "gdToggle") { ui.guideOff = !e.target.checked; saveUi(); renderMain(); }
  });
  const input = $("#input");
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(input.value); }
  });
  document.addEventListener("input", e => {
    if (e.target.id === "motiveText") ui.picked.motive = e.target.value;
    if (e.target.id === "memo") trySet(MEMO_KEY, e.target.value);
  });

  (function greetCurrent() {
    const c0 = E.st.current;
    if (E.available(c0) && !E.st.chars[c0].met) { E.st.chars[c0].met = true; log(c0, { f: "c", t: S.characters[c0].greet }); }
  })();
  /* 표지: 처음 열었을 때(주소 끝에 #intro를 붙이면 다시 나온다) */
  function showCover() {
    const cv = document.createElement("div"); cv.className = "intro"; cv.id = "cover";
    const status = id => (E.ev[id] ? evStatus(id) : "locked");
    cv.innerHTML = `<div class="intro-sheet"><div><h1 class="intro-title"><span>보스콤</span><span>밸리</span><span class="w">사건</span></h1>
      <p class="intro-lede">6월 3일 월요일 오후 3시경, 찰스 매카시가 보스콤 연못가에서 머리를 맞고 숨졌다. 아들 제임스가 체포됐고 검시 배심은 고의적 살인으로 평결했다.</p>
      <p class="intro-lede strong">앨리스 터너만이 그의 무죄를 믿는다.</p>
      <button class="intro-seal" id="btnStart"><svg viewBox="-50 -50 100 100" aria-hidden="true"><path class="wax a" d="M-40 -8 C-44 -30 -24 -46 0 -44 L4 0 Z M4 0 L0 -44 C26 -46 46 -26 42 0 Z"/><path class="wax b" d="M-40 -8 L4 0 L42 0 C44 26 24 46 0 44 C-26 46 -46 24 -40 -8 Z"/><circle class="emboss" r="30"/><text class="emboss-t" text-anchor="middle" y="13">B</text></svg><span>봉인을 뜯고 수사 시작</span></button>
      <p class="intro-src">아서 코넌 도일, 「보스콤 계곡의 수수께끼」(1891) · WhoDunIt 벤치마크 각색 · 인물은 심리 기반 페르소나로 대답한다</p></div>
      <div class="intro-art">${Art.mapSVG(status, charPinInfo(), null)}</div></div>`;
    document.body.appendChild(cv);
  }

  renderAll();
  checkServer();
  const fresh = !tryGet(SAVE_KEY) || E.st.turn === 0 && !E.st.owned.length;
  if ((fresh || location.hash === "#intro") && !/[?&]qa=1/.test(location.search)) showCover();
  window.__bv = { E: E, PS: PS, PR: PR, settings: settings, send: send, openChar: openChar, inspect: inspect, ui: ui, renderAll: renderAll, showHint: showHint, submitConclusion: submitConclusion,
    aiSpeak: aiSpeak, aiJudge: aiJudge, aiOn: aiOn, api: api, koreanOk: koreanOk, sample: () => sampleFn, toast: toast, modal: modal, closeModal: closeModal, esc: esc, NAMES: NAMES, CHAR_ORDER: CHAR_ORDER };
})();
