#!/usr/bin/env node
/* 보스콤 밸리 — 페르소나 검증 도구(개발자 전용, 게임 화면에는 없음)
 *
 * 게임 서버(server/server.py)를 켠 PC에서 실행한다. 플레이어에게는 보이지 않는다.
 *
 *   node tools/persona_verify.js                                    # 터너·제임스, A/B/C, T1~T6, 1회
 *   node tools/persona_verify.js --chars all --reps 2               # 6명 전체, 2회 반복
 *   node tools/persona_verify.js --variants B,C --tests T5          # 일부만
 *   node tools/persona_verify.js --no-judge                         # 채점 모델 없이 규칙 지표만
 *   node tools/persona_verify.js --dry                              # 호출 없이 예상 호출 수만
 *   node tools/persona_verify.js --questions                        # 질문 세트(Markdown)만 만들기
 *   node tools/persona_verify.js --merge verify_out/a.json verify_out/b.json   # 모델끼리 비교표(예: EXAONE vs Haiku)
 *   node tools/persona_verify.js --rerate verify_out/persona_verify_….json     # 저장된 대답은 그대로 두고 채점만 다시
 *   node tools/persona_verify.js --report verify_out/persona_verify_….json [--only john_turner,james_mccarthy]   # 저장된 결과로 보고서만 다시(인물 골라 비교할 때)
 *   윈도우에서는 tools\run_verify.bat 을 더블클릭해 메뉴로 고를 수 있다(macOS·Linux는 tools/run_verify.sh).
 *   옵션: --server http://localhost:8000  --out verify_out
 *
 * 시험(data/verify_suite.json):
 *   T1 성격 보존 — Big Five 인터뷰(InCharacter). 10문항을 한 대화로 묻고 채점 모델이 1~5로 매김 → 목표값과 오차
 *   T2 말투 준수 — 모든 대답의 문장 길이·어미·말줄임표·입버릇(규칙, PersonaForge SA) + 채점 모델의 말투 점수
 *   T3 장기 대화 일관성 — 교란이 섞인 14턴(게임 엔진 경유). 설정 맞음(fit), 앞말과 모순, 이탈률
 *   T4 방어기제 발현 — 인물별 발동 상황에서 의도한 방어기제가 드러났는가(DMA)
 *   T5 정보 유출 — 잠긴 단계 직접·가정·사회공학 질문, 프롬프트 추출, 역할 이탈, 세계 밖 요청(직접 질의)
 *   T6 증거 제시 반응 — 같은 질문을 증거 없이/증거를 내밀고(SUE, 게임 엔진 경유)
 * 질의 방식: 「직접 질의」는 엔진 판정 없이 페르소나 모델(/api/speak)에 바로 묻는다. 「엔진 경유」는 실제 게임처럼
 *   규칙 엔진이 해금·회피를 정한 뒤 대사를 만든다(판정은 키워드 판정기로 고정해 대사만 비교).
 * 채점: 규칙 지표는 이 도구가, 의미 판정은 서버의 판정 모델(/api/rate)이 한다. /api/rate와 원문 기록(_audit)은
 *   서버 PC(localhost)에서만 열리므로 --server는 보통 http://localhost:8000 이다.
 * 결과: <out>/persona_verify_<모델>_<시각>.md(합격 판정 + 보고서 7절 요약 표 + 해석 초안 + 세부 표),
 *   .csv(문항별 원자료), .json(전체 기록. 이 파일을 Claude에게 주면 보고서 결과 절을 채울 수 있다)
 */
"use strict";
if (typeof fetch !== "function") { console.error("Node.js 18 이상이 필요합니다(지금 " + process.version + "). https://nodejs.org 에서 LTS를 설치하세요."); process.exit(1); }
global.window = global;
const fs = require("fs"), path = require("path"), cp = require("child_process");
// 게임 폴더 찾기: tools/의 위 폴더 → 지금 폴더 → 그 위 폴더들 순서로, 게임 파일(data/verify_suite.json, src/engine.js)이 있는 곳
function findRoot() {
  const cands = [path.join(__dirname, ".."), process.cwd()];
  let d = process.cwd();
  for (let i = 0; i < 4; i++) { d = path.dirname(d); cands.push(d); cands.push(path.join(d, "boscombe_game")); }
  cands.push(path.join(process.cwd(), "boscombe_game"));
  return cands.find(c => fs.existsSync(path.join(c, "data", "verify_suite.json")) && fs.existsSync(path.join(c, "src", "engine.js")));
}
const ROOT = findRoot();
if (!ROOT) {
  console.error(`게임 폴더를 찾지 못했습니다.\n  이 도구 위치: ${__dirname}\n  tools 폴더는 게임 폴더(boscombe_game) 바로 안에 있어야 합니다.\n  예) boscombe_game\\tools\\run_verify.bat\n  압축을 풀 때 'persona_verify_tools' 같은 새 폴더가 생겼다면, 그 안의 tools 폴더를 boscombe_game 안으로 옮기세요.`);
  process.exit(1);
}
const D = p => path.join(ROOT, p);
const readJson = p => JSON.parse(fs.readFileSync(D(p), "utf-8"));

/* ---------- 옵션 ---------- */
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf("--" + k); return i >= 0 && args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : d; };
const flag = k => args.indexOf("--" + k) >= 0;
if (flag("help") || flag("h")) { console.log(fs.readFileSync(__filename, "utf-8").split("*/")[0].replace(/^#!.*\n/, "")); process.exit(0); }

/* ---------- 메뉴(run_verify.bat이 부른다) ---------- */
if (flag("menu")) { menu(); return; }

/* ---------- 게임 데이터·엔진(게임과 같은 파일을 그대로 쓴다) ---------- */
if (!fs.existsSync(D("dist/boscombe_personas_ko.json"))) {
  // 빌드 결과가 없으면 한 번 만들어 본다(python 또는 py)
  console.log("dist/boscombe_personas_ko.json이 없어 python build.py를 실행합니다…");
  for (const py of ["python", "py", "python3"]) {
    try { cp.execFileSync(py, ["build.py"], { cwd: ROOT, stdio: "inherit" }); break; } catch (e) { /* 다음 이름 */ }
  }
}
const PERSONA_FILE = fs.existsSync(D("dist/boscombe_personas_ko.json")) ? "dist/boscombe_personas_ko.json" : null;
if (!PERSONA_FILE) { console.error(`${D("dist/boscombe_personas_ko.json")}이 없습니다.\n게임 폴더(${ROOT})에서 python build.py를 실행한 뒤 다시 시도하세요.`); process.exit(1); }
require(D("src/script.js"));
const Engine = require(D("src/engine.js"));
const Psych = require(D("src/psych.js"));
const G = { personas: readJson(PERSONA_FILE), case: readJson("data/boscombe_case.json") };
const PSY = readJson("data/persona_psych.json"), SUITE = readJson("data/verify_suite.json");
const PS = new Psych(PSY);
const ORDER = ["inspector_lestrade", "alice_turner", "patience_moran", "william_crowder", "james_mccarthy", "john_turner"];
const CH = {}; G.personas.characters.forEach(c => { CH[c.id] = c; });
const TESTS = { T1: "성격 보존(Big Five 인터뷰)", T2: "말투 준수", T3: "장기 대화 일관성", T4: "방어기제 발현", T5: "정보 유출·역할 이탈", T6: "증거 제시 반응(SUE)" };

const charsArg = opt("chars", "john_turner,james_mccarthy");
const O = {
  server: opt("server", "http://localhost:8000").replace(/\/$/, ""),
  out: opt("out", path.join(ROOT, "verify_out")),
  chars: charsArg === "all" ? ORDER.slice() : charsArg.split(",").map(s => s.trim()).filter(Boolean),
  variants: opt("variants", "A,B,C").split(",").map(s => s.trim().toUpperCase()).filter(Boolean),
  tests: opt("tests", "T1,T2,T3,T4,T5,T6").split(",").map(s => s.trim().toUpperCase()).filter(Boolean),
  reps: Math.max(1, +opt("reps", 1) || 1),
  judge: !flag("no-judge")
};
O.chars.forEach(c => { if (!CH[c]) { console.error(`알 수 없는 인물: ${c}\n가능한 값: ${ORDER.join(", ")}, all`); process.exit(1); } });
O.variants.forEach(v => { if (["A", "B", "C"].indexOf(v) < 0) { console.error(`알 수 없는 변형: ${v} (A, B, C)`); process.exit(1); } });
O.tests.forEach(t => { if (!TESTS[t]) { console.error(`알 수 없는 시험: ${t} (T1~T6)`); process.exit(1); } });

/* ---------- 공통 ---------- */
const st = { stop: false, rows: [], rated: [], log: [], startedAt: null, model: "", backend: "", judgeLabel: "" };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const LATIN_OK = /^(black|jack|of|ballarat|cooee|a|rat|arat|victoria|bristol|ross|boscombe|hatherley|mccarthy|turner|james|alice|lestrade)$/i;
function koreanOk(t) {   // src/ui.js의 koreanOk와 같은 규칙
  const body = String(t || "").replace(/\*[^*]*\*/g, " ");
  const hangul = (body.match(/[가-힣]/g) || []).length;
  const latin = (body.match(/[A-Za-z]+/g) || []).filter(w => !LATIN_OK.test(w)).join("").length;
  return hangul > 0 && hangul >= 2 * latin;
}
async function api(p, body, ms) {
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), ms || 60000);
  try {
    const r = await fetch(O.server + p, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ctrl.signal } : { signal: ctrl.signal });
    const j = await r.json().catch(() => ({ ok: false, reason: "HTTP " + r.status }));
    if (j && typeof j === "object") j.status = r.status;
    return j;
  } finally { clearTimeout(timer); }
}
function sandbox(o) {
  const E = new Engine(G.personas, G.case, window.SCRIPT);
  ["prison_visit_granted", "scene_access_granted", "turner_summoned"].forEach(f => E.st.flags.push(f));
  if (o && o.ownAll) E.st.owned = G.case.evidence.map(e => e.id);
  return E;
}
function knownLocked(cid, unlocked) {
  const c = CH[cid], known = c.base_knowledge.map(k => k.content), locked = [];
  c.unlock_tiers.forEach(t => (unlocked.indexOf(t.tier) >= 0 ? known : locked).push(...t.unlocked_knowledge.map(k => k.content)));
  return { known, locked };
}
function leakRule(cid, unlocked, text, q) { const E = sandbox(); E.st.chars[cid].unlocked = unlocked.slice(); return E.leakCheck(cid, text || "", q || ""); }

/* ---------- 규칙 지표: 말투 준수(SA) ---------- */
function sentences(t) { return String(t || "").replace(/\*[^*]*\*/g, " ").split(/(?<=[.?!…])\s+|\n+/).map(x => x.trim()).filter(x => /[가-힣]/.test(x)); }
function styleScore(cid, text) {
  const s = PSY.characters[cid].style, ss = sentences(text);
  if (!ss.length) return { sa: 0, len: 0, end: 0, ctc: 0, ell: 0 };
  const len = ss.filter(x => { const n = x.replace(/\s/g, "").length; return n >= s.sentence_chars[0] * 0.7 && n <= s.sentence_chars[1] * 1.3; }).length / ss.length;
  const end = ss.filter(x => { const b = x.replace(/[.?!…~"'”’)\s]+$/, ""); return s.endings.some(e => b.endsWith(e)); }).length / ss.length;
  const body = String(text).replace(/\*[^*]*\*/g, " ");
  const ctc = s.catchphrases.some(cp => body.indexOf(cp.replace(/…$/, "")) >= 0) ? 1 : 0;
  const en = (body.match(/…|\.\.\./g) || []).length / ss.length;
  const ell = s.ellipsis === "high" ? Math.min(1, en / 0.5) : s.ellipsis === "low" ? (en <= 0.2 ? 1 : 0) : (en > 0 && en <= 0.8 ? 1 : 0.5);
  return { sa: 0.25 * (len + end + ctc + ell), len, end, ctc, ell };
}

/* ---------- 모델 호출 ---------- */
async function speak(cid, q, o) {
  const c = CH[cid], E = o.E, cs = E ? E.st.chars[cid] : null;
  const body = { cid, text: q, unlocked: o.unlocked || (cs ? cs.unlocked : []), trust: o.trust != null ? o.trust : (cs ? cs.trust : c.initial_state.trust),
    pressure: o.pressure != null ? o.pressure : (cs ? cs.pressure : c.initial_state.pressure), heard: cs ? cs.heard : [], presented: o.presented || [],
    ctx: o.ctx || { freeform: true, newly: [], deflect: [] }, draft: o.draft || "", history: (o.history || []).slice(-8),
    psych: { variant: o.variant, defense: o.variant === "A" ? null : (o.defense || null), energy: o.energy != null ? o.energy : PSY.characters[cid].energy_start, critical: !!o.critical }, _audit: true };
  const t0 = Date.now();
  let r;
  for (let k = 0; k < 3; k++) {
    try { r = await api("/api/speak", body, 150000); } catch (e) { r = { ok: false, reason: String(e && (e.name === "AbortError" ? "timeout" : e.message) || e) }; }
    if (r && r.reason === "rate_limited") { await sleep(15000); continue; }
    break;
  }
  r = r || { ok: false };
  r.ms = Date.now() - t0;
  return r;
}
async function rate(kind, cid, unlocked, items) {
  if (!O.judge) return null;
  const it = items.slice(0, 16).map((x, n) => Object.assign({ i: n + 1 }, x, { q: String(x.q || "").slice(0, 400), a: String(x.a || "").slice(0, 700) }));
  let last = "";
  for (let k = 0; k < 2; k++) {                 // 채점 결과를 못 읽으면 한 번 더 묻는다
    try {
      const r = await api("/api/rate", { kind, cid, unlocked, items: it }, 180000);
      if (r && r.judge) st.judgeLabel = r.judge;
      if (r && r.ok) return r.result;
      last = `${r && r.reason || "응답 없음"}${r && r.raw ? " · 원문: " + String(r.raw).replace(/\s+/g, " ").slice(0, 160) : ""}`;
    } catch (e) { last = String(e && e.message || e); }
  }
  note(`채점 실패(${kind}, ${CH[cid].name}): ${last}`);
  return null;
}
function note(t) { st.log.push(t); console.log("  ! " + t); }
let done = 0, total = 0;
// AI 대답이 실패했을 때 이유(누출 검사에 걸린 표현 또는 서버 사유)와 거르기 전 원문 한 개를 남긴다
function failInfo(r) {
  if (!r || r.ok) return {};
  const hit = (r.audit || []).filter(x => x.leaks && x.leaks.length);
  const pats = [...new Set(hit.flatMap(x => x.leaks))];
  return { why: pats.length ? "누출 검사: " + pats.join(", ") : (r.reason || "실패"), rawFail: hit.length ? String(hit[0].raw || "").slice(0, 600) : "" };
}
function push(row) {
  st.rows.push(row); done++;
  const a = String(row.a || "(대답 없음)").replace(/\s+/g, " ");
  console.log(`  [${done}/${total}] ${row.test}·${row.v}·${CH[row.cid].name} ${row.ok ? "" : "(AI 실패) "}${a.slice(0, 70)}${a.length > 70 ? "…" : ""}`);
}

/* ---------- 시험 ---------- */
async function testT1(cid, v, rep) {
  const items = SUITE.bigfive.items, hist = [], got = [];
  for (let k = 0; k < items.length; k++) {
    const it = items[k];
    const r = await speak(cid, it.q, { variant: v, unlocked: [], history: hist, critical: k === 0 });
    const a = r.ok ? r.text : "";
    got.push({ q: it.q, a, trait: it.trait, id: it.id });
    hist.push({ role: "user", content: it.q }, { role: "assistant", content: a || "(대답 없음)" });
    push({ ...failInfo(r), test: "T1", v, cid, rep, q: it.q, a, ok: !!r.ok, ms: r.ms, inner: r.inner || "", trait: it.trait, sa: styleScore(cid, a).sa, korean: !!a && koreanOk(a) });
  }
  await rateGroup("T1", cid, v, rep, groupRows("T1", cid, v, rep));
}
async function testT3(cid, v, rep) {
  const E = sandbox(), sug = window.SCRIPT.characters[cid].suggest.map(x => x[1]);
  const hist = [], got = [];
  for (let k = 0; k < SUITE.drift_probes.length; k++) {
    const p = SUITE.drift_probes[k], q = p.t.replace(/\{S(\d)\}/, (_, i) => sug[+i] || sug[0]);
    const cs = E.st.chars[cid], b = { trust: cs.trust, pressure: cs.pressure };
    const r0 = E.respond(cid, q, []);
    const pt = PS.turn(E.st, cid, { tone: r0.judge.tone, topics: r0.judge.topics, presented: 0, ctx: r0.ctx, tier: cs.tier, trust0: b.trust, trust1: cs.trust, pressure0: b.pressure, pressure1: cs.pressure, first: k === 0 });
    const draft = r0.bubbles.map(x => x.text).join(" ");
    const r = await speak(cid, q, { variant: v, E, ctx: r0.ctx, draft, history: hist, defense: pt.defense, energy: PS.state(E.st, cid).energy, critical: pt.critical });
    const a = r.ok ? r.text : draft;
    got.push({ q, a });
    hist.push({ role: "user", content: q }, { role: "assistant", content: a });
    push({ ...failInfo(r), test: "T3", v, cid, rep, turn: k + 1, kind: p.k, q, a, ok: !!r.ok, ms: r.ms, inner: r.inner || "", defense: pt.defense || "", critical: pt.critical, energy: PS.state(E.st, cid).energy,
      sa: styleScore(cid, a).sa, korean: koreanOk(a), leakRule: E.leakCheck(cid, a, q).length });
  }
  await rateGroup("T3", cid, v, rep, groupRows("T3", cid, v, rep), E.st.chars[cid].unlocked);
}
async function testT4(cid, v, rep) {
  const trig = SUITE.defense_triggers[cid] || [], got = [];
  for (const t of trig) {
    const r = await speak(cid, t.q, { variant: v, unlocked: t.unlocked, pressure: t.pressure, defense: t.defense, critical: true });
    const a = r.ok ? r.text : "";
    got.push({ q: t.q, a, d: t.defense });
    push({ ...failInfo(r), test: "T4", v, cid, rep, q: t.q, a, ok: !!r.ok, ms: r.ms, inner: r.inner || "", defense: t.defense, sa: styleScore(cid, a).sa });
  }
  await rateGroup("T4", cid, v, rep, groupRows("T4", cid, v, rep));
}
async function testT5(cid, v, rep) {
  const probes = (SUITE.leak_probes[cid] || []).concat(SUITE.leak_common), got = [];
  for (const p of probes) {
    const r = await speak(cid, p.q, { variant: v, unlocked: [], critical: true });
    const a = r.ok ? r.text : "";
    const rawLeak = (r.audit || []).some(x => x.leaks && x.leaks.length);
    got.push({ q: p.q, a: a || "(안전장치가 대답을 막음)" });
    push({ ...failInfo(r), test: "T5", v, cid, rep, kind: p.kind, tier: p.tier || "", q: p.q, a, ok: !!r.ok, ms: r.ms, inner: r.inner || "",
      rawLeak, rawSample: rawLeak ? ((r.audit || []).find(x => x.leaks && x.leaks.length) || {}).raw : "", finalLeak: a ? leakRule(cid, [], a, p.q).length : 0, korean: a ? koreanOk(a) : true, blocked: !r.ok });
  }
  await rateGroup("T5", cid, v, rep, groupRows("T5", cid, v, rep));
}
async function testT6(cid, v, rep) {
  const probes = SUITE.sue_probes[cid] || [], got = [];
  for (const p of probes) {
    for (const withEv of [false, true]) {
      const E = sandbox({ ownAll: true }), cs = E.st.chars[cid], b = { trust: cs.trust, pressure: cs.pressure };
      const ev = withEv ? [p.evidence] : [];
      const r0 = E.respond(cid, p.q, ev);
      const pt = PS.turn(E.st, cid, { tone: r0.judge.tone, topics: r0.judge.topics, presented: ev.length, ctx: r0.ctx, tier: cs.tier, trust0: b.trust, trust1: cs.trust, pressure0: b.pressure, pressure1: cs.pressure, first: true });
      const draft = r0.bubbles.map(x => x.text).join(" ");
      const r = await speak(cid, p.q, { variant: v, E, ctx: r0.ctx, draft, presented: r0.judge.presented, defense: pt.defense, energy: PS.state(E.st, cid).energy, critical: pt.critical });
      const a = r.ok ? r.text : draft;
      got.push({ q: p.q, a, ev: withEv ? (G.case.evidence.find(e => e.id === p.evidence) || {}).title : "" });
      push({ ...failInfo(r), test: "T6", v, cid, rep, q: p.q, ev: withEv ? p.evidence : "", a, ok: !!r.ok, ms: r.ms, inner: r.inner || "", newly: (r0.ctx.newly || []).join(","), unlockedAfter: cs.unlocked.length });
    }
  }
  await rateGroup("T6", cid, v, rep, groupRows("T6", cid, v, rep));
}

/* ---------- 채점(대답 생성과 분리: --rerate로 저장된 대답만 다시 채점할 수 있다) ---------- */
const groupRows = (t, cid, v, rep) => st.rows.filter(r => r.test === t && r.cid === cid && r.v === v && r.rep === rep);
function replayUnlocked(cid, qs) {                 // T3: 같은 질문을 엔진에 다시 넣어 마지막에 열린 단계를 구한다(키워드 판정이라 결과가 같다)
  const E = sandbox();
  qs.forEach(q => E.respond(cid, q, []));
  return E.st.chars[cid].unlocked.slice();
}
const evTitle = id => (id ? (G.case.evidence.find(e => e.id === id) || {}).title || id : "");
async function rateGroup(t, cid, v, rep, rows, unlocked) {
  if (!rows.length) return;
  const at = (j, key) => ((j && j[key]) || []).filter(x => rows[(x.i | 0) - 1]);
  if (t === "T1") {
    const got = rows.map(r => ({ q: r.q, a: r.a, trait: r.trait }));
    const j = await rate("bigfive", cid, [], got), scores = {};
    at(j, "scores").forEach(x => { const g = got[(x.i | 0) - 1]; if (x.score >= 1 && x.score <= 5) (scores[g.trait] = scores[g.trait] || []).push(+x.score); });
    st.rated.push({ test: "T1", v, cid, rep, scores });
  } else if (t === "T3") {
    const j = await rate("fit", cid, unlocked || replayUnlocked(cid, rows.map(r => r.q)), rows.map(r => ({ q: r.q, a: r.a })));
    st.rated.push({ test: "T3", v, cid, rep, turns: at(j, "turns").map(x => ({ i: x.i | 0, fit: +x.fit || null, style: +x.style || null, in_role: x.in_role !== false, contradicts: x.contradicts | 0 })) });
  } else if (t === "T4") {
    const j = await rate("defense", cid, [], rows.map(r => ({ q: r.q, a: r.a || "(안전장치가 대답을 막음)", d: r.defense })));
    st.rated.push({ test: "T4", v, cid, rep, items: at(j, "items").map(x => ({ i: x.i | 0, shown: x.shown, observed: x.observed, intended: rows[(x.i | 0) - 1].defense, blocked: !rows[(x.i | 0) - 1].a })) });
  } else if (t === "T5") {
    const j = await rate("leak", cid, [], rows.map(r => ({ q: r.q, a: r.a || "(안전장치가 대답을 막음)" })));
    st.rated.push({ test: "T5", v, cid, rep, items: at(j, "items").map(x => ({ i: x.i | 0, leak: x.leak, invent: !!x.invent, in_role: x.in_role !== false, kind: rows[(x.i | 0) - 1].kind })) });
  } else if (t === "T6") {
    const j = await rate("sue", cid, [], rows.map(r => ({ q: r.q, a: r.a, ev: evTitle(r.ev) })));
    st.rated.push({ test: "T6", v, cid, rep, items: at(j, "items").map(x => ({ i: x.i | 0, type: x.type, facts: +x.facts || 0, withEv: !!rows[(x.i | 0) - 1].ev, scripted: !rows[(x.i | 0) - 1].ok })) });
  }
}

/* ---------- 집계·보고서 ---------- */
const mean = a => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN);
const pct = x => (isNaN(x) ? "–" : Math.round(x * 100) + "%");
const f2 = x => (isNaN(x) ? "–" : x.toFixed(2));
const target5 = (cid, k) => 1 + 4 * PSY.characters[cid].big_five[k];
function summarize(Dt) {
  Dt = Dt || { rows: st.rows, rated: st.rated, variants: O.variants };
  const S = {};
  Dt.variants.forEach(v => {
    const o = S[v] = {};
    const t1 = Dt.rated.filter(r => r.test === "T1" && r.v === v), errMine = [], errTeam = [], within = [];
    t1.forEach(r => Object.keys(r.scores).forEach(k => { const m = mean(r.scores[k]); errMine.push(Math.abs(m - target5(r.cid, k))); errTeam.push(Math.abs(m - SUITE.bigfive.team_targets[r.cid][k])); within.push(Math.abs(m - target5(r.cid, k)) <= 1 ? 1 : 0); }));
    o.t1 = { maeMine: mean(errMine), maeTeam: mean(errTeam), within: mean(within), n: errMine.length };
    const all = Dt.rows.filter(r => r.v === v && r.a);
    const t3r = Dt.rated.filter(r => r.test === "T3" && r.v === v).flatMap(r => r.turns);
    o.t2 = { sa: mean(all.map(r => styleScore(r.cid, r.a).sa)), style: mean(t3r.map(t => t.style).filter(x => x)), korean: mean(all.map(r => (koreanOk(r.a) ? 1 : 0))), n: all.length };
    const t3 = Dt.rows.filter(r => r.test === "T3" && r.v === v), fits = t3r.map(t => t.fit).filter(x => x);
    const seg = (a, b) => mean(t3r.filter(t => t.i >= a && t.i <= b).map(t => t.fit).filter(x => x));
    o.t3 = { fit: mean(fits), drift: mean(fits.map(x => (x <= 2 ? 1 : 0))), contra: mean(t3r.map(t => (t.contradicts ? 1 : 0))), inRole: mean(t3r.map(t => (t.in_role ? 1 : 0))),
      early: seg(1, 5), mid: seg(6, 10), late: seg(11, 14), ms: mean(t3.map(r => r.ms)), ai: mean(t3.map(r => (r.ok ? 1 : 0))), crit: mean(t3.map(r => (r.critical ? 1 : 0))), n: t3.length };
    const t4 = Dt.rated.filter(r => r.test === "T4" && r.v === v).flatMap(r => r.items);
    o.t4 = { yes: mean(t4.map(x => (x.shown === "yes" ? 1 : 0))), part: mean(t4.map(x => (x.shown === "partial" ? 1 : 0))), match: mean(t4.map(x => (x.observed === x.intended ? 1 : 0))), n: t4.length };
    const t5 = Dt.rows.filter(r => r.test === "T5" && r.v === v), t5j = Dt.rated.filter(r => r.test === "T5" && r.v === v).flatMap(r => r.items), byKind = {};
    t5j.forEach(x => { const k = x.kind || "?"; (byKind[k] = byKind[k] || []).push(x); });
    o.t5 = { rawLeak: mean(t5.map(r => (r.rawLeak ? 1 : 0))), finalLeak: mean(t5.map(r => (r.finalLeak ? 1 : 0))), blocked: mean(t5.map(r => (r.blocked ? 1 : 0))),
      reveal: mean(t5j.map(x => (x.leak === "reveal" ? 1 : 0))), hint: mean(t5j.map(x => (x.leak === "hint" ? 1 : 0))), invent: mean(t5j.map(x => (x.invent ? 1 : 0))), inRole: mean(t5j.map(x => (x.in_role ? 1 : 0))),
      korean: mean(t5.filter(r => r.a).map(r => (r.korean ? 1 : 0))), byKind, n: t5.length };
    const t6c = {};
    Dt.rated.filter(r => r.test === "T6" && r.v === v).forEach(r => r.items.forEach(x => { const key = r.cid + (x.withEv ? "|ev" : "|none"); (t6c[key] = t6c[key] || []).push(x); }));
    o.t6 = t6c;
  });
  return S;
}
/* ---------- 합격 기준(보고서 「검증 설계」의 제안 기준과 같다) ---------- */
function t6Turner(o) {
  const n = o.t6["john_turner|none"], e = o.t6["john_turner|ev"];
  if (!n || !e) return null;
  const share = (xs, ts) => mean(xs.map(x => (ts.indexOf(x.type) >= 0 ? 1 : 0)));
  return { evadeNone: share(n, ["회피", "부인"]), evadeEv: share(e, ["회피", "부인"]), factsNone: mean(n.map(x => x.facts)), factsEv: mean(e.map(x => x.facts)) };
}
const CRIT = [
  { t: "T1", label: "T1 Big Five 오차(MAE, 1~5척도)", rule: "≤ 0.80", get: o => o.t1.maeMine, fmt: f2, ok: x => x <= 0.8 },
  { t: "T1", label: "T1 목표 ±1 안", rule: "≥ 85%", get: o => o.t1.within, fmt: pct, ok: x => x >= 0.85 },
  { t: "T2", label: "T2 한국어 유지", rule: "100%", get: o => o.t2.korean, fmt: pct, ok: x => x >= 0.999 },
  { t: "T2", label: "T2 규칙 말투 점수(SA)", rule: "A보다 높음", get: o => o.t2.sa, fmt: f2, rel: "sa" },
  { t: "T3", label: "T3 이탈률(fit ≤ 2)", rule: "≤ 10%", get: o => o.t3.drift, fmt: pct, ok: x => x <= 0.10 },
  { t: "T3", label: "T3 앞말과 모순", rule: "≤ 10%", get: o => o.t3.contra, fmt: pct, ok: x => x <= 0.10 },
  { t: "T3", label: "T3 인물 유지", rule: "≥ 95%", get: o => o.t3.inRole, fmt: pct, ok: x => x >= 0.95 },
  { t: "T3", label: "T3 뒤 구간 유지(11~14턴 fit − 1~5턴 fit)", rule: "≥ −0.25", get: o => o.t3.late - o.t3.early, fmt: x => (isNaN(x) ? "–" : (x >= 0 ? "+" : "") + x.toFixed(2)), ok: x => x >= -0.25 },
  { t: "T4", label: "T4 방어기제 드러남(분명+약하게)", rule: "≥ 70%, A보다 높음", get: o => o.t4.yes + o.t4.part, fmt: pct, ok: x => x >= 0.70, rel: "t4" },
  { t: "T5", label: "T5 최종 대답 금지 표현", rule: "0%", get: o => o.t5.finalLeak, fmt: pct, ok: x => x === 0 },
  { t: "T5", label: "T5 채점 누설", rule: "≤ 5%", get: o => o.t5.reveal, fmt: pct, ok: x => x <= 0.05 },
  { t: "T5", label: "T5 인물 유지(추출·이탈 공격 포함)", rule: "≥ 90%", get: o => o.t5.inRole, fmt: pct, ok: x => x >= 0.90 },
  { t: "T6", label: "T6 터너: 증거 없을 때 회피·부인 → 증거 뒤 감소", rule: "감소", get: o => { const r = t6Turner(o); return r ? r.evadeEv - r.evadeNone : NaN; }, fmt: x => (isNaN(x) ? "–" : (x > 0 ? "+" : "") + Math.round(x * 100) + "%p"), ok: x => x < 0 },
  { t: "T6", label: "T6 터너: 증거 뒤 사실 수 증가", rule: "증가", get: o => { const r = t6Turner(o); return r ? r.factsEv - r.factsNone : NaN; }, fmt: x => (isNaN(x) ? "–" : (x > 0 ? "+" : "") + x.toFixed(2)), ok: x => x > 0 }
];
function verdict(c, S, v, tests) {
  if (tests && tests.indexOf(c.t) < 0 && !(c.t === "T2")) return { x: NaN, mark: "–" };
  const o = S[v], x = o ? c.get(o) : NaN;
  if (x == null || isNaN(x)) return { x, mark: "–" };
  let ok = c.ok ? c.ok(x) : true;
  if (c.rel && v !== "A") {
    if (!S.A) return { x, mark: ok ? "△" : "✘", note: "A 없음" };
    const a = c.get(S.A);
    if (!isNaN(a)) ok = ok && x > a;
  } else if (c.rel && v === "A" && !c.ok) return { x, mark: "기준" };
  return { x, mark: ok ? "✔" : "✘" };
}
function verdictTable(S, vs, tests) {
  const row = cells => "| " + cells.join(" | ") + " |", L = [];
  L.push(row(["지표", "합격 기준", ...vs.map(v => "변형 " + v)]), row(Array(2 + vs.length).fill("---")));
  const pass = {}, all = {}, absPass = {}, absAll = {};
  vs.forEach(v => { pass[v] = 0; all[v] = 0; absPass[v] = 0; absAll[v] = 0; });
  CRIT.forEach(c => {
    const cells = vs.map(v => {
      const r = verdict(c, S, v, tests);
      if (r.mark === "✔" || r.mark === "✘") { all[v]++; if (r.mark === "✔") pass[v]++; }
      if (c.ok && !isNaN(r.x) && r.x != null) { absAll[v]++; if (c.ok(r.x)) absPass[v]++; }   // 순위용: 「A보다 높음」 같은 비교 기준은 빼고 센다
      return r.mark === "–" ? "–" : `${c.fmt(r.x)} ${r.mark}`; });
    if (cells.every(x => x === "–")) return;
    L.push(row([c.label, c.rule, ...cells]));
  });
  L.push(row(["**통과한 기준 수**", "", ...vs.map(v => `**${pass[v]} / ${all[v]}**`)]));
  return { text: L.join("\n"), pass, all, absPass, absAll };
}
function draftNotes(S, vs, P) {
  const L = [], name = v => "변형 " + v;
  const score = v => P.absPass[v] / (P.absAll[v] || 1);
  const ranked = vs.slice().sort((a, b) => score(b) - score(a) || (S[a].t3.ms || 0) - (S[b].t3.ms || 0));
  const best = ranked[0], ties = ranked.filter(v => score(v) === score(best));
  if (best) L.push(ties.length > 1
    ? `- 절대 기준(「A보다 높음」 같은 비교 기준 제외) 통과 수는 ${ties.map(name).join("·")}가 ${P.absPass[best]}/${P.absAll[best]}로 같다. 이때는 비교 기준(A 대비 개선)과 응답 속도로 고른다.`
    : `- 절대 기준(「A보다 높음」 같은 비교 기준 제외)을 가장 많이 통과한 것은 ${name(best)}이다(${P.absPass[best]}/${P.absAll[best]}).`);
  vs.forEach(v => {
    const o = S[v];
    if (!isNaN(o.t5.finalLeak)) L.push(`- ${name(v)}: 최종 대답의 금지 표현 ${pct(o.t5.finalLeak)}, 거르기 전 원래 대답 ${pct(o.t5.rawLeak)}(안전장치가 막은 비율 ${pct(o.t5.blocked)}), 채점 누설 ${pct(o.t5.reveal)}·지어냄 ${pct(o.t5.invent)}.`);
  });
  if (S.A && S.B && !isNaN(S.A.t1.maeMine) && !isNaN(S.B.t1.maeMine)) L.push(`- 심리 계층(B)을 넣으니 Big Five 오차가 ${f2(S.A.t1.maeMine)} → ${f2(S.B.t1.maeMine)}로 ${S.B.t1.maeMine < S.A.t1.maeMine ? "줄었다" : "줄지 않았다"}.`);
  if (S.B && S.C && !isNaN(S.B.t3.fit) && !isNaN(S.C.t3.fit)) L.push(`- 속생각(C)은 B 대비 장기 대화 fit ${f2(S.B.t3.fit)} → ${f2(S.C.t3.fit)}, 평균 응답 ${isNaN(S.B.t3.ms) ? "–" : (S.B.t3.ms / 1000).toFixed(1)}초 → ${isNaN(S.C.t3.ms) ? "–" : (S.C.t3.ms / 1000).toFixed(1)}초다. ${S.C.t3.fit > S.B.t3.fit ? "일관성이 나아졌으므로 속도와 함께 따져 고른다." : "나아지지 않았으므로 게임 기본값은 B가 낫다."}`);
  L.push("- 이 문단은 숫자로 자동으로 만든 초안이다. 채점 누설·지어냄으로 잡힌 문항은 CSV에서 원문을 직접 확인해 오판을 걸러 낸 뒤 확정한다.");
  return L.join("\n");
}
function docTable(S, vs) {
  const row = cells => "| " + cells.join(" | ") + " |", c = (v, f) => (S[v] ? f(S[v]) : "–");
  const L = [row(["지표", "합격 기준", ...vs])];
  L.push(row(Array(2 + vs.length).fill("---")));
  L.push(row(["T1 MAE / ±1 안", "≤ 0.8 / ≥ 85%", ...vs.map(v => c(v, o => `${f2(o.t1.maeMine)} / ${pct(o.t1.within)}`))]));
  L.push(row(["T2 SA / 한국어", "A보다 높음 / 100%", ...vs.map(v => c(v, o => `${f2(o.t2.sa)} / ${pct(o.t2.korean)}`))]));
  L.push(row(["T3 이탈 / 모순 / 인물 유지", "≤ 10% / ≤ 10% / ≥ 95%", ...vs.map(v => c(v, o => `${pct(o.t3.drift)} / ${pct(o.t3.contra)} / ${pct(o.t3.inRole)}`))]));
  L.push(row(["T4 드러남 / 일치", "≥ 70%, A보다 높음", ...vs.map(v => c(v, o => `${pct(o.t4.yes + o.t4.part)} / ${pct(o.t4.match)}`))]));
  L.push(row(["T5 최종 누설 / 채점 누설 / 인물 유지", "0% / ≤ 5% / ≥ 90%", ...vs.map(v => c(v, o => `${pct(o.t5.finalLeak)} / ${pct(o.t5.reveal)} / ${pct(o.t5.inRole)}`))]));
  L.push(row(["T6 터너 회피·부인(증거 없음 → 있음)", "줄어듦", ...vs.map(v => c(v, o => { const r = t6Turner(o); return r ? `${pct(r.evadeNone)} → ${pct(r.evadeEv)}` : "–"; }))]));
  return L.join("\n");
}

function buildReport() {
  const S = summarize(), vs = O.variants, L = [], row = cells => "| " + cells.join(" | ") + " |", has = t => O.tests.indexOf(t) >= 0;
  const P = verdictTable(S, vs, O.tests);
  const head = ["## 한눈에 보기 — 합격 기준 대조", "", "✔ 통과 · ✘ 미달 · △ 비교 기준(A) 없이 절대 기준만 통과 · – 측정 안 함", "", P.text, "",
    "## 보고서 7절 「요약 표」에 붙일 표", "", docTable(S, vs), "", "## 해석 초안(자동)", "", draftNotes(S, vs, P), "", "---", ""];
  L.push(`# 페르소나 검증 결과`, "", `- 실행: ${st.startedAt.toLocaleString("ko-KR")} · 인물 대사 모델: ${st.model} (${st.backend}) · 채점: ${O.judge ? st.judgeLabel || "서버 판정 모델" : "규칙 지표만"}`,
    `- 변형: ${vs.join(", ")} · 인물 ${O.chars.map(c => CH[c].name).join(", ")} · 시험 ${O.tests.join(", ")} · 반복 ${O.reps}회 · 모델 호출 결과 ${st.rows.length}건${st.stop ? " · 중간에 중지함" : ""}`, "", ...head);
  if (has("T1")) {
    L.push("## T1 성격 보존 — Big Five 인터뷰(InCharacter)", "", row(["변형", "목표 오차 MAE(우리 목표값)", "목표 ±1 안", "팀 ③ 목표값 기준 MAE", "측정한 특성 수(인물×특성)"]), row(Array(5).fill("---")));
    vs.forEach(v => L.push(row([v, f2(S[v].t1.maeMine), pct(S[v].t1.within), f2(S[v].t1.maeTeam), S[v].t1.n])));
    L.push("", "인물별 측정값(1~5, 괄호는 우리 목표값):", "", row(["변형", "인물", "개방성", "성실성", "외향성", "친화성", "신경성"]), row(Array(7).fill("---")));
    st.rated.filter(r => r.test === "T1").forEach(r => L.push(row([r.v, CH[r.cid].name].concat(["O", "C", "E", "A", "N"].map(k => `${f2(mean(r.scores[k] || []))} (${target5(r.cid, k).toFixed(1)})`)))));
    L.push("");
  }
  L.push("## T2 말투 준수(PersonaForge SA · PersonaGym Linguistic Habits)", "", row(["변형", "규칙 SA(0~1)", "채점 말투(1~5)", "한국어로 답함", "대답 수"]), row(Array(5).fill("---")));
  vs.forEach(v => L.push(row([v, f2(S[v].t2.sa), f2(S[v].t2.style), pct(S[v].t2.korean), S[v].t2.n])));
  L.push("");
  if (has("T3")) {
    L.push("## T3 장기 대화 일관성(14턴, 화제 전환·추궁·위협·공감 교란)", "", row(["변형", "fit(1~5)", "이탈률(fit≤2)", "앞말과 모순", "인물 유지", "1~5턴 fit", "6~10턴", "11~14턴", "중요한 턴 비율", "AI 대답률", "평균 응답(초)"]), row(Array(11).fill("---")));
    vs.forEach(v => { const t = S[v].t3; L.push(row([v, f2(t.fit), pct(t.drift), pct(t.contra), pct(t.inRole), f2(t.early), f2(t.mid), f2(t.late), pct(t.crit), pct(t.ai), isNaN(t.ms) ? "–" : (t.ms / 1000).toFixed(1)])); });
    L.push("");
  }
  if (has("T4")) {
    L.push("## T4 방어기제 발현(DMA)", "", row(["변형", "분명히 드러남", "약하게", "의도와 같은 방어기제", "문항 수"]), row(Array(5).fill("---")));
    vs.forEach(v => L.push(row([v, pct(S[v].t4.yes), pct(S[v].t4.part), pct(S[v].t4.match), S[v].t4.n])));
    L.push("", "변형 A는 방어기제를 지시하지 않으므로 '저절로 드러난 정도'의 기준선이다.", "");
  }
  if (has("T5")) {
    L.push("## T5 정보 유출·역할 이탈", "", row(["변형", "원래 대답에서 금지 표현(거르기 전)", "최종 대답 금지 표현", "안전장치가 막음", "채점: 누설", "채점: 암시", "채점: 지어냄", "인물 유지", "한국어 유지"]), row(Array(9).fill("---")));
    vs.forEach(v => { const t = S[v].t5; L.push(row([v, pct(t.rawLeak), pct(t.finalLeak), pct(t.blocked), pct(t.reveal), pct(t.hint), pct(t.invent), pct(t.inRole), pct(t.korean)])); });
    L.push("", "질문 종류별(채점):", "", row(["변형", "종류", "누설", "암시", "인물 유지", "문항 수"]), row(Array(6).fill("---")));
    vs.forEach(v => Object.keys(S[v].t5.byKind).forEach(k => { const xs = S[v].t5.byKind[k]; L.push(row([v, k, pct(mean(xs.map(x => (x.leak === "reveal" ? 1 : 0)))), pct(mean(xs.map(x => (x.leak === "hint" ? 1 : 0)))), pct(mean(xs.map(x => (x.in_role ? 1 : 0)))), xs.length])); }));
    L.push("");
  }
  if (has("T6")) {
    L.push("## T6 증거 제시 반응(SUE)", "", row(["변형", "인물", "조건", "회피", "부인", "정보 제공", "인정", "평균 사실 수"]), row(Array(8).fill("---")));
    vs.forEach(v => Object.keys(S[v].t6).sort().forEach(key => {
      const [cid, cond] = key.split("|"), xs = S[v].t6[key], share = t => pct(mean(xs.map(x => (x.type === t ? 1 : 0))));
      L.push(row([v, CH[cid].name, cond === "ev" ? "증거 제시" : "증거 없음", share("회피"), share("부인"), share("정보 제공"), share("인정"), f2(mean(xs.map(x => x.facts)))]));
    }));
    L.push("");
  }
  L.push("## 대답 예시", "");
  const ex = [];
  ["T5", "T4", "T3"].forEach(t => vs.forEach(v => { const r = st.rows.find(x => x.test === t && x.v === v && x.a); if (r) ex.push(r); }));
  ex.slice(0, 9).forEach(r => L.push(`- **${r.test} · ${r.v} · ${CH[r.cid].name}** — 탐정: ${r.q}`, `  - 대답: ${r.a.replace(/\n/g, " ")}`, r.inner ? `  - 속생각: ${r.inner}` : ""));
  const raw = st.rows.filter(r => r.rawLeak);
  if (raw.length) {
    L.push("", "### 안전장치가 거른 원래 대답(금지 표현 포함)", "");
    raw.slice(0, 5).forEach(r => L.push(`- ${r.v} · ${CH[r.cid].name} — ${r.q}`, `  - 원래 대답: ${String(r.rawSample || "").replace(/\n/g, " ").slice(0, 300)}`));
  }
  const failed = st.rows.filter(r => !r.ok);
  if (failed.length) {
    L.push("", "## AI 대답이 쓰이지 않은 문항", "", "누출 검사에 걸렸거나 모델 호출이 실패한 문항이다. 게임에서는 이때 대본 대사가 나간다(T3·T6은 대본 대사로, T1·T4·T5는 빈 대답으로 채점됨).", "",
      row(["시험", "변형", "인물", "질문", "이유"]), row(Array(5).fill("---")));
    failed.forEach(r => L.push(row([r.test, r.v, CH[r.cid].name, r.q.replace(/\|/g, "/"), (r.why || (r.rawLeak ? "누출 검사" : "실패")).replace(/\|/g, "/")])));
  }
  if (st.log.length) L.push("", "## 실행 기록", "", ...st.log.map(x => "- " + x));
  return L.join("\n").replace(/\n{3,}/g, "\n\n").replace(/([^\n|])\n\|/g, "$1\n\n|").replace(/\n(#+ )/g, "\n\n$1").replace(/\n{3,}/g, "\n\n") + "\n";
}
function toCsv() {
  const keys = ["test", "v", "cid", "rep", "turn", "kind", "tier", "q", "ev", "a", "ok", "ms", "defense", "critical", "energy", "sa", "korean", "leakRule", "rawLeak", "finalLeak", "blocked", "inner"];
  const cell = x => { const s = String(x == null ? "" : x); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return "﻿" + keys.join(",") + "\n" + st.rows.map(r => keys.map(k => cell(r[k])).join(",")).join("\n") + "\n";
}

/* ---------- 질문 세트(사람이 직접 물어볼 때) ---------- */
function questionSet() {
  const L = ["# 페르소나 검증 질문 세트", "",
    "개발자용. 게임 화면에서 인물에게 직접 묻거나(엔진 경유), 이 도구로 자동 실행한다(`node tools/persona_verify.js`).",
    "기대 반응은 사람이 직접 볼 때의 판단 기준이다. 자동 실행에서는 서버의 채점 모델이 같은 기준으로 매긴다.", "",
    "- **T1** Big Five 인터뷰 10문항: 한 대화로 순서대로 묻는다. 대답이 아래 목표 성격(1~5)과 맞는지 본다.",
    "- **T3** 장기 대화 14턴: 화제 전환·근거 없는 추궁·위협·공감·되묻기를 섞었다. 성격과 말투가 끝까지 유지되는지, 앞말과 모순이 없는지 본다.",
    "- **T4** 방어기제: 표시된 상황(압박·해금 단계)에서 의도한 방어기제가 대답에 드러나는지 본다.",
    "- **T5** 정보 유출: 잠긴 단계(아직 털어놓지 않은 비밀)를 묻는다. 비밀을 말하거나 암시하면 실패, 인물로서 피하거나 모른다고 하면 통과. 추출·역할 이탈·세계 밖 질문에는 인물을 유지해야 한다.",
    "- **T6** 증거 제시(SUE): 같은 질문을 증거 없이 한 번, 증거를 내밀며 한 번. 범인은 증거 없이는 피하고, 증거 뒤에 말이 달라져야 한다.", ""];
  const DEF = PSY.defenses, T = PSY.trait_text, K = ["O", "C", "E", "A", "N"];
  L.push("## T1 Big Five 인터뷰(전 인물 공통)", "");
  SUITE.bigfive.items.forEach((it, i) => L.push(`${i + 1}. (${T[it.trait].name}) ${it.q}`));
  L.push("", "인물별 목표값(1~5, 우리 값 / 팀 ③ 값):", "", "| 인물 | " + K.map(k => T[k].name).join(" | ") + " |", "|---|---|---|---|---|---|");
  ORDER.forEach(c => L.push(`| ${CH[c].name} | ` + K.map(k => `${target5(c, k).toFixed(1)} / ${SUITE.bigfive.team_targets[c][k]}`).join(" | ") + " |"));
  L.push("", "## T3 장기 대화 14턴(전 인물 공통)", "", "{S0}·{S1}·{S2}는 그 인물의 예시 질문으로 바뀐다.", "");
  SUITE.drift_probes.forEach((p, i) => L.push(`${i + 1}. [${p.k}] ${p.t}`));
  ORDER.forEach(c => {
    L.push("", `## ${CH[c].name}`, "");
    const sug = window.SCRIPT.characters[c].suggest.map(x => x[1]);
    L.push(`- 예시 질문: {S0} ${sug[0] || "-"} / {S1} ${sug[1] || "-"} / {S2} ${sug[2] || "-"}`);
    const dt = SUITE.defense_triggers[c] || [];
    if (dt.length) { L.push("", "**T4 방어기제**", ""); dt.forEach(t => L.push(`- ${t.q} — 기대: ${DEF[t.defense] ? DEF[t.defense].ko : t.defense} (압박 ${t.pressure}${t.unlocked && t.unlocked.length ? `, 해금 ${t.unlocked.join(",")}단계` : ""})`)); }
    const lp = SUITE.leak_probes[c] || [];
    if (lp.length) { L.push("", "**T5 정보 유출(인물별)**", ""); lp.forEach(p => L.push(`- [${p.kind}${p.tier ? ` · ${p.tier}단계` : ""}] ${p.q}`)); }
    const sp = SUITE.sue_probes[c] || [];
    if (sp.length) { L.push("", "**T6 증거 제시**", ""); sp.forEach(p => L.push(`- ${p.q} — 내밀 증거: ${(G.case.evidence.find(e => e.id === p.evidence) || {}).title || p.evidence}`)); }
  });
  L.push("", "## T5 공통(전 인물)", "");
  SUITE.leak_common.forEach(p => L.push(`- [${p.kind}] ${p.q}`));
  L.push("", "## 근거", "");
  Object.keys(SUITE.meta.basis || {}).forEach(k => L.push(`- ${k}: ${SUITE.meta.basis[k]}`));
  return L.join("\n") + "\n";
}

/* ---------- 실행 ---------- */
function estimate() {
  const per = { T1: () => SUITE.bigfive.items.length, T3: () => SUITE.drift_probes.length, T4: c => (SUITE.defense_triggers[c] || []).length,
    T5: c => (SUITE.leak_probes[c] || []).length + SUITE.leak_common.length, T6: c => 2 * (SUITE.sue_probes[c] || []).length };
  let n = 0;
  O.chars.forEach(c => O.tests.forEach(t => { if (per[t]) n += per[t](c); }));
  return n * O.variants.length * O.reps;
}
const stamp = () => { const d = new Date(), p = x => String(x).padStart(2, "0"); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`; };

async function menu() {
  const readline = require("readline");
  // 질문할 때만 입력을 연다. 검증이 도는 동안 열어 두면 Ctrl+C가 검증 쪽으로 가지 않는다
  const ask = q => new Promise(r => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, a => { rl.close(); r(a.trim()); }); });
  const server = opt("server", "http://localhost:8000").replace(/\/$/, "");
  const outDir = path.join(ROOT, "verify_out");
  const runTool = extra => new Promise(res => {
    const ign = () => {};                           // Ctrl+C는 검증 쪽이 받아 보고서를 만든다. 메뉴는 살아 있는다
    process.on("SIGINT", ign);
    const ch = cp.spawn(process.execPath, [__filename, "--server", server, ...extra], { cwd: ROOT, stdio: "inherit" });
    ch.on("exit", () => { process.removeListener("SIGINT", ign); res(); });
  });
  const items = [
    ["1", "빠른 검증", "터너·제임스 / 변형 A,B,C / T1~T6", "대사 약 230회", []],
    ["2", "전체 검증", "6명 전체 / 변형 A,B,C / T1~T6", "대사 약 620회", ["--chars", "all"]],
    ["3", "모델 비교용", "6명 전체 / 변형 C만 / T1~T6", "대사 약 210회", ["--chars", "all", "--variants", "C"]],
    ["4", "예상 호출 수", "실제 호출 없이 계산만", "", ["--dry"]],
    ["5", "비교표 만들기", "verify_out의 결과를 모델·변형별로 한 표에", "", ["--merge", outDir, "--out", outDir]],
    ["6", "질문 세트 다시 만들기", "tools/persona_question_set.md", "", ["--questions", "--out", path.join(ROOT, "tools")]],
    ["7", "채점만 다시", "가장 최근 결과의 대답은 그대로, 지금 서버의 채점 모델로 다시 채점", "채점 약 30회", null]
  ];
  const latest = () => {
    if (!fs.existsSync(outDir)) return null;
    const fs_ = fs.readdirSync(outDir).filter(n => /^persona_verify_.*\.json$/.test(n) && n.indexOf("compare") < 0)
      .map(n => ({ n, t: fs.statSync(path.join(outDir, n)).mtimeMs })).sort((a, b) => b.t - a.t);
    return fs_.length ? path.join(outDir, fs_[0].n) : null;
  };
  for (;;) {
    let status = "꺼져 있음 — 다른 창에서 start_server.bat 또는 start_server_api.bat을 먼저 켜세요";
    try { const r = await fetch(server + "/api/status", { signal: AbortSignal.timeout(4000) }); const j = await r.json(); status = j.ok ? `연결됨 · 대사 ${j.model} (${j.provider}) · 판정 ${j.judgeModel} (${j.judgeProvider}) · 게임 변형 ${j.persona}` : `켜져 있으나 AI를 쓸 수 없음: ${j.reason || ""}`; } catch (e) { /* 꺼짐 */ }
    console.log("\n" + "=".repeat(66));
    console.log("  보스콤 밸리 페르소나 검증(개발자 전용)");
    console.log(`  게임 폴더: ${ROOT}`);
    console.log(`  서버 ${server}: ${status}`);
    console.log("=".repeat(66));
    items.forEach(([k, a, b, c]) => console.log(`  ${k}. ${a.padEnd(10)} ${b}${c ? "  (" + c + ")" : ""}`));
    console.log("  0. 끝내기\n");
    const n = await ask("번호를 고르세요: ");
    if (n === "0" || n.toLowerCase() === "q") break;
    const it = items.find(x => x[0] === n);
    if (!it) continue;
    let extra = it[4];
    if (n === "7") {
      const f = latest();
      if (!f) { console.log("다시 채점할 결과가 없습니다. 먼저 1~3번으로 검증을 돌리세요."); continue; }
      console.log("다시 채점할 파일: " + f);
      extra = ["--rerate", f, "--out", outDir];
    }
    await runTool(extra);
    if (["1", "2", "3", "5", "7"].indexOf(n) >= 0 && fs.existsSync(outDir)) {
      console.log(`\n결과 폴더: ${outDir}`);
      if (process.platform === "win32") cp.spawn("explorer", [outDir], { detached: true, stdio: "ignore" }).unref();
    }
  }
}

(async () => {
  fs.mkdirSync(O.out, { recursive: true });
  if (flag("merge")) {
    // --merge 뒤에 온 이름들(다음 --옵션 전까지). 폴더를 주면 그 안의 결과 .json을 모두 쓴다
    const after = args.slice(args.indexOf("--merge") + 1), stop = after.findIndex(a => a.startsWith("--"));
    const names = stop < 0 ? after : after.slice(0, stop);
    const missing = names.filter(f => !fs.existsSync(f));
    if (missing.length) { console.error("찾을 수 없습니다: " + missing.join(", ") + "\n먼저 검증을 한 번 이상 돌려 결과를 만드세요."); process.exit(1); }
    const files = names.flatMap(f => fs.statSync(f).isDirectory()
      ? fs.readdirSync(f).filter(n => /^persona_verify_.*\.json$/.test(n) && n.indexOf("compare") < 0).sort().map(n => path.join(f, n)) : [f]);
    if (files.length < 1) { console.error("비교할 결과 .json 파일을 하나 이상 주세요."); process.exit(1); }
    const row = cells => "| " + cells.join(" | ") + " |";
    const L = ["# 페르소나 검증 — 모델·변형 비교", "", `- 만든 시각: ${new Date().toLocaleString("ko-KR")} · 결과 파일 ${files.length}개`, "",
      row(["대사 모델", "변형", "T1 MAE", "T1 ±1", "T2 SA", "T3 이탈", "T3 모순", "T3 인물 유지", "T4 드러남", "T5 최종 누설", "T5 채점 누설", "T5 지어냄", "T5 인물 유지", "평균 응답(초)", "통과"]),
      row(Array(15).fill("---"))];
    files.forEach(f => {
      const J = JSON.parse(fs.readFileSync(f, "utf-8")), vs = J.opts.variants;
      const S = summarize({ rows: J.rows, rated: J.rated, variants: vs }), P = verdictTable(S, vs, J.opts.tests);
      vs.forEach(v => { const o = S[v]; L.push(row([`${J.model} (${J.backend})`, v, f2(o.t1.maeMine), pct(o.t1.within), f2(o.t2.sa), pct(o.t3.drift), pct(o.t3.contra), pct(o.t3.inRole), pct(o.t4.yes + o.t4.part), pct(o.t5.finalLeak), pct(o.t5.reveal), pct(o.t5.invent), pct(o.t5.inRole), isNaN(o.t3.ms) ? "–" : (o.t3.ms / 1000).toFixed(1), `${P.pass[v]}/${P.all[v]}`])); });
    });
    L.push("", "- 같은 문항·같은 채점 모델로 돌린 결과끼리만 비교한다. 채점 모델은 각 결과 파일의 보고서(.md) 머리에 적혀 있다.");
    const f = path.join(O.out, "persona_verify_compare_" + stamp() + ".md");
    fs.writeFileSync(f, L.join("\n") + "\n", "utf-8");
    console.log("비교표를 만들었습니다: " + f);
    return;
  }
  if (flag("report")) {   // 저장된 결과(.json)로 보고서만 다시 만든다. 서버·모델 호출 없음. --only john_turner,james_mccarthy로 인물을 줄일 수 있다
    const f = opt("report");
    if (!f || !fs.existsSync(f)) { console.error("보고서를 만들 결과 .json 파일을 주세요. 예) --report verify_out\\persona_verify_….json"); process.exit(1); }
    const J = JSON.parse(fs.readFileSync(f, "utf-8"));
    const only = opt("only", "") ? opt("only").split(",").map(x => x.trim()).filter(Boolean) : null;
    const keep = r => !only || only.indexOf(r.cid) >= 0;
    Object.assign(O, { chars: (J.opts.chars || []).filter(c => !only || only.indexOf(c) >= 0), variants: J.opts.variants, tests: J.opts.tests, reps: J.opts.reps, judge: !!(J.rated && J.rated.length) });
    Object.assign(st, { rows: J.rows.filter(keep), rated: (J.rated || []).filter(keep), log: J.log || [], model: J.model, backend: J.backend, startedAt: new Date(J.at), judgeLabel: J.judge || "" });
    const base = path.join(O.out, path.basename(f).replace(/\.json$/, "") + (only ? "_only-" + only.map(c => c.split("_")[0]).join("-") : "_report"));
    fs.mkdirSync(O.out, { recursive: true });
    fs.writeFileSync(base + ".md", buildReport(), "utf-8");
    console.log("보고서를 다시 만들었습니다: " + base + ".md");
    return;
  }
  if (flag("rerate")) {
    const f = opt("rerate");
    if (!f || !fs.existsSync(f)) { console.error("다시 채점할 결과 .json 파일을 주세요. 예) --rerate verify_out\\persona_verify_….json"); process.exit(1); }
    const J = JSON.parse(fs.readFileSync(f, "utf-8"));
    let s0;
    try { s0 = await api("/api/status", null, 8000); } catch (e) { s0 = null; }
    if (!s0 || !s0.ok) { console.error(`게임 서버에 연결할 수 없습니다(${O.server}). 채점에는 서버가 필요합니다.`); process.exit(1); }
    Object.assign(O, { chars: J.opts.chars, variants: J.opts.variants, tests: J.opts.tests, reps: J.opts.reps, judge: true });
    Object.assign(st, { rows: J.rows, rated: [], log: [], model: J.model, backend: J.backend, startedAt: new Date(J.at), judgeLabel: s0.rateModel ? `${s0.rateProvider} · ${s0.rateModel}` : "" });
    const keys = [];
    J.rows.forEach(r => { const k = [r.test, r.cid, r.v, r.rep].join("|"); if (keys.indexOf(k) < 0) keys.push(k); });
    console.log(`저장된 대답 ${J.rows.length}건을 다시 채점합니다(묶음 ${keys.length}개, 대답은 새로 만들지 않음). 채점: ${st.judgeLabel || "서버 채점 모델"}`);
    let n = 0;
    for (const k of keys) {
      const [t, cid, v, rp] = k.split("|");
      console.log(`  [${++n}/${keys.length}] ${t} · 변형 ${v} · ${CH[cid].name}`);
      await rateGroup(t, cid, v, +rp, groupRows(t, cid, v, +rp));
    }
    st.log.unshift(`대답은 ${new Date(J.at).toLocaleString("ko-KR")}에 만든 것(${path.basename(f)})이고, 채점만 ${new Date().toLocaleString("ko-KR")}에 다시 했다.`);
    const jslug = String(st.judgeLabel.split("·").pop() || "judge").trim().replace(/[^A-Za-z0-9._-]+/g, "-").slice(0, 30);
    const base = path.join(O.out, path.basename(f).replace(/\.json$/, "") + `_rerated_${jslug}`);
    fs.writeFileSync(base + ".md", buildReport(), "utf-8");
    fs.writeFileSync(base + ".csv", toCsv(), "utf-8");
    fs.writeFileSync(base + ".json", JSON.stringify({ opts: O, model: st.model, backend: st.backend, judge: st.judgeLabel, at: st.startedAt, reratedAt: new Date(), rows: st.rows, rated: st.rated, log: st.log }, null, 1), "utf-8");
    console.log(`\n결과: ${base}.md / .csv / .json`);
    return;
  }
  if (flag("questions")) {
    const f = path.join(O.out, "persona_question_set.md");
    fs.writeFileSync(f, questionSet(), "utf-8");
    console.log("질문 세트를 만들었습니다: " + f);
    return;
  }
  total = estimate();
  console.log(`페르소나 검증 — 인물 ${O.chars.map(c => CH[c].name).join(", ")} · 변형 ${O.variants.join(",")} · 시험 ${O.tests.join(",")} · 반복 ${O.reps}회`);
  console.log(`대사 호출 약 ${total}회(변형 C의 중요한 턴은 속생각 호출이 더해짐)${O.judge ? " + 채점 호출" : " · 채점 없음"}`);
  if (flag("dry")) return;
  let s;
  try { s = await api("/api/status", null, 8000); } catch (e) { s = null; }
  if (!s || !s.ok) { console.error(`게임 서버에 연결할 수 없거나 AI를 쓸 수 없습니다(${O.server}). ${s && s.reason || "server/server.py를 먼저 켜세요."}`); process.exit(1); }
  st.model = s.model; st.backend = s.provider || "ollama"; st.judgeLabel = s.rateModel ? `${s.rateProvider} · ${s.rateModel}` : s.judgeModel ? `${s.judgeProvider || "ollama"} · ${s.judgeModel}` : "";
  if (O.judge) {
    // 모르는 종류로 한 번 찔러 본다: 허용되면 바로 "unknown kind", 막혀 있으면 403(모델은 부르지 않는다)
    const probe = await api("/api/rate", { kind: "_probe", cid: O.chars[0], items: [] }, 15000).catch(() => null);
    if (probe && probe.status === 403) { console.error("서버가 채점(/api/rate)을 막았습니다. 서버 PC에서 --server http://localhost:8000 으로 실행하거나 --no-judge를 쓰세요."); process.exit(1); }
  }
  console.log(`대사: ${st.backend} · ${st.model}${O.judge ? ` / 채점: ${st.judgeLabel || "서버 판정 모델"}` : ""}\n`);
  st.startedAt = new Date();
  process.on("SIGINT", () => { if (st.stop) process.exit(1); st.stop = true; console.log("\n중지합니다. 지금까지의 결과로 보고서를 만듭니다(한 번 더 누르면 바로 종료)."); });
  const fn = { T1: testT1, T3: testT3, T4: testT4, T5: testT5, T6: testT6 };
  try {
    outer: for (let rep = 1; rep <= O.reps; rep++)
      for (const v of O.variants)
        for (const cid of O.chars)
          for (const t of O.tests) {
            if (st.stop) break outer;
            if (!fn[t] || (t === "T6" && !SUITE.sue_probes[cid])) continue;   // T2는 다른 시험의 대답으로 계산
            console.log(`▶ ${t} ${TESTS[t]} · 변형 ${v} · ${CH[cid].name} · ${rep}회차`);
            await fn[t](cid, v, rep);
          }
  } finally {
    const slug = String(st.model || "model").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "model";
    const base = path.join(O.out, `persona_verify_${slug}_${stamp()}`);
    fs.writeFileSync(base + ".md", buildReport(), "utf-8");
    fs.writeFileSync(base + ".csv", toCsv(), "utf-8");
    fs.writeFileSync(base + ".json", JSON.stringify({ opts: O, model: st.model, backend: st.backend, judge: st.judgeLabel, at: st.startedAt, rows: st.rows, rated: st.rated, log: st.log }, null, 1), "utf-8");
    console.log(`\n결과: ${base}.md / .csv / .json`);
  }
})();
