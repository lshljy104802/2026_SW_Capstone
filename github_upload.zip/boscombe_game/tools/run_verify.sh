#!/usr/bin/env bash
# 보스콤 밸리 — 페르소나 검증(개발자 전용). 게임 서버를 먼저 켠 뒤 실행한다. 메뉴는 persona_verify.js 안에 있다.
cd "$(dirname "$0")/.." || exit 1
command -v node >/dev/null || { echo "Node.js 18 이상이 필요합니다: https://nodejs.org"; exit 1; }
node "$(dirname "$0")/persona_verify.js" --menu "$@"
