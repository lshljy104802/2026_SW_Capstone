@echo off
rem Boscombe Valley - persona verification (developer only).
rem Keep this file ASCII-only: Korean text in a .bat breaks cmd line parsing. The menu itself is in persona_verify.js.
chcp 65001 >nul
cd /d "%~dp0.."
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or later is required. Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
node "%~dp0persona_verify.js" --menu %*
pause
