// 아티팩트 안의 claude.use("sample")를 흉내 내 Claude 연결판을 시험한다
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const out = process.argv[2];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.addInitScript(() => {
    const fn = async (input, opts) => {
      window.__calls = (window.__calls || []).concat([{ input, opts }]);
      const last = input[input.length - 1].content;
      if (/대답하기 전의 속생각/.test(last)) return { text: "기분: 조심스럽다\n받아들임: 탐정을 의심한다\n속셈: 아는 것만 말한다", modelApplied: "claude-haiku-5-5" };
      if (/브리스톨/.test(last) && !/털어놓는다/.test(last)) return { text: "등기소에서 몰래 결혼했습니다.", modelApplied: "claude-haiku-5-5" };  // 누출 시도
      if (/털어놓는다/.test(last)) return { text: "*한참 망설이다가* (Claude) " + last.match(/털어놓는다.*?\n\s*- (.*)/s)[1].slice(0, 80), modelApplied: "claude-haiku-5-5" };
      return { text: "*고개를 끄덕인다* (Claude 자유 답변) 그 일이라면 제가 아는 대로 말씀드리지요.", modelApplied: "claude-haiku-5-5" };
    };
    fn.json = async (prompt) => /채점관/.test(prompt) ? ({ points: [true, /결혼/.test(prompt.split('플레이어가 쓴 동기')[1]), true], feedback: "탐정님은 협박과 딸을 지키려는 마음을 잘 짚었습니다. (Claude 채점)" }) : ({ topics: /주선|얘기해 볼/.test(prompt.split('탐정의 발화')[1]) ? ["T_PRISON_VISIT"] : [], tone: "neutral" });
    window.claude = { use: async n => n === "sample" ? fn : null };
  });
  await p.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html'));
  await p.waitForTimeout(600); await p.click('#btnStart');
  console.log('pill:', await p.textContent('#btnAiPill'));
  const say = async (c, q) => p.evaluate(async ([c, q]) => { window.__bv.openChar(c); await window.__bv.send(q); const L = window.__bv.E.st.logs[c]; return L.slice(-3).map(m => m.f + ': ' + m.t).join('\n'); }, [c, q]);
  console.log(await say('inspector_lestrade', '그 청년과 직접 얘기해 볼 수 있게 주선해 줄 수 있소?'));
  console.log(await say('inspector_lestrade', '오늘 날씨가 좋네요'));
  console.log(await say('james_mccarthy', '브리스톨에서 누구를 만났죠?'));
  const calls = await p.evaluate(() => window.__calls.map(c => ({ n: c.input.length, first: c.input[0].role, last: c.input[c.input.length - 1].role, opts: c.opts })));
  console.log('lastAI', JSON.stringify(await p.evaluate(() => window.__bv.ui.lastAI.speak)));
  console.log('calls', JSON.stringify(calls.slice(0, 2)));
  await p.screenshot({ path: out + '/40_claude_mode.png' });
  // 결론 채점(Claude) + 터너 반응
  const end = await p.evaluate(async () => { const b = window.__bv; b.E.st.flags.push('turner_summoned'); b.ui.picked = { culprit: 'john_turner', motive: '오래 협박당해서 딸을 지키려고 끝냈다', ev: [] }; await b.submitConclusion(); return { g: b.E.st.ending.report.grade, log: b.E.st.logs.john_turner.slice(-1)[0].t }; });
  console.log('grade', JSON.stringify(end));
  await p.screenshot({ path: out + '/41_claude_grade.png' });
  await p.click('footer [data-modal-close]');
  await p.click('#btnReset'); await p.waitForTimeout(100);
  console.log('reset modal:', await p.textContent('.modal header h2'));
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
