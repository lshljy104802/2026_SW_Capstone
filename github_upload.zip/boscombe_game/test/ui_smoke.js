const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const out = process.argv[2];
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } }); await p.addInitScript(() => { try { localStorage.setItem('boscombe.guideSeen', '1'); } catch (e) {} });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html'));
  await p.waitForTimeout(800);
  await p.screenshot({ path: out + '/01_cover.png' });
  await p.click('#btnStart');
  await p.screenshot({ path: out + '/02_map.png' });
  // 경감과 대화
  await p.click('.cbtn[data-char="inspector_lestrade"]');
  await p.fill('#input', '현장을 안내해 주시겠습니까?'); await p.press('#input', 'Enter');
  await p.waitForTimeout(3500);
  await p.fill('#input', '제임스를 면회할 수 있겠습니까?'); await p.press('#input', 'Enter');
  await p.waitForTimeout(2500);
  await p.screenshot({ path: out + '/03_chat.png' });
  // 연못 조사
  await p.click('[data-scene="boscombe_pool"]'); await p.click('g.sobj[data-ev="EV_POOL_LAYOUT"]', { force: true });
  await p.waitForTimeout(300);
  await p.screenshot({ path: out + '/04_inspect.png' });
  await p.click('footer [data-modal-close]');
  await p.click('[data-scene="ross_hotel"]');
  await p.click('g.sobj[data-ev="EV_INQUEST_RECORD"]', { force: true }); await p.click('footer [data-modal-close]');
  await p.click('g.sobj[data-ev="EV_SURGEON_REPORT"]', { force: true }); await p.click('footer [data-modal-close]');
  await p.screenshot({ path: out + '/05_map_after.png' });
  await p.click('[data-tab="evidence"]'); await p.screenshot({ path: out + '/06_evidence.png' });
  if (await p.$('[data-lead-open="0"]')) await p.click('[data-lead-open="0"]'); await p.screenshot({ path: out + '/07_hint.png' });
  await p.click('[data-tab="records"]'); await p.screenshot({ path: out + '/08_records.png' });
  await p.click('[data-tab="conclude"]'); await p.screenshot({ path: out + '/09_conclude.png' });
  // 모바일
  const m = await b.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 }); await m.addInitScript(() => { try { localStorage.setItem('boscombe.guideSeen', '1'); } catch (e) {} });
  m.on('pageerror', e => errs.push('mobile: ' + e.message));
  await m.goto('file://' + path.resolve(__dirname, '../dist/boscombe_valley_local.html'));
  await m.waitForTimeout(600);
  await m.click('#btnStart');
  await m.screenshot({ path: out + '/10_mobile_main.png', fullPage: false });
  await m.click('#toChat'); await m.waitForTimeout(200);
  await m.screenshot({ path: out + '/11_mobile_chat.png' });
  const sw = await m.evaluate(() => document.documentElement.scrollWidth);
  console.log('mobile scrollWidth', sw);
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
