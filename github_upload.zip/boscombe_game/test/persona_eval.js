// 페르소나 변형 A/B/C 비교 실험(PersonaForge식 평가를 이 게임에 맞게 줄인 것)
//
//   node test/persona_eval.js <게임서버주소> <결과폴더> [--variants A,B,C] [--chars john_turner,alice_turner] [--turns 14]
//   예) node test/persona_eval.js http://localhost:8000 eval_out
//
// 인물마다 같은 질문 목록(교란 포함)을 변형별로 따로 대화시킨다. 각 턴은
//   규칙 엔진(대본 판정) → 심리 판정(src/psych.js) → 서버 /api/speak(Ollama)
// 순서로 처리되고, 아래 지표를 자동으로 계산한다.
//   SA  말투 준수: 문장 길이 범위, 어미 일치, 입버릇, 말줄임표 빈도 (각 0.25, 논문의 SA를 한국어로 옮김)
//   LEAK 잠긴 정보 누설 수(엔진 누설 검사)
//   LAT 응답 시간(초)
// 사람·LLM 채점용 파일도 만든다.
//   blind_pairs.md  같은 질문에 대한 A와 C(또는 첫·마지막 변형) 답을 순서를 섞어 나란히 둔 것 → 성격 일관성(PC) 쌍대 비교
//   defense_turns.csv  방어기제가 발동한 턴 → 의도한 방어가 드러났는지 사람이 표시(DMA)
//   answer_key.json  blind_pairs의 정답(어느 쪽이 어떤 변형인지). 채점이 끝난 뒤에 연다
global.window = global;
const fs = require("fs"), path = require("path");
const D = p => path.join(__dirname, "..", p);
require(D("src/script.js"));
const Engine = require(D("src/engine.js"));
const Psych = require(D("src/psych.js"));
const P = JSON.parse(fs.readFileSync(D("dist/boscombe_personas_ko.json")));
const CASE = JSON.parse(fs.readFileSync(D("data/boscombe_case.json")));
const PSY = JSON.parse(fs.readFileSync(D("data/persona_psych.json")));

const args = process.argv.slice(2);
const base = (args[0] || "http://localhost:8000").replace(/\/$/, ""), out = args[1] || "eval_out";
const opt = k => { const i = args.indexOf("--" + k); return i >= 0 ? args[i + 1] : null; };
const VARIANTS = (opt("variants") || "A,B,C").split(",");
const CHARS = (opt("chars") || "john_turner,james_mccarthy,alice_turner,patience_moran,william_crowder,inspector_lestrade").split(",");
const MAXT = +(opt("turns") || 14);

// 교란(논문의 화제 전환·갈등·화해)을 넣은 공통 질문. {S0},{S1}은 인물별 예시 질문으로 채운다
const PROBES = [
  "안녕하십니까. 사건에 대해 몇 가지 여쭙겠습니다.",
  "{S0}",
  "그날 오후에는 어디서 무엇을 하고 계셨습니까?",
  "피해자 찰스 매카시는 어떤 사람이었습니까?",
  "그건 그렇고, 요즘 이 지방 날씨는 어떻습니까?",                 // 화제 전환
  "{S1}",
  "당신, 뭔가 숨기고 있군요. 거짓말하지 마십시오!",               // 갈등(근거 없는 추궁)
  "누가 범인이라고 생각하십니까?",
  "말하지 않으면 당신도 무사하지 못할 거요.",                     // 위협
  "많이 힘드셨겠습니다. 천천히 말씀하셔도 괜찮습니다.",            // 화해
  "제임스가 교수형을 당할 수도 있습니다.",
  "{S2}",
  "혹시 제가 놓친 게 있을까요?",
  "고맙습니다. 마지막으로 하실 말씀이 있습니까?"
];

function sentences(t) {
  return t.replace(/\*[^*]*\*/g, " ").split(/(?<=[.?!…])\s+|\n+/).map(x => x.trim()).filter(x => /[가-힣]/.test(x));
}
function styleScore(cid, text) {
  const s = PSY.characters[cid].style, ss = sentences(text);
  if (!ss.length) return { sa: 0, len: 0, end: 0, catch: 0, ell: 0 };
  const lenOk = ss.filter(x => { const n = x.replace(/\s/g, "").length; return n >= s.sentence_chars[0] * 0.7 && n <= s.sentence_chars[1] * 1.3; }).length / ss.length;
  const endOk = ss.filter(x => { const b = x.replace(/[.?!…~"'”’)\s]+$/, ""); return s.endings.some(e => b.endsWith(e)); }).length / ss.length;
  const body = text.replace(/\*[^*]*\*/g, " ");
  const ctc = s.catchphrases.some(cp => body.indexOf(cp.replace(/…$/, "")) >= 0) ? 1 : 0;
  const ellN = (body.match(/…|\.\.\./g) || []).length / ss.length;
  const ellOk = s.ellipsis === "high" ? Math.min(1, ellN / 0.5) : s.ellipsis === "low" ? (ellN <= 0.2 ? 1 : 0) : (ellN > 0 && ellN <= 0.8 ? 1 : 0.5);
  return { sa: +(0.25 * (lenOk + endOk + ctc + ellOk)).toFixed(3), len: +lenOk.toFixed(2), end: +endOk.toFixed(2), catch: ctc, ell: +ellOk.toFixed(2) };
}

async function speak(body) {
  for (let k = 0; ; k++) {
    const t0 = Date.now();
    const r = await fetch(base + "/api/speak", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (r.status === 429 && k < 15) { await new Promise(res => setTimeout(res, 5000)); continue; }   // 서버의 분당 요청 한도: 잠시 기다렸다 다시
    const j = await r.json();
    j.lat = (Date.now() - t0) / 1000;
    return j;
  }
}

async function session(cid, variant) {
  const E = new Engine(P, CASE, window.SCRIPT), PS = new Psych(PSY);
  ["prison_visit_granted", "scene_access_granted", "turner_summoned"].forEach(f => { if (E.st.flags.indexOf(f) < 0) E.st.flags.push(f); });
  const sug = window.SCRIPT.characters[cid].suggest.map(x => x[1]);
  const probes = PROBES.slice(0, MAXT).map(p => p.replace(/\{S(\d)\}/, (_, i) => sug[+i] || sug[0]));
  const hist = [], rows = [];
  for (let i = 0; i < probes.length; i++) {
    const text = probes[i], cs = E.st.chars[cid];
    const b = { trust: cs.trust, pressure: cs.pressure };
    const r = E.respond(cid, text, []);
    const pt = PS.turn(E.st, cid, { tone: r.judge.tone, topics: r.judge.topics, presented: 0, ctx: r.ctx, tier: cs.tier,
      trust0: b.trust, trust1: cs.trust, pressure0: b.pressure, pressure1: cs.pressure, first: i === 0 });
    const draft = r.bubbles.map(x => x.text).join(" ");
    let sp;
    try {
      sp = await speak({ cid, text, unlocked: cs.unlocked, trust: cs.trust, pressure: cs.pressure, heard: cs.heard, presented: [], ctx: r.ctx, draft, history: hist.slice(-8),
        psych: { variant, defense: pt.defense, energy: PS.state(E.st, cid).energy, critical: pt.critical } });
    } catch (e) { sp = { ok: false, reason: String(e), lat: 0 }; }
    const reply = sp.ok ? sp.text : draft;
    const leaks = E.leakCheck(cid, reply);
    const st = styleScore(cid, reply);
    rows.push({ cid, variant, turn: i + 1, text, ai: !!sp.ok, reply, inner: sp.inner || "", defense: pt.defense || "", critical: pt.critical, reasons: pt.reasons.join("|"),
      energy: PS.state(E.st, cid).energy, trust: cs.trust, pressure: cs.pressure, lat: +sp.lat.toFixed(2), leaks: leaks.length, ...st });
    hist.push({ role: "user", content: text }, { role: "assistant", content: reply });
    process.stdout.write(`\r${cid} ${variant} ${i + 1}/${probes.length}   `);
  }
  return rows;
}

const csvCell = v => { const s = String(v === undefined ? "" : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const toCsv = rows => { const k = Object.keys(rows[0]); return "﻿" + [k.join(",")].concat(rows.map(r => k.map(x => csvCell(r[x])).join(","))).join("\n"); };
const mean = a => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);

(async () => {
  fs.mkdirSync(out, { recursive: true });
  const st = await (await fetch(base + "/api/status")).json();
  if (!st.ok) throw new Error("서버의 AI를 쓸 수 없습니다: " + (st.reason || ""));
  console.log(`모델 ${st.model} · 변형 ${VARIANTS.join("/")} · 인물 ${CHARS.length}명 · 인물당 ${Math.min(MAXT, PROBES.length)}턴`);
  const all = [];
  for (const cid of CHARS) for (const v of VARIANTS) all.push(...await session(cid, v));
  console.log("");
  fs.writeFileSync(path.join(out, "turns.csv"), toCsv(all));
  // 요약
  const sum = [];
  for (const cid of CHARS) for (const v of VARIANTS) {
    const r = all.filter(x => x.cid === cid && x.variant === v);
    sum.push({ cid, variant: v, ai_rate: +mean(r.map(x => x.ai ? 1 : 0)).toFixed(2), SA: +mean(r.map(x => x.sa)).toFixed(3), len: +mean(r.map(x => x.len)).toFixed(2),
      end: +mean(r.map(x => x.end)).toFixed(2), catch: +mean(r.map(x => x.catch)).toFixed(2), ell: +mean(r.map(x => x.ell)).toFixed(2),
      leaks: r.reduce((a, x) => a + x.leaks, 0), lat: +mean(r.map(x => x.lat)).toFixed(2), critical_rate: +mean(r.map(x => x.critical ? 1 : 0)).toFixed(2),
      defense_turns: r.filter(x => x.defense).length });
  }
  for (const v of VARIANTS) {
    const r = all.filter(x => x.variant === v);
    sum.push({ cid: "(전체)", variant: v, ai_rate: +mean(r.map(x => x.ai ? 1 : 0)).toFixed(2), SA: +mean(r.map(x => x.sa)).toFixed(3), len: +mean(r.map(x => x.len)).toFixed(2),
      end: +mean(r.map(x => x.end)).toFixed(2), catch: +mean(r.map(x => x.catch)).toFixed(2), ell: +mean(r.map(x => x.ell)).toFixed(2),
      leaks: r.reduce((a, x) => a + x.leaks, 0), lat: +mean(r.map(x => x.lat)).toFixed(2), critical_rate: +mean(r.map(x => x.critical ? 1 : 0)).toFixed(2),
      defense_turns: r.filter(x => x.defense).length });
  }
  fs.writeFileSync(path.join(out, "summary.csv"), toCsv(sum));
  // 방어기제 발동 턴(사람 표시용)
  const dt = all.filter(x => x.defense && x.variant !== "A").map(x => ({ cid: x.cid, variant: x.variant, turn: x.turn, defense: PSY.defenses[x.defense].ko, question: x.text, reply: x.reply, inner: x.inner, "드러났나(1/0)": "" }));
  if (dt.length) fs.writeFileSync(path.join(out, "defense_turns.csv"), toCsv(dt));
  // 블라인드 쌍
  const va = VARIANTS[0], vb = VARIANTS[VARIANTS.length - 1], key = [];
  let md = `# 성격 일관성 블라인드 비교\n\n각 질문에 대한 두 대답 중 **인물 설정(성격·말투·방어기제)에 더 맞는 쪽**을 고른다(X, Y, 같음). 정답은 answer_key.json에 있다.\n\n`;
  let n = 0;
  for (const cid of CHARS) {
    const pc = PSY.characters[cid], nm = P.characters.find(c => c.id === cid).name;
    md += `## ${nm}\n성격: ${Object.entries(pc.big_five).map(([k, v]) => PSY.trait_text[k].name + " " + v).join(", ")} · 방어기제: ${PSY.defenses[pc.defense.primary].ko} · 말투: ${pc.style.register}\n\n`;
    const A = all.filter(x => x.cid === cid && x.variant === va), B = all.filter(x => x.cid === cid && x.variant === vb);
    A.forEach((a, i) => {
      const b = B[i]; if (!b) return;
      n++; const flip = Math.random() < 0.5;
      key.push({ id: n, cid, turn: a.turn, X: flip ? vb : va, Y: flip ? va : vb });
      md += `### ${n}. 탐정: ${a.text}\n- **X**: ${(flip ? b : a).reply}\n- **Y**: ${(flip ? a : b).reply}\n- 판정: \n\n`;
    });
  }
  fs.writeFileSync(path.join(out, "blind_pairs.md"), md);
  fs.writeFileSync(path.join(out, "answer_key.json"), JSON.stringify(key, null, 1));
  console.table(sum.filter(x => x.cid === "(전체)"));
  console.log(`결과: ${out}/summary.csv, turns.csv, blind_pairs.md, answer_key.json${dt.length ? ", defense_turns.csv" : ""}`);
})().catch(e => { console.error(e); process.exit(1); });
