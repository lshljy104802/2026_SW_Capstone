// 맞대기 보드를 쓰는 풀이를 실제 게임 화면(대본 모드, AI 없음)에서 재생하고 기록을 남긴다.
// node test/scenario_board.js [결과.json] [스크린샷 폴더]
// 보드의 착안·대질·내밀기는 화면에서 토큰을 눌러 실행하고, 추리는 착안의 질문에 답하는 말을 경감에게 직접 보고한다.
const { chromium } = require("playwright");
const path = require("path"), fs = require("fs");
(async () => {
  const out = process.argv[2] || "scenario_board.json", shots = process.argv[3] || null;
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = []; p.on("pageerror", e => errs.push(e.message));
  await p.route(/^https?:\/\//, r => r.abort());   // 웹 글꼴 등 바깥 요청은 막는다(오프라인에서도 같은 결과)
  await p.goto("file://" + path.resolve(__dirname, "../dist/boscombe_valley_local.html"), { waitUntil: "domcontentloaded" });
  await p.waitForTimeout(500);
  await p.click("#btnStart");
  const log = [];
  const state = () => p.evaluate(() => { const E = window.__bv.E; return { turn: E.st.turn, ded: E.st.deductions.slice(), flags: E.st.flags.slice(), owned: E.st.owned.length, hints: E.st.hintsUsed,
    tiers: Object.fromEntries(Object.keys(E.st.chars).map(k => [k, E.st.chars[k].tier])) }; });
  const closeModal = async () => { if (await p.$("#modal")) await p.evaluate(() => window.__bv.closeModal()); };
  const idle = () => p.waitForFunction(() => !window.__bv.ui.busy, null, { timeout: 20000 });
  async function say(cid, q, ev) {
    const before = await state();
    const r = await p.evaluate(async ([c, q, ev]) => {
      const B = window.__bv, n0 = B.E.st.logs[c].length;
      B.openChar(c); if (ev) B.ui.attach = ev; await B.send(q);
      const L = B.E.st.logs[c].slice(n0), cs = B.E.st.chars[c];
      return { reply: L.filter(m => m.f === "c").map(m => m.t), sys: L.filter(m => m.f === "s").map(m => m.t), trust: cs.trust, pressure: cs.pressure, tier: cs.tier };
    }, [cid, q, ev || null]);
    await closeModal();
    const after = await state();
    log.push({ act: "talk", cid, q, ev: ev || [], ...r, newDed: after.ded.filter(d => before.ded.indexOf(d) < 0), newFlags: after.flags.filter(f => before.flags.indexOf(f) < 0), state: after });
  }
  async function grab(ids) {
    for (const id of ids) { await p.evaluate(id => window.__bv.inspect(id), id); await closeModal(); }
    log.push({ act: "inspect", ids, state: await state() });
  }
  async function openBoard() {
    await closeModal();
    await p.evaluate(() => { const B = window.__bv; B.ui.tab = "map"; B.ui.fold.board = false; B.ui.bpick = null; B.renderAll(); });
  }
  async function readOutcome() {
    await p.waitForTimeout(150);
    const ins = await p.$("#modal .insight");
    if (ins) {
      const o = await p.evaluate(() => { const m = document.querySelector("#modal .insight"); const g = s => (m.querySelector(s) || {}).textContent || "";
        return { kind: g(".ins-kind"), title: g("h3"), text: g(".ins-text") || [...m.querySelectorAll(".ins-line")].map(x => x.textContent).join(" / "), ask: g(".ins-ask") || g(".ins-note"),
          go: (document.querySelector("#modal footer [data-char]") || {}).textContent || "" }; });
      await closeModal();
      return { ok: true, ...o };
    }
    const t = await p.evaluate(() => [...document.querySelectorAll("#toasts .toast")].map(x => x.textContent).pop() || "");
    return { ok: false, toast: t };
  }
  async function combine(a, c, shot) {
    await openBoard();
    await p.click(`#contact .ctok[data-bk="ev"][data-bid="${a}"]`);
    await p.click(`#contact .ctok[data-bk="ev"][data-bid="${c}"]`);
    if (shots && shot) { await p.waitForTimeout(250); await p.screenshot({ path: path.join(shots, shot) }); }
    const o = await readOutcome();
    log.push({ act: "combine", a, b: c, ...o, state: await state() });
  }
  async function confront(a, c) {
    await openBoard();
    await p.click(`#contact [data-bgrab="${a}"]`);
    await p.click(`#contact .ctok[data-bk="person"][data-bid="${c}"]`);
    const o = await readOutcome();
    log.push({ act: "confront", a, b: c, ...o, state: await state() });
  }
  async function present(ev, cid) {
    await openBoard();
    const before = await state();
    const n0 = await p.evaluate(c => window.__bv.E.st.logs[c].length, cid);
    await p.click(`#contact .ctok[data-bk="ev"][data-bid="${ev}"]`);
    await p.click(`#contact .ctok[data-bk="person"][data-bid="${cid}"]`);
    await p.waitForTimeout(300); await idle();
    const r = await p.evaluate(([c, n0]) => { const B = window.__bv, L = B.E.st.logs[c].slice(n0), cs = B.E.st.chars[c];
      return { q: (L.find(m => m.f === "p") || {}).t || "", reply: L.filter(m => m.f === "c").map(m => m.t), sys: L.filter(m => m.f === "s").map(m => m.t), trust: cs.trust, pressure: cs.pressure, tier: cs.tier }; }, [cid, n0]);
    await closeModal();
    const after = await state();
    log.push({ act: "present", ev, cid, ...r, newDed: after.ded.filter(d => before.ded.indexOf(d) < 0), newFlags: after.flags.filter(f => before.flags.indexOf(f) < 0), state: after });
  }

  const L = "inspector_lestrade", A = "alice_turner", J = "james_mccarthy", T = "john_turner";
  // 1) 사건 기록
  await grab(["EV_NEWS_REPORT", "EV_GROOM_APPOINTMENT", "EV_PATIENCE_DEPOSITION", "EV_INQUEST_RECORD", "EV_ARREST_REMARK", "EV_SURGEON_REPORT"]);
  // 2) 기록끼리 맞대기: 헛짚음 한 번, 그리고 '받아 마땅한 벌'
  await combine("EV_NEWS_REPORT", "EV_SURGEON_REPORT");
  await combine("EV_ARREST_REMARK", "EV_INQUEST_RECORD", "sb_01_insight.png");
  // 3) 경감: 면회·현장
  await say(L, "제임스를 면회할 수 있겠습니까?");
  await say(L, "현장을 안내해 주시겠습니까?");
  // 4) 착안이 짚은 사람(앨리스)에게
  await say(A, "제임스가 검시 심리에서 다툰 이유를 끝내 말하지 않았습니다. 짐작 가는 데가 있으십니까?");
  await say(A, "아버님 건강은 어떠신가요?");
  // 5) 제임스에게 그날 일을 듣고, 앨리스와 대질 → 다시 묻기
  await say(J, "그날 있었던 일을 처음부터 말해 주겠소?");
  await confront("william_crowder", "patience_moran");
  await confront(A, J);
  await say(J, "그날 있었던 일을 계속 말해 주시오.");
  await say(J, "그날 일을 끝까지 들려주시오.");
  await confront(A, J);
  await say(J, "앨리스 양은 다툰 이유에 자기가 관련돼 있을 거라더군요. 당신을 믿는다는 말도 전해 달랬소.");
  await say(J, "브리스톨에서는 누구와 계셨습니까? 들은 말은 비밀로 하겠습니다.");
  // 6) 현장 증거
  await grab(["EV_POOL_LAYOUT", "EV_BOOTS_HATHERLEY", "EV_RENT_RECORD", "EV_TRACKS_POOL", "EV_TIPTOE_TRACKS", "EV_BEECH_CIGAR", "EV_STONE_WEAPON", "EV_WOOD_PATH", "EV_VICTORIA_MAP", "EV_TURNER_GAIT", "EV_STAFF_REGISTER"]);
  if (shots) { await openBoard(); await p.evaluate(() => document.querySelector("#contact").scrollIntoView({ block: "start" })); await p.screenshot({ path: path.join(shots, "sb_02_board.png") }); }
  // 7) 착안 → 경감에게 보고(착안의 질문에 플레이어가 답한다)
  await combine("EV_SURGEON_REPORT", "EV_TIPTOE_TRACKS");
  await say(L, "등 뒤에서 내리쳤는데 상처가 머리 왼쪽에 있소. 범인은 왼손을 썼을 거요.");
  await combine("EV_TIPTOE_TRACKS", "EV_TRACKS_POOL");
  await say(L, "네모 장화는 오른발을 늘 덜 디뎠소. 범인은 오른쪽 다리를 저는 사람이오.");
  await say(L, "제임스의 발자국은 양발 깊이가 고르니, 범인의 발자국과는 다르오.");
  await combine("EV_INQUEST_RECORD", "EV_TIPTOE_TRACKS");
  await say(L, "같은 사람이 두 번 다녀갔소. 두 번째는 떨어뜨린 회색 망토를 되찾으러 돌아온 거요.");
  await combine("EV_STONE_WEAPON", "EV_VICTORIA_MAP");
  await combine("EV_INQUEST_RECORD", "EV_VICTORIA_MAP");
  await say(L, "매카시가 마지막에 말한 '아랫'은 지도에 있는 발라랫의 끝소리요. '발라랫의 아무개'를 말하려 한 거지.");
  await combine("EV_INQUEST_RECORD", "EV_NEWS_REPORT");
  await say(L, "쿠이는 호주 사람들이 쓰는 외침이오. 매카시는 호주 시절의 누군가를 부른 거요.");
  await combine("EV_INQUEST_RECORD", "EV_GROOM_APPOINTMENT");
  await say(L, "아버지는 아들이 돌아온 줄도 몰랐소. 3시 약속 상대는 아들이 아니었소.");
  // 8) 배제·좁히기(보드가 짚어 준 것)
  await combine("EV_STAFF_REGISTER", "EV_VICTORIA_MAP");
  await say(L, "크라우더는 이 지방 토박이라 발라랫과는 상관이 없소.");
  await combine("EV_POOL_LAYOUT", "EV_TRACKS_POOL");
  await say(L, "연못에 오려면 농장이나 영지를 지나야 하오. 범인은 이 지역 지리를 잘 아는 사람이오.");
  await combine("EV_TIPTOE_TRACKS", "EV_TURNER_GAIT", "sb_03_body.png");
  await say(L, "다리를 절고 손발이 큰 거구, 범인의 특징이 터너 씨와 들어맞소.");
  // 9) 터너: 결혼 반대 이유를 듣고 앨리스와 대질 → 지도를 보드에서 내밀기
  await say(T, "따님과 제임스의 결혼에는 어떤 입장이셨습니까?");
  await confront(A, T);
  if (shots) { await openBoard(); await p.evaluate(() => document.querySelector("#contact").scrollIntoView({ block: "start" })); await p.screenshot({ path: path.join(shots, "sb_04_links.png") }); }
  await present("EV_VICTORIA_MAP", T);
  await say(T, "그날 당신은 연못가 너도밤나무 뒤에서 시가를 피우며 매카시를 기다렸소.");
  await say(T, "따님에게는 알리지 않겠습니다.");
  // 10) 결론
  const end = await p.evaluate(() => window.__bv.E.accuse("john_turner", { text: "매카시가 호주 시절 과거를 빌미로 20년 동안 터너를 협박했고, 끝내 앨리스를 제임스와 결혼시키라고 요구했다. 터너는 딸을 지키려고 그를 죽였다." },
    ["EV_INQUEST_RECORD", "EV_TIPTOE_TRACKS", "EV_VICTORIA_MAP", "EV_TURNER_GAIT", "EV_STAFF_REGISTER"]));
  const contacts = await p.evaluate(() => { const s = window.__bv.E.st; return { insights: s.insights, contacts: { present: s.contacts.present, combine: s.contacts.combine, confront: s.contacts.confront } }; });
  log.push({ act: "accuse", ending: end.id, report: end.report });
  fs.writeFileSync(out, JSON.stringify({ log, contacts, errors: errs }, null, 1));
  console.log("엔딩", end.id, "추리", end.report.deductions + "/" + end.report.deductionsTotal, "배제", end.report.exclusions, "동기", end.report.grade.score + "/" + end.report.grade.max, "턴", end.at, "힌트", end.report.hintsUsed);
  console.log("착안", contacts.contacts.combine, "대질", contacts.contacts.confront, "내밀기", contacts.contacts.present, "errors", errs);
  await b.close();
})();
