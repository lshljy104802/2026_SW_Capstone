// 가짜 Ollama + 게임 서버를 띄운 상태에서 브라우저로 접속해 AI 모드를 시험한다
const { chromium } = require('playwright');
(async () => {
  const out = process.argv[2], url = process.argv[3];
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(url); await p.waitForTimeout(1200);
  await p.click('#btnStart');
  console.log('pill:', await p.textContent('#btnAiPill'));
  const say = async (c, q, ev) => p.evaluate(async ([c, q, ev]) => { window.__bv.openChar(c); if (ev) window.__bv.ui.attach = ev; await window.__bv.send(q); const L = window.__bv.E.st.logs[c]; return L.slice(-4).map(m => m.f + ': ' + m.t).join('\n'); }, [c, q, ev || null]);
  console.log(await say('inspector_lestrade', '그 청년과 직접 얘기해 볼 수 있게 주선해 줄 수 있소?'));
  console.log('james available:', await p.evaluate(() => window.__bv.E.available('james_mccarthy')));
  console.log(await say('inspector_lestrade', '오늘 날씨가 참 좋군요'));
  console.log(await say('james_mccarthy', '브리스톨에서 뭘 했는지 비밀로 해 드릴 테니 말해 보세요'));
  await p.screenshot({ path: out + '/30_ai_chat.png' });
  const end = await p.evaluate(async () => { const b = window.__bv; b.E.st.flags.push('turner_summoned'); b.ui.picked = { culprit: 'john_turner', motive: '오래 협박당해서 딸을 지키려고 끝냈다', ev: [] }; await b.submitConclusion(); return { g: b.E.st.ending.report.grade, log: b.E.st.logs.john_turner.slice(-1)[0].t }; });
  console.log('grade', JSON.stringify(end));
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
