"""가짜 API 서버: Anthropic(/v1/messages)과 OpenAI 호환(/v1/chat/completions) 형식을 받아
가짜 Ollama(test/mock_ollama.py)로 넘기고 그 답을 API 형식으로 돌려준다. 키 헤더가 있는지도 검사한다.

  python test/mock_ollama.py 11500 &
  python test/mock_api.py 11600 http://127.0.0.1:11500 &
  BOSCOMBE_API_KEY=test-key python server/server.py --provider custom --api-base http://127.0.0.1:11600/v1 --api-model mock-api
"""
import json
import sys
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 11600
OLLAMA = sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:11500"
KEY = "test-key"
SEEN = {"anthropic": 0, "openai": 0, "gateway": 0, "rejected_json_object": 0, "throttled": 0}
FIRST = {"done": False}


def ollama(messages, json_mode):
    body = {"model": "mock:1b", "messages": messages, "stream": False}
    if json_mode:
        body["format"] = "json"
    req = urllib.request.Request(OLLAMA + "/api/chat", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read())["message"]["content"]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def out(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        # HAI 게이트웨이 흉내: 모델 목록(OpenAI 형식)
        if self.path.startswith("/v1/gateway/models/"):
            if self.headers.get("Authorization") != "Bearer " + KEY:
                return self.out(401, {"error": {"message": "invalid key"}})
            return self.out(200, {"object": "list", "data": [{"id": i, "object": "model", "type": "llm"} for i in ("claude-haiku-5-5", "claude-sonnet-5-5", "gpt-6-luna", "gemini-3.7-flash")]})
        self.out(200, SEEN)

    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        if self.path.endswith("/messages"):
            if self.headers.get("x-api-key") != KEY or not self.headers.get("anthropic-version"):
                return self.out(401, {"type": "error", "error": {"message": "invalid x-api-key"}})
            if "system" in req and not isinstance(req["system"], str):
                return self.out(400, {"error": "system must be string"})
            if req["messages"][0]["role"] != "user":
                return self.out(400, {"error": "first message must be user"})
            msgs = ([{"role": "system", "content": req["system"]}] if req.get("system") else []) + req["messages"]
            text = ollama(msgs, "JSON" in req["messages"][-1]["content"])
            SEEN["anthropic"] += 1
            return self.out(200, {"content": [{"type": "text", "text": text}], "usage": {"input_tokens": 10, "output_tokens": 5}})
        if self.path == "/v1/gateway/chat/completions/":
            # HAI 게이트웨이 흉내: 끝 '/' 필수, json_object 미지원(400), 첫 호출은 분당 한도(429)
            if self.headers.get("Authorization") != "Bearer " + KEY:
                return self.out(401, {"error": {"message": "invalid key"}})
            if not FIRST["done"]:
                FIRST["done"] = True; SEEN["throttled"] += 1
                return self.out(429, {"error": {"message": "rate limited"}})
            if (req.get("response_format") or {}).get("type") == "json_object":
                SEEN["rejected_json_object"] += 1
                return self.out(400, {"error": {"type": "invalid_request_error", "message": "response_format json_object not supported"}})
            last = req["messages"][-1]["content"]
            text = ollama(req["messages"], "JSON 객체 하나만" in last)
            SEEN["gateway"] += 1
            return self.out(200, {"choices": [{"message": {"role": "assistant", "content": text}}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}, "billing": {"deducted_credit": 0.001}})
        if self.path.endswith("/chat/completions"):
            if self.headers.get("Authorization") != "Bearer " + KEY:
                return self.out(401, {"error": {"message": "invalid key"}})
            text = ollama(req["messages"], bool(req.get("response_format")))
            SEEN["openai"] += 1
            return self.out(200, {"choices": [{"message": {"role": "assistant", "content": text}}], "usage": {"prompt_tokens": 10, "completion_tokens": 5}})
        self.out(404, {"error": "not found"})


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", PORT), H).serve_forever()
