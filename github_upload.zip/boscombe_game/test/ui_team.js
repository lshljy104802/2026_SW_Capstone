// 팀 UI 틀 + 심리 페르소나 화면 확인: node test/ui_team.js <서버주소> <저장폴더>
const { chromium } = require('playwright');
(async () => {
  const base = process.argv[2], out = process.argv[3];
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1600, height: 900 } }); await p.addInitScript(() => { try { localStorage.setItem('boscombe.guideSeen', '1'); } catch (e) {} });
  const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto(base); await p.waitForTimeout(1200);
  await p.screenshot({ path: out + '/01_cover.png' });
  await p.click('#btnStart'); await p.waitForTimeout(300);
  await p.screenshot({ path: out + '/02_main.png' });
  // 연구 모드 켜기
  await p.fill('#input', '경감님, 이 사건을 어떻게 보십니까?'); await p.press('#input', 'Enter');
  await p.waitForFunction(() => !window.__bv.ui.busy, null, { timeout: 20000 });
  await p.fill('#input', '경감님이 틀렸소. 당신은 무능하오!'); await p.press('#input', 'Enter');
  await p.waitForFunction(() => !window.__bv.ui.busy, null, { timeout: 20000 });
  await p.waitForTimeout(800);
  await p.screenshot({ path: out + '/03_chat.png' });
  console.log('lastAI', JSON.stringify(await p.evaluate(() => window.__bv.ui.lastAI)));
  console.log('psy', JSON.stringify(await p.evaluate(() => window.__bv.E.st.psy)));
  await p.click('[data-tab="records"]'); await p.screenshot({ path: out + '/05_records.png' });
  await p.click('#btnSettings'); await p.waitForTimeout(200); await p.screenshot({ path: out + '/06_settings.png' });
  await p.click('[data-modal-close]');
  await p.setViewportSize({ width: 390, height: 844 }); await p.waitForTimeout(300);
  await p.screenshot({ path: out + '/07_mobile_main.png' });
  await p.click('#toChat'); await p.waitForTimeout(300);
  await p.screenshot({ path: out + '/08_mobile_chat.png' });
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
